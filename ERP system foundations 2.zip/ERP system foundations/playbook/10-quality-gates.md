---
id: P10
stage: HARDEN
audience: orchestrator, verifier, qa-reviewer
read_when: per phase (Definition of Done) and the final system hardening pass
produces: pass/fail evidence in progress/reviews/, a shippable system
depends_on: R6-ai-build-method, R8-testing-migration
---

# 10 · Quality Gates — Making "Done" Mean Something

The owner's #1 observed AI failure: **empty files, stub files, hallucinated APIs, and "done" claimed without proof.** This file is the defense. Its rules are enforced by commands (`playbook/templates/verify-phase.sh`) and by Claude Code hooks (`playbook/templates/settings-hooks.json`) — not by an agent's good intentions, which do not survive compaction.

## The one rule

> **A phase is `done` only when `verify-phase.sh <phase>` exits 0, run by the VERIFIER (never the builder), with evidence captured in `progress/reviews/<phase>.md`.**

If the script didn't run, the phase isn't done. If it ran and failed, the phase isn't done. There is no "done" by assertion.

## Definition of Done — the checklist the script enforces

| # | Gate | Command class | Fails when |
|---|---|---|---|
| 1 | **No stubs/placeholders** | grep for `TODO/FIXME/placeholder/not implemented/WIP/lorem/throw "not impl"` | any match in source |
| 2 | **No empty/tiny files** | `find … -size -20c` | any near-empty source file |
| 3 | **Format** | project formatter (`prettier`, `gofmt`, `black`…) | drift |
| 4 | **Lint** | linter incl. `no-unresolved`/`no-undef` | any error |
| 5 | **Typecheck / compile (strict)** | `tsc --noEmit` / `cargo check` / `mypy --strict` / build | any error — *this kills most hallucinated APIs* |
| 6 | **Orphan / dead-code** | `knip` / `ts-prune` / `depcheck` / lang equiv | any file not imported/reached |
| 7 | **Tests (unit + integration)** | test runner | any failure |
| 8 | **Diff coverage** | coverage on **changed lines** ≥ threshold (default 85%) | below threshold |
| 9 | **Locked-decision drift** | project-specific linter generated at G1 (see below) | code contradicts `locked-decisions.json` |
| 10 | **Dependency + secret audit** | `npm audit`/`pip-audit`/`osv-scanner` + `gitleaks` | high-sev vuln or secret |
| 11 | **Security scenario checks** | this module's `security/scenarios/*` test hooks | any scenario reproduces |
| 12 | **Smoke run** | execute the actual code path (script/CLI/HTTP call) | path errors or no-ops |
| 13 | **UI verify** (UI phases) | Playwright e2e (light+dark) + visual regression + axe WCAG 2.2 AA + Lighthouse (`playbook/12-…`) | e2e/visual/a11y/perf regression; `true # N/A` waiver for non-UI phases |

Green on all → evidence written → phase-log appended → git commit. Anything red → bounce back to the builder with the evidence.

For **money-touching modules** (ledger, tax, pricing, period-close), the DoD additionally requires the **golden-reference oracle** and the allocation sum-preservation property test to pass at zero-tolerance (`playbook/advanced/A2-formal-correctness.md`) — wire these into `verify.test`. For **UI modules**, the `design-qa-reviewer` screenshot review must be attached and clean (a separate agentic gate, recorded in `progress/reviews/`).

**Fail-closed.** `verify-phase.sh` runs the 12 config-driven gates (rows 3–13; dependency-audit and secret-scan are separate evidence blocks under one key) as **required** — a `verify.*` key that is empty/unconfigured **FAILS** the phase ("gate not configured"), it never silently skips. Rows 1–2 (stub/empty-file scans) are unconditional. To legitimately waive a gate for a phase, set an explicit no-op (`true # N/A: no UI in this module`) — silence is never a pass. The command strings are generated at G1: **copy the block matching the locked stack from `playbook/templates/verify-commands.map.json`** into `locked-decisions.json.verify`, then adapt paths/thresholds. G1 must also confirm the toolchain (jq, formatter, linter, typechecker, the named security/perf tools) is installed and on PATH.

## Anti-hallucination specifics (gate 5 + a discipline)

- **Confirm before you call.** Before using any external library symbol, the builder must confirm it exists in the *installed* version — grep the shipped `.d.ts`, `npm ls`, package source, or `python -c "import x; help(x.y)"`. Never from memory. Versions are pinned by the locked stack.
- **Exercise every API.** Every external call must be hit by a test that actually runs. "It compiles" is necessary, not sufficient — gate 12 requires real execution.
- **No unversioned installs.** A new dependency requires: confirm the package is real (registry check), pin the exact version + integrity hash, disable install scripts by default. (See `R6-ai-build-method`.)

## The drift linter (gate 9) — generated at G1

When decisions lock, generate a small project-specific check from `locked-decisions.json` and wire it into `verify.drift`. Examples:
- stack.db = `postgres` → fail if a `mysql`/`mongodb` driver import appears.
- tenancy = `single_tenant` → fail if `tenant_id` columns/filters proliferate (or the inverse for `multi_tenant`: fail if a tenant-scoped table lacks `tenant_id` + RLS).
- auth = `oidc` → fail if a hand-rolled password table/`bcrypt.compare` on a users table appears.
- api.external = `rest_openapi` → fail if a GraphQL schema is introduced without a decision change.

## Hooks make it compaction-proof

Ship `playbook/templates/settings-hooks.json` into the project's `.claude/settings.json`:
- **PreToolUse** → block edits to `project-config/locked-decisions.json` (force the gate + changelog path).
- **PreToolUse** → block writes outside the repo root and destructive shell (`rm -rf`, prod-credential writes).
- **Stop / pre-commit** → run the stub-scan + `verify-phase.sh`; refuse the commit if it fails.

Rules enforced by the harness survive context loss; rules that live only in prose do not.

## Test doctrine (what "tests" means here) — from R8

- **Posting engine / money paths:** property-based testing (`fast-check`/Hypothesis) modeled as a stateful machine, with invariants `sum(debit)==sum(credit)`, idempotent re-post, no mutation of posted documents. Mutation score ≥ 80–85% required here specifically.
- **Service boundaries / integrations:** consumer-driven contract tests (Pact + broker + `can-i-deploy`).
- **Performance:** `k6` against explicit envelopes (peak transaction volume × 3–5 headroom); treat month-end close as a first-class load profile.
- **Security in CI:** Semgrep (SAST) + Gitleaks (secrets) + Trivy/osv (SCA) + Checkov (IaC) blocking on PR; OWASP ZAP (DAST) nightly.
- **Coverage:** diff coverage 85% on changed lines (not repo-wide vanity coverage).

## Final hardening pass (the HARDEN stage)

After all modules are built, run `workflows/adversarial-review.js` across the whole system: a full security-scenario sweep (all of `security/scenarios/*`), a performance run against envelopes, a dependency/secret re-audit, and an owner-facing risk summary. Nothing ships to P11 until this is clean.

**NEXT:** `playbook/11-deployment-production.md` (once modules are built & hardened) or back to `playbook/09-build-loop.md` for the next module.
