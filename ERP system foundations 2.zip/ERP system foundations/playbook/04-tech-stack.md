---
id: P04
stage: DECIDE
audience: orchestrator, owner
read_when: tech-stack decision chunk (feeds project-config/decisions.html; locks at G1)
produces: stack.* keys in locked-decisions.json (PROPOSED until owner locks at G1)
depends_on: R3-tech-stacks, playbook/03-decision-file-spec.md
---

# 04 · Tech Stack — The DECIDE Chunk

Drafts the **stack.\*** section of the decision file (`playbook/03-decision-file-spec.md`) for the owner to approve at gate G1. Every choice below is a recommendation, not a decision. Nothing in this file may be treated as locked until it appears, checksummed, in `project-config/locked-decisions.json`. **Never build against this file directly — build against the locked JSON.**

Full reasoning and sources: research track `R3-tech-stacks`. This file is the operating summary; do not re-derive the analysis, just apply it.

## How this chunk works

1. Orchestrator renders the table in §1 into the tech-stack panel of `decisions.html`, each row tagged **PROPOSED**, with one-line "why" and the deviation triggers from §3.
2. Owner accepts defaults wholesale, or picks a deviation row from §3 per layer.
3. At G1, the accepted values are written verbatim into `locked-decisions.json.stack` (schema: `playbook/templates/locked-decisions.schema.json`), checksummed, and become the drift-linter's ground truth (`10-quality-gates.md` gate 9).
4. Versions are point-in-time. Before rendering §1 into the decision file, re-check fast-moving version numbers **(verify via playbook/01-freshness-check.md)** — do not hand the owner stale version strings.

---

## 1. PROPOSED default stack

**PROPOSED** — the whole-stack default an agent should reach for absent a specific reason to deviate (§3).

| Layer | Choice | Version (verify via 01-freshness-check.md) | `locked-decisions.json` key |
|---|---|---|---|
| Language | TypeScript | 6.0 GA (~2026-03); 7.0 (Go-based rewrite) in RC as of mid-2026 (verify via 01-freshness-check.md) | `stack.language` |
| Runtime | Node.js | latest Active LTS (Node 24 as of 2026-07; Node 26 LTS ~Oct 2026) | `stack.runtime` |
| Backend framework | NestJS | v11.1.x (watch v12 GA, ESM-only, ~Q3 2026) | `stack.backend_framework` |
| ORM | Prisma | v7.x (pure-TS client, no Rust engine) | `stack.orm` |
| Database | PostgreSQL | 18.x, RLS on, partitioned ledger/audit tables | `stack.db` |
| Internal API | tRPC | current stable | `stack.internal_api` |
| External/partner API | REST + OpenAPI 3.1 | — | `stack.external_api` |
| Frontend | Next.js (App Router) + React | Next.js 16.2.x, React 19.2 | `stack.frontend` |
| Validation | Zod (shared front/back schema) | current stable | `stack.validation` |
| Jobs/cache | Redis + BullMQ; escalate to Temporal.io only for multi-day resumable workflows | current stable | `stack.jobs` |
| Search | Postgres FTS (`tsvector`/GIN); escalate to Meilisearch/Typesense only once faceted/fuzzy UX outgrows it | — | *(not a schema key — record as a build note)* |

**Why this exact combination:** one language end-to-end (TypeScript) minimizes the context-switch surface where an agent's type/idiom model drifts between frontend and backend; financial-transaction correctness lives in the database (Postgres ACID + RLS), not in application code an agent could plausibly forget to check; every layer here has enough 2025–2026 training-data density that Claude's first-draft code reliably compiles and is idiomatic. See `core/architecture.md § The Double-Entry Posting Engine` for what the posting path must guarantee regardless of stack.

## 2. Why PostgreSQL + RLS is the ERP default (non-negotiable unless §3 fires)

Each reason below is independently sufficient; together they are why this is a default, not a preference:

1. **ACID transactions up to SERIALIZABLE** — required for double-entry posting, inventory reservation, and multi-step order/invoice workflows that must never partially commit. See `core/architecture.md § Concurrency`.
2. **Row-Level Security enforces tenant isolation in the database itself** (`tenant_id = current_setting('app.tenant_id')::uuid`) — an application-code bug cannot leak Company A's data into Company B's report. This is the default multi-tenant isolation pattern; see `core/architecture.md § Multi-Tenancy`. **House rule:** `tenant_id` must be the leading column of every relevant index — RLS predicates without it degrade ~2 orders of magnitude. Enforce this in migration review, not as a footnote.
3. **JSONB** models long-tail/variant fields (per-tenant custom fields, flexible line-item attributes) without a migration per tenant, while the core schema stays relational and typed.
4. **Declarative partitioning** for append-heavy tables (ledger entries, audit logs, stock movements) — see `core/architecture.md § Audit Immutability`.
5. **One database, one operational surface.** ERPs are relational-by-nature (orders → lines → shipments → invoices → payments, all FK-linked); a single strongly-consistent store is simpler to back up, audit, and reason about than polyglot persistence, which most ERPs don't need below hyperscale volume.

Add Redis only for cache/session/rate-limit; add a dedicated search engine only once Postgres FTS is insufficient. Neither is a system of record for financial state.

## 3. Decision matrices — when to deviate from the default

Score each candidate against the same three axes the research used: **AI-buildability** (training-data density, first-draft compile rate), **typing strength** (does the type system catch ERP-class bugs — wrong currency rounding, wrong tenant scope, null GL account — at compile time), **transactional-integrity fit** (native ACID story, decimal/money handling, isolation levels).

### Language / runtime

| Signal | Deviate to | Trade-off |
|---|---|---|
| Org is Microsoft/Windows shop, needs on-prem AD/SQL Server, wants native `decimal` | .NET 10 + EF Core, C# 14 | Strong typing + native decimal; smaller AI-buildability edge than TS, but excellent enterprise fit |
| Org is existing Java/Spring enterprise (bank, insurer, SAP/Oracle integrations) | Spring Boot (Kotlin or Java) | Best-in-class transaction management (`@Transactional`); more boilerplate, slower iteration |
| Need one isolated, extremely high-throughput, high-integrity service (ledger posting kernel, payment-settlement engine) alongside the main TS app | Go + sqlc, or Rust + Axum + SQLx for the single narrowest correctness-critical component | Sacrifices one-language-everywhere for compile-verified SQL / zero ORM magic; not a whole-ERP default |
| Fast internal back-office CRUD tooling, not the system of record | Django + DRF prototype | Fastest bootstrap; migrate the financial core to the primary stack once validated — never let this become the ledger |

### Backend framework

| Signal | Deviate to | Trade-off |
|---|---|---|
| Deploying primarily to edge/serverless (Cloudflare Workers, Vercel Edge) with tight cold-start budgets | Hono (or lighter TS framework) instead of NestJS | Loses NestJS's rigid module/DI template — the "template rigidity" that keeps a multi-session agent build pattern-matching consistently; accept only if cold-start truly dominates |
| Already deviated to Go for a narrow service (see above) | Go stdlib + sqlc + chi/net-http | Zero framework magic — most hallucination-resistant option, but too much boilerplate for a whole ERP UI+API surface |

### ORM / query layer

| Signal | Deviate to | Trade-off |
|---|---|---|
| Deploying to edge/serverless | Drizzle ORM instead of Prisma | ~7.4KB gzip, SQL-shaped API, wins cold-start; less DX polish for migrations than Prisma 7 |
| Any financial-posting write-path, regardless of ORM choice | Hand-written, reviewed raw SQL (`$queryRaw` / `$transaction` in Prisma, or an equivalent) | **House rule, not optional:** never let the ORM auto-generate SQL for a write that touches the ledger. An agent (and a human) must be able to audit exactly what hits `core/architecture.md § The Double-Entry Posting Engine` as literal SQL |
| Deviated to Go for the ledger kernel | sqlc (generates typed Go from hand-written SQL, verified at generation time) | Strongest correctness guarantee of any layer surveyed — no query-builder abstraction to get subtly wrong |

### Database

| Signal | Deviate to | Trade-off |
|---|---|---|
| Genuinely need multiple specialized stores at hyperscale volume (rare for typical ERP scale) | Add a purpose-built store alongside Postgres (e.g. a dedicated search engine, a time-series store) | Only after Postgres FTS/partitioning is demonstrably insufficient — never on day one |
| Legacy migration constraint forces a specific existing RDBMS | Document the deviation and re-derive the RLS-equivalent tenant-isolation pattern for that engine | Loses native RLS; must build equivalent isolation in the app layer with extra scrutiny at security review |

### API style

| Signal | Deviate to | Trade-off |
|---|---|---|
| Single-repo, single-language TS monorepo, no third-party callers yet | tRPC internally (the PROPOSED default) | Zero schema-drift class of bug; breaks down the moment a mobile app or non-TS caller appears |
| Any external caller: partner integration, accounting export, bank feed, e-commerce connector | REST + OpenAPI 3.1 (mandatory regardless of internal choice) | Every real ERP eventually needs this — build it as the public boundary from the start, not as an afterthought |
| Multi-team org needing a federated data graph across many services/teams | GraphQL (Apollo/Federation) at the aggregation layer only, tRPC/REST underneath | Adds resolver N+1 and schema-governance complexity rarely justified for a single-product ERP — don't default to this |

### Frontend

| Signal | Deviate to | Trade-off |
|---|---|---|
| 30+ near-identical CRUD screens across the module set | Schema-driven/server-driven UI renderer on top of Next.js + React (still the default) | Reduces near-duplicate screens an agent must generate and keep in sync; not needed for MVP |
| Complex interactive grids (the bread-and-butter ERP data table) | TanStack Query + TanStack Table alongside Next.js | This is already part of the default, not a deviation — call out explicitly in the SPEC.md for any module with heavy tabular UI |

## 4. Background jobs, cache, search — sizing rule

- **Queue-shaped** work (send email, generate a PDF invoice, process an upload, nightly batch report) → BullMQ on Redis. Default.
- **Process-shaped** work (multi-day approval-and-payment-release, month-end close orchestration that must survive crashes mid-flight and resume exactly) → escalate to Temporal.io *in addition to* the queue. Do not default to Temporal for simple CRUD side-effects — it is real infrastructure to operate.
- **Cache** → Redis, narrowly: sessions, rate limiting, read-through cache for reference data. Never a system of record for financial state.
- **Search** → Postgres FTS first; escalate to Meilisearch/Typesense only once faceted/fuzzy requirements exceed it.

## 5. What gets written to `locked-decisions.json` at G1

Orchestrator writes exactly these keys under `stack` (schema: `playbook/templates/locked-decisions.schema.json`) once the owner has chosen (defaults or deviations) in `decisions.html`:

```json
"stack": {
  "language": "typescript",
  "runtime": "node-24-lts",
  "backend_framework": "nestjs-11",
  "orm": "prisma-7",
  "db": "postgresql-18-rls",
  "internal_api": "trpc",
  "external_api": "rest-openapi-3.1",
  "frontend": "nextjs-16-react-19",
  "validation": "zod",
  "jobs": "redis-bullmq"
}
```

Every value here is **PROPOSED** until this block is actually inside a checksummed `locked-decisions.json` written at G1 — do not let a subagent treat a draft `decisions.html` value as locked.

## 6. What this chunk feeds downstream

- `10-quality-gates.md` gate 9 (drift linter) is generated from these exact `stack.*` values — e.g. `stack.db` containing `postgresql` fails the build if a `mysql`/`mongodb` driver import ever appears.
- `09-build-loop.md` SPEC.md template cites the locked `stack.*` keys as "which locked decisions apply" for every module.
- `05-architecture-deployment.md` assumes this stack when reasoning about deployment topology and tenancy — do not re-decide the language/DB there.

**NEXT:** `playbook/05-architecture-deployment.md` (architecture/tenancy/deployment decision chunk — same G1 lock).
