---
id: SEC-CHK-DEPLOY
stage: SHIP
audience: security-reviewer, verifier
read_when: before gate G2 (production deploy approval), playbook/11-deployment-production.md
depends_on: playbook/06-security-foundations.md, playbook/10-quality-gates.md
produces: pass/fail evidence gating G2
---

# Security checklist — pre-production deploy

Run once, whole-system, after `playbook/10-quality-gates.md`'s HARDEN pass is clean and before the owner is asked to approve G2. This is the last check before real money/data flows.

## Transport & infrastructure

- [ ] TLS 1.3 enforced on every public endpoint; HSTS on; weak cipher suites disabled.
- [ ] mTLS between internal services (or documented exception with owner sign-off).
- [ ] No debug endpoints, verbose stack traces, or default credentials reachable in the production config.
- [ ] Cloud/IaC config scanned (Checkov/tfsec) clean of high-severity misconfiguration.

## Secrets & keys

- [ ] No secret exists in source, image layers, or CI logs — final gitleaks/trufflehog sweep on the release artifact.
- [ ] Production secrets live in the secrets manager/KMS, injected at runtime, not baked into images.
- [ ] Envelope encryption confirmed live: per-tenant DEKs present, KEK held in KMS/HSM with automated rotation configured (not manual).
- [ ] BYOK path tested end-to-end if any locked tenant requires it.

## Audit & compliance

- [ ] Audit log hash-chain verifier job runs and reports clean on the pre-prod dataset.
- [ ] WORM/Object Lock retention policy is active on the audit archive and matches the locked jurisdictional period.
- [ ] `locked-decisions.json.security.compliance` obligations (e.g. SOC2, GDPR, PCI-DSS) each have a mapped control verified — cross-check against `core/security.md § Compliance by Region`.

## SDLC gate evidence

- [ ] SAST, SCA, secret-scan, IaC-scan all green on the release commit (not an older commit).
- [ ] SBOM generated and stored for this release.
- [ ] Dependencies pinned with lockfile + integrity hashes; no floating versions.
- [ ] DAST run (staging) completed with no unresolved high findings.

## Operational readiness

- [ ] Break-glass/emergency-access procedure documented and itself logged to the audit log.
- [ ] Backup/DR tier matches `locked-decisions.json.architecture.backup_tier`; a restore has been test-run.
- [ ] Per-tenant rate/resource quotas active (API, query timeout, background jobs) to contain a noisy tenant or runaway AI-copilot loop.
- [ ] Incident response contact/escalation path defined for a suspected breach or audit-log tamper alert.

## Result

All boxes checked → write evidence to `progress/reviews/deploy-security.md` → raise gate **G2** per `00-START-HERE.md §3` with this file attached as the evidence artifact. Any unchecked box blocks G2.
