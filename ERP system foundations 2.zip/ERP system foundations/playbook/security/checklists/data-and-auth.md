---
id: SEC-CHK-DATA-AUTH
stage: BUILD
audience: security-reviewer, builder
read_when: any module touching the data model, tenant isolation, authentication, or authorization
depends_on: playbook/06-security-foundations.md §2-§4
produces: pass/fail evidence feeding gate 11 of playbook/10-quality-gates.md
---

# Security checklist — data model, tenancy, authn/authz

Deeper checklist for foundation-tier modules (auth/identity, tenant model, ledger core) that `build.md` treats as a subset of. Run this in full for these modules; treat as a Gk-candidate (flag for owner gate per `00-START-HERE.md §3`).

## Schema & migrations

- [ ] Every table carrying tenant-owned data has a `tenant_id` column (multi-tenant builds).
- [ ] RLS policy exists for every such table; `FORCE ROW LEVEL SECURITY` set; both verified by the CI drift check, not by eyeballing.
- [ ] Migration does not run as `BYPASSRLS`/superuser in the app's normal deploy path (only in a dedicated, logged migration job).
- [ ] No table added without a corresponding entry in the RLS coverage test.

## Authentication

- [ ] Auth is OIDC against the locked IdP — no hand-rolled password storage/verification introduced.
- [ ] MFA is enforced (not merely offered) for roles marked privileged/finance in `locked-decisions.json`.
- [ ] MFA step-up enforced on privileged/finance actions (single-factor session is denied/challenged, incl. any remember-device bypass).
- [ ] Human sessions: server-side, revocable, `HttpOnly; Secure; SameSite` cookie, idle timeout matches locked policy.
- [ ] Service/API tokens: JWT ≤15 min lifetime, `aud`/`iss`/`exp`/`tenant_id` validated on every request, refresh rotation in place.
- [ ] Termination/deprovisioning path actually revokes sessions and tokens (test: revoke, then reuse old token/cookie → denied).

## Authorization

- [ ] Every permission check is server-side and centralized through the PDP (OPA/Cedar or the locked equivalent) — no per-endpoint ad hoc role string comparisons.
- [ ] RBAC (coarse) + ABAC (contextual attributes: cost center, approval limit, time window) both exercised by tests.
- [ ] SoD pairs relevant to this module are enumerated and a test proves the conflict is blocked.
- [ ] Privilege escalation probe: a low-privilege identity cannot reach an admin/finance action by direct call, replay, or parameter tampering.

## Cross-tenant leakage probes (multi-tenant builds)

- [ ] Direct object reference across tenants → denied (IDOR probe on every new resource type).
- [ ] Simulated pooled-connection reuse (two sequential requests, different tenants, same pooled connection) does not leak context.
- [ ] Bulk/export endpoints scoped to the caller's tenant only, even with crafted filter params.

## Sensitive data & CSRF

- [ ] Sensitive columns (bank/tax_id/national_id/salary) stored via field-encryption wrapper — a plaintext-column drift check exists and passes.
- [ ] State-changing endpoints have CSRF protection (anti-CSRF token or SameSite=strict + origin check).

## Result

PASS only if every box above is checked with a concrete repro/test reference. Any FAIL on this checklist escalates to a `Gk` gate per `00-START-HERE.md` before the module proceeds — this is foundation-tier, not a routine bounce.
