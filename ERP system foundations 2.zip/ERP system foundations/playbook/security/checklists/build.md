---
id: SEC-CHK-BUILD
stage: BUILD
audience: security-reviewer
read_when: stage 3 (SECURITY) of every module iteration in playbook/09-build-loop.md
produces: pass/fail evidence feeding gate 11 of playbook/10-quality-gates.md
depends_on: playbook/06-security-foundations.md
---

# Security checklist — per-module BUILD

Run against the diff for module M, fresh context, adversarial. Check the box only with evidence (a failing-then-passing test, a grep, a manual repro). Any unchecked box that applies to M → bounce to builder, do not proceed to VERIFY.

## Access control

- [ ] Every new endpoint/resolver/handler has an explicit server-side authorization check (no reliance on hidden UI/client-only gating).
- [ ] Object-level check present (not just "is authenticated") — verify with an IDOR probe: request another tenant's/user's object id and confirm denial.
- [ ] Deny-by-default: an unmatched policy path returns deny, not allow.
- [ ] If M defines a new role/permission, it was added via the PDP/policy layer, not a scattered `if user.role ==`.
- [ ] SoD: if M touches an SoD pair (§06-security-foundations §3), the two duties cannot be satisfied by one identity — tested.

## Tenant isolation (multi-tenant builds only)

- [ ] Every new table with tenant-scoped data has RLS enabled **and** `FORCE ROW LEVEL SECURITY`.
- [ ] Policy uses `WITH CHECK`, not just `USING`.
- [ ] App code sets tenant context with `SET LOCAL` inside the transaction — grep for bare `SET app.tenant_id` (fail if found).
- [ ] App DB role is not table owner, not superuser, not `BYPASSRLS`.
- [ ] New composite indexes lead with `tenant_id`.

## Data handling

- [ ] Sensitive fields introduced by M (bank details, tax ID, national ID, salary, secrets) are field-level encrypted, not plaintext.
- [ ] No new secret/credential/API key committed to source, config, or test fixtures — run gitleaks/trufflehog on the diff.
- [ ] All external inputs are parameterized/validated (no string-concatenated SQL, no unescaped shell calls).
- [ ] No user/vendor-influenceable field is rendered without contextual output encoding + CSP.
- [ ] Any LLM-produced value used in query/shell/path/report is treated as untrusted (parameterized/allow-listed).

## Audit log

- [ ] Every state-changing action in M writes an `audit_log` row in the same transaction (trigger/outbox), with before/after state.
- [ ] No code path can bypass the audit write (checked by attempting the mutation directly at the data-access layer, not just through the "normal" API path).

## AI/copilot modules only

- [ ] Tool calls execute with the end-user's tenant + role + attributes, never a privileged service identity.
- [ ] No autonomous posting/payment — a human approval step gates any write with financial effect.
- [ ] Untrusted ingested content (documents, emails) is marked as data, not instructions, in the prompt construction.
- [ ] RAG/vector store queries are tenant-namespaced.

## Scenario sweep

- [ ] Ran the `security/scenarios/*` file(s) matching M's tags (see `06-security-foundations.md §8`); each scenario's repro fails to reproduce against M.

**Result:** PASS only if every applicable box is checked with evidence. Write findings to `progress/reviews/<module>-security.md`.
