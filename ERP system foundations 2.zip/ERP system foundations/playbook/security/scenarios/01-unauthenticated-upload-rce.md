---
id: SCN-01
title: Unauthenticated file-upload leads to remote code execution
tags: [upload, auth]
applies_to_phase: P06
---

# S1 — Unauthenticated file-upload → RCE

**Class:** Pre-auth RCE · **Primary control:** Auth on every upload endpoint

- **Attacker goal:** Remote code execution on the app tier with no credentials.
- **Preconditions:** An upload/metadata endpoint reachable pre-auth (internet or flat network); web root or execution path writable; server executes uploaded content (JSP/WAR/JAR/ASPX/PHP or a deploy hook).
- **Attack steps:** (1) Discover an unauthenticated upload endpoint (e.g., the `/developmentserver/metadatauploader` pattern in CVE-2025-31324, CVSS 10.0). (2) POST a webshell or archive that lands in a servlet-served directory. (3) Request the uploaded artifact to execute OS commands as the app service account (often `<sid>adm`). Real intrusions dropped JSP webshells into `irj/root/` and reached OS command execution.
- **Impact:** Full app-server takeover, pivot to DB and OS, exfiltration of finance/HR/manufacturing data. China-linked APTs breached 581+ systems via this pattern in 2025.
- **Detection signals:** New/unexpected files in web-served dirs; POSTs to upload endpoints from unauthenticated sessions; child processes (`sh`, `cmd`, `powershell`) spawned by the web/app process; outbound connections from the app user.
- **Prevention controls:** Require authentication + authorization on **every** upload endpoint; store uploads outside any executable/served path; disallow server-side execution of user content; enforce content-type + magic-byte validation; WAF-deny direct access to internal deploy/metadata paths; remove unused add-ons.
- **Test/verification steps:**
  1. Enumerate every upload/deploy route and assert an unauthenticated request returns 401/403 (not 200).
  2. Upload a benign `.jsp`/`.war` and confirm it is (a) rejected or (b) stored non-executably and never rendered.
  3. Grep the deployed tree for user-writable executable paths.
  4. Automated DAST job that fails the build if any POST-upload route accepts anonymous input.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; wire step 4 into `playbook/10-quality-gates.md` gate 11.
