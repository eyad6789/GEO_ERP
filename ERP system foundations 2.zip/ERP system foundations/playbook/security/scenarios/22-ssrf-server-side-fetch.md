---
id: SCN-22
title: SSRF via server-side fetch (webhooks, imports, integrations)
tags: [integration, api]
applies_to_phase: P06
---

# S22 — SSRF via server-side fetch

**Class:** Network/Injection · **Primary control:** Egress allow-list + private-range blocking

- **Attacker goal:** Force the ERP server to make an HTTP(S) request to an attacker-chosen internal/private/metadata address, to read cloud credentials, reach internal-only services, or pivot past the network perimeter.
- **Preconditions:** A server-side feature accepts an attacker-influenceable URL: webhook-destination validator/"test connection", document/URL import, avatar/logo fetch-by-URL, stored integration destination configurable by a lower-privileged user; the fetch layer resolves DNS and connects without validating the destination is public/external; redirects are followed without re-validation.
- **Attack steps:** (1) Submit a webhook/import/avatar URL pointing at cloud metadata (`http://169.254.169.254/latest/meta-data/...`, `http://169.254.169.254/computeMetadata/v1/...`). (2) Submit loopback/link-local/RFC1918 targets (`127.0.0.1`, `10.x`, `172.16-31.x`, `192.168.x`, `::1`, `fd00::/8`). (3) Use a DNS name that first resolves to a public IP (passes validation) then rebinds to an internal IP at fetch time (TOCTOU/DNS-rebind). (4) Use a redirect chain (public URL → 302 → internal URL) to bypass a naive one-time check. (5) Use alternate encodings/schemes (`http://0177.0.0.1`, decimal IP, `file://`, `gopher://`) to evade a string-based blocklist.
- **Impact:** Cloud IAM credential theft via metadata endpoint, internal service enumeration/compromise, firewall bypass, potential RCE via reached internal admin interfaces.
- **Detection signals:** Outbound requests from app servers to 169.254.169.254, loopback, or RFC1918 ranges; fetch destinations resolving to IPs outside the expected external range at connect time; repeated "test connection"/import attempts against varying internal IPs (scanning pattern); non-standard URL schemes submitted to URL-accepting fields.
- **Prevention controls:** Enforce an allow-list of schemes (https only, no `file://`/`gopher://`/`dict://`) and, where feasible, allow-listed hosts/domains for known integrations; resolve DNS once, validate the resolved IP is public (deny loopback, link-local incl. 169.254.0.0/16, RFC1918, RFC4193 IPv6 ULA, multicast), and connect to that validated IP directly (pin the connection) rather than re-resolving, to close DNS-rebind TOCTOU; do not follow redirects automatically — re-validate each hop or disable redirect-following for this class of fetch; run outbound fetches from a network-isolated egress path/proxy with no route to internal admin networks or the cloud metadata service (metadata service should require IMDSv2/hop-limit or be unreachable from app subnets); never expose fetch response headers/credentials back to the requester.
- **Test/verification steps:**
  1. Submit `http://169.254.169.254/latest/meta-data/iam/security-credentials/` (and the GCP/Azure equivalents) as a webhook/import/avatar URL and assert the request is rejected before any outbound connection is attempted (check outbound-traffic logs show zero connection attempts to that address).
  2. Submit `127.0.0.1`, `10.0.0.1`, `192.168.1.1`, `::1` variants and assert all rejected with a clear validation error, not a fetch attempt.
  3. Set up a DNS name you control that resolves to a public IP on first lookup and an internal IP on second lookup; submit it and assert the connection is pinned to the validated (first-resolved, public) IP — confirm via egress logs that no connection reached the internal IP.
  4. Configure a test URL that public-allow-list-passes but issues a 302 to `http://127.0.0.1/admin`; assert the redirect is not followed, or the target is re-validated and rejected.
  5. Submit encoded/alternate forms (`http://0x7f000001/`, `http://0177.0.0.1/`) and confirm the validator normalizes and rejects them rather than string-matching literal `127.0.0.1` only.
  6. Confirm no fetch response body/headers/error containing internal service data or credentials is echoed back to the calling user.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `20-batch-job-scheduler-abuse.md` for the broader integration-trust-boundary review.
