---
id: SCN-15
title: JWT and session token flaws
tags: [session, auth]
applies_to_phase: P06
---

# S15 — JWT / session token flaws

**Class:** AuthN · **Primary control:** Verified alg, short TTL, rotation

- **Attacker goal:** Forge or hijack a session to impersonate users/admins.
- **Preconditions:** `alg:none` or algorithm-confusion accepted; weak/leaked signing key; long-lived non-revocable tokens; tokens in URLs/logs; missing audience/issuer checks.
- **Attack steps:** (1) Strip/switch the JWT algorithm or brute a weak secret. (2) Forge a token with elevated claims (`role:admin`, another `tenant_id`). (3) Replay a stolen token that never expires.
- **Impact:** Full account/admin/tenant takeover; combines with S6/S10.
- **Detection signals:** Tokens with unexpected `alg`; signature failures; claims mismatching session; reuse from new geo/IP; tokens past intended TTL.
- **Prevention controls:** Pin the accepted algorithm and reject others; strong rotated keys (asymmetric preferred); short TTL + refresh with rotation and server-side revocation; validate `iss`/`aud`/`exp`/`nbf`; never trust client-set role/tenant claims; tokens out of URLs and logs.
- **Test/verification steps:**
  1. Assert `alg:none` and RS→HS confusion tokens are rejected.
  2. Assert expired/revoked tokens fail.
  3. Assert tampered `role`/`tenant` claims are ignored (authz re-derived server-side).
  4. Scan logs to confirm no tokens are recorded.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `06-role-self-assignment-privesc.md` and `10-cross-tenant-data-leak.md`.
