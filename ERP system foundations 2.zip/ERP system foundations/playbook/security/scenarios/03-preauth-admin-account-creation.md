---
id: SCN-03
title: Pre-auth admin-account creation
tags: [auth]
applies_to_phase: P06
---

# S3 — Pre-auth admin-account creation (RECON pattern)

**Class:** Auth bypass · **Primary control:** Deny unauth writes to admin APIs

- **Attacker goal:** Create a high-privilege account without authenticating.
- **Preconditions:** An admin/user-management API or console reachable without auth (the CVE-2020-6287 RECON pattern: unauthenticated access to LM Configuration Wizard → create admin user).
- **Attack steps:** (1) Reach the unauthenticated admin function. (2) Invoke the create-user/assign-role operation to mint an administrator. (3) Log in normally with the new super-user.
- **Impact:** Complete application control, listed in CISA KEV; enables all downstream fraud and exfiltration.
- **Detection signals:** User-create/role-grant events not tied to an authenticated admin session; new admin accounts outside change tickets; access to setup/wizard URLs from the internet.
- **Prevention controls:** Every administrative/config endpoint must require authenticated, authorized, MFA'd admin identity; disable setup wizards post-install; alert on any privileged-account creation; deny internet exposure of admin planes.
- **Test/verification steps:**
  1. Assert all user-management and configuration routes return 401/403 unauthenticated.
  2. Assert a non-admin authenticated user cannot create/grant admin.
  3. Alert-fires test on synthetic admin-create event.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; cross-check `06-role-self-assignment-privesc.md` for the authenticated-side equivalent.
