---
id: SCN-16
title: Mass-assignment on document write APIs
tags: [api, injection]
applies_to_phase: P06
---

# S16 — Mass-assignment on document write APIs

**Class:** AuthZ · **Primary control:** Field allow-lists on binding

- **Attacker goal:** Set protected fields by adding them to a request body.
- **Preconditions:** API binds request JSON directly to entities; no field allow-list; protected fields (status, price, `approved`, `owner_id`, `gl_account`) are bindable.
- **Attack steps:** (1) POST/PATCH a document with extra fields (`"approved":true`, `"amount":0.01`, `"owner_id":<attacker>`). (2) Server persists them, bypassing workflow/pricing/ownership.
- **Impact:** Financial manipulation, approval bypass, ownership/tenant takeover of records.
- **Detection signals:** Writes setting fields not on the intended form; status/price/approval flips outside workflow; owner changes.
- **Prevention controls:** Explicit input DTOs / field allow-lists per operation; never bind straight to persistence entities; server sets workflow/derived fields; ignore unknown/read-only fields; validate state transitions server-side.
- **Test/verification steps:**
  1. For each write endpoint, submit extra protected fields and assert they are ignored/rejected.
  2. Assert status/price/approval cannot be set directly.
  3. Assert `owner_id`/`tenant_id` are server-derived.
  4. Contract test on the allow-list.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; same root cause as `06-role-self-assignment-privesc.md` and `08-idor-bola-document-apis.md`.
