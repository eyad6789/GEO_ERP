---
id: SCN-05
title: Server-side code injection via privileged module
tags: [injection, api]
applies_to_phase: P06
---

# S5 — Server-side code injection via privileged module

**Class:** Code injection · **Primary control:** No dynamic code from user input

- **Attacker goal:** Low-priv user injects code that runs with high privilege (the CVE-2025-42957 S/4HANA ABAP-injection pattern, CVSS 9.9, exploited in the wild Sept 2025).
- **Preconditions:** An RFC/BAPI/API/function that builds and executes code (ABAP `GENERATE SUBROUTINE`, `eval`, dynamic SQL/DDL, template engines) from parameters; caller has only low privilege plus one narrow auth object.
- **Attack steps:** (1) Call the exposed module with a payload that becomes executable code. (2) Use it to create an admin, patch data, or read secrets — bypassing SoD and audit.
- **Impact:** Full-system takeover from a low-privilege foothold; SAP rated it "everything is at risk — confidentiality, integrity, availability."
- **Detection signals:** Calls to codegen/deploy function modules from non-developer users; new admin users; unexpected transports/objects generated at runtime.
- **Prevention controls:** Never construct executable code from user input; tightly restrict authorizations on any codegen/deploy module; patch promptly; monitor RFC calls to sensitive modules; segment developer capabilities from business users.
- **Test/verification steps:**
  1. Inventory every dynamic-code/codegen sink; fuzz with injection markers and assert no evaluation occurs.
  2. Assert business-role users are denied on codegen function auths.
  3. Regression test that RFC/API allow-lists exclude deploy modules.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `09-sql-injection-report-filters.md` for the data-layer analog.
