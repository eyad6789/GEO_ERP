---
id: SCN-19
title: Broken audit log or tamper-evidence gap
tags: [audit]
applies_to_phase: P06
---

# S19 — Broken audit log / tamper-evidence gap

**Class:** Forensics · **Primary control:** Append-only signed hash-chain + externally-anchored tail

- **Attacker goal:** Act without a reliable trail, or erase evidence after the fact.
- **Preconditions:** Security-relevant events unlogged; logs writable/deletable by app or admin accounts; no integrity protection; short retention; no external anchor for the chain tail (a fully-compromised DB admin can rewrite the whole table *and* truncate the end).
- **Attack steps:** (1) Perform privileged/fraudulent actions in an unlogged path. (2) Delete/alter log entries, including truncating the most recent N rows so the visible chain still "verifies" from genesis to its new (shorter) end. (3) Deny/obscure the activity.
- **Impact:** Undetectable fraud, failed investigations, compliance violations (SOX/GDPR).
- **Detection signals:** Gaps in log sequence; log-config changes; logging service stopped; privileged actions with no corresponding events; current chain tail hash does not match the last externally-anchored/signed hash.
- **Prevention controls:** Log all auth, authz, privileged, and financial events; ship to append-only/WORM external store; hash-chain entries per `06-security-foundations.md` §4 (`row_hash = SHA-256(JCS-canonical(row w/o hash) || prev_hash)`, genesis row's `prev_hash` = 32 zero bytes); anchor/sign the latest `row_hash` hourly to an append-only external store (defends against a fully-compromised DB admin, and is the *only* thing that catches tail-truncation); `REVOKE UPDATE, DELETE ON audit_log FROM app_role`; separate logging identity from app/admin; retention per policy; alert on logging outages/config changes.
- **Test/verification steps:**
  1. **Full-chain recompute:** starting at the genesis row (`prev_hash` = 32 zero bytes, `\x0000...00`, 32 bytes), walk every row in `seq` order, recompute `SHA-256(JCS-canonical(row w/o row_hash) || prev_hash)` and assert it equals the stored `row_hash` for every row, ending with the stored final `row_hash`. Assert this passes on an untouched log.
  2. **Tail-truncation must NOT be caught by step 1 alone — prove the anchor catches it:** delete the most recent N rows (`DELETE FROM audit_log WHERE seq > (max_seq - N)`). Re-run the step-1 recompute over the *remaining* rows and confirm it still reports "chain verifies" (document this as the expected, intentionally-insufficient result — a bare re-verify has nothing left to contradict). Then compare the new (shorter) tail's `row_hash` against the last externally-signed anchor recorded before the deletion; assert this comparison reports a **MISMATCH/tamper-detected**, because the anchor's `row_hash` no longer exists in the table. Confirm the detection fires from the anchor comparison, not from the chain-walk.
  3. **Grant enforcement:** as the application role (`app_role`, non-owner), attempt `UPDATE audit_log SET action = 'x' WHERE seq = 1` and `DELETE FROM audit_log WHERE seq = 1`; assert both fail with a permission-denied error due to the `REVOKE UPDATE, DELETE ON audit_log FROM app_role` grant. Repeat as any non-owner admin role used by operators; assert the same denial. Confirm only a break-glass/migration-only role (audited separately) can write to the table, and that role is not the app's runtime identity.
  4. **Canonicalization conformance:** take a sample row, compute its canonical form under RFC 8785 JSON Canonicalization Scheme (JCS) — sorted object keys, no insignificant whitespace, fixed number formatting — and assert the implementation's `canonical()` output byte-for-byte matches the JCS output for that row. Assert the genesis row's `prev_hash` is exactly 32 zero bytes (`\x00` × 32), matching `06-security-foundations.md` §4.

**NEXT:** see `playbook/06-security-foundations.md` §4 for the full hash-chain + anchor schema and §8 for the scenario index; underpins detection for `12-insider-sod-violation.md`.
