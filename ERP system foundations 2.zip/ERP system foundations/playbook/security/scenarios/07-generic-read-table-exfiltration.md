---
id: SCN-07
title: Generic-read table function used for bulk data exfiltration
tags: [api, reporting]
applies_to_phase: P06
---

# S7 — RFC_READ_TABLE / generic-read data exfiltration

**Class:** Exfil · **Primary control:** Restrict generic-read function auths

- **Attacker goal:** Read arbitrary tables (payroll, bank data, secrets) via a generic remote-read function.
- **Preconditions:** User holds broad `S_RFC` / generic-read authorization; a generic table-read function (`RFC_READ_TABLE`/`RFC_READ_TABLE2` or a custom equivalent) is callable. Onapsis documented payroll + PII exfiltration in under 30 seconds this way.
- **Attack steps:** (1) Call the generic-read function with a target table (e.g., `PA0008`, `USR02`) and WHERE clause. (2) Page through results to dump the table. (3) Repeat across sensitive tables.
- **Impact:** Bulk PII/financial/credential theft via a *legitimate* function — often invisible to app-level audit.
- **Detection signals:** High-volume generic-read RFC calls; reads of HR/finance/credential tables by non-owning users; unusual WHERE clauses; off-hours bulk reads.
- **Prevention controls:** Restrict `S_RFC` to specific function groups; remove generic-read from business roles; wrap data access in purpose-built, authorization-checked APIs; row/column masking on sensitive tables; rate-limit and log all generic reads.
- **Test/verification steps:**
  1. Assert business-role users cannot invoke generic table-read functions.
  2. Assert sensitive tables are not readable via generic RFC.
  3. Volume-anomaly alert test on table dumps.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `18-report-builder-exfiltration.md` for the report-tool analog.
