---
id: SCN-11
title: Supply-chain or dependency compromise
tags: [supply-chain, secrets]
applies_to_phase: P06
---

# S11 — Supply-chain / dependency compromise

**Class:** Supply chain · **Primary control:** Pinned, verified, egress-locked deps

- **Attacker goal:** Run malicious code inside the ERP by poisoning a dependency or build.
- **Preconditions:** Unpinned/unverified third-party packages; build with registry/network access; CI secrets reachable. 2025 saw the `chalk`/`tinycolor` compromise (18+ packages, 2B+ weekly downloads) and the self-replicating **Shai-Hulud** npm worm exfiltrating cloud creds and DB passwords.
- **Attack steps:** (1) Attacker publishes a malicious version of a used package (or compromises a maintainer token). (2) The ERP build pulls it; install/postinstall harvests secrets and injects backdoors. (3) Stolen creds pivot to cloud, DB, and production.
- **Impact:** Credential theft, backdoored ERP, ransomware/DB theft downstream.
- **Detection signals:** New/unexpected dependency versions; postinstall scripts making network calls; outbound to unknown hosts from CI; new public repos ("Shai-Hulud") under org accounts; lockfile drift.
- **Prevention controls:** Pin exact versions + integrity hashes (lockfiles); vendor/verify signatures (Sigstore/provenance); disable install scripts by default; build in egress-restricted, secret-scoped runners; SBOM + continuous SCA; short-lived, least-priv CI tokens; separate publish creds.
- **Test/verification steps:**
  1. CI fails on lockfile drift or unpinned deps.
  2. SCA gate blocks known-malicious/CVE packages.
  3. Assert build runner blocks unexpected egress.
  4. Secret-scanning on every commit.
  5. Verify provenance/signature before promote.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; wire into `playbook/10-quality-gates.md` gate 9 (drift/SCA scan).
