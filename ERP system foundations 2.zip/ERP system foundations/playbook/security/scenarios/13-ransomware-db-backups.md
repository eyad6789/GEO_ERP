---
id: SCN-13
title: Ransomware on the ERP database or backups
tags: [secrets, audit]
applies_to_phase: P06
---

# S13 — Ransomware on ERP database / backups

**Class:** Availability · **Primary control:** Immutable, tested backups

- **Attacker goal:** Encrypt/destroy ERP data and backups to extort or halt operations.
- **Preconditions:** Reachable DB/file shares; over-privileged service/backup accounts; backups online and mutable; often follows S1/S4/S11 for initial access.
- **Attack steps:** (1) Gain foothold, escalate, reach DB/backup infra. (2) Exfiltrate for double-extortion. (3) Encrypt/delete DB, logs, and reachable backups.
- **Impact:** Business stoppage, data loss, extortion, regulatory exposure.
- **Detection signals:** Mass file/table changes; backup deletion/disable events; new admin on DB hosts; large egress before encryption; VSS/shadow-copy deletion.
- **Prevention controls:** Immutable/offline (air-gapped or object-lock) backups, tested restores; least-privilege DB and backup identities; network segmentation of the DB tier; EDR on DB/app hosts; MFA on all admin access; encryption-at-rest with guarded keys.
- **Test/verification steps:**
  1. Prove a full restore from immutable backup meets RTO/RPO.
  2. Assert backup store rejects deletion/overwrite by the app/backup account.
  3. Assert DB tier is not reachable from user networks.
  4. Tabletop + detection test on mass-change/backup-deletion signals.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; assume upstream scenarios `01`, `04`, `11` will occasionally succeed and this is the backstop.
