---
id: SCN-20
title: Batch-job or scheduler abuse for lateral movement
tags: [integration, secrets]
applies_to_phase: P06
---

# S20 — Batch-job / scheduler abuse for lateral movement

**Class:** Automation · **Primary control:** Least-priv service identities

- **Attacker goal:** Ride the ERP's automation (job scheduler, RFC destinations, integration users) to escalate or move laterally.
- **Preconditions:** Over-privileged integration/batch service accounts; stored trusted RFC/API destinations with embedded creds; users can define/modify jobs that run as a privileged principal.
- **Attack steps:** (1) Create/modify a scheduled job or step to run attacker logic. (2) Abuse a stored trusted destination to jump to a connected system as its service user. (3) Chain to admin or another system.
- **Impact:** Privilege escalation, cross-system compromise, persistence via legitimate automation.
- **Detection signals:** New/modified jobs by non-admins; jobs invoking unusual programs; use of trusted destinations off-pattern; batch account interactive logons.
- **Prevention controls:** Least-privilege, non-interactive service identities scoped per integration; no stored super-user destinations; authorize job creation/modification and run jobs as the *requesting* least-priv user; review trusted-RFC/destination graphs; alert on job/definition changes.
- **Test/verification steps:**
  1. Assert non-admins cannot create/edit privileged jobs.
  2. Assert integration accounts cannot log on interactively and are scoped to one purpose.
  3. Map and assert no destination grants super-user.
  4. Alert-fires test on job-definition change.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; last scenario in the R2 set — return to `playbook/06-security-foundations.md` for the cross-cutting gate list.
