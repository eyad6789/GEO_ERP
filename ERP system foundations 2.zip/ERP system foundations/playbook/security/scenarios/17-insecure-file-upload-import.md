---
id: SCN-17
title: Insecure file upload or data import with a malicious payload
tags: [upload, injection]
applies_to_phase: P06
---

# S17 — Insecure file upload / data import (malicious payload)

**Class:** Input · **Primary control:** Type/content validation, sandbox

- **Attacker goal:** Deliver malware, XXE, formula injection, or path traversal via an import/upload.
- **Preconditions:** Import of CSV/XLSX/XML/images with weak validation; parsers with external-entity/formula features; filenames used in paths.
- **Attack steps:** (1) Upload a spreadsheet with `=CMD|…` formula, an XML with an XXE payload, or a `../../` filename. (2) On open/parse/export, code runs or files are read/written outside scope.
- **Impact:** CSV-injection RCE on end-user machines, SSRF/file read via XXE, path traversal overwrite, stored malware distribution.
- **Detection signals:** Uploads with traversal sequences; XML DOCTYPE/ENTITY; formula-leading cells; type/extension mismatch vs magic bytes.
- **Prevention controls:** Validate type by content (magic bytes), size, and schema; disable external entities and DTDs in XML parsers; sanitize/escape cells against formula injection on export; generate server-side safe filenames; AV/sandbox scan; store outside web root.
- **Test/verification steps:**
  1. Upload XXE, CSV-formula, traversal-filename, and type-mismatch samples and assert each is neutralized.
  2. Assert XML parser has DTD/entity resolution disabled.
  3. Assert exported CSV escapes `= + - @`.
  4. Confirm files land outside executable paths.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `01-unauthenticated-upload-rce.md` for the pre-auth variant.
