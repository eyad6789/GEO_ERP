---
id: SCN-12
title: Insider segregation-of-duties violation (vendor create + payment)
tags: [payments, audit]
applies_to_phase: P06
---

# S12 — Insider SoD violation (vendor create + payment)

**Class:** Fraud · **Primary control:** Enforced SoD ruleset

- **Attacker goal:** Commit fraud by holding conflicting duties (create fictitious vendor + approve/pay it).
- **Preconditions:** One identity accumulates both master-data-maintenance and payment/approve rights (privilege creep); SoD evaluated at role level, not effective-transaction level.
- **Attack steps:** (1) Create/modify a vendor with attacker bank details. (2) Raise and approve/execute a payment to it. (3) Repeat below alerting thresholds.
- **Impact:** Direct financial loss, undetected disbursements, audit findings.
- **Detection signals:** Same user in vendor-create and payment events; bank-detail change followed by payment; new vendor paid immediately; approvals by requester.
- **Prevention controls:** Enforced SoD ruleset at provisioning and at runtime; mandatory dual control on vendor bank changes and payments; periodic access-recertification to kill privilege creep; alert on conflicting effective entitlements.
- **Test/verification steps:**
  1. Run the SoD ruleset against all users and assert zero unmitigated conflicts.
  2. Attempt vendor-create-then-pay as one user and assert block/approval-required.
  3. Assert bank-change → payment triggers dual control.
  4. Recert job proves stale grants are revoked.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `19-broken-audit-log-tamper.md` for the detection backbone.
