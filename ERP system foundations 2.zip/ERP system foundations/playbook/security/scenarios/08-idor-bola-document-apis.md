---
id: SCN-08
title: IDOR / BOLA on OData/REST document APIs
tags: [api, auth]
applies_to_phase: P06
---

# S8 — IDOR / BOLA on OData/REST document APIs

**Class:** AuthZ · **Primary control:** Per-object ownership checks

- **Attacker goal:** Read or modify another user's/tenant's records by changing an identifier.
- **Preconditions:** Object-level authorization missing; object IDs guessable/sequential; API trusts the ID in the URL/body over the caller's ownership. BOLA is OWASP API Top-10 #1.
- **Attack steps:** (1) Authenticate as a low-priv user. (2) Change `/Invoices('1001')` to `('1002')` or a filter to another org. (3) Enumerate IDs to bulk-read/modify records.
- **Impact:** Cross-user/tenant data disclosure and tampering; bulk exfiltration by scripting the ID space.
- **Detection signals:** One session accessing many distinct object IDs; 200s on objects the user never created; sequential-ID scans; access spanning orgs.
- **Prevention controls:** Enforce per-object ownership/authorization on **every** read/write, server-side; scope every query by the caller's tenant/org; use unguessable IDs (UUIDs) as defense-in-depth, never as the sole control; deny `$filter`/`$expand` that crosses authorization boundaries.
- **Test/verification steps:**
  1. Automated BOLA test — create objects as user A, attempt access as user B, assert 403/404 for every endpoint and method.
  2. Enumerate IDs and assert no cross-owner leakage.
  3. Test OData `$filter`/`$expand`/`$batch` for authorization bypass.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `10-cross-tenant-data-leak.md` for the tenant-scoped variant.
