---
id: SCN-09
title: SQL injection on custom report/filter parameters
tags: [injection, reporting]
applies_to_phase: P06
---

# S9 — SQL injection on custom report/filter parameters

**Class:** Injection · **Primary control:** Parameterized queries only

- **Attacker goal:** Read/alter the database via injected SQL.
- **Preconditions:** User input concatenated into SQL (custom reports, search filters, dynamic `ORDER BY`, native-SQL escapes in the ERP layer).
- **Attack steps:** (1) Inject `' OR '1'='1`, UNION, or stacked queries into a filter/report field. (2) Extract schema, dump tables, or write data.
- **Impact:** Full DB read/write, credential theft, data tampering, potential RCE via DB features.
- **Detection signals:** SQL errors in logs; anomalous query shapes; UNION/`information_schema`/`OR 1=1` patterns; long-running reads.
- **Prevention controls:** Parameterized queries / prepared statements everywhere; allow-list dynamic identifiers (columns, sort direction); least-privilege DB accounts; ORM with bound params; WAF as backstop only.
- **Test/verification steps:**
  1. SQLi fuzz suite (sqlmap-style) against every filter/report/search param.
  2. Static analysis flags string-built SQL.
  3. Assert dynamic `ORDER BY`/column names come from an allow-list.
  4. DB account has no DDL/`xp_cmdshell` rights.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `18-report-builder-exfiltration.md`.
