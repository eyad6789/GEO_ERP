---
id: SCN-06
title: Privilege escalation via self-service role assignment
tags: [auth]
applies_to_phase: P06
---

# S6 — Privilege escalation via self-service role assignment

**Class:** AuthZ · **Primary control:** Server-side role guards + approval

- **Attacker goal:** A normal user grants themselves elevated roles/entitlements.
- **Preconditions:** Role/entitlement changes are trusted from the client, or an approval workflow can be bypassed; missing server-side authorization on the grant operation.
- **Attack steps:** (1) Intercept the "request role" or profile-update call. (2) Add high-privilege roles / flip an `isAdmin` or approval field. (3) Server persists the grant without re-checking who may grant what.
- **Impact:** Escalation to SoD-violating or admin power; enables fraud and exfiltration.
- **Detection signals:** Self-grants (grantor == grantee); role changes outside the approval workflow; privilege deltas without a change ticket.
- **Prevention controls:** All role/entitlement changes enforced server-side against a "who-can-grant-what" policy; mandatory second-approver for privileged roles; deny self-approval; emit immutable audit events on every grant.
- **Test/verification steps:**
  1. Attempt to self-assign an admin role via the API and assert 403.
  2. Attempt to approve one's own request and assert rejection.
  3. Assert audit event emitted.
  4. Test that tampering with a role list in the request body is ignored server-side.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `16-mass-assignment-document-apis.md` (same root cause: trusting the client).
