---
id: SCN-02
title: HTTP request/response smuggling and session hijack
tags: [session, auth]
applies_to_phase: P06
---

# S2 — HTTP request/response smuggling & session hijack (ICMAD pattern)

**Class:** Desync · **Primary control:** Strict Content-Length/Transfer-Encoding parsing

- **Attacker goal:** Hijack an authenticated user's request/session or poison caches without credentials.
- **Preconditions:** A front proxy/dispatcher and app server that disagree on request boundaries (Content-Length vs Transfer-Encoding, or a memory-pipe desync as in CVE-2022-22536, CVSS 10.0).
- **Attack steps:** (1) Send a single crafted request whose framing is interpreted differently by proxy and backend. (2) Prepend arbitrary data to a victim's next request to execute functions as that victim, or smuggle a response to poison a shared cache.
- **Impact:** Account takeover, session theft, cache poisoning, persistence — all unauthenticated via a commonly exposed HTTP(S) port.
- **Detection signals:** Requests with both `Content-Length` and `Transfer-Encoding`; malformed/duplicated headers; responses served to the wrong session; anomalous request pairing at the proxy.
- **Prevention controls:** Normalize and strictly parse framing at the edge; reject requests with conflicting length/encoding headers; keep dispatcher/proxy and app patched; disable keep-alive reuse across trust boundaries where feasible.
- **Test/verification steps:**
  1. Run a smuggling test suite (CL.TE / TE.CL / TE.TE, and CL.0) against the proxy→app pair.
  2. Assert conflicting-header requests are rejected with 400.
  3. Assert no cross-request contamination under load.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `03-preauth-admin-account-creation.md` for edge/auth-plane hardening.
