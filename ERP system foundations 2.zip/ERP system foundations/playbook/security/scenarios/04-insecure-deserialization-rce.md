---
id: SCN-04
title: Deserialization of untrusted data leads to RCE
tags: [api, injection]
applies_to_phase: P06
---

# S4 — Deserialization of untrusted data → RCE

**Class:** Insecure deserialization · **Primary control:** Allow-list deser, no gadget classes

- **Attacker goal:** Execute code by feeding a crafted serialized object to a deserializer.
- **Preconditions:** Endpoint deserializes attacker-controlled bytes (Java/.NET/pickle/PHP) with dangerous classes on the classpath. This is the CVE-2025-42999 residual-risk pattern that chained with the S1 upload flaw for OS command execution as admin.
- **Attack steps:** (1) Identify a deserialization sink (upload processor, message queue, cookie, RFC/OData payload). (2) Submit a gadget-chain payload. (3) Trigger code execution without dropping an on-disk artifact.
- **Impact:** RCE as the app service account; hard to detect (fileless).
- **Detection signals:** Deserialization exceptions/gadget class names in logs; app process spawning shells; unexpected class loading.
- **Prevention controls:** Prefer data-only formats (JSON with schema) over native serialization; if native deser is unavoidable, use strict allow-lists / look-ahead deserialization filters; remove known gadget libraries; run the app tier with least OS privilege and no outbound egress.
- **Test/verification steps:**
  1. Send known gadget payloads (ysoserial-style, defanged) to each deser sink and assert rejection.
  2. Static-scan for `readObject`/`BinaryFormatter`/`pickle.loads` on untrusted input.
  3. Assert allow-list config is present.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; often chains with `01-unauthenticated-upload-rce.md`.
