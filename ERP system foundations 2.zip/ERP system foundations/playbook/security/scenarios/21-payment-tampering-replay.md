---
id: SCN-21
title: Payment tampering and replay on money-movement endpoints
tags: [payments, audit]
applies_to_phase: P06
---

# S21 — Payment tampering and replay

**Class:** Fraud/Integrity · **Primary control:** Server-side idempotency + re-verification

- **Attacker goal:** Move money more than once, alter the amount/payee in flight, or force an unapproved payment through by replaying a previously-approved request.
- **Preconditions:** Payment/disbursement/approval endpoint trusts a client-supplied idempotency key without server enforcement; endpoint trusts client-supplied amount/payee/total instead of recomputing from the stored transaction; no unique constraint or lock on (payment_id, execution) tuples; approval decision is bound to a replayable token rather than a server-side state transition.
- **Attack steps:** (1) Capture a legitimate approved-payment request (browser proxy, replay tool, or double-click/retry). (2) Resend it unmodified — assert single execution, not double disbursement. (3) Resend with a modified amount/payee/account while keeping the same auth/approval token — assert server rejects or re-derives values from the trusted record rather than the request body. (4) Fire N concurrent identical requests (double-submit / race) — assert exactly one settles. (5) Attempt to reuse an old approval's token/signature against a new or altered payment record.
- **Impact:** Duplicate disbursement, redirected funds to attacker-controlled account, bypass of approval workflow, financial and audit-integrity loss.
- **Detection signals:** Duplicate idempotency keys with differing payloads; two settlement events for one payment_id; payment amount/payee in the executed transaction differing from the approved transaction; high-frequency retries from one session/IP on the same resource; approval-token reuse across distinct payment IDs.
- **Prevention controls:** Require a server-generated (or server-validated, uniquely-constrained) idempotency key per payment intent, enforced at the database/transaction layer, not just app logic; enforce a DB-level unique constraint or SELECT…FOR UPDATE on the payment record so concurrent duplicate submissions serialize to one winner; on execution, re-fetch amount/payee/bank-details server-side from the approved record — never trust totals in the execution request; bind approval to a one-time-use, single-payment-scoped token that is invalidated on first use and cannot be replayed against a modified or different payment; log every state transition (created→approved→executed) with before/after values for audit.
- **Test/verification steps:**
  1. Submit an approved payment request twice with an identical idempotency key and assert exactly one execution and one ledger entry (query settlement table, count = 1).
  2. Fire the same request 20x concurrently (e.g. via `ab`/`hey`/a small concurrency script) and assert exactly one succeeds, the rest return a duplicate/conflict response, and no double-debit occurs.
  3. Replay a captured approved request with the amount or payee/bank-account field altered but the original approval token intact; assert HTTP 4xx and assert the executed ledger amount/payee matches the originally approved record, not the tampered payload.
  4. Attempt to reuse an approval token from payment A against payment B; assert rejection.
  5. Inspect the payment execution code path directly (or via API contract) and confirm it re-reads amount/payee from the stored approved record rather than accepting them from the incoming request body.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `19-broken-audit-log-tamper.md` for post-hoc detection of any tampering that slips through.
