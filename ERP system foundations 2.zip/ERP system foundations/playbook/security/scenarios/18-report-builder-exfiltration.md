---
id: SCN-18
title: Report-builder or query-designer data exfiltration
tags: [reporting, api]
applies_to_phase: P06
---

# S18 — Report-builder / query-designer data exfiltration

**Class:** Exfil · **Primary control:** Row-level security on ad-hoc queries

- **Attacker goal:** Use a legitimate ad-hoc reporting tool to read data beyond entitlement and bulk-export it.
- **Preconditions:** Report/query designer lets users pick tables/joins/columns; authorization enforced only in the UI, not in the generated query; unlimited export.
- **Attack steps:** (1) Build a report joining sensitive tables (payroll, bank, other cost centers). (2) Bypass UI filters by editing the query/params. (3) Export the full dataset.
- **Impact:** Large-scale PII/financial exfiltration through a sanctioned feature — low suspicion, hard to spot.
- **Detection signals:** Reports hitting sensitive tables by non-entitled users; very large exports; queries lacking row-level filters; off-hours bulk pulls.
- **Prevention controls:** Enforce row-/column-level security in the data layer so it applies to *all* queries; restrict selectable objects by role; cap and log exports; mask sensitive columns; require approval for cross-domain joins.
- **Test/verification steps:**
  1. As a low-entitled user, attempt to report on payroll/bank tables and assert row-level security blocks/masks it.
  2. Assert UI-filter tampering doesn't widen data.
  3. Assert export caps and audit logging fire.

**NEXT:** see `playbook/06-security-foundations.md` §8 for the full scenario index; pair with `07-generic-read-table-exfiltration.md` and `09-sql-injection-report-filters.md`.
