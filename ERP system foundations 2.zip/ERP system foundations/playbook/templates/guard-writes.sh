#!/usr/bin/env bash
# guard-writes.sh — PreToolUse hook wired in .claude/settings.json (see settings-hooks.json).
# Vetoes Write/Edit tool calls that target protected paths or escape the repo root.
# The harness passes the tool input as JSON on stdin; exit non-zero to BLOCK the call.
set -uo pipefail

payload="$(cat)"
path="$(printf '%s' "$payload" | jq -r '.tool_input.file_path // .tool_input.path // empty' 2>/dev/null)"
[ -z "$path" ] && exit 0   # nothing to guard

repo="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
abs="$(cd "$(dirname "$path")" 2>/dev/null && pwd)/$(basename "$path")" || abs="$path"

deny() { echo "guard-writes: BLOCKED — $1" >&2; exit 2; }

case "$abs" in
  "$repo"/*) : ;;                                  # inside repo — ok
  *) deny "write outside repo root ($abs)";;
esac
case "$path" in
  *project-config/locked-decisions.json) deny "locked-decisions.json is edit-locked — use the G1/gate procedure (owner sign-off + changelog + new checksum)";;
  *.env|*.env.*|*/secrets/*|*id_rsa*|*.pem) deny "secret/credential file — must not be written by an agent";;
esac
exit 0
