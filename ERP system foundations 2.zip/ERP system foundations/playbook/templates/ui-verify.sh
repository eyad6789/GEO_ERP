#!/usr/bin/env bash
# ui-verify.sh — the UI gate invoked by verify-phase.sh's `must ui_verify` (fail-closed).
# Copied into the target project as scripts/ui-verify.sh. Single source of truth for what
# "a UI phase is done" means. Makes the SEE step scripted, not prose: a UI phase cannot pass
# unless real visual + a11y tests exist AND a human/agent multimodal design-QA review artifact
# with a passing score referencing a real screenshot exists.
#
# Usage: scripts/ui-verify.sh <phase-id>
# UI-ness is per-phase: the phase's SPEC.md declares `has_ui: true`. Non-UI phases waive cleanly.
set -uo pipefail
PHASE="${1:?usage: ui-verify.sh <phase-id>}"
SPEC="progress/specs/${PHASE}.SPEC.md"

# --- Is this a UI phase? Read the declaration; do NOT guess from a silent test grep. ---
if ! grep -qiE '^\s*has_ui:\s*true' "$SPEC" 2>/dev/null; then
  echo "ui-verify: N/A — $PHASE is not a UI phase (SPEC has_ui not true). Waived."
  exit 0
fi

fail(){ echo "ui-verify: FAIL ($PHASE) — $1" >&2; exit 1; }
TESTDIR="${UI_TEST_DIR:-tests/ui}"

# --- 1. Real visual + a11y tests must EXIST (never passWithNoTests for a UI phase) ---
VIS=$(grep -rlE '@visual|toHaveScreenshot' "$TESTDIR" 2>/dev/null | wc -l | tr -d ' ')
A11Y=$(grep -rlE '@a11y|AxeBuilder|@axe-core' "$TESTDIR" 2>/dev/null | wc -l | tr -d ' ')
[ "$VIS"  -ge 1 ] || fail "no @visual/toHaveScreenshot test found in $TESTDIR (UI phase must have ≥1)"
[ "$A11Y" -ge 1 ] || fail "no @a11y/axe test found in $TESTDIR (UI phase must have ≥1 WCAG 2.2 AA check)"

# --- 2. Committed visual baseline must be non-empty (broken-but-stable baselines are caught by the design-QA look, see step 4) ---
SNAPS=$(find "$TESTDIR" -type d -name '*-snapshots' 2>/dev/null | head -1)
[ -n "$SNAPS" ] && [ -n "$(ls -A "$SNAPS" 2>/dev/null)" ] || fail "no committed visual-regression baseline (*-snapshots) — first baseline requires a recorded design-QA PASS"

# --- 3. Run the suites (light+dark projects); NO --update-snapshots in CI ---
npx playwright test --grep "@ui|@visual|@a11y" || fail "Playwright e2e / visual-regression / axe failed"
# Lighthouse: gate a11y + LCP + CLS + total-blocking-time (TBT = lab INP proxy; field INP advisory)
if command -v lhci >/dev/null 2>&1; then lhci autorun || fail "Lighthouse CI gate failed (a11y / LCP / CLS / TBT)"; fi

# --- 4. The SEE gate: a multimodal design-QA review artifact must exist and PASS ---
node scripts/design-qa-score.mjs "$PHASE" --min 85 --require-screenshot || fail "design-QA gate: no passing looked-at review for $PHASE"

echo "ui-verify: PASS ($PHASE) — tests exist, suites green, design-QA review looked at and scored ≥85"
exit 0
