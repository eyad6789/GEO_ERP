# Gate <G-id> — <short title>

<!-- Written to project-config/gates/pending/ when the machine reaches a gate.
     The orchestrator sets state.json.phase_status="blocked_on_gate", stops, and surfaces
     this to the owner. When answered, fill "Owner decision" and move to gates/answered/. -->

- **Gate:** <G0 | G1 | Gk-<module> | G2>
- **Raised at:** <ISO timestamp>
- **Stage/phase:** <phase-id>
- **Type:** <soft | hard>
- **Blocking:** <what is halted until this is answered>

## Context (why I'm asking)

<1–3 sentences: the situation and why this is the owner's call, not mine.>

## The question

<the specific decision needed>

## Options

| # | Option | Implication / trade-off | My recommendation |
|---|--------|-------------------------|-------------------|
| 1 | <option> | <what it means downstream> | <✓ if recommended> |
| 2 | <option> | <…> | |

## What I'll do with each answer

<how the answer changes locked-decisions.json or the build; be concrete so the owner
 knows the consequence before choosing.>

---
## Owner decision  <!-- filled in when answered -->

- **Chosen:** …
- **Notes:** …
- **Answered at:** …
- **Applied:** <locked-decisions.json changelog entry id, if this changed a locked value>
