#!/usr/bin/env node
// design-qa-score.mjs — the SEE gate's scripted enforcement, called by ui-verify.sh.
// Copied into the target project as scripts/design-qa-score.mjs. It does NOT judge the UI
// itself (the design-qa-reviewer agent does that, multimodally); it enforces that such a
// review actually happened, passed, and cited a real screenshot — so "I looked at it" cannot
// be skipped or faked in prose. Fail-closed: any doubt → non-zero exit.
//
// Usage: node scripts/design-qa-score.mjs <phase-id> --min 85 --require-screenshot
import { readFileSync, existsSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

const [phase, ...flags] = process.argv.slice(2)
if (!phase) { console.error('design-qa-score: usage: <phase-id> --min N [--require-screenshot]'); process.exit(2) }
const min = Number((flags.find(f => f.startsWith('--min')) || '').split('=')[1] || flags[flags.indexOf('--min') + 1] || 85)
const requireShot = flags.includes('--require-screenshot')

const artifact = join('progress', 'reviews', `${phase}-design.md`)
const die = (msg) => { console.error(`design-qa-score: FAIL (${phase}) — ${msg}`); process.exit(1) }

if (!existsSync(artifact)) die(`no design-QA review artifact at ${artifact} — the design-qa-reviewer must run and write its verdict (a UI never reviewed is not done)`)
const text = readFileSync(artifact, 'utf8')

// Verdict must be an explicit PASS with a numeric score, e.g. "PASS (92/100)".
const verdict = text.match(/\b(PASS|BLOCK)\b\s*\((\d{1,3})\s*\/\s*100\)/i)
if (!verdict) die(`artifact has no machine-readable verdict line ("PASS (NN/100)" / "BLOCK (NN/100)") — the reviewer must state the scored verdict`)
const outcome = verdict[1].toUpperCase(), score = Number(verdict[2])
if (outcome !== 'PASS') die(`design-QA verdict is ${outcome} (${score}/100) — fix the UI and re-review`)
if (score < min) die(`design-QA score ${score} < required ${min}`)

// A passing review MUST cite a real committed screenshot (forces looking, not asserting).
if (requireShot) {
  const citesImg = /\.png\b/i.test(text)
  const shotsExist = (() => {
    try { return readdirSync('tests/ui', { recursive: true }).some(f => String(f).endsWith('.png')) } catch { return false }
  })()
  if (!citesImg) die(`review cites no screenshot (.png) — a passing design-QA must reference the images it looked at`)
  if (!shotsExist) die(`no committed screenshot artifacts found under tests/ui — the looked-at images must be committed`)
}

console.log(`design-qa-score: PASS (${phase}) — ${outcome} ${score}/100, screenshot-cited`)
process.exit(0)
