#!/usr/bin/env bash
# verify-phase.sh — the command-based Definition of Done for one build phase/module.
# Copied into each ERP project as scripts/verify-phase.sh and run by the VERIFIER role
# (never the builder). A phase is "done" ONLY when this exits 0. Every check writes to
# the evidence file so a resuming session can trust it.
#
# Usage:  scripts/verify-phase.sh <phase-id> [<src-dir>]
# Reads project-config/locked-decisions.json for stack-specific commands (via jq).
# Exit 0 = phase passes. Any non-zero = phase FAILS; do not commit, do not mark done.

set -uo pipefail

PHASE="${1:?usage: verify-phase.sh <phase-id> [src-dir]}"
SRC="${2:-src}"
export PHASE SRC   # gate commands run via `bash -c` child shells and reference $PHASE/$SRC
CFG="project-config/locked-decisions.json"
EVID_DIR="progress/reviews"
EVID="${EVID_DIR}/${PHASE}.md"
mkdir -p "$EVID_DIR"

# Preflight: the script itself needs jq and a locked config. Hard-fail loudly if missing.
command -v jq >/dev/null 2>&1 || { echo "verify-phase.sh: FATAL — jq not installed (required). Install jq (G1 toolchain check)."; exit 3; }
[ -f "$CFG" ] || { echo "verify-phase.sh: FATAL — $CFG not found. Decisions must be locked (G1) before verification."; exit 3; }
jq -e '.checksum != null' "$CFG" >/dev/null 2>&1 || { echo "verify-phase.sh: FATAL — decisions not locked (checksum null). Run G1 first."; exit 3; }

FAIL=0
section() { printf '\n## %s\n\n```\n' "$1" >>"$EVID"; }
endsec()  { printf '```\n' >>"$EVID"; }
# run <label> <command...> : capture output to evidence, mark FAIL on non-zero
run() {
  local label="$1"; shift
  section "$label"
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  printf '%s\n' "$out" | tail -n 60 >>"$EVID"
  endsec
  if [ $rc -ne 0 ]; then printf '**RESULT: FAIL (exit %s)**\n' "$rc" >>"$EVID"; FAIL=1;
  else printf '**RESULT: pass**\n' >>"$EVID"; fi
  return 0
}
# grep_must_be_empty <label> <grep-args...> : FAIL if grep finds anything
grep_must_be_empty() {
  local label="$1"; shift
  section "$label"
  local hits
  hits="$(grep -rnI "$@" 2>/dev/null)"
  if [ -n "$hits" ]; then printf '%s\n' "$hits" | head -n 40 >>"$EVID"; endsec
    printf '**RESULT: FAIL — matches found (must be none)**\n' >>"$EVID"; FAIL=1
  else printf '(none)\n' >>"$EVID"; endsec; printf '**RESULT: pass**\n' >>"$EVID"; fi
}

# jq helper: read a command string from locked-decisions.json, empty if absent
cfgcmd() { [ -f "$CFG" ] && jq -r "$1 // empty" "$CFG" 2>/dev/null || true; }

# must <key> <label> : run the REQUIRED configured command. Empty/unconfigured key = FAIL
# (fail-closed). To legitimately waive a gate for a phase, set the key to an explicit no-op
# such as "true # N/A: no UI in this module" — silence is never a pass.
must() {
  local key="$1" label="$2" cmd
  cmd="$(cfgcmd ".verify.${key}")"
  if [ -z "$cmd" ]; then
    section "$label"
    printf '(verify.%s is not configured)\n' "$key" >>"$EVID"; endsec
    printf '**RESULT: FAIL — gate `verify.%s` not configured. Generate it at G1, or set an explicit `true # N/A` waiver.**\n' "$key" >>"$EVID"
    FAIL=1; return 0
  fi
  run "$label" bash -c "$cmd"
}

: >"$EVID"
printf '# Verify evidence — phase `%s`\n\n- src: `%s`\n- config: `%s`\n' "$PHASE" "$SRC" "$CFG" >>"$EVID"

# ── 1. Anti-stub / anti-empty-file (the #1 failure mode) ────────────────────────
grep_must_be_empty "No stub/placeholder markers" \
  -iE 'TODO|FIXME|XXX|placeholder|not[ _-]?implemented|coming soon|\bWIP\b|lorem ipsum|throw new Error\(["'"'"']?not impl' \
  --include='*.ts' --include='*.tsx' --include='*.js' --include='*.py' --include='*.go' \
  --include='*.java' --include='*.cs' --include='*.rs' --include='*.sql' "$SRC" \
  --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=dist --exclude-dir=build

section "No suspiciously tiny source files (<20 bytes)"
TINY="$(find "$SRC" -type f \( -name '*.ts' -o -name '*.tsx' -o -name '*.py' -o -name '*.go' -o -name '*.java' -o -name '*.cs' -o -name '*.rs' \) -size -20c 2>/dev/null)"
if [ -n "$TINY" ]; then printf '%s\n' "$TINY" >>"$EVID"; endsec
  printf '**RESULT: FAIL — empty/stub files present**\n' >>"$EVID"; FAIL=1
else printf '(none)\n' >>"$EVID"; endsec; printf '**RESULT: pass**\n' >>"$EVID"; fi

# ── 2–7. Config-driven gates — ALL REQUIRED (fail-closed). An empty key FAILS the phase. ──
# These read command strings generated at G1 from the locked stack (see
# playbook/templates/verify-commands.map.json). Security gates in particular must never be
# silently absent — that is how a phase "passes" without ever being checked.
must format             "Format check"
must lint               "Lint"
must typecheck          "Typecheck / compile (strict)"
must orphan             "Orphan / dead-code scan"
must test               "Tests (unit + integration)"
must coverage           "Diff coverage gate"
must drift              "Locked-decision drift scan (incl. RLS+FORCE coverage for multi-tenant)"
must dep_audit          "Dependency vuln audit"
must secret_scan        "Secret scan"
must security_scenarios "Security scenario checks (this module's tagged scenarios)"
must smoke              "Smoke run (exercise the path)"
must ui_verify          "UI: Playwright e2e (light+dark) + visual regression + axe WCAG 2.2 AA + Lighthouse"

# ── verdict ──────────────────────────────────────────────────────────────────────
printf '\n---\n\n' >>"$EVID"
if [ "$FAIL" -eq 0 ]; then
  printf '# VERDICT: ✅ PASS — phase `%s` meets Definition of Done.\n' "$PHASE" >>"$EVID"
  echo "verify-phase.sh: PASS ($PHASE) — evidence: $EVID"; exit 0
else
  printf '# VERDICT: ❌ FAIL — phase `%s` is NOT done. Fix and re-run.\n' "$PHASE" >>"$EVID"
  echo "verify-phase.sh: FAIL ($PHASE) — see $EVID"; exit 1
fi
