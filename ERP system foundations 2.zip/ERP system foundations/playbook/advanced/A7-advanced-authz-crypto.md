---
id: A7
stage: DECIDE + BUILD (advanced/optional depth)
audience: orchestrator, builder, security-reviewer, verifier
read_when: P06 shows ≥4 approval tiers / matrixed cost-center hierarchy (ReBAC trigger), OR the owner's compliance bar requires regulator-grade non-repudiation beyond the base hash-chain (anchoring trigger), OR the build is large green-field with ≥3 bounded contexts and no existing code to imitate (spec-gen trigger)
produces: security.authz_engine, security.audit_anchoring keys in project-config/locked-decisions.json; authz model files (`authz/*.fga` or `*.zed`); `audit_anchor` table + anchoring job; layered spec files consumed by 09-build-loop SPEC.md
depends_on: AR7-advanced-authz-crypto (research), playbook/06-security-foundations.md §3-4 (authz pattern, hash-chain spec — this file extends, never replaces), playbook/09-build-loop.md (SPEC.md contract), core/security.md
runs_with: playbook/09-build-loop.md (stage 0 PLAN + BUILD), playbook/10-quality-gates.md, playbook/security/checklists/*
---

# A7 · Frontier AuthZ, Cryptographic Audit Anchoring, and Spec-Driven Generation

**ADOPT WHEN (three independent triggers — adopt each section on its own merits, not as a bundle):**
- **§1 ReBAC:** the ERP has >3 approval tiers, cost-center/org-unit hierarchy, or delegation chains — i.e., "who can approve up to $X for this cost center, including delegates, while the period is open" is a real query. **SKIP** if ≤3 static roles and no hierarchy — plain RBAC+ABAC from `06-security-foundations.md` §3 is cheaper.
- **§2 Anchoring:** regulated/high-assurance domains (SOX, financial audit, government) where "a compromised DBA rewrote the whole chain" must be provably impossible, not just improbable. **SKIP** if the base hash-chain + single signed anchor (`06-security-foundations.md` §4) already satisfies the compliance bar — most builds stop there.
- **§3 Spec-gen:** large green-field builds (≥3 bounded contexts, no legacy code to imitate) where spec-as-source-of-truth meaningfully shrinks the hallucination surface. **SKIP** for small/brownfield builds where retrofitting a spec stack costs more than it saves.

---

## 1. ReBAC — relationship-based authorization for approval hierarchies

### 1.1 Why RBAC+ABAC breaks on this sentence

> "This cost center's manager can approve up to $X for these categories during open fiscal periods."

RBAC alone needs one role per cost-center × tier (role explosion). ABAC alone has no native hierarchy traversal ("everything under me in the org tree"). **ReBAC** (Zanzibar model: `object#relation@user` tuples, graph traversal) natively subsumes RBAC (a role is a relation) and layers ABAC-style **conditions** (CEL-like expressions) on top for the dollar-ceiling/period-state clauses. `06-security-foundations.md` §3's RBAC+ABAC-via-OPA/Cedar default is correct for the base case; **this section is the upgrade path once hierarchy + dollar-conditions become first-class queries, not an override of that default.**

**PROPOSED: model ERP authz as a ReBAC relation graph with conditions the moment hierarchy-aware or dollar-ceiling checks appear** — not RBAC-with-if-statements bolted on.

### 1.2 Engine choice

| Engine | Model fidelity | Storage | 2026 differentiator | Fit |
|---|---|---|---|---|
| **OpenFGA** (CNCF) | High — DSL + Conditions (CEL) + contextual tuples | Postgres/MySQL/SQLite | Conditions GA; broad SDK matrix; Auth0/Okta-backed | **PROPOSED default** — fastest onboarding, no vendor lock |
| **SpiceDB** (AuthZed) | Highest — closest to the original Zanzibar paper | Postgres/CockroachDB/Spanner | "Relationship Integrity" — cryptographically signs every tuple; mismatch on read rejects the whole load, defeating a DBA who edits grants directly | **PROPOSED upgrade** when tamper-evident *permission data itself* (not just app data) is the compliance bar |

**(verify exact SpiceDB Relationship Integrity version/GA status against the SpiceDB CHANGELOG before pinning — vendor-blog-sourced as of the research date; verify via `playbook/01-freshness-check.md`)**

### 1.3 Model sketch (OpenFGA DSL — illustrative pseudocode, not compiled/tested)

**This sketch is illustrative only** — it is meant to convey the shape of the relation graph and where a condition attaches, not to be copy-pasted as a working model. Two structural rules the sketch below follows (and the earlier draft violated): a `condition` is declared as its own **model-scope block**, never nested inside a `type`'s `relations` block; and it binds on the **type restriction of the directly-assignable relation** (the `[...]` term a tuple can actually be written against), with any computed relation (like `can_approve`) simply referencing that relation.

```
model
  schema 1.1

type user

type cost_center
  relations
    define parent: [cost_center]
    define manager: [user] or manager from parent
    define delegate: [user]
    define approver: manager or delegate

type expense_category
  relations
    define allowed_for: [cost_center]

type approval_request
  relations
    define cost_center: [cost_center]
    define category: [expense_category]
    define approver: [cost_center#approver with within_limit_and_open_period]
    define can_approve: approver

condition within_limit_and_open_period(amount: double, period_status: string, ceiling: double) {
  amount <= ceiling && period_status == "open"
}
```

`approver` on `approval_request` is the directly-assignable relation — its type restriction (`cost_center#approver`) is what the `with within_limit_and_open_period` condition binds to. `can_approve` is a plain computed relation on top of it, so a Check for `can_approve` resolves through `approver` and evaluates the condition along the way.

Stored tuples are relationships only (rarely change). The dollar ceiling, amount, and period status are **not** contextual tuples — they are **condition context**: the `context` object passed on the Check request, evaluated against the condition bound above. Contextual tuples (a distinct OpenFGA feature) would mean supplying a temporary relationship tuple for the duration of one request; that is not what's happening here.

```jsonc
// stored, written once
{"object":"cost_center:CC-4410","relation":"manager","user":"user:priya"}
{"object":"cost_center:CC-4410","relation":"parent","user":"cost_center:CC-4400"}

// per-request Check call, condition context (the 'context' field), NOT a contextual tuple, NOT stored
{
  "object": "approval_request:REQ-9931", "relation": "can_approve", "user": "user:priya",
  "context": { "amount": 4200.00, "period_status": "open", "ceiling": 5000.00 }
}
```

### 1.4 The non-negotiable rule

**STRUCTURAL: never encode an approval-limit number in application code or a static role table.** The ceiling is always a condition parameter resolved from cost-center/category master data at check time — a finance re-org (new ceiling, re-parented cost center) becomes a data write, not a deploy. Model delegation as its own `delegate` relation with a validity-window condition; `approver = manager or delegate`, so revocation/expiry is one tuple write, not an application-code branch.

### 1.5 Break-even test

If the ERP is single-tenant, ≤3 static roles, no hierarchy-aware checks — plain RBAC in app tables stays cheaper; do not stand up a Zanzibar-style service for a point-solution add-on. The moment "who can access this AND everything under it" or "up to $X" becomes a first-class query, ReBAC pays for itself.

### 1.6 AI-agent authz (if A6 is also adopted)

If `ai_capability.*` (A6) includes an agent that reads/proposes against the ledger, it must be checked against the **same** ReBAC graph the human UI uses — not a parallel shadow permission system. AuthZed's `spicedb-dev`/SpiceBox pattern (relationship-scoped tool permissions for coding/finance agents) is the reference shape; don't hand an agent a service-super-user credential that bypasses the graph.

---

## 2. Cryptographic audit anchoring — beyond the base hash-chain

### 2.1 What the base chain doesn't cover

`06-security-foundations.md` §4's hash-chain + single signed anchor already defends against mid-chain edits and (via the anchor) tail truncation. **This section adds independent, differently-trusted anchors** for regulatory non-repudiation scenarios where "the DBA regenerated the entire chain from scratch, including a fake anchor" must be provably excluded — a step beyond what one KMS-signed anchor alone proves, because that anchor's signing key lives in the same operator's trust domain.

### 2.2 Three independent anchor types

| Anchor | Mechanism | Proves | Trust domain |
|---|---|---|---|
| **Transparency log** (Sigstore Rekor v2 / Trillian-Tessera) | Merkle tree; inclusion + consistency proofs (RFC 9162 mechanism, domain-agnostic) | This root was in the log at time T; no entry silently deleted/reordered since | Log operator (self-hosted or public instance) — separate from the ERP's DB operator |
| **RFC 3161 TSA** | Third-party signs `(hash, time)` | Data existed before time T | An audited, eIDAS/WebTrust-compliant timestamp authority — independent of both the ERP and the log operator |
| **OpenTimestamps** | Batches hashes into a Bitcoin transaction Merkle tree | Vendor-independent, publicly re-derivable proof, marginal cost ≈0 | No ongoing relationship with any vendor — the public chain itself |

**PROPOSED: batch audit-log rows into fixed windows (hourly/daily/every-N-rows), compute a Merkle root per window, submit to all three.** A compromised DBA now has to simultaneously suppress detection across three independently-trusted anchors — this is the point.

**Do NOT** default to a managed "ledger database" (e.g., AWS QLDB) as the sole anchoring mechanism — QLDB was discontinued (support ended July 2025); the category is contracting, not maturing, on major hyperscalers. Open-source ledger DBs (immudb, Dolt, Azure SQL Ledger) reintroduce single-operator trust unless *they themselves* anchor externally per this section.

### 2.3 Schema extension (additive to `06-security-foundations.md` §4's `audit_log` table)

```sql
CREATE TABLE audit_anchor (
  id           BIGSERIAL PRIMARY KEY,
  window_start BIGINT NOT NULL REFERENCES audit_log(seq),
  window_end   BIGINT NOT NULL REFERENCES audit_log(seq),
  merkle_root  BYTEA NOT NULL,
  rekor_uuid   TEXT,          -- transparency-log entry ID
  rekor_proof  JSONB,         -- cached inclusion + consistency proof
  tsa_token    BYTEA,         -- RFC 3161 TimeStampToken (DER)
  ots_proof    BYTEA,         -- OpenTimestamps .ots proof
  anchored_at  TIMESTAMPTZ NOT NULL
);
```

A DBA editing `audit_log` directly breaks `row_hash` chaining from that point AND makes the corresponding `merkle_root` unreproducible — detectable by anyone who independently recomputes the root and compares against the externally-anchored proof. **All proof artifacts must be stored in the DB and additionally exported/published** — they must outlive the system that produced them.

### 2.4 Cadence and verification

State cadence explicitly in `locked-decisions.json` (**PROPOSED: hourly windows**, same cadence family as the base anchor). A verifier job (distinct from the builder — same fail-closed pattern as `scripts/verify-phase.sh`) recomputes each window's Merkle root and cross-checks against all three stored proofs on a schedule; a mismatch is a Sev-1 incident, not a warning.

---

## 3. Spec-driven generation — the deepest anti-hallucination lever

### 3.1 Why this beats post-hoc review

Tests/lint/code-review operate *after* code exists and can themselves be hallucinated alongside it. **Spec-driven development inverts the hierarchy: the formal spec is the source of truth; code, tests, migrations, and docs are regenerable projections of it.** A human reviews one dense spec instead of thousands of generated lines — the review surface shrinks by an order of magnitude, and code/test/doc drift becomes structurally impossible because they share one origin. Early adopter reports cite 3-10x higher first-pass success rate on non-trivial agent tasks when work is spec-anchored vs. prompted ad hoc **(verify current figures via `playbook/01-freshness-check.md` — vendor-reported, moves fast)**.

### 3.2 This is NOT a replacement for `09-build-loop.md`'s SPEC.md

`09-build-loop.md` stage 0 already mandates a per-module SPEC.md (contracts, invariants, edge cases) before any BUILD begins — that is the base doctrine and is never optional. **This section is a deeper, layered spec stack for teams that want machine-generated code/migrations/docs directly off formal artifacts**, feeding SPEC.md as structured input rather than free prose.

### 3.3 The layered spec stack (PROPOSED, per layer)

| Layer | Format | Generates | PROPOSED tool |
|---|---|---|---|
| Business-rule (approval limits, tax rules, matching tolerances) | DMN decision tables (OMG standard) | Executable decision logic; condition params for §1.3 | Camunda or any DMN-compliant engine |
| API/contract | TypeSpec (or Smithy) DSL | OpenAPI 3.1, gRPC, typed client/server SDKs | TypeSpec — 1.0 GA; demote hand-written OpenAPI entirely |
| Data/schema | Prisma schema / Atlas HCL / JSON Schema | DB migrations, validators, fixtures | Prisma schema (matches base stack default in `04-tech-stack.md`) |
| AuthZ | OpenFGA/SpiceDB DSL (§1.3) | Permission checks, generated from the same domain nouns | Same engine chosen in §1.2 |
| Process/orchestration | GitHub Spec Kit Spec→Plan→Tasks | The agent execution harness consuming all layers above as fixed inputs | GitHub Spec Kit — open, agent-agnostic |

**PROPOSED: every layer's spec file is checked-in, versioned, code-reviewed source; the corresponding generated code/OpenAPI/migrations are CI-regenerated build output, never hand-edited.** Wire a CI check: regenerate from spec, diff against committed output — any mismatch fails the build ("someone hand-edited a generated artifact — the spec is now a lie"). This diff-check is the mechanical enforcement; add it to the module's `verify-phase.sh` alongside the existing gate-9 drift linter.

### 3.4 DMN closes the drift gap for approval logic specifically

Every row of a DMN decision table is a test case waiting to be materialized — "the policy" and "the tests" can be the literal same rows when a DMN engine executes the table directly. This is the concrete link back to §1: the dollar-ceiling condition parameters in the ReBAC model should be *generated from* the DMN table, not maintained twice.

### 3.5 Formal methods — narrow, not general

TLA+ can model-check concurrency/consistency invariants no test suite exhaustively covers (e.g., "can two concurrent postings double-book the same GL period"). **Reserve it for the 3-5 scariest concurrency invariants in the ledger/period-close core** (same boundary where §2's anchoring concentrates) — not as a general spec layer for CRUD-shaped modules. LLM-authored TLA+ correctness is an active research question as of the research date; treat any agent-generated TLA+ spec as needing the same human review rigor as the invariant it's modeling, not as a shortcut around that review.

---

## 4. Consolidated keys and defaults

```jsonc
"security": {
  "authz_engine": {
    "value": "PROPOSED: OpenFGA (upgrade to SpiceDB when tamper-evident permission data is required)",
    "adopt_when": "≥4 approval tiers or cost-center hierarchy present (P06)",
    "condition_params_never_hardcoded": true   // STRUCTURAL
  },
  "audit_anchoring": {
    "value": "PROPOSED: transparency log (Rekor/Tessera) + RFC 3161 TSA + OpenTimestamps, hourly windows",
    "adopt_when": "regulatory non-repudiation bar exceeds single-anchor baseline in 06-security-foundations.md §4",
    "extends_not_replaces": "playbook/06-security-foundations.md §4 base hash-chain + single signed anchor"
  },
  "spec_gen_stack": {
    "value": "PROPOSED: DMN (rules) + TypeSpec (API) + Prisma (data) + OpenFGA DSL (authz) + Spec Kit (orchestration)",
    "adopt_when": "≥3 bounded contexts, green-field, no legacy code to imitate",
    "ci_diff_check": true                       // STRUCTURAL if adopted: regen-and-diff or build fails
  }
}
```

Non-negotiables regardless of which triggers fire:
1. Approval-limit numbers are **never** static role-table values or hardcoded constants — always condition params from master data (§1.4).
2. If anchoring is adopted, it **adds to**, never replaces, the base hash-chain + signed anchor in `06-security-foundations.md` §4.
3. If spec-gen is adopted, a generated-artifact diff mismatch is a **build failure**, not a lint warning.

**NEXT:** if the ReBAC trigger fired, write the authz model file (`authz/*.fga` or `*.zed`) during the module's P09 BUILD stage and reference it from that module's SPEC.md; run `playbook/security/checklists/data-and-auth.md` against it. If the anchoring trigger fired, extend the `audit_log` migration from `06-security-foundations.md` §4 with the `audit_anchor` table (§2.3) and add the anchoring job + verifier to `playbook/10-quality-gates.md`'s release checklist. If the spec-gen trigger fired, wire the chosen layers' regen-and-diff check into `09-build-loop.md` stage 0 SPEC.md generation before P09 begins. If none of the three triggers fired, skip this file entirely and proceed with the base defaults in `06-security-foundations.md`.
