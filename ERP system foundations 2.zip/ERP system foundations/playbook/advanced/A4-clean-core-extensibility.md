---
id: A4
stage: DECIDE/BUILD
audience: orchestrator + builder + verifier
read_when: the build has (or will have) client-specific or industry-specific logic, a plugin/ISV ecosystem, or is multi-tenant SaaS — i.e. almost every build past a single-client MVP
produces: architecture.extension_model.* keys for locked-decisions.json
depends_on: AR4-clean-core-extensibility (research track), core/architecture.md § Multi-Tenancy, playbook/05-architecture-deployment.md
runs_with: playbook/04-tech-stack.md, playbook/10-quality-gates.md
---

# A4 · The Clean-Core Extension Boundary

**ADOPT WHEN:** the ERP will carry client- or industry-specific logic beyond generic config (almost always, once you leave a single throwaway MVP), OR the product is multi-tenant SaaS with more than one tenant's customization living in the same deployment. **SKIP/DEFER** only for a genuinely single-tenant, single-client build with no plugin ambition and no plan to resell — in that case a lighter version of §3.1 (typed UDFs) may be all that's needed; do not build the full side-by-side + plugin-API machinery for a build that will never have a second customer.

Every legacy-ERP horror story is the same mechanism: a need arrives, no sanctioned extension point exists, someone patches the core, the patch becomes load-bearing, the next upgrade breaks it or is deferred forever. The fix is not developer discipline — it is an **architectural boundary with a CI gate that makes the unsanctioned path harder to ship than the sanctioned one.** (Source: AR4 §1, SAP Clean Core A–D model.)

Do not re-derive multi-tenancy or RLS here — that's `playbook/05-architecture-deployment.md`. This doc is the boundary *inside* a tenant's logical space: what's core vs. what's extension, and how the build OS enforces it.

---

## 1. The four sanctioned extension mechanisms — pick one, never bypass

Anything a builder wants to do that doesn't fit one of these four is a signal to extend the *menu* (propose a new mechanism, get it reviewed), never to bypass the gate.

| Mechanism | Use for | Trust/blast-radius | Where code runs |
|---|---|---|---|
| **1.1 Typed UDFs + metadata config** | "one more field," approval thresholds, validation rules | Low — sandboxed by type system | In-process, sidecar schema |
| **1.2 Side-by-side services** | genuine bespoke logic (custom pricing, regulatory calc, proprietary integration) | Medium — own deploy, no DB access | Separate process/container |
| **1.3 Webhooks** | notify external systems async | Low — signed, replay-guarded, dead-lettered | External, out-of-process |
| **1.4 Declared sync extension points** | rare true pre-commit validation (e.g. credit check) | High — can block core txn; requires explicit review | In-process, timeout-bounded |

**PROPOSED default:** 1.4 is disallowed unless explicitly reviewed and logged as an exception — default every "must run synchronously" request to 1.2 (event) or 1.1 (rule-as-data) first.

---

## 2. Core boundary — the invariants

- Core = narrow domain services behind a **versioned public API** (REST/GraphQL) + an **event bus** (CloudEvents envelope, §3).
- **No tenant/plugin code runs in-process with core.** No shared memory, no shared transaction.
- **No direct DB access from outside `core.*` schema.** Extension code never holds credentials to the core schema — it goes through the public API or reads from the event bus.
- Core migrations own `core.*` exclusively. Extension/tenant code owns `ext.*` (and, if schema-per-tenant, its own tenant schema) — never `core.*`.

```
┌─────────────────────────────┐        ┌──────────────────────────┐
│ CORE (core.* schema)        │        │ SIDE-BY-SIDE SERVICE      │
│ domain services             │  API   │ (separate deploy)         │
│ public API + event bus  ───▶│◀──────▶│ subscribes to events      │
│ NO plugin code in-process   │ events │ writes back via API only  │
└─────────────────────────────┘        └──────────────────────────┘
        │ owns core.*                          │ owns ext.* / own schema
        ▼                                       ▼
   core migrations                        ext migrations (plugin/tenant)
```

---

## 3. Typed UDFs + metadata config (`ext.*` sidecar schema)

**PROPOSED default:** hybrid — JSONB for unstructured tenant-level config/feature flags; typed EAV-ish sidecar for UDFs that need query/validation/reporting. Never a single JSONB blob for queryable business fields (AR4 §3.1 — this is what every mature SaaS ERP converges on).

```sql
-- core table: NEVER altered per-tenant, never gets an ALTER TABLE for a customer request
CREATE TABLE core.purchase_order (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  vendor_id UUID NOT NULL,
  total_amount BIGINT NOT NULL,   -- integer minor units, never float
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- sanctioned extension surface: typed, validated, per-tenant
CREATE TABLE ext.field_definition (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  entity TEXT NOT NULL,                -- 'purchase_order'
  field_key TEXT NOT NULL,             -- 'customs_broker_ref'
  data_type TEXT NOT NULL CHECK (data_type IN ('string','number','bool','date','enum','ref')),
  is_required BOOLEAN DEFAULT false,
  validation JSONB,                    -- {"maxLength":40,"pattern":"^[A-Z]{2}\\d+$"}
  UNIQUE (tenant_id, entity, field_key)
);

CREATE TABLE ext.field_value (
  entity_id UUID NOT NULL,             -- logical FK to core.purchase_order.id; NO cross-schema FK constraint
  field_def_id UUID NOT NULL REFERENCES ext.field_definition(id),
  value_string TEXT, value_number NUMERIC, value_bool BOOLEAN,
  value_date DATE, value_ref UUID,
  PRIMARY KEY (entity_id, field_def_id)
);
```

Rules:
- No FK constraint from `ext.*` into `core.*` — decouples extension schema migration cadence from core's. Application layer enforces the logical link.
- Business rules (approval matrices, thresholds) are **rows the engine interprets**, not `if` statements the core ships — this is what lets most "customization requests" never become code.
- Every UDF/rule created through the sanctioned surface must be **exportable to a declarative YAML/JSON file** in the tenant's git-tracked config repo — never only a DB row (Odoo Studio's lesson: un-diffable config is a black box at upgrade time, AR4 §5).

---

## 4. Side-by-side extensions — versioned domain events

For genuinely bespoke logic: a separate deployable subscribing to versioned domain events, writing back only through the public API.

```yaml
# CloudEvents 1.0.2 envelope — published by core
specversion: "1.0"
type: "com.erp.purchasing.po.approved.v1"
source: "/tenants/{tenant_id}/purchasing"
id: "3f2a9e2e-..."
time: "2026-07-07T10:15:00Z"
datacontenttype: "application/json"
data:
  po_id: "PO-00219"
  tenant_id: "..."
  total_amount_minor: 4820000
  approved_by: "user:2211"
```

- Event schemas are **versioned artifacts** (`po.approved.v1`, `.v2`). Additive fields ship on the same version; breaking changes ship as a new version published side-by-side with the old for the deprecation window (§6).
- The side-by-side service has **no DB credentials to `core.*`**. If it needs to affect the core record, it calls the same public API every other client uses — no privileged path.

---

## 5. Webhooks — Standard Webhooks spec, no bespoke signing

**PROPOSED default:** adopt the [Standard Webhooks](https://github.com/standard-webhooks/standard-webhooks) spec verbatim rather than inventing signing.

```
POST /tenant-configured-endpoint
webhook-id: msg_2f8x...
webhook-timestamp: 1751877300
webhook-signature: v1,K5oZ...        # HMAC-SHA256(secret, id.timestamp.body)
content-type: application/json

{ "type": "po.approved.v1", "data": { ... } }
```

Hard-coded rules (not optional):
- Per-tenant **rotatable** signing secret.
- Timestamp tolerance window to defeat replay.
- At-least-once delivery; idempotency key = event id (receiver dedupes).
- Dead-letter queue, visible to the tenant, with retry/replay UI.
- Synchronous in-process hooks are **disallowed by default** (SAP's Level-D "implicit enhancement" — a slow/failing hook corrupts or blocks a core transaction). If a true synchronous need exists (e.g., reject-if-credit-check-fails), it must be a **declared extension point**: named, timeout-bounded, with an explicit fail-open/fail-closed policy chosen per hook, and logged as a reviewed exception.

---

## 6. Plugin API — its own versioning, independent of core release cadence

The plugin/extension API is a product with its own lifecycle — this is the most-missed piece in home-grown ERPs.

```json
{
  "plugin_id": "customs-broker-integration",
  "plugin_version": "2.3.0",
  "requires_platform_api": ">=2026-01 <2027-01",
  "extension_points": ["po.approved.v1", "po.line_item.ui_slot"],
  "permissions": ["read:purchase_order", "write:po.custom_field"],
  "webhook_endpoints": ["https://broker.example.com/hooks/po"]
}
```

**PROPOSED defaults** (synthesized from Shopify's calendar-versioning + Salesforce's version-per-release; verify current numbers via `playbook/01-freshness-check.md` since these are policy choices, not physical facts):

| Policy | Default |
|---|---|
| Version cadence | Calendar-quarter API versions (`2026-Q3`), not tied to core software releases |
| Minimum support window | ≥12 months per API version |
| Overlap before removal | ≥9 months (old + new version both live) |
| Deprecation signal | Additive-first; deprecated surface carries `Deprecation` header (RFC 9745) + `Sunset` header (RFC 8594), or manifest-level flag |
| Install-time gate | `requires_platform_api` range checked against tenant's current platform version at install/upgrade — **refuse install**, never fail at runtime (SemVer 2.0.0 range semantics) |
| Changelog | Public, dated, separate from core changelog — one entry per deprecation with migration guide + removal date before it happens |

Failure this prevents: Salesforce managed packages can pin a stale API version and break silently on a retirement wave years later — the build OS must surface each installed plugin's **effective API version** proactively, not wait for breakage (AR4 §5).

---

## 7. The "no customization in core" gate — enforcement, not policy

Policy without enforcement decays. Wire these as CI-blocking checks, not documentation:

| Gate | Mechanism | Blocks |
|---|---|---|
| **Core-path diff gate** | Any diff touching `core/**` or `core.*` schema from a non-core-team PR fails CI automatically; no override short of core-team-only merge | This is the single highest-leverage rule — everything else is instrumentation |
| **Schema boundary linter** | Migration linter rejects any DDL outside the author's owned schema (`core.*` for core team, `ext.*` for extension/tenant code) | Silent core-schema drift from a plugin migration |
| **Runtime sandbox** | Side-by-side/plugin code runs in a separate process/container with only public API + event bus reachable — no DB credentials, no core code import | A plugin process gaining DB access |
| **A/B/C/D classification** | Every extension tagged at build time: A = sanctioned typed-field/side-by-side, B = stable public API only, C = internal/unreleased API (grey zone), D = core fork/direct modification. Dashboard tracks % at each level | D = 0 is release-blocking; C trending to zero is a quarterly KPI (SAP's Clean Core Share KPI, formalized Aug 2025) |
| **Plugin compat gate** | `requires_platform_api` range checked before activation/upgrade | Incompatible plugin blocks *its own* update, never blocks the core upgrade |
| **Deprecation gate** | Core cannot remove a released API/event version until its published sunset date has passed AND telemetry shows the overlap window has been honored | Premature breaking removal |

**Verification hook:** wire the core-path diff gate and schema boundary linter into `scripts/verify-phase.sh` (drift check) so a phase cannot pass verification with a D-level extension present or an `ext.*`-authored DDL touching `core.*`. This is the VERIFIER's job, not the builder's — see `playbook/09-build-loop.md`.

---

## 8. What fails even with the sanctioned surface in place

- **Grey-zone drift (Level C):** deadline pressure pushes teams to internal APIs when the released surface has a gap. Mitigation: every Level-C usage is a logged, owned, release-targeted "extensibility debt" ticket — not just a linter warning.
- **Stale plugin pinning:** an org can be current while an installed plugin's own API version is years stale. Mitigation: surface effective API version per plugin proactively.
- **Un-diffable customization:** config as DB records only (no exported declarative file) is a black box at upgrade. Mitigation: §3 export rule, enforced.
- **Extension-mechanism obsolescence:** even a good sandboxed mechanism (Shopify Scripts) gets deprecated wholesale when it can't scale/secure. Mitigation: §6 versioning policy applies to the *mechanism itself*, not just endpoints — assume any given mechanism has a multi-year but finite lifespan.
- **Synchronous hook creep:** the most common real violation is "just call this webhook synchronously before commit." Default to async event + compensating action (§5); reviewed exception only.

---

## 9. Decision keys to lock at G1

```json
{
  "architecture.extension_model.tenancy_scope": "single-client | multi-tenant-saas",
  "architecture.extension_model.udf_storage": "hybrid-jsonb-plus-typed-sidecar",
  "architecture.extension_model.side_by_side_enabled": true,
  "architecture.extension_model.event_envelope": "cloudevents-1.0.2",
  "architecture.extension_model.webhook_spec": "standard-webhooks",
  "architecture.extension_model.plugin_api_versioning": "calendar-quarter",
  "architecture.extension_model.plugin_support_months_min": 12,
  "architecture.extension_model.plugin_overlap_months_min": 9,
  "architecture.extension_model.core_gate_enforced": true,
  "architecture.extension_model.sync_hooks_allowed": false
}
```

All values above are **PROPOSED** — owner locks the actual values in `_project-instance/project-config/locked-decisions.json` at G1. If `tenancy_scope = single-client` and no plugin/resale ambition exists, owner may lock a reduced scope (§1 UDFs only, skip §4/§6) — record that choice explicitly, don't let it default silently.

---

**NEXT:** `playbook/10-quality-gates.md` (wire the core-path diff gate + A/B/C/D dashboard into gate checks) and `playbook/09-build-loop.md` (verifier enforcement of the schema boundary linter). For the multi-tenancy/RLS layer this boundary sits inside, see `playbook/05-architecture-deployment.md`.
