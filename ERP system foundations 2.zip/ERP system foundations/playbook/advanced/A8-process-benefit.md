---
id: A8
stage: ELICIT + DECIDE (advanced/optional depth) + POST-SHIP
audience: orchestrator, owner (at G1/Gk), builder, verifier
read_when: P02 discovery interview (process capture) and P07 feature selection (backlog gate) for any real (non-throwaway) deployment; re-enter post-go-live for the 12-month benefit-tracking obligation
produces: process.* and value_case.* and benefit_realization_plan.* keys in project-config/locked-decisions.json; a `process/<process_id>.bpmn` file per in-scope process; a machine-checked gate that blocks feature-ticket creation
depends_on: AR8-process-benefit (research), playbook/02-discovery-interview.md, playbook/03-decision-file-spec.md, playbook/07-features-selection.md, playbook/10-quality-gates.md
runs_with: playbook/09-build-loop.md (ticket-creation step), playbook/10-quality-gates.md (verify-phase.sh), scripts/verify-phase.sh
---

# A8 · Process-First & Benefit Realization

## 0. ADOPT-WHEN

**Always, for any real deployment.** Skip only for a throwaway/demo/prototype build with no real budget or business owner behind it — set `process.fit_posture = "skipped_demo"` and move on. Everywhere else this is not optional depth to save time on; it is the single highest-leverage failure point in ERP delivery (Gartner: >70% of ERP initiatives fail to fully meet their original business case by 2027; Prosci: projects with *no* success metrics (26% success) beat projects with *poorly-defined* metrics (7% success) — see AR8-process-benefit §0). A feature built for an unexamined process automates waste and makes it harder to remove, because it now has code, tests, and training material defending it.

**The one law:** *No feature ticket references a `process_id` until that process has a BPMN AS-IS+TO-BE map, a fit/deviation decision, and a scored Value Case. No project is "done" at go-live — it is done when the benefit register shows realized value, tracked for ≥12 months.*

---

## 1. Gate placement in the pipeline

```
 P02 INTERVIEW              P07 FEATURES / DECIDE           BUILD LOOP (P09)         POST-SHIP (≥12mo)
┌───────────────────┐   ┌──────────────────────┐   ┌────────────────────┐   ┌───────────────────────────┐
│ Process Discovery  │──▶│ Gate: process_id may  │──▶│ Feature ticket for  │──▶│ Benefit Realization       │
│ - AS-IS BPMN       │   │ enter backlog only if │   │ process_id X only   │   │ Tracking                  │
│ - TO-BE BPMN       │   │ gate_status = LOCKED  │   │ if X.gate=LOCKED    │   │ - T+30/90/180/365         │
│ - fit_decision     │   │ (§4 validator)        │   │ (CI/ticket-tool     │   │ - escalate on 2x          │
│ - Value Case       │   └──────────────────────┘   │  check, not policy) │   │   AT_RISK/MISSED          │
└───────────────────┘                                └────────────────────┘   └───────────────────────────┘
```

This reuses the repo's existing locked-decision-record gating pattern (`security.*`, `ai_capability.*` locking at G1 in `playbook/advanced/A6-ai-native-operation.md` §1) — `process.*`/`value_case.*` is the same mechanism applied to process/value instead of security tiers.

---

## 2. P02 addition — process capture (BPMN, mandatory before P07)

For every process area the owner names as in-scope (drawn from the P02 module checklist, `playbook/02-discovery-interview.md` §4 Chunk 10), the interview subagent must produce a `.bpmn` file, not a prose description. Standardize on **BPMN 2.0 XML** (OMG spec 2.0.2, stable since Jan 2014 — de facto standard, dual-readable by a stakeholder as a flowchart and parseable by tooling) [AR8 §1.3]. **PROPOSED tool:** `bpmn-js` (bpmn.io, MIT, Camunda-maintained) embedded in interview tooling for AS-IS/TO-BE capture; no vendor lock-in.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
                   id="proc-p2p-invoice-approval" targetNamespace="erp-build-os">
  <bpmn:process id="Process_InvoiceApproval" name="Invoice Approval (AS-IS)" isExecutable="false">
    <bpmn:startEvent id="Start_InvoiceReceived" name="Invoice received"/>
    <bpmn:task id="Task_ManualMatch" name="Manually match to PO (no tolerance rule)"/>
    <bpmn:exclusiveGateway id="Gate_OverThreshold" name="&gt; $5,000?"/>
    <bpmn:task id="Task_CFOApproval" name="CFO approves in person (no delegate)"/>
    <bpmn:task id="Task_Post" name="Post to GL"/>
    <bpmn:endEvent id="End_Posted" name="Invoice posted"/>
    <!-- sequence flows omitted for brevity -->
  </bpmn:process>
</bpmn:definitions>
```

Rules for this step:
1. Annotate AS-IS waste markers in plain text on the task labels (`no tolerance rule`, `no delegate`) — the map exists to be interrogated, not archived.
2. The mapping session **must include the actual process owner and front-line users** — an architect's assumption is a guess with a diagram around it, not a process map (AR8 §4.4).
3. TO-BE is produced in the same session by walking the AS-IS map against the reference/best-practice process for that process category (see `core/features-core.md` for the standard module process shapes, via `knowledge-map.md`).
4. Store as `project-config/process/<process_id>.bpmn`, both AS-IS and TO-BE variants (`<process_id>.asis.bpmn`, `<process_id>.tobe.bpmn`).

---

## 3. Fit-to-standard vs. fit-to-process — the decision rule

**Default posture: conform to reference best-practice. Deviation is the justified exception, never the default.** This generalizes SAP Activate's Fit-to-Standard (F2S) principle beyond SAP: "any proposed customization must be motivated against business value" [AR8 §1.1].

| | Fit-to-standard (default) | Fit-to-process (justified deviation) |
|---|---|---|
| Posture | Business adapts to the reference process | Software/extension adapts to a genuine differentiator |
| When | Commodity function (AP, AR, standard close, standard procurement) | Core competitive differentiator, or a regulatory carve-out standard can't satisfy |
| Cost signal | ~50-60% cheaper, faster rollout | Materially higher cost; ongoing upgrade drag; tracked as technical debt |
| Governance | Record scope item as accepted | **Mandatory written justification tied to quantified business value**, signed by process owner, logged in deviation register |

**Two-question test, applied to every gap found in the AS-IS vs. reference comparison, before any feature ticket opens:**
1. Does this differentiate competitively, or is it legally required in a way standard can't satisfy? If no → fit-to-standard; close the gap by changing the business process, not the software.
2. If yes — what is the quantified value of the deviation, and does it exceed the fully-loaded cost of building + testing + upgrading it forever? If the value case can't be written down, the deviation is **rejected by default**.

`process.fit_decision` ∈ `{fit_to_standard, justified_deviation}`. If `justified_deviation`, `process.deviation_justification` must be non-empty and reference a quantified cost/value comparison — free text is not sufficient; it must cite numbers.

**Verification layer (post-go-live, not design-time):** process mining (Celonis for cross-ERP; SAP Signavio Process Intelligence for SAP shops) compares the actual event-log-derived process against the TO-BE BPMN map — mine what people actually do, don't just trust the interview (AR8 §1.3). Wire this into the same monitoring cadence as §6 benefit checkpoints if the tooling is available; if not, a periodic manual sample against the TO-BE map is the **PROPOSED** fallback.

---

## 4. Value Case — schema object, defined before features

**No feature-building sprint starts until every in-scope process has this object populated with real numbers.** This is the direct fix for Prosci's finding that bad metrics are worse than no metrics — a bad metric creates false confidence and gets gamed (AR8 §2.1).

```yaml
value_case:
  process_id: proc-p2p-invoice-approval
  business_outcome: "Reduce invoice-to-post cycle time and eliminate late-payment penalties"
  baseline:
    metric: days_invoice_to_post
    value: 14.2
    measured_as_of: 2026-06-01
    source: "AP aging report, current ERP export"   # never "estimated"/"anecdotal" — gate fails
  target:
    metric: days_invoice_to_post
    value: 3.0
    by_date: 2027-01-15
  secondary_metrics:
    - { metric: late_payment_penalty_usd_per_qtr, baseline: 18400, target: 0 }
    - { metric: pct_touchless_invoices, baseline: 4, target: 60 }
  owner: "AP Manager — J. Ruiz"          # named individual, not a department
  measurement_method: "Query on invoice.created_at vs gl_posting.posted_at, automated dashboard"
  gate_status: DEFINED   # DEFINED | BASELINED | LOCKED | AT_RISK | REALIZED
```

If a process area cannot produce a real baseline number, that absence is itself a finding: the org doesn't currently measure the thing it wants fixed. The first work item is instrumenting the *current* state, not building the *future* one — do not let the builder skip ahead to features.

### 4.1 Scoring rubric (PROPOSED — owner locks threshold at G1)

Score 0-3 per dimension; gate requires **≥7/12** or an explicit `executive_override` (named approver + written reason).

| Dimension | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| Baseline quality | No baseline | Estimated/anecdotal | One-time report pull | Automated, repeatable query |
| Target specificity | Vague | Directional, no number | Numeric, no date | Numeric + date + named owner |
| Measurability post-launch | No plan | Manual survey only | Semi-automated report | Fully automated dashboard |
| Process fit classification | Not done | AS-IS only | AS-IS + TO-BE | AS-IS + TO-BE + fit decision logged |

A value case scoring below 7/12 with no override is `gate_status: BLOCKED` — no feature ticket may reference its `process_id` (AR8 §2.3, §4.2).

---

## 5. Benefit Realization Plan — live tracking object, ≥12 months

Go-live is not the finish line. Prosci: organizations that stop at go-live "misunderstand when ERP value materializes" — real value surfaces through post-launch refinement measured against the original baseline (AR8 §3.1). **PROPOSED** minimum structure, generated directly from the Value Case at go-live:

```yaml
benefit_realization_plan:
  process_id: proc-p2p-invoice-approval
  value_case_ref: value_case.proc-p2p-invoice-approval
  review_cadence: monthly    # weekly for first 90 days, then monthly to month 12
  dashboards:
    - name: "AP Cycle Time"
      query: "avg(gl_posting.posted_at - invoice.created_at) group by month"
      owner: "AP Manager — J. Ruiz"
  checkpoints:
    - at: T+30d,  expect: "cycle_time <= 10 days (interim)"
    - at: T+90d,  expect: "cycle_time <= 5 days"
    - at: T+180d, expect: "cycle_time <= 3 days (target met)"
    - at: T+365d, expect: "sustained at target; re-baseline if process changed"
  status_states: [ON_TRACK, AT_RISK, MISSED, ESCALATED, REALIZED]
  escalation_rule: "2 consecutive AT_RISK/MISSED checkpoints -> escalate to steering committee with root-cause + remediation plan"
```

### 5.1 Default KPI taxonomy (PROPOSED — don't invent from scratch)

| Category | Example default metrics | Source-of-truth query pattern |
|---|---|---|
| Financial | ROI = (Value − Cost)/Cost; reduced opex; DSO/DPO change | GL + AP/AR aging vs. pre-implementation baseline export |
| Operational efficiency | Cycle time (O2C, P2P, invoice-to-post); inventory turnover; close duration | Timestamp diffs between lifecycle events in ledger/workflow tables |
| Data & process quality | Data entry error rate; % touchless (STP) transactions; exception rate | Validation failure logs; workflow exception queue counts |
| Adoption & experience | Active users/module; satisfaction score; support ticket volume | Auth/session logs; helpdesk ticket tags; pulse survey |

Report financial ROI as a **trend line against the target curve**, not a single pass/fail point — ROI can legitimately take years to fully materialize; a slow-burn benefit at the 90-day checkpoint is `AT_RISK`, not automatically `MISSED` (AR8 §3.3).

---

## 6. Gate P1 — machine-checkable validator (PROPOSED, encode literally)

A process is **LOCKED** (feature tickets may reference its `process_id`) only if **all** of the following are true. Encode this as a literal validator in the decision-record repo (pre-commit-style hook on the backlog schema, or CI check) — not a wiki checklist a human eyeballs and deadline pressure routes around.

```
1. process.bpmn_file (AS-IS) and process.bpmn_file_tobe (TO-BE) exist, parse as valid
   BPMN 2.0 XML, and each has ≥1 start event and ≥1 end event.
2. process.fit_decision ∈ {fit_to_standard, justified_deviation}.
   If justified_deviation: process.deviation_justification is non-empty and
   references a quantified cost/value comparison.
3. value_case.baseline.value is numeric AND value_case.baseline.source ∉
   {"estimated", "anecdotal"}.
4. value_case.target.value, value_case.target.by_date, value_case.owner
   are all populated (owner = named individual).
5. value_case scoring (§4.1) totals >= 7/12 OR value_case.executive_override
   {approver, reason} is populated.
6. benefit_realization_plan.checkpoints contains T+30/90/180/365 entries AND
   >=1 dashboards entry with a runnable query (not "manual only").
```

If any check fails → `gate_status: BLOCKED`; the build loop's ticket-creation step (`playbook/09-build-loop.md`) refuses to open a feature ticket tagged to that `process_id`. Wire this the same way `ai_capability.*` structural floors are wired in `playbook/advanced/A6-ai-native-operation.md` — a code-level check, not policy.

### 6.1 Post-go-live enforcement (the same mechanism, run in reverse)

A `benefit_realization_plan` with **2 consecutive `AT_RISK`/`MISSED`** checkpoint evaluations auto-generates an escalation record requiring a named remediation owner and a revised plan within **15 business days** (PROPOSED, owner locks at G1). Escalations unresolved after 3 checkpoints surface on the same steering-committee dashboard used for security/architecture escalations (`playbook/10-quality-gates.md`) — benefit shortfall is a program risk of the same order as a security finding, not a "business side" conversation engineering never sees.

### 6.2 What this deliberately does NOT allow

- No "we'll define metrics after go-live" — a Value Case created retroactively has no real baseline; the old system's data is stale or the process already changed.
- No BPMN mapping performed by IT alone — process owner + front-line users must be in the room (§2 rule 2).
- No deviation justified by "the vendor's other customers wanted this" — every deviation needs *this org's* quantified value case (§3).

---

## 7. Emit into locked-decisions.json (at G1)

```jsonc
"process": {
  "fit_posture": "PROPOSED: fit_to_standard_default",   // owner locks per process at G1; "skipped_demo" only for throwaway builds
  "proc-p2p-invoice-approval": {
    "bpmn_file": "project-config/process/proc-p2p-invoice-approval.asis.bpmn",
    "bpmn_file_tobe": "project-config/process/proc-p2p-invoice-approval.tobe.bpmn",
    "fit_decision": "fit_to_standard",
    "deviation_justification": null,
    "gate_status": "LOCKED"
  }
},
"benefit": {
  "plan": {
    "proc-p2p-invoice-approval": { "value_case_ref": "value_case.proc-p2p-invoice-approval", "review_cadence": "monthly", "escalation_business_days": 15 }
  },
  "min_tracking_months": 12,          // PROPOSED — owner locks at G1
  "escalation_threshold_consecutive": 2   // PROPOSED
}
```

Every `process_id` selected in `playbook/07-features-selection.md` §2 must have a corresponding `process.<id>` and `value_case.<id>` block before its feature tickets are opened in P09.

---

## 8. Summary table — defaults this doctrine proposes (all PROPOSED, owner locks at G1)

| Decision | Default | Rationale |
|---|---|---|
| Process notation | BPMN 2.0 XML, bpmn-js/Camunda-compatible | Dual-readable, machine-parseable (AR8 §1.3) |
| Default posture on gaps | Fit-to-standard; deviation requires written, quantified justification | SAP Activate F2S, generalized (AR8 §1.2) |
| Feature-build gate | Blocked until BPMN map + Value Case ≥7/12 (or exec override) | Targets Prosci's "bad metrics worse than none" finding |
| Benefit tracking horizon | ≥12 months post go-live, T+30/90/180/365 checkpoints | ROI materializes over years, not weeks |
| Escalation trigger | 2 consecutive AT_RISK/MISSED → remediation plan in 15 business days | Governance rhythm predicts realized benefit, not one-time measurement |
| Verification post-launch | Process mining (Celonis/Signavio or equivalent) vs. TO-BE map | Closes interview-vs-reality gap |

---

**NEXT:** if this is not a throwaway/demo build, route P02 to produce `.bpmn` AS-IS/TO-BE files and Value Case objects for every process named in `playbook/02-discovery-interview.md` §4 Chunk 10 *before* `playbook/07-features-selection.md` opens the module checklist; wire the §6 validator into the ticket-creation step of `playbook/09-build-loop.md` and the 12-month checkpoint schedule into whatever post-ship operations doc the org uses. If the build is genuinely throwaway/demo, set `process.fit_posture = "skipped_demo"` in `locked-decisions.json` and proceed directly to `playbook/07-features-selection.md`.
