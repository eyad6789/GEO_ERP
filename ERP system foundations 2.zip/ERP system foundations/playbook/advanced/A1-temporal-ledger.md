---
id: A1
stage: DECIDE|BUILD
audience: orchestrator, builder (ledger-core module), owner (at G1/Gk)
read_when: P05 architecture chunk if the ADOPT-WHEN trigger fires (§0); mandatory before building the ledger-core module in P09 (see 09-build-loop.md "The ledger core")
produces: architecture.temporal_model, architecture.ledger_store keys (PROPOSED, locked at G1) + the ledger-core module's schema/invariants for its SPEC.md
depends_on: AR1-temporal-ledger, playbook/04-tech-stack.md, playbook/05-architecture-deployment.md, playbook/09-build-loop.md, playbook/10-quality-gates.md, core/architecture.md (§ The Double-Entry Posting Engine, § Audit Immutability, § Concurrency)
runs_with: workflows/build-module.js (module: ledger-core), Gk gate (this module is a default Gk candidate — see 09-build-loop.md)
---

# A1 · The Temporal & Ledger Core

## 0. ADOPT-WHEN

Adopt this doc's patterns **in full for the GL/ledger and any restatable financial sub-ledger** — this is almost always true for an ERP, because restatement, as-of reporting, and audit reconstruction are core ERP requirements, not edge cases. Do **not** reflexively apply bitemporality to every table (§7). Skip straight to `09-build-loop.md` without this doc only for a build with **no financial ledger at all** (e.g. a pure catalog/content system) — vanishingly rare for an ERP.

## 1. Thesis

An ERP is a machine for answering "what did we believe was true, about what point in time, and when did we come to believe it?" The core substrate is **not** current-state tables. It is: **(a)** an append-only event log for money/quantity movements, and **(b)** bitemporal storage (valid-time × transaction-time) for facts with a business-effective date distinct from recording date. Balances, trial balances, aged reports are **projections rebuilt from the log**. Get this right on day one; get it wrong and the ERP's life becomes reconciliation. Full research: `AR1-temporal-ledger`.

## 2. Bitemporality — the highest-leverage decision

| Axis | Answers | Controlled by |
|---|---|---|
| **Valid time** | When is this fact true in the business world? | The business/user |
| **Transaction time** | When did the system record that belief, immutably? | The system, never mutated |

Uni-temporal systems collapse these and lose information the instant reality and recording diverge (backdating, corrections, late invoices) — which is always. Bitemporality (Snodgrass & Jensen 1994; ISO SQL:2011) buys **native restatement**, **as-of reporting** (`WHERE system_time @> :report_date`), **audit reconstruction as a range query**, and **bug forensics** (replay the exact transaction-time slice). The recurring cost of bolting these on later (shadow audit tables, backup-restore reporting) vastly exceeds two range columns up front.

### 2.1 PostgreSQL pattern (PROPOSED default)

**PostgreSQL 18** (verify version currency via `playbook/01-freshness-check.md`) adds native temporal constraints — `PRIMARY KEY`/`UNIQUE ... WITHOUT OVERLAPS` and `FOREIGN KEY ... PERIOD` — but has **no native system-versioned (transaction-time) tables**. Handle the two axes with two different mechanisms:

- **Valid time** → a `tstzrange` column + `WITHOUT OVERLAPS` (PG18 native) or a `btree_gist EXCLUDE` (portable to PG14+).
- **Transaction time** → append-only rows; close by setting `system_time`'s upper bound, never `UPDATE` the fact itself.

```sql
CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE TABLE price (                         -- bitemporal MASTER DATA (not an event log)
    price_id      bigint GENERATED ALWAYS AS IDENTITY,
    sku           text        NOT NULL,
    amount_minor  bigint      NOT NULL,       -- integer minor units, ALWAYS
    currency      char(3)     NOT NULL,
    valid_time    tstzrange   NOT NULL,       -- business-effective window
    system_time   tstzrange   NOT NULL DEFAULT tstzrange(now(), NULL, '[)'),
    recorded_by   text        NOT NULL,
    CONSTRAINT price_no_overlap
      EXCLUDE USING gist (sku WITH =, valid_time WITH &&)
      WHERE (upper_inf(system_time))          -- non-overlap applies only to live knowledge
);
```

**Correction = close + append, never `UPDATE ... SET amount`:**

```sql
BEGIN;
UPDATE price SET system_time = tstzrange(lower(system_time), now(), '[)')
 WHERE sku = 'WIDGET-1' AND upper_inf(system_time);
INSERT INTO price (sku, amount_minor, currency, valid_time, recorded_by)
VALUES ('WIDGET-1', 1899, 'USD', tstzrange('2026-01-01', NULL, '[)'), 'clerk:42');  -- valid_from CAN be in the past
COMMIT;
```

**As-of query — the point of the whole exercise:**

```sql
SELECT amount_minor, currency FROM price
WHERE sku = 'WIDGET-1'
  AND valid_time  @> timestamptz '2026-03-15'   -- effective on this business date
  AND system_time @> timestamptz '2026-04-15';  -- as we knew it on this report-run date
```

**Three patterns, ranked** — (1) append-only + dual `tstzrange` + `btree_gist EXCLUDE` (this doc's default, portable PG14+); (2) layer PG18 `WITHOUT OVERLAPS`/`PERIOD` FKs on top of (1) for the valid-time dimension only — use it, but transaction-time is still hand-rolled; (3) history-table extensions (`periods`, `temporal_tables`) — fine as audit shadowing of an otherwise uni-temporal table, not a substitute for first-class valid-time modeling.

## 3. The boundary discipline (memorize this)

| Event-source it (immutable facts that *happened*) | Bitemporal STATE, not an event stream |
|---|---|
| GL journal postings | Chart of accounts (master data) |
| Inventory movements (receipts, issues, transfers) | Item master, BOMs |
| Payments, receipts, settlements | Customer/vendor master, addresses |
| Invoice issued / credited | Config, tax rates *as current lookup* |

**Rule:** money and quantity movements are events; the nouns they reference are bitemporal master data (§2), referenced by `(id, valid_time)`. Event-sourcing a customer record buys replay complexity with zero audit benefit — nobody restates a phone number the way they restate a ledger.

## 4. Immutable journal — the GL as an event-sourced log

```sql
CREATE TABLE journal_entry (
    entry_id     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    occurred_at  timestamptz NOT NULL,        -- valid time: business-effective date
    recorded_at  timestamptz NOT NULL DEFAULT now(),  -- transaction time: when booked
    description  text NOT NULL,
    source_type  text NOT NULL,               -- lineage: 'ap_invoice','inventory_receipt',...
    source_id    uuid NOT NULL,               -- FK into the originating document; NOT NULL always
    reversed_by  uuid REFERENCES journal_entry(entry_id)   -- corrections = reversing entries, never DELETE
);

CREATE TABLE journal_line (
    line_id      bigint GENERATED ALWAYS AS IDENTITY,
    entry_id     uuid NOT NULL REFERENCES journal_entry(entry_id),
    account_id   bigint NOT NULL REFERENCES account(account_id),
    amount_minor bigint NOT NULL,              -- signed integer minor units; + = debit, - = credit (pick ONE, forever)
    currency     char(3) NOT NULL,             -- ISO 4217 of THIS line
    CHECK (amount_minor <> 0)
);
```

**Money representation, reconciled with `A2-formal-correctness.md` §1 (no contradiction, two pipeline stages):** pre-posting compute — pricing, tax, FX-rate math, proration/allocation — is `NUMERIC(exponent+guard-digit)` / typed `Decimal`, per A2, because intermediate rounding must be controlled before a figure is final. The instant a figure is posted here, it is `bigint` integer minor units, full stop — there is no `NUMERIC` column on the posted ledger, and a posted line is never re-widened back to `NUMERIC` except at report-edge display scaling. Pipeline: compute in `Decimal`/`NUMERIC` → round once (A2 §2's rounding policy) → post as `amount_minor bigint` → done.

**Currency-scoped balance, not entry-naive:** a bare `SUM(amount_minor) per entry_id = 0` is satisfied by, e.g., `+100 USD` and `-100 EUR` on the same entry — that nets apples against oranges and is not a real balance. Two supported shapes, pick one and lock it in `locked-decisions.json` (§10):

- **(a) Single-currency entry — this doc's default.** Every line of an entry shares one `currency`; the trigger below rejects any entry that doesn't. Cross-currency business events decompose into linked entries (e.g., a settlement entry in the customer's currency + a separate FX-gain/loss entry in the functional currency), joined by `source_id`/`reversed_by` — never mixed inside one entry. A row-level `CHECK` can't see sibling rows, so "single currency per entry" is enforced in the statement-level trigger, not a separate constraint.
- **(b) Multi-currency entry with a base leg.** If the ledger's design genuinely requires one entry to carry lines in more than one currency (e.g., both legs of an FX trade in a single posting), add `amount_base_minor bigint NOT NULL` — the functional-currency equivalent, computed once at post time per A2's rounding policy — and assert `SUM(amount_base_minor) per entry_id = 0` in place of the per-currency check for entries that opt into it.

```sql
CREATE OR REPLACE FUNCTION assert_entries_balanced() RETURNS trigger AS $$
DECLARE
  r record;
BEGIN
  -- one pass over only the entry_ids this transaction actually touched, not the whole table
  FOR r IN
    SELECT jl.entry_id,
           jl.currency,
           SUM(jl.amount_minor)                                          AS net_minor,
           COUNT(*)                                                      AS n_lines,
           COUNT(DISTINCT jl.currency) OVER (PARTITION BY jl.entry_id)    AS n_currencies
    FROM journal_line jl
    WHERE jl.entry_id IN (SELECT DISTINCT entry_id FROM new_rows)
    GROUP BY jl.entry_id, jl.currency
  LOOP
    IF r.n_currencies > 1 THEN
      RAISE EXCEPTION 'entry % mixes currencies (%) — split into single-currency entries or add amount_base_minor (§4b)', r.entry_id, r.n_currencies;
    END IF;
    IF r.net_minor <> 0 THEN
      RAISE EXCEPTION 'entry % currency % does not balance: net=% minor units', r.entry_id, r.currency, r.net_minor;
    END IF;
    IF r.n_lines < 2 THEN
      RAISE EXCEPTION 'entry % has % line(s); a posted entry requires >= 2', r.entry_id, r.n_lines;
    END IF;
  END LOOP;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER journal_balanced
AFTER INSERT ON journal_line
DEFERRABLE INITIALLY DEFERRED
REFERENCING NEW TABLE AS new_rows
FOR EACH STATEMENT EXECUTE FUNCTION assert_entries_balanced();
-- balance asserted per (entry_id, currency); single-currency-per-entry enforced; every posted entry has >= 2 lines
```

**Perf:** `FOR EACH STATEMENT` + `REFERENCING NEW TABLE` fires the check **once per statement** (batch all of an entry's lines into one multi-row `INSERT` and it's a single trigger invocation, not N row-level ones), and only re-aggregates the `entry_id`s named in `new_rows` — never a full-table scan. Because the trigger is `DEFERRED`, it runs once at commit regardless of how many separate `INSERT` statements touched the same entry earlier in the transaction; by then `journal_line` holds every line the transaction wrote, so the aggregate is complete even though each statement's own transition table only ever saw its own rows.

**Non-negotiable, ties to `core/architecture.md § The Double-Entry Posting Engine`:** never `UPDATE`/`DELETE` a posted line — corrections are reversing entries via `reversed_by`; money is integer minor units, never float, `NUMERIC`/`Decimal` only pre-posting (A2 §1) or at report-edge scaling; balance is enforced at write time, per `(entry_id, currency)`, by the deferred statement-level trigger, not by application code discipline.

## 5. Balances and reports are rebuildable projections

```sql
CREATE MATERIALIZED VIEW account_balance AS
SELECT jl.account_id, jl.currency, SUM(jl.amount_minor) AS balance_minor, max(je.recorded_at) AS as_of
FROM journal_line jl JOIN journal_entry je USING (entry_id)
GROUP BY jl.account_id, jl.currency;
```

An as-of balance is the same fold filtered by `je.recorded_at <= :cutoff` (transaction-time) and/or `je.occurred_at <= :cutoff` (valid-time). A trial balance is `SUM(amount_minor) GROUP BY currency` across all accounts, which must equal zero — that equality *is* the continuous-close invariant (§6).

**Outbox + CDC, not out-of-band publish:** write the domain change and an `outbox` row in the same transaction; a CDC relay (Debezium — verify version via `playbook/01-freshness-check.md`) tails the WAL and forwards. Delivery is at-least-once, so **every projection consumer must be idempotent** (upsert keyed by `entry_id`/event id).

```sql
INSERT INTO outbox (id, aggregate_type, aggregate_id, event_type, payload)
VALUES (gen_random_uuid(), 'journal_entry', :entry_id, 'EntryPosted', :json);
-- Debezium tails WAL -> broker -> projection consumers (idempotent upsert by event id)
```

Watch the single-outbox-table hot spot under high write throughput; partition/shard the outbox if it becomes a bottleneck. **Snapshot** periodically (default: daily period-end + on-demand once an account crosses ~10k post-snapshot events) so live balance = snapshot + fold of events after the checkpoint. Snapshots are derived and disposable; the log is the only source of truth, and any projection must be rebuildable from zero by full replay.

## 6. Continuous close (shift discovery left, not batch)

A trigger-enforced, event-sourced ledger is balanced by construction — so monitor the invariant continuously instead of discovering imbalance at month-end.

| Invariant | Check | Alert when |
|---|---|---|
| Debits == credits | `SUM(amount_minor)` per currency, all lines | `<> 0` |
| Entry-level balance | per-`(entry_id, currency)` sum (§4) | `<> 0`, or `n_currencies > 1` for a single-currency entry (should be impossible — a breach means the trigger was bypassed) |
| Sub-ledger ↔ GL tie-out | `SUM(AP subledger)` vs GL control account | delta `<> 0` |
| Inventory value ↔ GL | `SUM(movement value)` vs inventory GL account | delta `<> 0` |
| Projection freshness | `max(recorded_at)` in read model vs log head | lag > SLA |

```sql
SELECT currency, SUM(amount_minor) AS imbalance_minor
FROM journal_line GROUP BY currency
HAVING SUM(amount_minor) <> 0;   -- ANY row returned => page on-call; should always be empty
```

**PROPOSED default:** run the full invariant suite every 1–5 min (`pg_cron` or the orchestrator's own scheduler) and alert same-day on drift, carrying the offending `source_id`/`entry_id` so triage starts at the exact event, not a spreadsheet reconciliation.

## 7. Lineage as a first-class API, not a DBA favor

Chain: **report figure → projection rows → journal lines → journal entry → source document (`source_type`,`source_id`) → originating event.** Because postings are immutable and carry mandatory `source_type`/`source_id`, lineage is a join.

```sql
SELECT je.entry_id, je.occurred_at, je.recorded_at, je.source_type, je.source_id,
       jl.account_id, jl.amount_minor, je.description
FROM journal_line jl JOIN journal_entry je USING (entry_id)
WHERE jl.account_id = :account
  AND je.occurred_at <@ tstzrange('2026-01-01','2026-04-01')   -- reported period (valid time)
  AND je.recorded_at <= :report_run_time                        -- as-of knowledge (transaction time)
ORDER BY je.occurred_at;
```

**PROPOSED default:** expose this as a supported drill-down API endpoint on every report/projection, not an ad-hoc query a DBA runs on request. Design rule: every projection row retains the `entry_id`(s) it was folded from; reversals link via `reversed_by` so a number's full history (posted, then corrected) is always reachable.

## 8. Escalation stores — companions, not replacements

| Store | Use when | Caution |
|---|---|---|
| **PostgreSQL 18** (this doc's default) | Always start here | — |
| **XTDB v2** | Bitemporality is *pervasive* (nearly every entity needs both axes) or as-of/time-travel is a *primary product surface*; regulated domains where "immutable by construction" is a compliance argument | Speaks SQL:2011 temporal over the Postgres wire protocol, but production-hardening maturity is `(verify via playbook/01-freshness-check.md)` — load-test before betting the ledger on it |
| **TigerBeetle** | Ledger throughput/safety genuinely exceeds a general RDBMS — millions of transfers/sec, strict double-entry primitives (`accounts`,`transfers`) | Two-primitive model, not a reporting/master-data store; keep Postgres alongside it for that |

**PROPOSED default:** treat both as specialized companions bolted on once proven under load, never the wholesale replacement for Postgres on day one.

## 9. The caution — don't go bitemporal-everywhere

Bitemporality and event sourcing are **taxes**: write amplification, query complexity, mandatory idempotency, more surface for bugs. Apply surgically.

| Full bitemporal + event sourcing | Uni-temporal / plain current-state is fine |
|---|---|
| GL/journal, inventory movements | Session state, caches, feature flags |
| Restatable/legally auditable (prices, tax, payroll rates, contracts) | High-churn telemetry, logs, ephemeral queues |
| Sub-ledgers, revenue recognition | UI preferences, draft/scratch data |
| Regulated master data | Reference lookups never restated |

**Heuristic:** *Will anyone ever restate this, or ask how it looked at a past instant? → bitemporal. Is it a money/quantity movement? → event-sourced immutable log. Otherwise → current-state table + plain `updated_at`.* Reject explicitly: event-sourcing master data; bitemporal-everything by reflex; float money (ever); mutable postings; publishing events without the transactional outbox.

## 10. Proposed defaults → `locked-decisions.json`

All **PROPOSED**, owner locks at G1 (or the module's Gk gate — ledger-core is a default Gk candidate per `09-build-loop.md`). These two keys extend `architecture.*` beyond the base schema in `playbook/templates/locked-decisions.schema.json` — add them to that schema (or record as an allowed extension) before G1, per `03-decision-file-spec.md` §3.

```json
"architecture": {
  "temporal_model": "bitemporal_append_only_pg18",   // PROPOSED default
  "ledger_store": "postgresql_18_event_sourced"        // PROPOSED default; add "+xtdb_v2" / "+tigerbeetle" if §8 fires
}
```

| # | Default | PROPOSED |
|---|---|---|
| 1 | PostgreSQL 18+, `btree_gist` on; money = integer minor units + explicit currency | ✅ |
| 2 | Bitemporal master data: append-only, dual `tstzrange`, correction = close+append; PG18 `WITHOUT OVERLAPS`/`PERIOD` FK for valid-time | ✅ |
| 3 | Event-source only money/quantity movements; master data stays bitemporal state | ✅ |
| 4 | Immutable journal, balanced-by-construction (deferred trigger); reversing entries only | ✅ |
| 5 | Balances/trial balance/aged reports = rebuildable projections; period-end + threshold snapshots | ✅ |
| 6 | Transactional outbox + Debezium CDC; idempotent upsert-keyed projections | ✅ |
| 7 | Continuous invariant monitors every 1–5 min; same-day drift alerts carrying `entry_id`/`source_id` | ✅ |
| 8 | Lineage drill-down as a first-class API endpoint | ✅ |
| 9 | XTDB v2 / TigerBeetle only as proven companions once §8's triggers fire | ✅ |

**NEXT:** `playbook/09-build-loop.md` § "The ledger core" to schedule this as a Gk-gated module; `playbook/10-quality-gates.md` to wire the continuous-close invariants (§6) into the drift/monitoring gate; `playbook/01-freshness-check.md` before locking any version-specific claim above.
