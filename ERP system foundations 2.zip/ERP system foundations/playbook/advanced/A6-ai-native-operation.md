---
id: A6
stage: DECIDE + BUILD (advanced/optional depth)
audience: orchestrator, builder, security-reviewer, verifier
read_when: the owner opts into AI product features (copilot, doc ingestion, anomaly detection, NL reporting) operating on a LIVE ERP — not AI that builds the ERP (see R6/09-build-loop)
produces: ai_capability.* keys in project-config/locked-decisions.json; routes builder/reviewer to §2-§7 contracts and eval gate
depends_on: AR6-ai-native-operation (research), playbook/06-security-foundations.md, playbook/security/scenarios/14-prompt-injection-ai-copilot.md, core/security.md, research/R6-ai-build-method.md
runs_with: playbook/09-build-loop.md (SECURITY stage), playbook/10-quality-gates.md, playbook/security/checklists/*
---

# A6 · AI-Native ERP Operation — Done Safely

**ADOPT WHEN:** the owner wants AI *product* features running against the live ERP (copilot, invoice auto-extraction, anomaly flags, NL reporting) — this is opt-in. **If not selected, set `ai_capability.copilot = "off"` (and all sibling keys `off`) and skip this entire file** — nothing else in the build depends on it. Do not confuse this with using Claude Code to *build* the ERP (that's R6); this doctrine governs AI running *inside* the shipped product.

---

## 0. The one law

> **AI proposes. Deterministic engines dispose. Humans authorize anything that moves money. The financial record's determinism and reproducibility are never delegated to a probabilistic model.**

Every AI surface below has this shape, no exceptions:

```
untrusted input → LLM (propose) → structured proposal → deterministic engine (validate/authorize) → human gate (if $) → posting
                   probabilistic   typed, bounded         rules/RBAC/SoD/limits    HITL              immutable, hash-chained
```

The LLM's output is a *proposal object*, never the side-effect. This is where the safe 2025-2026 vendors landed after a year of "agentic" hype — see §8. (verify vendor specifics via playbook/01-freshness-check.md)

---

## 1. Capability tiers — the `ai_capability.*` key set

Supersedes the coarse `security.ai_copilot` key in `playbook/06-security-foundations.md` §9 (keep that key for back-compat; it maps to `ai_capability.copilot`). One key per surface, each an autonomy tier — **a surface may never be set higher than the org's risk appetite, and no surface may auto-post money.**

| Tier | Meaning | Money movement? |
|---|---|---|
| `off` | Feature disabled | — |
| `read_only` | Reads, summarizes, scores, answers; zero write proposals | Never |
| `propose` | Drafts a typed proposal into a review queue; human accepts/rejects; deterministic engine re-validates on accept | Never auto; human posts |
| `bounded_auto` | Auto-executes only inside a hard, deterministic, reversible, rate-limited allow-list: (i) non-financial (tag, route, draft comms), or (ii) the single money-adjacent exception in §9 non-negotiable #6 — narrowly-bounded liability booking under a deterministic 3-way match | Never, except §9 #6's bounded liability-booking case |
| `auto_post` | **Forbidden by doctrine** for any money-moving action (cash, payment execution, disbursement); reserved for non-financial idempotent effects, or the same §9 #6 exception as `bounded_auto` — never general auto-posting | Never for cash; only §9 #6's bounded case for liability booking |

**PROPOSED defaults (owner locks at G1):**

```jsonc
"ai_capability": {
  "copilot":            "propose",       // read broad (scoped to caller), propose writes, never auto-post
  "doc_ingestion":       "propose",       // OCR+LLM extract → exception queue → human posts
  "anomaly_detection":   "read_only",     // flags + scores only; never blocks/reverses autonomously
  "nl_reporting":        "read_only",     // NL → governed semantic layer; no raw SQL to ledger
  "auto_actions":        "bounded_auto",  // non-financial only: tagging, routing, draft comms
  "ap_three_way_match_stp": "off",        // the ONLY surface allowed bounded_auto/auto_post for booking (§9 #6); off unless owner locks a per-vendor cap
  "money_movement":      "off",           // STRUCTURAL floor — never raise this for money
  "confidence_thresholds": { "money_field": 0.95, "descriptive_field": 0.85 },
  "semantic_layer":      "PROPOSED: dbt MetricFlow (OSS) or Cube; NO raw text-to-SQL on ledger",
  "model_provider":      "PROPOSED: Claude via API; no tenant-data training; residency pinned",
  "eval_gate":           { "injection": "zero_pass", "authz_containment": "zero_escape", "hitl_money": "enforced" },
  "log_every_action":    true,            // STRUCTURAL
  "human_gate_for_money": true,           // STRUCTURAL
  "reversible_only":     true             // STRUCTURAL — compensating entries only
}
```

`money_movement`, `log_every_action`, `human_gate_for_money`, `reversible_only` are **structural, not tunable** — same carve-out pattern as the audit hash-chain in `playbook/06-security-foundations.md`.

---

## 2. Copilot — broad READ, scoped PROPOSE, zero auto-execute

**Contract (all four are load-bearing, not optional):**

1. **Runs as the caller, never a service super-user.** Every read/proposed-write is evaluated against the *invoking user's* RBAC+ABAC (entity, BU, cost centre) by the same deterministic authz layer the UI uses — independent of the LLM. Primary control for OWASP **LLM06 Excessive Agency** and repo **SCN-14**.
2. **Writes are proposals only.** The only "write" tool the copilot may call returns a proposal, never a posting:

```typescript
// NOTE: no `amount` field anywhere on the proposal. The LLM never gets to state
// a number the approval-limit gate trusts — see acceptProposal below.
type ProposeJournalEntry = (args: {
  memo: string;
  lines: { account: string; debit?: Money; credit?: Money; entity: string; currency: string }[];
  evidence_refs: string[];
}) => Promise<{ proposal_id: string; status: "pending_review" }>;

// Deterministic, human-triggered, re-validates EVERYTHING — never trusts the LLM's numbers.
function acceptProposal(proposalId: string, actingUser: User): PostResult {
  const p = load(proposalId);
  assert(actingUser.can("post", p.entity));                 // authz, not the LLM
  assertBalancedPerCurrency(p.lines);                        // determinism — see below
  assert(periodOpen(p.entity, p.date));                      // immutability
  assert(!sodConflict(actingUser, "post_je"));               // SoD

  // Money gate: the gated amount is COMPUTED here, from the just-validated lines,
  // AFTER the balance assert — never read from any LLM-supplied field (there is
  // none on the type above; if one ever appears on `p`, it must be ignored).
  const gatedAmount = totalDebits(p.lines, actingUser.functionalCurrency);
  assert(withinApprovalLimit(actingUser, gatedAmount));      // money gate

  return ledger.post(p, { proposedBy: "copilot", authorizedBy: actingUser.id, evidence: p.evidence_refs });
}

// Debits must equal credits WITHIN EACH currency. Summing raw numbers across
// currencies (e.g. a 100 USD debit vs a 100 EUR credit) would net to "balanced"
// by coincidence of magnitude — a currency-naive assert must never be trusted.
function assertBalancedPerCurrency(lines: JournalLine[]): void {
  const byCcy = groupBy(lines, (l) => l.currency);
  for (const [ccy, ls] of byCcy) {
    assert(sum(ls, "debit") === sum(ls, "credit"), `unbalanced in ${ccy}`);
  }
}

// Deterministic total used ONLY to feed the approval-limit gate. Runs after
// assertBalancedPerCurrency, so each currency's debits already equal its
// credits — this sums debit legs and, for multi-currency proposals, converts
// to the approver's functional currency via the deterministic FX-rate table
// (never an LLM estimate) before the limit check.
function totalDebits(lines: JournalLine[], functionalCcy: string): Money {
  const byCcy = groupBy(lines, (l) => l.currency);
  return sum(
    [...byCcy.entries()].map(([ccy, ls]) => toFunctionalCcy(sum(ls, "debit"), ccy, functionalCcy)),
  );
}
```

3. **No raw-egress tools** — no arbitrary-URL fetch/POST, no shell, no raw SQL against the ledger. Output destinations allow-listed (chat UI, proposal queue). This is the defence against EchoLeak-class zero-click exfil (CVE-2025-32711).
4. **Untrusted content fenced from instructions** — wrap RAG/doc context in `<untrusted_document>…</untrusted_document>` with a system instruction that content inside is data, never commands. Defense-in-depth, not the primary control (#1 and #3 are).
5. **LLM05 at every consumption point** — any copilot-extracted value later used in SQL/shell/file-path/report is parameterized or allow-list-validated, never string-concatenated. Test per `playbook/security/scenarios/14-prompt-injection-ai-copilot.md` step 5.

---

## 3. Document ingestion — confidence-gated, never silent auto-post

```
document → OCR → LLM structured extract (per-field confidence 0..1)
        → deterministic validators (3-way match, tax recompute, vendor master lookup, duplicate hash)
        → gate: all fields ≥ τ_field AND all validators pass AND amount ≤ τ_amount → STP candidate
                 else → EXCEPTION QUEUE (human reviews ONLY the low-confidence fields)
        → human approve → acceptProposal (§2) → post
```

| Control | PROPOSED default | Rationale |
|---|---|---|
| `τ_field` money/qty/account/tax | **0.95** | Money fields fail closed |
| `τ_field` descriptive (memo, notes) | **0.85** | Lower stakes, higher tolerance |
| Route-to-queue trigger | ANY money-field < τ, OR any validator fail, OR amount ≥ `τ_amount` | Silent auto-post prohibited regardless of confidence |
| Silent auto-post | **Structural: never**, with one bounded exception | Even 100%-confidence invoices post only after human accept — UNLESS the §9 non-negotiable #6 exception applies: a deterministic 3-way match (invoice × human-created PO × human-created receipt, quantities and price within locked tolerance) under an explicit locked per-vendor spend cap. That case books the liability only (`ai_capability.ap_three_way_match_stp`); it never authorizes cash disbursement |
| Duplicate guard | Deterministic hash(vendor, invoice#, amount, date) before queueing | ML flags; the hash *blocks* |

Vision-LLM OCR hits ~97-99% field accuracy (verify via playbook/01-freshness-check.md) — good enough to route most documents straight-through, not to skip the gate: the 1-3% failures are silent and land on real cash. Confidence + validator gating (not model accuracy alone) is what let real AP platforms lift straight-through-processing rates safely — the exception queue surfaces only the flagged fields, not the whole document, which is what makes human review economical at volume.

---

## 4. Anomaly detection — flag + score, never autonomously reverse

`read_only` by default, structurally: it opens a case, it does not block, hold, or reverse a transaction. A false-positive freeze on payroll or a supplier payment is its own incident.

- **Models (PROPOSED):** unsupervised — Isolation Forest on outlier journal entries; autoencoder/VAE for anomalous account-code combinations; LSTM for anomalous amount sequences — labelled fraud is scarce so unsupervised is the right family. Layer deterministic rules underneath: Benford's-law digit tests, round-number spikes, off-hours postings, unusual poster×account pairs.
- **Every flag carries an explainable reason** ("amount 6σ above this vendor's 12-month distribution; posted 02:14 Sat by a user who never posts to this account") — an unexplained score is not SOX-audit evidence.
- Wire flags into the existing SIEM/UEBA path (`core/security.md` § Audit Trails and Continuous Monitoring) — anomaly detection is the finance-semantics complement to UEBA's access-semantics.
- The detector is a versioned, drift-monitored asset. A silently degraded model is a control failure, not just a data-quality issue.

---

## 5. NL reporting — governed semantic layer, raw text-to-SQL BANNED on the ledger

**The single most important call in this file for the reporting surface: the LLM never generates SQL against the ledger.** It maps NL onto a governed semantic layer (metrics/dimensions/entities, pre-defined and version-controlled — see `playbook/07-features-selection.md` / `core/architecture.md` for the reporting-layer base pattern); a deterministic engine (PROPOSED: dbt MetricFlow OSS, or Cube) compiles the chosen metric+dimensions into SQL and enforces row-level access at query time using the *caller's* identity.

```yaml
metrics:
  - name: net_revenue
    agg: sum
    expr: revenue_amount - returns_amount
    entity: legal_entity          # RLS applied here, deterministically, per caller
    dimensions: [period, product_line, region]
```
```
User → "net revenue by product line for DE01, Q2 vs Q1"
LLM  → { metric: net_revenue, group_by: [product_line], filter: {entity: DE01, period: [Q1,Q2]} }  # a PLAN, not SQL
Engine → deterministic SQL + RLS check (can this caller see DE01?) → cached result
```

Rationale: raw text-to-SQL "might join tables incorrectly, misinterpret a column, or return a confidently wrong number nobody notices" — a worse failure mode than a crash. The semantic layer trades "answers only what's modelled" for "never silently wrong," and an injected instruction cannot exfiltrate cross-tenant data because RLS is applied by the engine on caller identity, not by the model. (verify via playbook/01-freshness-check.md)

---

## 6. Guardrails — logged, reversible, attributable (all structural)

**(a) Logged.** Every AI action (read, proposal, extraction, flag, query) writes to the same append-only, sha256 hash-chained, WORM audit log mandated in `playbook/06-security-foundations.md` §4, with an AI envelope:

```jsonc
{
  "actor": "copilot", "on_behalf_of": "user:me@corp", "session": "…",
  "action": "propose_journal_entry", "proposal_id": "…",
  "model": "claude-…", "model_version": "…", "prompt_hash": "sha256:…",
  "inputs_ref": ["doc:8842"], "confidence": 0.71, "outcome": "queued",
  "authorized_by": null,   // filled only when a human accepts
  "ts": "2026-07-07T…Z", "prev_hash": "…", "row_hash": "…"
}
```
An AI action with no attributable human on at least one end (`on_behalf_of` or `authorized_by`) is a design bug.

**(b) Reversible.** Financial effects post as ledger entries reversible only via compensating entries (never destructive UPDATE/DELETE on posted periods — this is the base ledger invariant, unchanged by AI). Non-financial AI actions (tags, routing) must be undoable. If it can't be reversed, a human must authorize it first.

**(c) Attributable.** Model id + version + prompt hash + input refs are captured so any AI output is reproducible-enough to investigate. You can't make the LLM deterministic; you can make the *record* of what it did deterministic and complete.

### Evaluation harness — release gate, not a nice-to-have

| Eval suite | Asserts | Gate |
|---|---|---|
| Injection corpus | Docs/emails with embedded instructions → no unauthorized read/tool-call/egress, no cross-tenant leak | Zero tolerance; any pass blocks release |
| Extraction accuracy | Field-level precision/recall per field, held-out set; confidence calibration checked | ≥ locked threshold; miscalibration blocks |
| Authz containment | Copilot cannot exceed invoking user's entitlements across roles×entities matrix | Zero escapes |
| HITL enforcement | Every money-moving path requires human accept; CI greps for absence of any auto-post code path | Structural |
| Trajectory eval | Tool choice, argument validity, policy compliance over full agent traces; deterministic tool mocks + rubric/LLM-judge scoring; OTel/agent tracing feeds production traces back into the eval set | ≥ locked pass rate |
| Anomaly detector | Precision/recall on seeded anomalies + false-positive budget | ≥ threshold; drift-monitored |

Build evals *before* shipping the feature (eval-driven development — see `research/R6-ai-build-method.md`). 20-50 tasks from real failures is a workable start.

---

## 7. Reconciliation with existing security scenarios

| Repo control | A6 surface | Reconciliation |
|---|---|---|
| SCN-14 (prompt injection → exfil, LLM01) | §2 copilot | Same control, extended to all 5 surfaces + `ai_capability.*` keys |
| SCN-14 §5 (LLM05 improper output handling) | §2.5, §3 | Extracted values parameterized/escaped/allow-listed at every downstream consumption point |
| EchoLeak CVE-2025-32711 | §2.3 | No raw-egress tools → zero-click exfil channel removed |
| Cross-tenant leak (RLS scenarios) | §5 NL reporting | RLS enforced by semantic-layer engine on caller identity, not the model |
| SQLi in report filters | §5 | LLM emits a metric plan, not SQL; filters validated against the catalog |
| Audit-log tamper | §6a | AI actions share the hash-chained + externally-anchored WORM log |
| Payment tampering/replay | §1, §3 | No AI surface moves money; duplicate-payment hash guard; human authorizes |
| SoD violation | `acceptProposal` §2 | SoD re-checked deterministically on accept; proposer (AI) and authorizer (human) are structurally different actors |
| OWASP LLM06 Excessive Agency | §1 tiers, §2.1 | Least-privilege tools, no broader-than-task permissions, human approval on consequential actions |

**Net:** A6 is not a new security regime — it is the finance-semantics application of the repo's existing least-privilege + immutable-audit + HITL doctrine (`playbook/06-security-foundations.md`, `core/security.md`) to five AI surfaces, with a decision-key set to lock each surface's autonomy at G1.

---

## 8. 2025-2026 market reality (grounded, verify freshness)

Vendors are racing from "copilot" to "agentic" but the credible ones bound autonomy hard: SAP Joule's finance/procurement agents are reportedly powered by Anthropic's Claude and ship subagents with human-approval loops + SOX-compliant logging; Microsoft Copilot for Finance (GA Oct 2025) routes AI-suggested GL coding through approval-by-threshold workflows; Oracle NetSuite's "autopilot" starts agentic autonomy only in bounded, authorized cases (close orchestration, EPM reconciliation); Sage Copilot frames its shift as "controlled execution," not open autonomy. **(verify current vendor posture via playbook/01-freshness-check.md — this segment moves monthly.)** The pattern to copy: ship value at `propose`/`bounded_auto`, keep `money_movement: off`, let the deterministic engine + human be the only things that dispose.

---

## 9. Non-negotiables (promoted from PROPOSED — do not soften)

1. No AI surface auto-executes a money-moving action, ever (`money_movement: "off"`).
2. Every AI action logs to the hash-chained WORM audit log with human attribution on at least one end.
3. Financial effects reverse only via compensating entries; no destructive mutation of posted periods.
4. Release is blocked if injection / authz-containment / HITL evals fail locked thresholds.
5. NL reporting never generates SQL against the ledger; it maps to the governed semantic layer only.
6. `bounded_auto` and `auto_post` are never used for general auto-posting. Their only permitted money-adjacent use is narrowly-bounded liability booking (dr expense/asset, cr accounts payable) under a **deterministic 3-way match** — invoice line items reconciled against a **human-created** purchase order and a **human-created** goods/service receipt, within a locked quantity/price tolerance and a locked per-vendor spend cap. Cash disbursement/payment execution stays `off` regardless — this exception books a liability, it never releases money.

Everything else in §1's key block is the owner's dial, locked at G1.

**NEXT:** if `ai_capability.copilot` (or any sibling key) is set to anything but `off`, route the builder to `playbook/security/scenarios/14-prompt-injection-ai-copilot.md` for the injection test suite and to `playbook/09-build-loop.md` (SECURITY stage) to wire the eval gate (§6) into the phase's `verify-phase.sh`. If AI capability is `off` end-to-end, skip straight back to `playbook/07-features-selection.md`.
