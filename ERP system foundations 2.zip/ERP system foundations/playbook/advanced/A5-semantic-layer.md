---
id: A5
stage: BUILD
audience: orchestrator, builder, qa-reviewer
read_when: cross-module reporting/KPIs/exec dashboards are in scope (P07 modules include BI, or any two modules feed one dashboard/report) — decide adoption at P07, wire during P09 module builds for GL/AR/AP/Inventory/HR/O2C, gate at Gk before any dashboard ships
produces: reporting.semantic_layer.* keys in locked-decisions.json; semantic_models/<context>/*.yml (git-tracked metric definitions); CI jobs (unit + historical-reconciliation + dimensional-consistency); a certification registry
depends_on: A1-temporal-ledger (as_of_valid_time/as_of_system_time contract), AR5-semantic-layer (research track), core/architecture.md § The Double-Entry Posting Engine, core/architecture.md § Audit Immutability, knowledge-map.md
runs_with: workflows/build-module.js (per bounded-context semantic model), scripts/verify-phase.sh (metric CI gate)
---

# A5 · The One-Number Problem — A Governed Semantic/Metrics Layer

**ADOPT WHEN:** the build has ≥2 modules whose numbers land on the same dashboard, board deck, or exec KPI screen (revenue, DSO, margin, headcount, inventory turns) — true for almost every ERP past a single-module MVP. **SKIP/DEFER** only for a single-module build with no cross-module reporting requirement (e.g., a standalone AP-only tool) — add this the moment a second module's numbers need to reconcile with the first's.

## 1. The problem this solves

Two dashboards showing different "revenue" is not usually a data bug — it's **definition drift**: the same English word bound to two different computations. Five entry points recur in every ERP (full anatomy: `AR5-semantic-layer.md` §1):

| Drift type | Example | Fixed by |
|---|---|---|
| Grain/join-path | order-line fact vs. invoice-header fact | one semantic model, one join path |
| Filter/scope | "active customer" = Sales' 90-day window vs. Support's "live contract" | named, certified filter in the metric def |
| **Temporal-cut** (ERP-specific) | "AR as of June 30" = corrected-today vs. as-reported-at-close | `as_of_valid_time` + `as_of_system_time` params (§5) |
| Aggregation-function | DSO ending-balance vs. average-AR method | certified formula + `definition_note` |
| Recency/currency | stale spreadsheet extract vs. live query | single query surface, no ad hoc extracts |

The fix: **define every metric once, in version-controlled code, and force every consumer to call it by name** rather than re-deriving SQL. This is the headless-BI / semantic-layer pattern.

## 2. Architecture — the query surface every report goes through

```
raw operational tables / event log (ledger)  ← OLTP, mutable, read by A1's bitemporal views
        │
semantic models (entities, dimensions, measures) — one file set per bounded context
        │
governed metrics (simple / ratio / derived / cumulative)
        │
query surfaces: SQL · REST · GraphQL · MCP (agents) · JDBC/ODBC (BI tools)
        │
consumers: BI dashboards · finance close workbook · AI copilot · embedded widget
```

**Rule:** no consumer (dashboard, spreadsheet, AI copilot, embedded widget) queries raw tables for a named business metric. Every one calls the semantic layer by metric name + dimensional slice + time grain + temporal cut. This is the single mechanical guarantee that produces "the one number." Enforce it structurally: raw schemas are not granted to BI/reporting service accounts — only the semantic layer's query surface is.

## 3. Engine choice **PROPOSED**

| # | Choice | Why |
|---|---|---|
| 1 | **Cube Core** (open-source) as primary query surface | Queries the operational store directly (not warehouse-only), ships pre-aggregation/caching for operational-latency dashboards, exposes SQL/REST/GraphQL + **MCP** (agents discover certified metrics by name) out of the box |
| 2 | **dbt Semantic Layer / MetricFlow** as metrics-as-code authoring layer, feeding Cube (or standing alone) if the org is already dbt-centric | Metrics-as-code compiled to SQL; ties certification to existing dbt tests/docs; not mutually exclusive with Cube — MetricFlow can be the compiler, Cube the server |

Owner locks the engine at **Gk** (module-level gate) alongside the module set that first needs cross-module reporting — do not leave it undecided into HARDEN. Full 2026 tool landscape (AtScale, Looker/LookML, Databricks Metric Views, Snowflake Semantic Views, Malloy/Honeydew/Omni) and the Open Semantic Interchange (OSI) portability initiative: `AR5-semantic-layer.md` §3. **Do not depend on OSI conformance in production** — spec published 2026-01-27, cross-vendor conformance unverifiable as of 2026-07 (verify via `playbook/01-freshness-check.md`). Author metric YAML in plain diffable code, not a vendor's proprietary project format, so an OSI export later is a translation, not a rewrite.

## 4. Metric definitions — one file set per bounded context

Do **not** build one monolithic `metrics.yml`. Each module owns its semantic model and certified metrics; the module owner is the metric's data steward. Cross-module metrics are **derived metrics** that reference upstream certified metrics, never raw tables directly.

| Bounded context | File | Owner (steward) |
|---|---|---|
| GL | `semantic_models/gl/*.yml` | Finance data team |
| AR/AP | `semantic_models/ar_ap/*.yml` | Finance data team |
| Inventory | `semantic_models/inventory/*.yml` | Supply-chain owner |
| HR | `semantic_models/hr/*.yml` | People/HR data team |
| O2C | `semantic_models/o2c/*.yml` | Revenue/Sales-ops owner |

```yaml
# semantic_models/ar_ap/ar.yml (MetricFlow-style sketch)
semantic_models:
  - name: ar_invoice
    model: ref('fct_ar_invoice')
    defaults: { agg_time_dimension: invoice_date }
    entities:
      - {name: customer, type: foreign}
      - {name: invoice, type: primary}
    dimensions:
      - {name: invoice_date, type: time, type_params: {time_granularity: day}}
      - {name: business_unit, type: categorical}
    measures:
      - {name: invoice_amount, agg: sum, expr: amount_local_ccy}
      - name: ar_open_balance
        agg: sum
        expr: open_balance   # reads A1's bitemporal view at valid_time = query as_of
        agg_time_dimension: invoice_date

metrics:
  - name: revenue
    type: simple
    type_params: {measure: invoice_amount}
    meta: {certified: true, owner: finance_data_team, certified_on: "2026-05-12"}

  - name: dso
    type: derived
    type_params:
      expr: (ar_open_balance / credit_sales_90d) * 90
      metrics: [ar_open_balance, credit_sales_90d]
    meta:
      certified: true
      owner: finance_data_team
      definition_note: >
        Ending-balance method over trailing-90-day credit sales.
        NOT average-AR method — see ADR-014 for why this was chosen.
```

`definition_note` is not decoration: DSO has ≥2 industry-standard formulas that can differ by double-digit days for a seasonal business. The semantic layer's job is to end the argument by publishing which one is canonical, with rationale, so nobody quietly recomputes the other in a spreadsheet.

**Access control is metric-aware, not table-aware.** Row/column policies (e.g., regional controller sees `headcount`/`revenue` by region but not individual comp) attach to the semantic model, per `core/security.md` § Access Control Architecture — do not re-derive RBAC/ABAC design here.

## 5. The A1 tie: every ledger-derived metric is temporal-cut aware

This is the ERP-specific requirement general BI semantic layers miss. If the ledger is event-sourced and bitemporal (per `A1-temporal-ledger.md`), every metric reading from it has an implicit third parameter: **which time axis, which cut?**

Two legitimate, different answers to "what is AR as of June 30":

1. **Corrected/current-knowledge**: `as_of_valid_time = 2026-06-30`, `as_of_system_time = now()` — operational monitoring.
2. **As-reported/audit**: `as_of_valid_time = 2026-06-30`, `as_of_system_time = close_ts('2026-06-30')` — the immutable number from the actual close, required for SOX walkthroughs.

**Mandatory contract**: every time-sensitive measure built on the ledger exposes both `as_of_valid_time` and `as_of_system_time` as first-class metric parameters — never a single unlabeled `as_of`.

```sql
-- bitemporal AR-balance view the metric reads from (not the raw event log directly)
CREATE VIEW v_ar_balance_asof AS
SELECT customer_id, business_unit, sum(amount) AS ar_open_balance
FROM   ar_ledger
FOR PORTION OF valid_time FROM :as_of_valid TO :as_of_valid
FOR SYSTEM_TIME AS OF        :as_of_system
GROUP BY customer_id, business_unit;
```

`dso(as_of_valid_time='2026-06-30', as_of_system_time=close_ts)` and `dso(as_of_valid_time='2026-06-30', as_of_system_time=now())` must both be first-class, nameable, certified queries — never hand-reconstructed bitemporal SQL by a human or an agent.

**Default PROPOSED** (owner locks at Gk, per metric):

| Metric class | Default `as_of_system_time` |
|---|---|
| Financial/reported metrics (revenue, DSO, AR balance used in close) | as-reported — frozen at last period close |
| Operational metrics (open AR aging today, current headcount) | current knowledge — `now()` |

The chosen default per metric is itself certified, documented in `definition_note`, exactly like the DSO formula choice — never left as silent behavior.

Underlying store: native bitemporal engine, or Postgres + `periods` extension (Postgres 18 has no native system-versioning), or SQL Server system-versioned + application-time tables — decided in `A1-temporal-ledger.md`, not re-derived here.

## 6. Certification lifecycle **PROPOSED**

```
draft → proposed → reviewed (data steward) → certified → deprecated
```

| State | Gate | Requirement |
|---|---|---|
| `draft` | none | any engineer/analyst opens a PR with a candidate metric |
| `proposed` | CI (blocking) | unit tests on the SQL; **historical-reconciliation test** against the prior "legacy" number for N periods; **dimensional-consistency test** (slicing by region sums to the whole); ADR-style note on formula choice |
| `certified` | steward sign-off (Gk-class) | module owner merges with `certified: true`, `certified_on` date; badge surfaced in every downstream BI tool/catalog |
| `deprecated` | steward-initiated | old metric stays queryable with a warning banner + pointer to replacement for a grace period — never a silent break |

CI jobs to wire into `scripts/verify-phase.sh` for any phase touching `semantic_models/`:

```bash
# verify-phase.sh addition (semantic layer gate)
metric_unit_tests            || exit 1   # SQL compiles, returns expected shape
metric_historical_reconcile  || exit 1   # matches legacy number for last N periods within tolerance
metric_dimensional_consistency || exit 1 # sum(slices) == total, per dimension
```

**Lineage**: track raw table → semantic model → base measure → metric → derived metric → dashboard as a diffable DAG. A PR changing a base measure must flag every certified metric and dashboard downstream for re-review — treat this as a CI check, not a manual memory task. dbt's DAG/catalog covers metric-to-model lineage natively; pair with OpenLineage-emitting ingest jobs + a catalog (DataHub/Atlan/Select Star) if the build has one, so certification is visible at discovery time, not just query time.

## 7. `locked-decisions.json` keys

```json
{
  "reporting": {
    "semantic_layer": {
      "engine": { "value": "cube_core", "tag": "PROPOSED" },
      "authoring": { "value": "dbt_metricflow", "tag": "PROPOSED", "note": "optional — only if dbt-centric mart already exists" },
      "bounded_contexts": ["gl", "ar_ap", "inventory", "hr", "o2c"],
      "certification_required_for_dashboard": { "value": true, "tag": "PROPOSED" },
      "default_temporal_cut": {
        "financial_metrics": { "value": "as_reported_at_close", "tag": "PROPOSED" },
        "operational_metrics": { "value": "current_knowledge_now", "tag": "PROPOSED" }
      },
      "osi_conformance_dependency": { "value": false, "tag": "PROPOSED", "note": "track only, do not depend on — verify via playbook/01-freshness-check.md" }
    }
  }
}
```

## 8. Build-loop placement

- **P07** (features selection): if ≥2 modules feed shared reporting, add `reporting.semantic_layer.*` cards to the decision file per `playbook/03-decision-file-spec.md` §3 (new section, same card shape).
- **P09** (build loop): each bounded-context semantic model is built as part of that module's build loop (builder → QA ∥ security → verify), not as a separate late-stage BI project. A module is not "done" if it posts to the ledger but has no certified semantic model for its headline metrics.
- **Gk**: certify the first cross-module derived metric (e.g., revenue-per-employee = GL revenue ÷ HR headcount) before any exec dashboard ships — this is the concrete proof the pattern works end-to-end.
- **G2**: no dashboard/report ships against an uncertified metric; `verify-phase.sh` fails closed if a dashboard manifest references a metric without `certified: true`.

**NEXT:** `A1-temporal-ledger.md` for the bitemporal contract this file depends on, then `playbook/09-build-loop.md` to wire the first bounded-context semantic model into a module's build loop.
