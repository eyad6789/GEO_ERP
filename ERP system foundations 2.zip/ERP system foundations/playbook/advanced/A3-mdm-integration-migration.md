---
id: A3
stage: DECIDE + BUILD
audience: orchestrator, builder, researcher
read_when: at P05/P07 if the project has a legacy system to replace OR more than one external data source (nearly always) — decide adoption before P09 builds any MDM/integration/migration module; re-read before writing any ACL adapter or reconciliation job
produces: integration.* and migration.* PROPOSED keys for project-config/locked-decisions.json (requires a schema extension, see §4); canonical MDM schema; ACL contract shape; reconciliation control design + runbook
depends_on: AR3-mdm-integration-migration, research/R8-testing-migration.md (Part B baseline runbook — this file supersedes it when adopted), core/architecture.md (`## Integration & Eventing Architecture`), playbook/07-features-selection.md, playbook/templates/locked-decisions.schema.json
runs_with: playbook/09-build-loop.md, playbook/10-quality-gates.md (gate 9, gate 12), playbook/06-security-foundations.md (audit trail), playbook/03-decision-file-spec.md
---

# A3 · MDM, Integration Contracts, Continuous Reconciled Migration

ERPs rarely fail in the app layer. They fail at the **data seam**: duplicate parties, orphaned GL mappings, a legacy feed silently drifting, a big-bang cutover weekend with no fallback. This file is the advanced-depth doctrine for that seam. One principle underlies all three parts: **legacy and new are both untrusted until reconciled against a control total.**

## 0. ADOPT WHEN

| Signal | Action |
|---|---|
| Replacing/co-existing with any legacy ERP, spreadsheet-of-record, or bolt-on system | **ADOPT** all three parts (§1–§3) |
| >1 external data source feeds any shared entity (customer, vendor, item, GL account) — true for nearly every real build | **ADOPT** §1 (MDM) + §2 (contracts) at minimum |
| Pure greenfield, single data source, no legacy to migrate, <3 external integrations total | **SKIP** — use `research/R8-testing-migration.md` Part B's lighter runbook instead; revisit if a second source appears |
| Financial subledgers (AR/AP/GL/Inventory) in scope for migration | **ADOPT** §3 unconditionally — do not attempt big-bang for money-bearing domains |

Do not adopt this file's full weight for a single-tenant internal tool with one source of truth — that is over-engineering. The orchestrator records the adopt/skip call as a decision card (§4) either way, so it's never silently assumed.

---

## 1. Canonical MDM Layer

### 1.1 Canonical entity model (PROPOSED default schema)

Build one ERP-agnostic canonical schema per shared domain (Party, Item, GL-account-mapping). Party is highest-leverage — shared by AR, AP, procurement, CRM.

```yaml
# canonical-party.schema.yaml
Party:
  id: uuid                 # canonical MDM id — never a foreign system's PK, never reused
  party_type: enum[organization, person]
  golden_name: string
  tax_ids: [{ scheme, value, country }]
  addresses: [{ type: enum[legal,shipping,billing], line1, line2, city, region, postal, country, valid_from, valid_to }]
  identifiers:              # THE integration join key — one row per source system
    - { system: string, external_id: string, external_type: string, confidence: float, last_seen: datetime }
  status: enum[active, merged, deprecated, pending_review]
  survivorship_trace: [{ field, winning_source, rule, timestamp }]
  merged_into: uuid?         # tombstone for dead golden records
```

`identifiers[]` is the single most important decision here: it is what makes §3's reconciliation mechanical rather than bespoke, and what lets old transactions in the legacy system still resolve after a merge. Mirror this shape for `Item` (add `uom_conversions[]`, `bom_role`) and `GLAccountMapping` (add `chart_of_accounts_version`, `mapped_segment_combo`).

### 1.2 Match / merge / survivorship

| Step | PROPOSED default | Note |
|---|---|---|
| Match — deterministic | tax ID + country, exact DUNS/EIN, email domain + name | run first, cheap, high precision |
| Match — probabilistic | **Splink** (Fellegi-Sunter, DuckDB/Spark backend, MIT) | production pedigree incl. 2025 UK Civil Service Award case-linkage system; prefer over hand-rolled fuzzy SQL |
| Match — scale alternative | **Zingg** (Spark-native, active learning) | consider only past Splink's comfortable record-count ceiling |
| Auto-merge | never for financial entities via LLM similarity | LLM output is acceptable only as candidate surfacing in the steward queue — nondeterministic, unauditable, indefensible to an auditor |
| Merge semantics | never destructive; new survivorship-traced golden record; old IDs retained as aliases | `merged_into` tombstone keeps legacy history resolvable |

Survivorship is **per-field**, not per-record, and every field decision writes a `survivorship_trace` row (winning source, rule, timestamp) — an auditor must be able to answer "why does this say NET-30" six months post-launch.

| Field | PROPOSED rule |
|---|---|
| Legal name | most-recent-wins, legal-entity-registry source |
| Tax ID | most-trusted-source-wins (govt registry > CRM > spreadsheet) |
| Address | most-recent-non-null, active/expired banding |
| Payment terms | ERP-of-record wins, never CRM |
| Credit limit | highest-authority-system wins + human approval on conflict |
| Email/phone | most-recent-non-null |

Stewardship queue thresholds (PROPOSED): confidence ≥ 0.98 → auto-merge, logged; 0.80–0.98 → steward review, side-by-side diff; < 0.80 → flagged "possible duplicate," no block on operations; every steward decision feeds back as a labeled pair to the match model; unresolved review items > 30 days escalate to the named data owner.

### 1.3 Data-quality gates block promotion

Golden-record promotion is **gated, not best-effort**: run **Soda Core** or **Great Expectations (GX Core)** declarative expectations (`not_null`, `valid_values`, referential checks, freshness) as a CI gate on every MDM batch run, versioned in git next to the match/merge code — same discipline as unit tests. A failed suite blocks the batch from being published as golden. Golden records publish as an event (`party.golden_record.updated.v1`) to the bus in §2 — never written directly into ERP tables by a side process.

### 1.4 Build vs buy (PROPOSED)

Start hand-rolled: **Splink + dbt + Soda Core + a thin steward UI** — cheap, auditable, and the match/merge code *is* the migration pipeline in §3 (one codebase, not two). Graduate to a commercial MDM platform (Profisee, Semarchy — 2025/2026 Gartner MQ leaders alongside Stibo/Reltio/Informatica; **SAP acquired Reltio March 2026**, a vendor-lock-in signal — verify via `playbook/01-freshness-check.md`) only past ~5 source systems feeding one domain, or when steward volume exceeds a 2-person data team's weekly triage capacity. **AtroCore** is the most credible open-source full-platform contender if a UI-driven tool is needed sooner, but its production track record at MDM specifically (vs. PIM) is thinner — verify via freshness check before committing.

---

## 2. Integration Contract Layer

### 2.1 Anti-corruption layer (ACL) per external system

Every external system (legacy ERP, bank, tax engine, EDI/VAN, e-commerce, CRM, payroll) gets its own ACL: owns the native shape, the canonical event, and the mapping. No downstream service parses a legacy format directly.

```
[Legacy ERP] --native--> [ACL: legacy-erp-adapter] --canonical event--> [Bus] --> [MDM] [New ERP] [Warehouse]
[New ERP]    --native--> [ACL: new-erp-adapter]    --canonical event--> [Bus]
```

During migration both adapters publish the *same* canonical event type — this is what makes §3's shadow reconciliation mechanical. Swapping the legacy ERP later only changes the inbound adapter, never the 40 downstream consumers.

### 2.2 Idempotent, replayable, versioned

| Concern | PROPOSED default |
|---|---|
| Idempotency key | `source_system + source_id + version`, independent of transport; consumers keep a dedupe ledger `(key) -> last_applied_version` |
| Replay | every ACL adapter reproduces the last 90 days of canonical events byte-for-byte from source-of-record (except processing timestamps) — this is the DR and reconciliation backbone |
| CDC transport | **Kafka + Debezium** for DB-backed legacy sources (log-based, no polling load on legacy prod) |
| File/API sources (EDI, SFTP, SOAP) | ACL normalizes to the same canonical schema and publishes to the same bus regardless of how the byte arrived |
| Envelope | **CloudEvents 1.0** (`id`, `source`, `type`, `time`, `dataschema`, `data`) |
| Type versioning | explicit in `type`: `com.acmeco.party.golden_record.updated.v1` → bump to `.v2` on breaking change; never silently mutate `.v1` |
| Catalog | **AsyncAPI 3.0** document is the source of truth for channel/message/schema |
| Registry enforcement | schema registry (Confluent or self-hosted Avro/JSON-Schema) at **`BACKWARD`** compatibility minimum — a producer cannot register a breaking schema without a version bump |

### 2.3 Contract testing gates every ACL deploy

**Pact** (≥v4, supports message/async contracts, not just HTTP) between each ACL and every internal consumer of its canonical events. Run a **Pact Broker** (self-hosted OSS or PactFlow) — every consumer publishes expectations, every ACL verifies against all registered consumers in CI. Concrete merge-blocking gate: **`can-i-deploy`** — an ACL adapter cannot ship unless the Broker confirms every currently-deployed consumer's contract is satisfied by the candidate.

### 2.4 Integration-contract registry (mandatory, not "docs later")

One folder per external system under `integration-contracts/`: `asyncapi.yaml` + `CONTRACT.md` (owner, SLAs, replay runbook link) + Pact Broker pacticipant link. An unregistered integration is an unowned integration — unowned integrations break silently weeks after cutover.

---

## 3. Continuous Reconciled Migration

### 3.1 The bet

The migration pipeline is not a project-end deliverable — it is the **first thing built**, running in production-shadow mode against live legacy from week 1, long before the new ERP is "ready." Inverts the usual plan (build → freeze → migrate → cutover → hope) into: build pipeline → shadow-run daily → reconcile nightly → fix drift continuously → cutover is a config flip, not an event. This targets the big-bang failure mode directly: silent script rot for months, one high-stakes weekend, discovering breaks *after* legacy is decommissioned with no fallback.

### 3.2 Pipeline architecture

```
Legacy ERP (system of record) --CDC/Debezium or scheduled extract--> Landing zone (append-only, immutable)
   --> Transform/canonicalize (dbt) --> MDM match/merge (Splink) --> Golden records
   --> Load (idempotent upsert, keyed by identifiers[]) --> New ERP staging schema
   --> Nightly reconciliation (control totals, tie-outs) --> drift report --> steward/finance review
```

Landing zone is append-only — never mutate raw extracts; this is what lets the whole migration replay when a survivorship rule changes. `dbt` owns canonicalization (SQL-testable, `dbt test` doubles as a DQ gate). Loads are idempotent upserts keyed by `identifiers[]` — rerunning against an unchanged legacy state is a no-op.

### 3.3 Reconciliation control design (three-way, nightly)

| Control | Legacy | Pipeline output | New ERP (post-cutover) | Tolerance |
|---|---|---|---|---|
| AR open balance by customer | SUM(open invoices) | SUM(golden AR) | SUM(AR module) | $0.00 |
| AP open balance by vendor | SUM(open bills) | SUM(golden AP) | SUM(AP module) | $0.00 |
| GL trial balance | debits=credits | same | same | $0.00 |
| Party count | count(active) | count(golden) | count(party) | 0, named-diff list |
| Inventory qty by SKU/location | SUM(qty) | SUM(qty) | SUM(qty) | 0 units or documented in-transit exception |
| Bank cash balance | statement balance | derived balance | GL cash account | $0.00 |

Design rules: **enumerate diffs, never just percentage-match**; classify each as `timing` / `mapping-defect` / `data-quality-defect` (only the last two are steward work items — timing diffs shrink toward zero as batch→CDC-streaming closes the window); publish the run itself as an event (`reconciliation.nightly.completed.v1`), a first-class bus producer, not a side script; cutover readiness is a **rolling metric** — default **14 consecutive clean nights** across all financial controls — reviewed weekly, not a subjective PM judgment call.

### 3.4 Runbook (condensed)

1. **Week 1**: landing zone + CDC/extract for the highest-risk domain (GL + AR/AP) before any new-ERP config work starts.
2. **Week 2–4**: canonical schema + dbt transforms + first-pass MDM rules; nightly reconciliation wired even with the new-ERP side stubbed (validate transform correctness first).
3. **Ongoing from week 4**: nightly job runs unattended; failures page the data team, not the PM. Weekly steward triage.
4. **New ERP available (any env)**: extend pipeline to load new-ERP staging; three-way reconciliation begins — expect a mapping-defect spike; this is the point of starting early, with no time pressure.
5. **T-90 days**: reconciliation daily with a published dashboard; freeze non-essential legacy config (CoA, tax codes) — config drift during countdown is a top real cause of surprise diffs.
6. **T-14 days**: start the rolling clean-nights clock (§3.3).
7. **Cutover weekend**: no bespoke scripts — the same pipeline that ran nightly for months gets pointed "new ERP is source of record for new transactions; legacy read-only." Pipeline keeps running *backward* (new→legacy shape) for 30–60 days as fallback verification, not primary flow.
8. **T+30 to T+60**: decommission legacy only after zero drift for the full window and finance sign-off on final trial-balance tie-out.

### 3.5 Big-bang vs. continuous (put this in front of sponsors)

| | Big-bang | Continuous reconciled |
|---|---|---|
| Migration code first run for real | days before cutover | week 1 |
| Defects found | cutover weekend, under pressure | continuously, months ahead, no pressure |
| Fallback if cutover fails | rollback, redo scripts, lose weeks | none needed — legacy stays authoritative until readiness metric hits |
| Failure mode | silent — surfaces as wrong invoices post-cutover | loud — a failed nightly job, weeks before it matters |

Relation to `research/R8-testing-migration.md` Part B: R8's phase-based runbook (profile → map → ETL → cleanse → mock cutover → reconcile → cutover) is the correct **baseline** for a single, bounded migration event. This file's §3 is the upgrade when the migration must run for months against a live financial system — same reconciliation-control substance (§3.3 ≈ R8 §B.6), but continuous instead of a T-1/T0/T+1 window around one weekend.

---

## 4. locked-decisions.json keys this doc emits

Adopting this file adds two **new top-level objects** to `locked-decisions.json`. The schema's top level is `additionalProperties: false` (`playbook/templates/locked-decisions.schema.json`) — the orchestrator must extend that schema file at G1 before these keys validate; do not add them silently and expect gate 9 (drift check) to pass.

| Key | Example value | PROPOSED default |
|---|---|---|
| `integration.acl_per_source` | `true` | **true** |
| `integration.event_envelope` | `cloudevents_1.0` | **PROPOSED** |
| `integration.cdc_transport` | `kafka_debezium` \| `polling_batch` \| `file_sftp_normalize` | **PROPOSED**: `kafka_debezium` where legacy is DB-backed |
| `integration.contract_testing` | `pact` | **PROPOSED** |
| `integration.schema_registry` | `{tool, compat_mode: backward}` | **PROPOSED** |
| `integration.contract_registry` | `integration-contracts/` (git path) | **PROPOSED** |
| `mdm.match_engine` | `splink` \| `zingg` \| `profisee` \| `semarchy` | **PROPOSED**: `splink` |
| `mdm.dq_gate` | `soda_core` \| `gx_core` | **PROPOSED**: `soda_core` |
| `mdm.golden_record_promotion` | `gated` | **PROPOSED**: `gated` (never best-effort) |
| `migration.mode` | `continuous_shadow` \| `big_bang` | **PROPOSED**: `continuous_shadow` |
| `migration.pipeline_start_phase` | `week_1` | **PROPOSED**: `week_1`, not phase-3 |
| `migration.reconciliation_cadence` | `nightly` | **PROPOSED**: `nightly` |
| `migration.cutover_readiness_metric` | `14_consecutive_clean_nights` | **PROPOSED**: `14` |
| `migration.post_cutover_shadow_days` | `45` | **PROPOSED**: `45` (range 30–60) |

Tag every card `risk_flag: "gk-candidate"` in the P03 decision file — `migration.mode` and `mdm.golden_record_promotion` both gate financial correctness and warrant a module-level **Gk** review before BUILD starts on any subledger-touching module.

---

## Proposed Defaults (summary)

1. **MDM**: canonical Party/Item/GL-mapping schema with `identifiers[]` cross-ref array as the join key; **Splink** match; per-field survivorship with `survivorship_trace`; **Soda Core** gates block golden-record promotion; hand-rolled until >5 sources/domain.
2. **Integration**: one ACL per external system; **CloudEvents 1.0** envelope, **AsyncAPI 3.0** catalog, `BACKWARD`-compat registry; **Debezium** CDC preferred over polling; **Pact + Broker + `can-i-deploy`** gates every ACL deploy; git-based contract registry is mandatory.
3. **Migration**: pipeline built week 1, run continuously as a legacy shadow; append-only landing zone; **dbt** transforms; nightly three-way reconciliation with enumerated, classified diffs; rolling clean-nights readiness metric; 30–60 day reverse-shadow after cutover before legacy decommission.

All defaults above are **PROPOSED** — the owner locks the actual values at G1 via the decision cards in §4.

**NEXT:** if adopting, extend `playbook/templates/locked-decisions.schema.json` with `integration` and `migration` objects, then route to `playbook/09-build-loop.md` to build the ACL/MDM/reconciliation modules as the first BUILD-phase work, ahead of user-facing modules.
