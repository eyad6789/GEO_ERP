---
id: A2-formal-correctness
stage: BUILD
audience: orchestrator, builder, qa-reviewer, verifier
read_when: at G1 (lock rounding/allocation/decision-table defaults) and before building any module that posts, taxes, prices, allocates, or closes money — re-read before wiring P10 gates
produces: rounding-policy table, typed Money value object, DMN table set, golden-reference corpus, optional TLA+/Alloy specs, extended verify-phase.sh gates
depends_on: AR2-formal-correctness (research), core/architecture.md (`## The Double-Entry Posting Engine`, `## Fiscal Calendar`, `## Costing Engines`, `## Concurrency`), playbook/10-quality-gates.md, playbook/09-build-loop.md, project-config/locked-decisions.json
runs_with: playbook/10-quality-gates.md (gates 7/8/12 + new rows), playbook/09-build-loop.md (ledger/tax/pricing/close modules), workflows/build-module.js
---

# A2 · Formal Correctness for the Money Core

> **ADOPT WHEN** the build has a general ledger, tax computation, pricing/discount stacking, proration/allocation, or a period-close lifecycle — i.e. almost every ERP. **SKIP/defer** only for a pure read-only reporting mirror with no money movement of its own, or during pre-G1 throwaway prototyping. Once adopted, it is not optional per-module — it applies to every module that touches money, full stop.

This file does not repeat `core/architecture.md`'s posting-engine/fiscal-calendar sections — it is the **provable-correctness layer on top of them**: numeric discipline, decision tables instead of `if`-chains, model-checked concurrency invariants, and a zero-tolerance regression oracle. Read `AR2-formal-correctness` (research track) for full source citations; anything below marked "(verify)" is fast-moving and must be re-checked per `playbook/01-freshness-check.md` before a real build relies on it.

---

## 1. Decimal/Money discipline — **PROPOSED** default stack

| Layer | Representation | Never |
|---|---|---|
| DB column | `NUMERIC(19,4)` — one extra digit of precision beyond the settlement currency's minor unit | `FLOAT`/`REAL`/`DOUBLE PRECISION` |
| DB column, 3-minor-digit currencies (KWD/BHD/OMR) | `NUMERIC(19,4)` leaves only **one** guard digit here, not two — use higher intermediate precision (e.g. `NUMERIC(23,8)`) for chained compute (tax-on-tax, multi-step allocation), then settle at the currency's exponent | reusing the 2-decimal guard-digit assumption for 3-decimal currencies |
| TS/Node app (locked default stack) | `decimal.js` `Decimal`, constructed from **strings**, not floats | `Number` for any stored/compared/summed amount |
| Wire (REST/tRPC JSON) | `{ amountMinorUnits: 123450, currency: "USD", exponent: 2 }` | bare JSON number for a currency amount |
| Rounding boundary | round only at posting/settlement; book the residual to a rounding-gain/loss account | silently dropping a cent |

**PROPOSED** `Money` value object — reject cross-currency arithmetic at the type level:

```typescript
import Decimal from "decimal.js";

const MINOR_UNIT_EXPONENT: Record<string, number> = {
  USD: 2, EUR: 2, GBP: 2, JPY: 0, KRW: 0, VND: 0, KWD: 3, BHD: 3, OMR: 3,
  // full ISO 4217 table lives in one module — never hardcode "/100" at a call site
};

export class Money {
  private constructor(readonly amount: Decimal, readonly currency: string) {}

  static of(amountString: string, currency: string): Money {
    if (!(currency in MINOR_UNIT_EXPONENT)) throw new Error(`unknown currency ${currency}`);
    return new Money(new Decimal(amountString), currency); // never new Decimal(0.1)
  }

  add(other: Money): Money {
    if (other.currency !== this.currency)
      throw new TypeError(`cannot add ${other.currency} to ${this.currency} — convert via a recorded FX transaction`);
    return new Money(this.amount.plus(other.amount), this.currency);
  }

  toMinorUnits(jurisdiction: string, txnType: string): bigint {
    return BigInt(roundMoney(this.amount, jurisdiction, txnType, MINOR_UNIT_EXPONENT[this.currency])
      .times(new Decimal(10).pow(MINOR_UNIT_EXPONENT[this.currency])).toFixed(0));
  }
}
```

FX conversion is always a recorded transaction (rate, rate source, rate timestamp) — never an inline multiply in display code.

## 2. Rounding policy — a table, not a coder's default

**PROPOSED**: rounding mode is resolved by `(jurisdiction, txn_type)`, looked up, never hardcoded.

```typescript
type RoundMode = "HALF_UP" | "HALF_EVEN" | "DOWN";

const ROUNDING_POLICY: Record<string, RoundMode> = {
  "US|SALES_TAX": "HALF_UP",      // PROPOSED — matches US IRS convention (verify via playbook/01-freshness-check.md)
  "US|GL_POSTING": "HALF_EVEN",   // PROPOSED — unbiased aggregation default
  "EU|VAT":        "HALF_UP",     // PROPOSED — verify per member-state at build time
  "*|GL_POSTING":  "HALF_EVEN",   // PROPOSED — safe fallback
};

function roundMoney(amount: Decimal, jurisdiction: string, txnType: string, exponent: number): Decimal {
  const mode = ROUNDING_POLICY[`${jurisdiction}|${txnType}`] ?? ROUNDING_POLICY["*|GL_POSTING"];
  const modeConst = mode === "HALF_UP" ? Decimal.ROUND_HALF_UP
                   : mode === "DOWN" ? Decimal.ROUND_DOWN : Decimal.ROUND_HALF_EVEN;
  // Pass the mode as toDecimalPlaces' 2nd arg — never Decimal.set({ rounding }). Decimal.set mutates
  // decimal.js' GLOBAL config; under concurrent/async calls with different (jurisdiction, txn_type) the
  // last writer wins for every in-flight computation, which is non-deterministic and breaks the
  // golden-reference oracle's byte-identical guarantee (Section 6).
  return amount.toDecimalPlaces(exponent, modeConst);
}
```

Every rounding call site must resolve through this table — never a bare `.toFixed(2)`. An auditor asking "why did this round up" must get a policy-table row, not "it's the language default."

## 3. Allocation — Largest Remainder Method (mandatory, everywhere money splits)

**PROPOSED**: use Largest Remainder (Hamilton) for every proration/allocation (invoice line split, tax apportionment, revenue-recognition schedules, multi-currency settlement).

```typescript
function allocateLargestRemainder(totalMinorUnits: bigint, weights: Decimal[]): bigint[] {
  // Allocate on the MAGNITUDE, reapply the sign at the end. `.toFixed(0, ROUND_DOWN)` truncates
  // toward zero, not toward -infinity: for a negative total that makes every floor 0-or-less-negative,
  // the "remainder" comes out negative, the distribution loop's `for (k=0; k<Number(remainder); k++)`
  // never executes, and result.reduce(sum) lands short of totalMinorUnits by up to N-1 units — silently
  // destroying money on every credit memo, reversal, or negative-proration allocation. Working on
  // abs(total) keeps floors/remainder non-negative (ROUND_DOWN == ROUND_FLOOR when the value is >= 0),
  // so the distribution loop is correct for both signs.
  const sign = totalMinorUnits < 0n ? -1n : 1n;
  const absTotal = totalMinorUnits < 0n ? -totalMinorUnits : totalMinorUnits;
  const totalWeight = weights.reduce((a, w) => a.plus(w), new Decimal(0));
  const exact = weights.map(w => new Decimal(absTotal.toString()).times(w).div(totalWeight));
  const floors = exact.map(e => BigInt(e.toFixed(0, Decimal.ROUND_DOWN))); // safe: exact is always >= 0 here
  const remainder = absTotal - floors.reduce((a, f) => a + f, 0n); // always >= 0
  const order = exact
    .map((e, i) => ({ i, frac: e.minus(floors[i].toString()) }))
    .sort((a, b) => b.frac.cmp(a.frac) || a.i - b.i); // tie-break: stable secondary key, never insertion order
  const result = [...floors];
  for (let k = 0; k < Number(remainder); k++) result[order[k].i] += 1n;
  return result.map(r => r * sign); // invariant: result.reduce(sum) === totalMinorUnits, always — including negative totals
}
```

**Mandatory CI gate** (fast-check property, wire into `playbook/10-quality-gates.md` gate 7):

```typescript
import fc from "fast-check";
test("allocation never creates or destroys a cent", () =>
  fc.assert(fc.property(
    // Must include negative totals — credit memos, reversals, and negative proration all pass a
    // negative total through this function. A generator sampling only 0n..max never exercises the
    // sign-handling path, so it cannot catch the truncate-toward-zero bug fixed above.
    fc.bigInt({ min: -10_000_000n, max: 10_000_000n }),
    fc.array(fc.integer({ min: 1, max: 1000 }), { minLength: 1, maxLength: 50 }),
    (total, weightInts) => {
      const result = allocateLargestRemainder(total, weightInts.map(w => new Decimal(w)));
      return result.reduce((a, b) => a + b, 0n) === total;
    })));
```

This property test is a **permanent, non-negotiable CI gate** on every allocation function — not optional even if the rest of this file is skipped.

## 4. Decision tables replace if-chains — DMN, hit policy `Unique`

| Hit policy | Use for | Effect |
|---|---|---|
| **Unique (U)** — **PROPOSED default** | tax-rate lookup, eligibility gates | engine errors at authoring time on overlap; validates full coverage |
| **Collect (C)** | multi-jurisdiction tax stacking | all matching rules fire, outputs summed |
| **Priority (P)** | discount stacking with precedence | highest-priority match wins |
| **First (F)** | legacy migration only | avoid for new tables — hides gaps |

**PROPOSED** tooling: Camunda 8 DMN engine (commercial+OSS core) or Apache KIE/Drools DMN (OSS, DMN Conformance Level 3) as the reference evaluator — call it via its API/REST from the Node app rather than re-implementing hit-policy semantics by hand. Validate every table against the [DMN TCK](https://github.com/dmn-tck/tck) in CI (verify tool/version via `playbook/01-freshness-check.md`).

**PROPOSED** authoring rule: decision tables are versioned `.dmn` XML files in the repo, reviewed like a schema migration. Effective-dated rule changes (e.g., a tax rate change on a future date) are **new rows** with `valid_from`/`valid_to` columns — never in-place edits, because past periods must re-evaluate identically for restatements/audits.

Wire into `playbook/09-build-loop.md`: any tax/pricing/eligibility module's PLAN(M) step must list which decision tables it introduces/touches; the loop's QA stage runs the engine's overlap/coverage validator before merge.

## 5. Model checking vs. property testing — pick the right tool

| Question | Tool |
|---|---|
| Does allocation/rounding hold over many random inputs? | fast-check / Hypothesis (Section 3) |
| Can concurrent postings to one period, or a close racing an in-flight post, corrupt the ledger? | **TLA+** |
| Is the period state machine missing a transition letting a doc post into a closed period? | **TLA+** (temporal) or Alloy (structural) |
| Do fiscal periods have gaps/overlaps in the calendar data model? | **Alloy** |
| Does a DMN table have gaps/overlapping rules? | the DMN engine's own Unique-hit-policy validator (Section 4), not a general model checker |

**PROPOSED**: hand-author (not necessarily CI-automated) a TLA+ spec for exactly three subsystems, and no more — this is a scalpel, not a general design tool:
1. period open/close/lock lifecycle,
2. the posting-commit protocol (the close-vs-post race, double-post under retries),
3. multi-currency settlement concurrency, if settlement is distributed.

```tla
\* Abbreviated — full spec in AR2-formal-correctness research file, Section 3.2
CommitPost(d, p) ==
    /\ d \in pendingPost
    /\ periodState[p] = "OPEN"        \* MUST re-check here, not assume from BeginPost
    /\ postedDocs' = postedDocs \cup {d}
    /\ pendingPost' = pendingPost \ {d}

NoPostToClosedPeriod == \A d \in postedDocs : DocPeriod(d) \notin ClosedPeriods
```

The value is TLC finding, in minutes, the interleaving where `BeginPost` succeeds under `OPEN` while a concurrent `CloseHard` fires and `CommitPost` naively reuses the stale check — a bug class random testing needs a precisely-timed harness to hit by chance.

**PROPOSED**: translate the same invariant into a fast-check/Hypothesis **stateful** model (`fc.commands` / `RuleBasedStateMachine`) that runs on every CI build — the formal spec is the design-time proof, the property test is the regression guard that catches a future code change violating the already-proven design. Keep both; they are complementary, not redundant.

## 6. The Golden-Reference Oracle — highest-leverage correctness artifact

**Definition**: a fixed, versioned corpus of input transactions paired with **exact expected financial statements**, diffed to the minor unit with zero tolerance.

```
/golden-reference/
  scenarios/
    001-simple-cash-sale/{input/transactions.json, expected/trial_balance.json, expected/p_and_l.json}
    002-multi-currency-fx-revaluation/...
    003-prorated-subscription-largest-remainder/...
    004-period-close-late-arriving-invoice/...
    005-multi-jurisdiction-tax-stack-collect/...
    006-13-period-fiscal-year-rollover/...
    007-reversal-credit-memo-round-trip/...
  runner/replay_and_diff.ts     # deterministic clock/FX/IDs; replays vs. current build
```

**Non-negotiable determinism**: frozen `now()`, frozen FX fixture rates (never live), frozen ID generation, frozen rounding-policy inputs. A passing run means **byte-identical** amounts per account per period — not "within a cent." An intentional rule/rate change requires an explicit, reviewed update to `expected/` in the same PR, visible to a **named financial/product approver**, not only an engineering approver — this makes "we changed the tax logic" a reviewable financial-statement diff.

**PROPOSED gate wiring**: run on every PR touching `ledger/`, `tax/`, `pricing/`, `period-close/`; as a release gate before any tagged build; after every DMN table change (Section 4) and every rounding-policy change (Section 2).

## 7. Three dates, never conflated

| Date | Meaning | Controlled by |
|---|---|---|
| Document date | date on the source business document | counterparty/business event |
| Posting date | which GL period the amount lands in | accountant/system, constrained by period-lock state |
| System/entry date | DB row creation timestamp | system clock — forensic only, never used in calculation |

A June document date with a July posting date is valid (late-arriving invoice); a posting date into a `HARD_CLOSE`/`LOCKED` period must be **impossible**, enforced at the DB, not only in an `if`:

```sql
-- PROPOSED: trigger-level guard (a CHECK constraint alone can't join to period state)
CREATE OR REPLACE FUNCTION enforce_period_lock() RETURNS trigger AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM fiscal_period fp
             WHERE fp.id = NEW.posting_period_id AND fp.state IN ('HARD_CLOSE','LOCKED')) THEN
    RAISE EXCEPTION 'posting_date % falls in a closed period %', NEW.posting_date, NEW.posting_period_id;
  END IF;
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_period_lock BEFORE INSERT OR UPDATE ON gl_journal_line
  FOR EACH ROW EXECUTE FUNCTION enforce_period_lock();
```

## 8. Fiscal calendars as versioned config, not code forks

**PROPOSED**: `FiscalYear { periods: Period[] }`, `Period { number, start_date, end_date, type: OPERATING | ADJUSTMENT }` as its own entity, decoupled from the posting engine — see `core/architecture.md`'s `## Fiscal Calendar` section for the base schema. This file adds: 4-4-5 (4/4/5-week quarters), 13-period (13×4wk), and a synthetic **Period 13** (adjustment-only, year-end) are all **configuration** of the same entity, never a fork in application code (verify current-year specifics via `playbook/01-freshness-check.md`). Validate structurally with Alloy once at design time: periods within a year are contiguous, non-overlapping, and exhaustive over the year's date range.

## 9. Period state machine

```
DRAFT/FUTURE → OPEN → SOFT_CLOSE → HARD_CLOSE → LOCKED
                 ↑_____________________|  (REOPEN: logged, elevated-approval only)
```

`OPEN` normal posting · `SOFT_CLOSE` adjustment-only · `HARD_CLOSE` no postings, statements final, feeds the golden-reference comparison · `LOCKED` = HARD_CLOSE + compliance flag. `REOPEN` is always a **new, logged transition** (`REOPENED_FROM_LOCKED_BY: user, reason, ticket`) emitting its own audit event — never a silent revert.

**PROPOSED close checklist**: soft-close → run allocation jobs and assert `sum(allocated)==sum(source)` inside the job itself → run decision tables and diff against prior period's table version for unintentional drift → run the golden-reference scenarios for this period type as a pre-hard-close gate → hard-close and snapshot trial balance immutably (hash-chained, per `core/architecture.md`'s `## Audit Immutability`) → optional lock.

---

## 10. Wiring into the DoD (`playbook/10-quality-gates.md`)

| New/extended check | Gate | `locked-decisions.json.verify` key |
|---|---|---|
| Allocation sum-preservation property test | extends gate 7 (tests) | `verify.test` includes the fast-check suite |
| Rounding-policy table coverage (every call site resolves through it, no bare `.toFixed`) | extends gate 6 (orphan/dead-code) + a grep gate | new: `verify.rounding_policy_grep` |
| DMN table Unique-hit-policy validation + TCK conformance | new row, blocks merge on any tax/pricing/eligibility PR | new: `verify.decision_table_validate` |
| Golden-reference zero-tolerance diff | new row, blocks PR + release | new: `verify.golden_reference` |
| Period-lock trigger present & tested (cannot post into HARD_CLOSE/LOCKED) | extends gate 12 (smoke) | `verify.smoke` includes this scenario |
| TLA+/Alloy specs exist for the three named subsystems (Section 5) | one-time design-time check, not per-PR CI | tracked in `progress/state.json`, not `verify.*` |

All four new `verify.*` keys are **required, not optional** for any module tagged `ledger`/`tax`/`pricing`/`period-close` in the module inventory — an empty key still **fails** per P10's fail-closed rule. The three wholly-new keys this doc introduces — `verify.rounding_policy_grep`, `verify.decision_table_validate`, `verify.golden_reference` — are not self-registering: the wiring pass adds their command/exit-code contract to `verify-commands.map.json` and the `locked-decisions.json.verify` schema (per `playbook/10-quality-gates.md`) before P10 will recognize them; a module that references a key not yet present in that map fails closed, same as an empty key.

## Proposed Defaults — Summary

| Area | Default |
|---|---|
| Wire/DB/app money types | integer minor units / `NUMERIC(19,4)` / `decimal.js` `Decimal`, never `float` |
| Rounding | `(jurisdiction, txn_type)` policy table; `HALF_EVEN` GL default, `HALF_UP` US tax |
| Allocation | Largest Remainder Method + mandatory `sum(parts)==total` property test |
| Currency | ISO 4217 exponent lookup + typed `Money`, no cross-currency arithmetic |
| Rule logic | DMN, hit policy `Unique` default; Camunda 8 or Apache KIE/Drools DMN engine; TCK-validated |
| Concurrency proofs | TLA+ for period-close + posting-commit race; Alloy for fiscal-calendar structure — 3 subsystems only |
| Everyday regression | fast-check/Hypothesis stateful tests mirroring the same invariants, every CI build |
| Regression oracle | golden-reference corpus, zero-tolerance minor-unit diff, gated on every money-touching PR |
| Fiscal calendar | 4-4-5 / 13-period / monthly + adjustment period as versioned data, not code forks |
| Dates | document / posting / system, distinct fields; posting blocked at HARD_CLOSE/LOCKED by a DB trigger |
| Period lifecycle | OPEN → SOFT_CLOSE → HARD_CLOSE → LOCKED, logged elevated-approval REOPEN |

Owner locks every **PROPOSED** item above at G1 alongside the rest of `locked-decisions.json`.

**NEXT:** `playbook/10-quality-gates.md` to wire the new gate rows, then back to `playbook/09-build-loop.md` to build the ledger-core module under this discipline.
