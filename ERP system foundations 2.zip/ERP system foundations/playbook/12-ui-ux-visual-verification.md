---
id: P12
stage: BUILD
audience: orchestrator, builder, design-qa-reviewer, verifier
read_when: before building ANY module with a rendered surface (i.e. almost every module); mandatory before that module's phase can be marked done
produces: design.ui_toolchain + design.visual_baseline keys in locked-decisions.json; verify.ui_verify gate; the per-phase screenshot + written multimodal assessment artifact
depends_on: AR9-uiux-visual-verification, playbook/08-design-system.md (tokens, two-surface model), playbook/09-build-loop.md (the loop this stage inserts into), playbook/10-quality-gates.md (Definition of Done), playbook/templates/locked-decisions.schema.json
runs_with: playbook/templates/verify-phase.sh, scripts/ui-verify.sh (invoked by verify.ui_verify per verify-commands.map.json), workflows/build-module.js (UI tier), Playwright MCP (browser_navigate/snapshot/take_screenshot/click/fill_form)
---

# 12 · UI/UX Excellence + Visual Verification (Enforced)

## 0. ADOPT-WHEN

**Adopt this doc in full for every module that renders a screen a human looks at** — this is nearly every ERP module. The only modules that skip it are pure backend/data/integration modules with zero rendered surface (a batch job, a webhook receiver, a migration script). If a module has even one screen, route, or component, this doc's gate applies to it. Do not let "it's just an internal tool" or "we'll polish it later" waive this — §1 explains why that reasoning kills adoption.

## 1. Thesis: "functions" ≠ "usable" — and this is existential, not cosmetic

A functionally perfect ERP with mediocre UI is a **failed** ERP. The CFO, the AP clerk, and the auditor who decide whether the system was worth building cannot read your event-sourced ledger, your RLS policies, or your green test suite — they judge the *entire system* by the screen in front of them. Adoption is a UX function, not a feature-count function: friction (extra clicks, dead-ends, cognitive load) is the top reason ERP rollouts stall. Perceived value is visual. A clean approvals inbox *is* the ROI story to a non-technical stakeholder.

The corollary for an AI builder: **an AI that never looks at the screen it generated is shipping blind.** "It compiles" and "the test is green" are not evidence a UI is usable, or even visible (invisible text, clipped grids, broken dark mode all pass a naive test suite). This doc has two jobs: set a high enterprise-UX bar (§2), and make "I built a UI and never looked at it" **structurally impossible** via an enforced build-loop stage (§3–§5).

Design tokens (color, type, spacing, light/dark) are already specified in `playbook/08-design-system.md` — do not redefine them here. This doc governs behavior, verification, and gates on top of those tokens.

## 2. The enterprise-UX excellence bar

An ERP screen is a data-dense workbench an expert lives in 8 hours a day — the bar is Linear/Retool/Ramp/SAP Fiori, not a generic SaaS landing page. These are **acceptance criteria**, not enhancements:

| Pattern | Reject ("functions") | DEFAULT bar ("usable/delightful") |
|---|---|---|
| **Data grid** | `<table>` dumps all rows | Virtualized rows (TanStack Virtual / AG Grid), sticky header + frozen first column, resizable/reorderable columns, per-column sort+filter, inline Excel-like edit, right-aligned tabular numerics |
| **Master–detail** | separate page per record | Split view/drawer; list stays as context; deep-linkable URL per record; back preserves scroll+filters |
| **Bulk actions** | one row at a time | Hover-reveal checkboxes, "select all matching filter (N)", sticky action bar on ≥1 selected, optimistic apply + undo toast |
| **Saved views** | filters reset on reload | Named, shareable, per-user + per-team, URL-encoded; "unsaved changes" affordance; default view per role |
| **Keyboard-first** | mouse only | `j/k` nav, `x` select, `/` search focus, `Enter` open, `e` edit, `Esc` close, visible focus ring, full tab order |
| **Command palette** | buried nav menus | `Cmd/Ctrl-K`: jump to any object, run any action, switch company/period — the transaction-code (`/nXXXX`) reborn |
| **Approvals inbox** | scattered per-module queues | One unified inbox, grouped by SLA/age, inline approve/reject with reason, keyboard-drivable, bulk-approve with guardrails |
| **Progressive disclosure** | 60-field form wall | 8 fields that matter; "Advanced" reveals the rest; pre-filled defaults; dependent fields appear on demand |
| **Empty/loading/error** | blank white screen | Empty = onboarding CTA; Loading = skeleton rows (never a bare spinner); Error = cause+retry+support ref; Partial = show what loaded |
| **Responsive** | desktop-only | Grid degrades to card/stacked list on narrow; primary actions never below the fold; touch targets ≥44px |
| **Theme** | light only | `prefers-color-scheme` + `data-theme` override, per `08-design-system.md`; charts/status colors re-mapped, not inverted |

**DEFAULT stance (PROPOSED, owner locks at G1):** every list surface is a real grid with virtualization, saved views, bulk actions, keyboard nav from day one. Every screen ships all four states (empty/loading/error/partial) before it is considered built. No module skips this because it's "internal" or "MVP" — an MVP AP clerk still needs the grid to not die at 10k rows.

## 3. The Visual Verification Loop — the model must SEE and DRIVE

**Core doctrine:** an AI builder may not claim a UI works until it has rendered it, screenshotted it, *looked at the pixels with its own multimodal vision*, driven the flow as a user, and diffed against a baseline. Five stages, enforced in order, inserted into the module build loop (`playbook/09-build-loop.md`) between BUILD and VERIFY:

```
BUILD(M) → [ RENDER → SEE → DRIVE → DIFF → SCORE ] → VERIFY(M)
```

1. **RENDER** — start the app; `browser_navigate` (Playwright MCP) to the built route.
2. **SEE (multimodal self-review)** — `browser_take_screenshot` (`scale:"device"` for Retina-accurate pixels), then the builder *loads that image back into its own context* and grades it against §6. This is the step that makes "shipped a UI I never looked at" impossible — the screenshot goes back into the vision model, not just to disk.
3. **DRIVE** — `browser_snapshot` (accessibility tree — cheap, structured, the agent's *hands*) to act: `browser_click` / `browser_fill_form` / `browser_type` / `browser_press_key` through the happy path AND one error path. Confirm empty/loading/error states actually render, not just that code paths exist.
4. **DIFF** — `expect(page).toHaveScreenshot()` against the committed baseline (Playwright native); fail on unexpected pixel drift.
5. **SCORE** — emit the §6 rubric score in writing, with cited evidence, in the phase output. Below threshold blocks the phase.

**Screenshot vs. snapshot — use both, deliberately.** The a11y snapshot is the agent's hands (~2–5 KB, 20–50× cheaper — use for acting). The screenshot is the agent's eyes (expensive, pixel-truth — the only thing that catches "white text on white background", overlap, clipped tables, broken dark mode). A visual-regression diff alone catches only *changes from* a baseline — but the first baseline could itself be broken. Only a multimodal look catches broken-but-stable. The gate requires **both**: subjective multimodal review (new/first-time breakage) and objective pixel diff (regressions).

**The orchestrator MUST require, in the phase output:** the screenshot artifact itself, plus the builder's written multimodal assessment of it, citing specific pixel evidence (not "looks fine"). A phase whose output lacks a looked-at screenshot is auto-rejected — same fail-closed posture as `10-quality-gates.md`'s "no done by assertion."

## 4. Tooling — the 2026 concrete stack

| Layer | Tool | Role in loop | Notes |
|---|---|---|---|
| E2E driver | **Playwright Test** (`@playwright/test`) | RENDER+DRIVE+DIFF | Auto-wait, trace viewer, component testing; `toHaveScreenshot()` waits for network-idle + frozen animations, diffs via pixelmatch |
| Agent browser | **Playwright MCP** (v0.0.77+) | RENDER+SEE+DRIVE | `browser_navigate/snapshot/take_screenshot/click/fill_form/type/press_key/console_messages/network_requests` — lets the *agent* observe and act live, not just a fixed test script |
| Visual regression | **Playwright native `toHaveScreenshot`** (DEFAULT, PROPOSED) | DIFF | Free, zero-dep, local; baselines in `*-snapshots/`, keyed by browser+platform |
| Visual regression (hosted, optional) | Chromatic / Percy | DIFF + human review | Add **only** when a design team needs hosted approval UI or Storybook-level component coverage. Do not adopt before native snapshots are green — premature |
| Accessibility | **@axe-core/playwright** | SCORE gate | `AxeBuilder`, tags `wcag2a,wcag2aa,wcag21aa,wcag22aa` → target **WCAG 2.2 AA**, zero violations |
| Accessibility (audit) | Lighthouse a11y / Pa11y | secondary SCORE | Broad audit, not a substitute for axe assertions |
| Performance | **Lighthouse CI** | SCORE gate | Budget (verify via `playbook/01-freshness-check.md`): **accessibility ≥0.95, LCP < 2.5s, CLS < 0.1, TBT < 200ms** at p75. Lighthouse is a *lab* tool — it cannot measure the field metric INP directly, so **TBT is the enforced lab proxy for INP**; track real-user INP via CrUX/RUM as an **advisory** signal reviewed at gate time, not a lab-blocking assertion. TBT/heavy main-thread work is the usual failure point and data grids are the usual culprit |

**Visual regression call (PROPOSED default):** Playwright native `toHaveScreenshot()`. Reach for Chromatic/Percy only for hosted human-approval workflows or Storybook design-system coverage.

**Determinism config (PROPOSED) — `playwright.config.ts`:**
```ts
export default defineConfig({
  expect: { toHaveScreenshot: {
    maxDiffPixelRatio: 0.01, animations: 'disabled', caret: 'hide', scale: 'css',
  }},
  use: { timezoneId: 'UTC', locale: 'en-US' },
  projects: [
    { name: 'light', use: { colorScheme: 'light' } },
    { name: 'dark',  use: { colorScheme: 'dark'  } },
  ],
});
```

**Visual + a11y + interaction in one spec** — mask volatile ERP data (timestamps, running balances) so diffs stay stable:
```ts
test('invoices grid — visual + a11y + interaction', async ({ page }) => {
  await page.goto('/ap/invoices?view=needs-approval');
  await expect(page.getByRole('grid')).toBeVisible();
  // DRIVE
  await page.getByPlaceholder('Search').fill('vendor:acme');
  await page.getByRole('row').nth(1).getByRole('checkbox').check();
  await expect(page.getByRole('toolbar', { name: 'Bulk actions' })).toBeVisible();
  // DIFF
  await expect(page).toHaveScreenshot('invoices-needs-approval.png', {
    mask: [page.locator('[data-col="posted_at"], [data-col="balance"]')],
  });
  // SCORE (a11y)
  const a11y = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']).analyze();
  expect(a11y.violations, JSON.stringify(a11y.violations, null, 2)).toEqual([]);
});
```

**CI hygiene:** pin the Playwright container image (`mcr.microsoft.com/playwright:vX-jammy`) so font rendering is byte-stable dev↔CI — font hinting is the #1 source of false-positive diffs. Run visual + a11y as **required** status checks; store trace-viewer traces + screenshots as CI artifacts on every failure.

## 5. Wiring into the Build OS

### 5a. Extended module loop (see `09-build-loop.md` §"The loop")
Insert the UI stage between BUILD and VERIFY, and add a **design-qa-reviewer** role alongside qa-reviewer/security-reviewer for any module with a rendered surface:

```
BUILD(M) → [ UI STAGE: render→SEE→DRIVE→DIFF→SCORE ] → QA(M) ∥ SECURITY(M) ∥ DESIGN-QA(M) → VERIFY(M)
```
- **design-qa-reviewer** (Sonnet-max, fresh context, sees the diff + the screenshots + §6 rubric): re-scores independently — the builder's self-score is not sufficient on its own, same "never certifies itself" principle as QA/SECURITY. Runs in parallel with QA and SECURITY; a design-qa fail bounces to BUILD before VERIFY, same 3-bounce cap as `09-build-loop.md`.

**UI-vs-non-UI is a per-phase declaration, not a grep.** Stage 0 of `09-build-loop.md` writes each module's `SPEC.md`; that file MUST declare an explicit `has_ui: true|false` field for the phase. `scripts/ui-verify.sh` and the orchestrator both read **that field**, never a repo-wide grep for `.tsx`/route files — a grep is both a false-negative risk (a UI hidden behind a codegen layer) and a false-positive risk (a stray fixture file). If `SPEC.md` omits `has_ui`, that is a **FATAL** stage-0 error (fail-closed, per `10-quality-gates.md`) — the phase cannot proceed to BUILD until the owner/orchestrator states it explicitly. `has_ui: false` still requires the explicit `true # N/A: no UI in this module` waiver in `locked-decisions.json.verify.ui_verify` — the SPEC.md flag and the verify waiver must agree, and `scripts/ui-verify.sh` refuses to run (or waive) silently if they disagree.

### 5b. `scripts/ui-verify.sh` — the concrete, shipped UI gate
`verify.ui_verify` (required key, `locked-decisions.json`) resolves to `bash scripts/ui-verify.sh "$PHASE"` per `playbook/templates/verify-commands.map.json`; the template shipped by the wiring pass lives at `playbook/templates/verify-phase.sh` alongside a `scripts/ui-verify.sh` template. For every phase where `SPEC.md` declares `has_ui: true`, the script runs the following, **in order, any non-zero exit BLOCKS the phase**:

```bash
#!/usr/bin/env bash
# scripts/ui-verify.sh <phase-id> — runs only when SPEC.md's has_ui: true.
set -euo pipefail
PHASE="${1:?usage: ui-verify.sh <phase-id>}"

echo "▶ Test-existence gate — @visual and @a11y specs must EXIST, not merely pass"
VISUAL_N="$(npx playwright test --grep @visual --list 2>/dev/null | grep -c ' › ' || true)"
A11Y_N="$(npx playwright test --grep @a11y   --list 2>/dev/null | grep -c ' › ' || true)"
[ "${VISUAL_N:-0}" -ge 1 ] || { echo "FATAL: 0 @visual tests found for phase $PHASE — a UI phase with no visual spec is unverified, not passing"; exit 3; }
[ "${A11Y_N:-0}"   -ge 1 ] || { echo "FATAL: 0 @a11y tests found for phase $PHASE — a UI phase with no a11y spec is unverified, not passing"; exit 3; }
# Never rely on the runner's own "no tests found" behavior as a pass — Playwright/Jest
# `passWithNoTests` (or an empty --grep match) exits 0 with zero assertions run. The
# explicit count check above is what turns that silent no-op into a hard FAIL.

echo "▶ E2E + interaction (happy + error paths, light+dark) — $VISUAL_N visual, $A11Y_N a11y specs"
npx playwright test --project=light --project=dark --grep @ui

echo "▶ Visual regression vs committed baseline (no --update-snapshots in CI)"
npx playwright test --grep @visual

echo "▶ Accessibility — axe WCAG 2.2 AA (wcag2a,wcag2aa,wcag21aa,wcag22aa), zero violations"
npx playwright test --grep @a11y

echo "▶ Performance budget — a11y≥0.95, LCP<2.5s, CLS<0.1, TBT<200ms (lab proxy for INP; field INP advisory only)"
npx lhci autorun \
  --assert.assertions.categories:accessibility=0.95 \
  --assert.assertions.largest-contentful-paint=2500 \
  --assert.assertions.cumulative-layout-shift=0.1 \
  --assert.assertions.total-blocking-time=200

echo "▶ Design-QA gate — an evidenced ≥85 PASS must already be on record for this phase"
DQA="progress/reviews/${PHASE}-design.md"
[ -f "$DQA" ] || { echo "FATAL: $DQA missing — design-qa-reviewer must record its scored review before ui-verify can pass"; exit 3; }
grep -Eq '^\s*(PASS)\s*\(([89][0-9]|100)/100\)' "$DQA" || { echo "FATAL: $DQA does not contain a PASS at >=85/100"; exit 3; }
grep -Eiq 'scale.*device|device.*scale|device-scale screenshot' "$DQA" || { echo "FATAL: $DQA does not reference a device-scale screenshot as evidence"; exit 3; }
echo "  ok: $DQA — PASS on record, device-scale screenshot cited"
```

**Baseline governance — the first commit is a look, not just a snapshot.** A diff-only visual-regression gate catches drift from a baseline, but the very first commit of any baseline has nothing to diff against — a broken-but-stable screen (invisible text, clipped grid, broken dark mode) would commit clean and stay "green" forever after. So: **the first commit of any `*-snapshots/` baseline file MUST carry, in the same PR/commit, a `progress/reviews/${PHASE}-design.md` recording a design-qa-reviewer multimodal PASS** (≥85/100, evidenced, per §6) **against that exact baseline image** — `scripts/ui-verify.sh` refuses a first-time baseline add (a new file under `*-snapshots/` with no prior git history) unless that PASS record exists and cites the new baseline's filename. Subsequent updates to an already-reviewed baseline follow the existing rule below (explicit `--update-snapshots` by a human/reviewer with the diff attached).

Beyond the first commit: snapshot PNGs live in-repo under `*-snapshots/`, code-reviewed like source. Updated **only** via an explicit `--update-snapshots` run by a human/reviewer with the diff attached — never auto-updated in CI (that would let a regression silently become the new "truth").

### 5c. `locked-decisions.json` keys this doc emits (owner locks at G1)
```jsonc
"design": {
  "ui_toolchain": "playwright+playwright-mcp+axe-core+lighthouse-ci",  // PROPOSED
  "visual_baseline": "e2e/__screenshots__/"                             // PROPOSED, path to committed baselines
}
```
These sit alongside the existing `design.tokens`/`design.theme` keys from `08-design-system.md` — same object, no new top-level key.

## 6. Design-QA Rubric — scored, evidence-required, self-graded then re-graded

The builder scores its own screenshot in writing before the phase closes; design-qa-reviewer independently re-scores from the same artifacts. **Pass = ≥85/100 AND no category scores 0.** Any 0 is an automatic block regardless of total. Scores asserted without cited visual evidence (e.g. "row 1 header sticky at y=64; status-pill contrast = 5.1:1") are treated as 0 — this is the mechanism that forces looking, not guessing.

| # | Category | Wt | 0 (block) | 3 | 5 (target) |
|---|---|---|---|---|---|
| 1 | Visibility & legibility | 15 | invisible/low-contrast text, overlap, clipped grid | minor contrast issues | all text ≥4.5:1, nothing clipped, tabular numerics aligned |
| 2 | Data grid quality | 15 | plain dump, no sort/filter | sortable, static | virtualized, sticky header, resize, filter, inline-edit |
| 3 | State coverage | 12 | missing empty/error | some states present | empty+loading(skeleton)+error+partial all present |
| 4 | Keyboard & command palette | 10 | mouse-only | tab order OK | full kbd nav + `Cmd-K` palette + visible focus ring |
| 5 | Bulk actions & saved views | 10 | none | bulk only | bulk + "select all matching" + named URL-encoded views |
| 6 | Accessibility (axe/WCAG 2.2 AA) | 12 | violations > 0 | minor warns | 0 violations, roles/labels/landmarks correct |
| 7 | Consistency w/ `08-design-system.md` tokens | 8 | off-system colors/spacing | mostly on | tokens only; spacing/type scale honored |
| 8 | Responsive & dark/light | 8 | breaks narrow or in dark | one theme solid | both themes + card degrade, targets ≥44px |
| 9 | Performance (CWV) | 6 | TBT>200ms or LCP>2.5s (lab); field INP red in CrUX | borderline | LCP<2.5s, TBT<200ms (lab proxy), CLS<0.1; field INP green (advisory) |
| 10 | Feedback & error affordance | 4 | silent failures | toasts only | optimistic apply + undo, actionable errors w/ ref |

## 7. Recommended DEFAULT (all PROPOSED — owner locks at G1)

- **UI/grid:** React + virtualization-first grid (TanStack Table/Virtual for control; AG Grid Enterprise where Excel-parity is required). Tokens per `08-design-system.md`.
- **Verification stack:** Playwright Test (spine: E2E + component + `toHaveScreenshot`) + Playwright MCP (agent render/see/drive) + `@axe-core/playwright` (WCAG 2.2 AA) + Lighthouse CI (CWV). Chromatic/Percy only if a hosted approval workflow is explicitly needed.
- **The enforced gate:** every UI phase must produce (1) a device-scale screenshot, (2) the builder's written multimodal review against §6 citing evidence, (3) an independent design-qa-reviewer re-score, (4) a green happy+error-path interaction run showing all four states, (5) zero axe violations, (6) a clean visual diff vs. reviewed baseline, (7) CWV within budget. Missing the screenshot-plus-assessment artifact = automatic phase rejection, no exceptions for "internal" or "MVP" screens.

**Bottom line:** you have not built the UI until you have looked at it. Render it, screenshot it, read the pixels back into your own eyes, drive it like the AP clerk will, and diff it against the baseline. Green unit tests are not permission to ship a screen you never saw.

**NEXT:** apply this stage inside `playbook/09-build-loop.md`'s per-module loop for every UI-bearing module; on completion of all modules, proceed to `playbook/10-quality-gates.md` (final hardening) and `playbook/11-deployment-production.md`.
