---
id: P05
stage: DECIDE
audience: orchestrator
read_when: architecture/tenancy/deploy decision chunk (after P04 tech-stack, before P06 security)
produces: architecture.* keys for project-config/decisions.html → locked-decisions.json
depends_on: R4-deployment, R1-security-doctrine, project-config/freshness-report.md
runs_with: playbook/03-decision-file-spec.md
---

# 05 · Architecture & Deployment — The Tenancy Fork + Where It Runs

Two decisions in this chunk are load-bearing and hard to reverse post-BUILD: **tenancy model** (§1) and **deployment topology** (§2). Get the owner's answer at G1; every downstream module (RLS policies, backup scripts, IaC) derives from it. All defaults below are **PROPOSED** — none are decided until the owner locks them in `locked-decisions.json`.

Knowledge library refs: `core/architecture.md § Multi-Tenancy & Data Partitioning`, `§ Concurrency, Locking & Idempotency`, `§ Audit Immutability & Event Sourcing`. Do not re-derive that content here — only decide+configure.

---

## 1. Tenancy — the biggest architectural fork

Ask first: **is this system one client's dedicated instance, or a SaaS product serving many clients?** Everything else in this section follows from that answer.

| Model | Isolation strength | Cost/density | Noisy-neighbor risk | Best for |
|---|---|---|---|---|
| **Single-tenant** (one dedicated stack per client) | Strongest — physical | Highest per-client cost | None (own box) | One client, regulated/high-trust clients, simplest compliance story |
| **Shared schema + RLS** (`tenant_id` column, Postgres Row-Level Security) | Medium — depends on correct RLS | Highest density, cheapest | Worst (shared everything) | SaaS with many small/self-serve tenants |
| **Schema-per-tenant** | Medium-high | Medium; migration fan-out pain at 1000s of tenants | Moderate | Mid-market SaaS, moderate tenant count |
| **Database-per-tenant** | Strongest (physical) | Lowest density, highest ops cost | Best | Enterprise/regulated/BYOK tenants |

**PROPOSED default:** single-tenant per client for a bespoke client build (the common case in this playbook). **PROPOSED default for a SaaS product:** pooled shared-schema+RLS as the base tier, with a documented **bridge/graduation path** to schema-per-tenant or DB-per-tenant for enterprise/regulated/BYOK tenants — do not commit to pure-pooled or pure-siloed at the outset; most B2B SaaS ERPs need both. (R1 §3, R4 §6)

### 1.1 If multi-tenant: the isolation contract (non-negotiable, not a style choice)

Whichever pooled model is chosen, these are enforced, not optional:

- `ALTER TABLE … ENABLE ROW LEVEL SECURITY; ALTER TABLE … FORCE ROW LEVEL SECURITY;` on **every** tenant-scoped table. `FORCE` matters — without it the table owner still bypasses RLS.
- App connects as a **non-owner, non-superuser** role. `BYPASSRLS` reserved strictly for migration jobs, never the app role.
- Tenant context set with `SET LOCAL app.tenant_id = '…'` **inside the transaction** — never `SET` (persists across a pooled connection and leaks into the next request).
- Every policy has both `USING` and `WITH CHECK` — `WITH CHECK` is what stops a tenant INSERTing rows tagged with another tenant's id.
- Composite indexes lead with `tenant_id`.
- CI test (wired at P10 gate 9, drift linter) asserts every table with a `tenant_id` column has RLS + `FORCE` set — a missing policy on a new table is a silent full leak.

Canonical pattern (from R1 §3 — implement verbatim, don't reinvent):
```sql
ALTER TABLE journal_entry ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entry FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON journal_entry
  USING (tenant_id = current_setting('app.tenant_id')::uuid)
  WITH CHECK (tenant_id = current_setting('app.tenant_id')::uuid);
-- per request, inside the txn:
SET LOCAL app.tenant_id = '…';
```

**Per-tenant DEKs + noisy-neighbor quotas (multi-tenant only):**
- Give each tenant its **own data-encryption key (DEK)**, wrapped by a shared KEK in KMS/HSM — a key compromise or BYOK revocation is then blast-radius-limited to one tenant. Pair BYOK with DB-per-tenant for enterprise carve-outs.
- Enforce **per-tenant resource quotas**: query timeout, connection-pool cap, background-job concurrency, API rate limit — so one tenant's month-end batch cannot starve everyone else.

### 1.2 Failure modes to design against (all verified real, R1 §3)

| Failure mode | Cause | Default mitigation |
|---|---|---|
| Connection-pool context leak | `SET` instead of `SET LOCAL` for tenant GUC | `SET LOCAL` always; reset on pool checkout |
| BYPASSRLS / owner bypass | Superuser or table-owner role ignores RLS | App role is non-owner/non-superuser; `FORCE ROW LEVEL SECURITY` |
| Missing policy on new table | Migration adds a `tenant_id` table without a policy | CI test asserting RLS+FORCE coverage on every such table |
| Index without `tenant_id` lead | Composite index ordered wrong | Lead every composite index with `tenant_id` |
| Noisy neighbor | No per-tenant quota | Query timeout + connection cap + rate limit per tenant |

**architecture.tenancy** emits one of: `single_tenant | multi_tenant`. If `multi_tenant`, also emit the isolation model chosen (`pooled_rls | schema_per_tenant | db_per_tenant | bridge`) as a sub-key for P09 module ordering and P10's drift linter.

---

## 2. Deployment topology

### 2.1 Chooser matrix

| Driver | Local on-prem | LAN-only/air-gapped | Single VPS | Cloud managed | Hybrid |
|---|---|---|---|---|---|
| No/unreliable internet | best fit | fits | — | — | partial |
| Regulatory/data-sovereignty hard requirement | fits | best fit | conditional | fits (region-pin + BAA) | fits |
| Lowest fixed monthly cost | fits (no recurring fee) | fits | fits (cheapest *hosted*) | — | — |
| Someone else owns hardware/power/network | — | — | fits | fits | partial |
| Single client, 1-150 users, no HA SLA | fits | if regulated | **default** | overkill | overkill |
| Multi-tenant SaaS fleet | — | — | early MVP only | **default** | — |
| Built-in automated failover/PITR required | manual | manual | manual scripting | fits | secondary only |
| Client wants full data control + cloud DR | — | — | — | — | **default** |
| No dedicated ops/platform engineer on the team | fits | fits | fits | conditional | risky |

Don't pick a topology because it "sounds serious" — pick it against a named driver in the row above. (R4 §2)

### 2.2 Sizing tiers (Postgres-backed ERP)

| Tier | Users | vCPU | RAM | Storage | Postgres `shared_buffers` |
|---|---|---|---|---|---|
| Micro | ≤10 | 2 | 4-8 GB | 40-80 GB SSD | 1-2 GB |
| Small | 10-50 | 2-4 | 8-16 GB | 80-160 GB NVMe | 2-4 GB |
| Medium | 50-150 | 4-8 | 16-32 GB | 160-500 GB NVMe, RAID1/10 | 4-8 GB |
| Large | 150+ | 8+ (split app/DB hosts) | 32 GB+ per host | 500 GB-2 TB NVMe | separate DB host, tuned per workload |

Above ~100-150 users, or once write contention appears, split app and DB onto separate hosts. Provision ~20% storage headroom for logs/growth regardless of tier. `(verify via playbook/01-freshness-check.md — cost/instance figures drift)`

### 2.3 Backup & DR — the default policy

Baseline: **3-2-1-1-0** — 3 copies, 2 media types, 1 off-site, 1 immutable/air-gapped, 0 errors on a *verified* restore. Ransomware targets backup infra directly (deletes snapshots, encrypts repos, uses stolen creds against backup consoles) — at least one copy must be unreachable from the production admin account.

Implementation: **pgBackRest**, multiple repositories with independent retention — local repo (fast restore) + remote object-storage repo (off-site) + one retention-locked/immutable repo. Automate a scheduled **restore test**, not just a backup-success check — this is the "0" and the most commonly skipped step. **PROPOSED, flag for reconfirmation:** pgBackRest's maintenance status reportedly had a near-lapse around 2026-04 — reconfirm active maintainership/release cadence before locking this at G1 `(verify via playbook/01-freshness-check.md)`.

| Tier | Example workload | RTO | RPO | Mechanism |
|---|---|---|---|---|
| 1 — Mission-critical | Core ledger, invoicing/payments | minutes-1 hr | near-0 to 15 min | continuous WAL archiving + standby / Multi-AZ |
| 2 — Business-critical | Internal reporting, CRM sync, notifications | 1-4 hr | 1-4 hr | scheduled incremental backups + documented restore runbook |
| 3 — Operational | Dev/staging, wikis, archives | 8-24 hr | 24 hr | nightly full backup only |

**PROPOSED default RPO/RTO tier:** Tier 2, unless the workload is explicitly transactional/revenue-critical → escalate to Tier 1 (standby replica or Multi-AZ managed DB). Chasing Tier-1 everywhere is expensive and usually unnecessary for SMB ERP. (R4 §4)

### 2.4 High availability

- **Single VPS/on-prem:** no built-in HA by default. Add a warm-standby with WAL-shipping only if the client's tier justifies it; otherwise HA = fast restore from backup (fine for Tier 2/3).
- **Cloud managed:** Multi-AZ/regional/zone-redundant failover is a checkbox — enable it once a client is Tier 1. It roughly doubles DB cost; don't default to it.
- **Kubernetes:** only once you have ≥3 nodes and a team that can absorb the operational tax (cited at 20-40% of an engineer's time for a small team without a platform group). Not a default HA answer for this playbook's target client profile.

---

## 3. Containerization / IaC baseline

| Layer | PROPOSED default | Escalate when |
|---|---|---|
| Container orchestration | **Docker Compose** — one `docker-compose.yml` for app + DB + reverse proxy + backup sidecar; one `.env` per environment; every image tag pinned (never `:latest` in prod) | 10+ independently-scaled services, real multi-node autoscaling need, or an existing platform team — then multiple Compose hosts behind a shared LB + managed Postgres is the honest middle step before Kubernetes |
| Reverse proxy / TLS | **Caddy** — zero-config automatic HTTPS (ACME/Let's Encrypt), ideal for a single client's VPS | **Traefik** once Docker-label-driven routing across many services/subdomains is needed (per-tenant subdomains → good Traefik fit) |
| IaC | **Terraform** for anything touching a cloud provider (VPC, managed DB, LB, DNS) — even for "just one VPS," so the DR runbook is `terraform apply` + restore latest backup, not tribal knowledge | n/a — always use IaC once a cloud provider is involved |

Mount the reverse-proxy's cert/data volume persistently — losing it on every container restart risks Let's Encrypt rate limits `(verify via playbook/01-freshness-check.md)`.

**Note:** Terraform is BUSL-1.1 licensed (HashiCorp/IBM); OpenTofu (MPL-2.0, Linux Foundation) is a drop-in open-source alternative if licensing is a concern `(verify via playbook/01-freshness-check.md)`.

---

## 4. PROPOSED defaults — decision file entries

Present these as pre-filled, clearly-labeled **PROPOSED** choices in `decisions.html` (P03); the owner accepts or overrides each at G1.

| Key | PROPOSED default | Condition to override |
|---|---|---|
| `architecture.tenancy` | `single_tenant` for a bespoke client build | Owner is building a SaaS product → `multi_tenant` |
| `architecture.multi_tenant_model` (if multi_tenant) | `pooled_rls` (bridge path documented) | Enterprise/regulated tenants known up front → plan `schema_per_tenant`/`db_per_tenant` carve-out from day one |
| `architecture.deployment` | `single_vps` (dedicated-vCPU tier, Docker Compose, Caddy, pgBackRest to 2 off-site targets incl. 1 immutable) | No/poor internet, physical-control preference, or a named regulatory driver → `local_server` or `lan_only`; SaaS fleet → `cloud_managed`; client wants on-prem system-of-record + cloud DR/reporting → `hybrid` |
| `architecture.backup_tier` | `Tier-2` (1-4h RTO/RPO) | Workload is explicitly transactional/revenue-critical → `Tier-1` |
| `architecture.ha` | `false` (no built-in HA) | Client requires a contractual uptime SLA → `true` + standby/Multi-AZ |
| `architecture.containerization` | `docker_compose` | 10+ services, multi-node autoscale, or existing platform team → `kubernetes` (name the specific trigger in the gate) |
| `architecture.reverse_proxy` | `caddy` | Many services/subdomains routed dynamically → `traefik` |
| `architecture.iac` | `terraform` | n/a (always-on once cloud-managed) |

If tenancy or deployment choice is ambiguous or high-stakes (e.g., client hesitant between on-prem and VPS, or SaaS with an unclear enterprise-tenant story), raise it as a **Gk gate** using `playbook/templates/gate.template.md` rather than silently applying the proposed default — this is exactly the kind of fork that's expensive to reverse mid-BUILD.

---

## 5. What P09 (build) needs from this chunk

- `architecture.tenancy` (+ model) determines module order: if `multi_tenant`, RLS + tenant-context middleware is built in the **foundations** wave, before the ledger core.
- `architecture.backup_tier` and `.ha` size the pgBackRest/Terraform scaffolding generated alongside the deployment module.
- `architecture.containerization`/`.reverse_proxy`/`.iac` become the literal templates dropped into the repo (`docker-compose.yml`, `Caddyfile`/`traefik.yml`, `*.tf`) — P11 consumes these at ship time.
- P10's drift linter (gate 9) is generated from `architecture.tenancy`: `multi_tenant` → fail if a tenant-scoped table lacks `tenant_id`+RLS; `single_tenant` → fail if `tenant_id` columns/filters proliferate unnecessarily.

**NEXT:** `playbook/06-security-foundations.md` (security baseline chunk — builds directly on the tenancy isolation contract in §1 above).
