---
id: P11
stage: SHIP
audience: orchestrator, verifier, owner
read_when: after P10's final hardening pass is green; this is the last phase before production
produces: gate G2 approval record, running production system, progress/phase-log.md entry, project-config/gates/answered/G2.md
depends_on: R4-deployment, R8-testing-migration, playbook/05-architecture-deployment.md, playbook/10-quality-gates.md, project-config/locked-decisions.json
runs_with: workflows/adversarial-review.js, playbook/templates/verify-phase.sh
---

# 11 · Deployment & Production — Go-Live (SHIP)

Everything here executes against the `architecture.*` keys already locked in `project-config/locked-decisions.json` (P05). This phase does not re-decide topology, tenancy, or backup tier — it deploys what was locked, proves it works, and cuts real data over. If a locked decision turns out to be wrong here, that is an unscheduled owner-stop (see `09-build-loop.md § Bounce & escalation`), not a silent override.

Knowledge library refs: `core/implementation.md § 6 Go-Live Strategy`, `§ 4 Data Migration`, `§ 11 Post-Go-Live`; `core/cautions.md § 2 Canonical Real-World Failure Cases`, `§ 5 Post-Go-Live Failure Modes` — read the Hershey/National Grid/MillerCoors cases before finalizing the cutover window; every one of them failed on a mistake this file's checklist exists to prevent (peak-season big-bang, happy-path-only testing, unresolved defects at go-live).

---

## 0. Entry condition — do not start P11 unless this is true

`workflows/adversarial-review.js` (the P10 final HARDEN pass) exited clean: full security-scenario sweep, performance run against the locked envelopes, dependency/secret re-audit, owner-facing risk summary all green. **If HARDEN is not green, stop — go back to `10-quality-gates.md`.** Shipping on a red hardening pass is the single most common way an AI-built system reaches production broken.

---

## 1. Gate G2 — production deploy approval (hard gate)

G2 is **hard**: the orchestrator cannot proceed past it on its own judgment. Raise it with `playbook/templates/gate.template.md`, write to `project-config/gates/pending/G2.md`, set `state.json.phase_status = "blocked_on_gate"`, and stop.

**G2 must capture, before the owner can approve:**

| Item | Who supplies it | Why it can't be skipped |
|---|---|---|
| Explicit go-live approval (date/time, named approver) | Owner | This is a business decision (revenue risk, customer impact), not a technical one |
| Production secrets (DB credentials, KMS/vault keys, TLS cert source, third-party API keys — bank, tax engine, payment gateway) | Owner (via vault/KMS, never pasted into chat/files) | The builder must never possess or generate real production secrets |
| Confirmation the HARDEN pass evidence was reviewed | Owner or delegate | G2 is the last human checkpoint before real data/customers are exposed |
| Named rollback authority for cutover day | Owner | Rollback decisions must be pre-authorized, not improvised (R8 §B.7) |

Do not accept "looks good, ship it" as the full G2 record — fill every field in the gate template, including the specific control-total thresholds from §3.1 below that will trigger rollback. Move the answered gate to `project-config/gates/answered/G2.md` once signed.

---

## 2. Production readiness checklist

Run this as a literal checklist in `progress/reviews/P11-readiness.md`; every row needs an evidence pointer (log, screenshot path, command output), not a checkbox alone.

### 2.1 Environment promotion

| Env | Purpose | Rule |
|---|---|---|
| DEV | Active development | Synthetic/masked data only (R8 §A.4) |
| QA | Automated test execution (CI) | Ephemeral/Testcontainers-backed; never hand-edited |
| UAT | Business-user sign-off, mock cutovers | Production-shaped (masked) data; this is where rehearsals in §3 run |
| PROD | Live system | Reached only via this checklist + G2 |

Promotion DEV→QA→UAT→PROD must be the **same artifact** (pinned container image/tag) moving forward, not a rebuild per environment — this is what makes "it passed UAT" mean anything about PROD.

### 2.2 Secrets & config

- All production secrets live in a vault/KMS (per the locked `architecture.iac`/cloud choice — e.g., provider secrets manager, HashiCorp Vault, or at minimum an encrypted `.env` outside the repo). **Never in git, never in a Dockerfile, never in plaintext CI logs.**
- `gitleaks` re-run against the full history immediately before go-live (P10 gate 10 covers per-PR; this is a final full-repo sweep).
- Rotate any secret that ever touched a non-vault surface (a chat transcript, a shared doc, a builder's scratch file) before go-live.

### 2.3 TLS & network

- TLS terminated per the locked reverse-proxy default (`caddy` or `traefik`, `05-architecture-deployment.md §3`); TLS 1.2+, HSTS, forced HTTP→HTTPS.
- Reverse-proxy cert/data volume is persistent storage, not ephemeral — losing it on restart risks ACME rate limits `(verify via playbook/01-freshness-check.md)`.
- Inbound firewall/security groups scoped to 80/443 (+ admin access via VPN/Tailscale/bastion only) — no raw SSH/DB ports exposed to WAN (R4 §3).

### 2.4 Backups proven by a restore test

- Backup implementation matches the locked `architecture.backup_tier` (pgBackRest, 3-2-1-1: local + off-site + one immutable/retention-locked repo).
- **A restore has actually been executed in this environment and verified** — restoring "successfully completing" is not the bar; recovering a real database from the actual backup artifact and confirming row counts/checksums is. This is the "0" in 3-2-1-1-0 and the most commonly skipped step (R4 §4). Log the restore-test evidence path in the readiness review.
- If `architecture.ha = true` (Tier-1): standby replica or Multi-AZ failover has been tested with an actual failover drill, not just configured.

### 2.5 Monitoring, alerting, log aggregation

- Uptime/health check (e.g., external pinger or self-hosted Uptime Kuma) on the public endpoint.
- Structured logging centralized (not just per-container stdout) — CloudWatch/Cloud Logging/Azure Monitor equivalent, or a self-hosted aggregator for on-prem/VPS, so a production incident is debuggable without SSHing to each host.
- Alerting wired for: disk/CPU/memory thresholds, backup job failure, TLS cert expiry, error-rate spike, and (ERP-specific) failed/queued posting-engine jobs and reconciliation-dashboard failures (§3.1).
- DAST (OWASP ZAP) has a nightly job already running against staging per P10 — confirm it is also scheduled against PROD post-launch (§6).

### 2.6 HA per the locked tier

- Re-confirm `architecture.ha` and `architecture.backup_tier` from `locked-decisions.json` match what's actually deployed — this is exactly what P10 gate 9 (drift linter) should have caught, but re-verify manually here since G2 is the last checkpoint before real risk.
- Tier-1 workloads: standby/Multi-AZ confirmed live. Tier-2/3: confirmed that "HA" = fast, tested restore, and that RTO/RPO in the readiness doc matches the locked tier's numbers (`05-architecture-deployment.md §2.3`).

### 2.7 Rollback plan (system-level, distinct from the migration rollback in §3.1)

- A tagged, deployable last-known-good container image/commit exists and is retrievable in under the cutover window's rollback budget.
- IaC (`terraform apply` against the previous state) + restore-from-backup is the documented path — not tribal knowledge (`05-architecture-deployment.md §3`).
- Named rollback authority (from G2) and the specific technical/business triggers that invoke it are written down **before** cutover, not decided live.

---

## 3. Data migration runbook (execute once, rehearse first)

This is the 7-phase pipeline from R8 Part B, generalized for any ERP migration. Every stage transition is gated by the previous stage's exit criteria — do not proceed on a partial pass.

| # | Phase | Exit criteria before proceeding |
|---|---|---|
| 1 | **Profiling** | Data-quality scorecard per entity (customers, vendors, COA, open AR/AP, inventory, fixed assets, open orders) run and reviewed; unbalanced legacy journal entries and negative-inventory conditions specifically flagged, not silently passed over |
| 2 | **Mapping** | Field-by-field source→target mapping documented (transformations, defaults, currency/unit conversions); COA and cost-center/dimension hierarchy mapping has a **named business-owner sign-off** — COA remapping errors are the single most common cause of post-go-live financial-reporting breakage; mapping spec itself is version-controlled and reviewed like code |
| 3 | **Cleanse** | Survivorship/merge rules from Phase 2 applied in a staging schema (never write directly to target); every transformation logged (source value → cleansed value → rule applied); unbalanced legacy entries rebalanced or quarantined to a manual-review queue with a control-total impact report — never force-balanced silently; scorecard re-run and clears threshold |
| 4 | **Mock cutover** | Full dress rehearsal of the actual cutover runbook — same tooling, same people, same timing — run **at least twice** (once at integration-test readiness, once at UAT readiness); at least one rehearsal includes finance approvers and day-one operational users, not just IT; every step's actual duration logged against the planned cutover-window budget |
| 5 | **Reconciliation controls** | See §3.1 below — all controls pass on the mock cutover before the real one is scheduled |
| 6 | **Cutover** | Minute-by-minute runbook with a named owner per task; every external integration (bank feed, tax engine, payment gateway, EDI) explicitly repointed and smoke-tested as its own step; phased domain-by-domain cutover (GL/COA → AR → AP → inventory) preferred over big-bang unless the business genuinely cannot tolerate a longer transition |
| 7 | **Rollback (if triggered)** | Written rollback triggers agreed **before** cutover (specific control-total/reconciliation failures, not "if it feels wrong"); pre-named authority (from G2) makes the call; for regulated/public entities, run a parallel run (both systems live, daily reconciliation) until N consecutive clean cycles pass before decommissioning legacy |

### 3.1 Reconciliation control totals — non-negotiable, each with a named owner

1. **Record counts + amount sums** (debits, credits, AR balance, AP balance, inventory value) captured in the source before extraction; identical totals compared in the target after load. Any variance blocks progression to the next phase.
2. **Three-point row-count check**: source extract → staging → target load, so a mismatch can be localized to the stage that dropped records, not just flagged as "source ≠ target."
3. **Financial tie-out**: `AR + AP + Inventory (+ other subledgers) = GL trial balance` in the target, proven on every mock load. Must balance before go-live proceeds — full stop.
4. **T-1 / T0 / T+1 reconciliation** around the actual cutover moment, with named sign-off at each checkpoint.
5. **Live reconciliation dashboard** during cutover (per-domain AR/AP/Inventory/Fixed-Assets/GL pass-fail against control totals) so the go/no-go call is data-driven, not judgment-based.

**Common failure points to check for explicitly** (compiled in R8 §B.8, all previously observed in the field): COA/dimension remapping errors, unbalanced or duplicate legacy journal entries surfacing only post-cutover, integration endpoints left pointed at legacy staging, reconciliation treated as a one-time event instead of continuous T-1/T0/T+1 control, rollback triggers not defined in advance, mock cutover run only once or without business-user participation, cash reconciliation underestimated (routinely the single biggest bottleneck — R8 §A.5, §B.8).

---

## 5. HARDEN must be green before this phase completes

Re-confirm (do not re-run from scratch if P10 already produced it within this deploy cycle, but do re-run if any code changed since): `workflows/adversarial-review.js` clean — security-scenario sweep, performance run against the locked envelope (including the month-end-close batch window as a first-class SLO per R8 §A.5), dependency/secret re-audit. Attach the evidence path to the G2 record. **No code change lands in PROD without this having run against the exact artifact being deployed.**

---

## 6. Post-go-live hypercare

- Define a **hypercare window** (PROPOSED default: 2 weeks of elevated support — daily stand-up on open defects, on-call engineer, daily reconciliation dashboard check even after cutover formally "completes") before dropping to normal support cadence. Owner locks the exact duration; do not assume it's decided.
- Track defects found post-go-live with the same severity/triage discipline as pre-go-live — "technical go-live is not organizational go-live" (`core/cautions.md § 5`); a system nobody adopts has failed regardless of uptime.
- Keep the ZAP DAST nightly scan and k6 perf check running against PROD (not just staging) through hypercare at minimum.
- Do not decommission the legacy system until: hypercare window closed, N consecutive reconciled cycles clean (parallel-run clients), and the owner explicitly signs off decommissioning as a separate, named decision — this is its own small gate, not an automatic side effect of go-live.

## 7. Recording the deploy

Same triad as every other phase (`00-START-HERE §6`, `09-build-loop.md`):
- `progress/state.json` → mark the build `phase_status: "shipped"`, record the deployed artifact tag/sha.
- `progress/phase-log.md` → append an entry: what was deployed, which `locked-decisions.json` keys governed the deploy topology, the G2 approval reference, HARDEN evidence path, migration reconciliation result (pass + control-total summary), rollback plan location.
- `git commit` (or tag) — `[P11/deploy] production go-live <date> | G2: gates/answered/G2.md | verify: reviews/P11-readiness.md | migration: reconciled`.

Move `project-config/gates/pending/G2.md` → `project-config/gates/answered/G2.md` with the owner's decision filled in, per `gate.template.md`.

---

## 8. PROPOSED defaults summary (all require owner lock at G2, none pre-decided)

| Item | PROPOSED default | Escalate when |
|---|---|---|
| Hypercare window | 2 weeks elevated support | Regulated/high-risk entity → parallel run + longer window |
| Backup restore-test cadence | Quarterly, logged | Tier-1 workload → test alongside every DR drill |
| Cutover style | Phased domain-by-domain (GL→AR→AP→inventory) | Business cannot tolerate a longer transition → big-bang, with correspondingly more rehearsals |
| Rollback authority | Named individual from G2, not the builder/orchestrator | n/a — always a named human |
| Post-cutover DAST/perf cadence | Nightly ZAP + scheduled k6 against PROD through hypercare | n/a |

---

**NEXT:** nothing downstream in this pipeline — P11 is the terminal phase. If new modules are added post-launch, re-enter at `playbook/09-build-loop.md` for that module and re-run this file's readiness checklist (§2) before the next deploy.
