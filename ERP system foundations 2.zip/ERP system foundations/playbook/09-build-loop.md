---
id: P09
stage: BUILD
audience: orchestrator
read_when: for every module you build (the core BUILD loop)
produces: a built, reviewed, verified, committed module
depends_on: R6-ai-build-method, locked-decisions.json
runs_with: workflows/build-module.js
---

# 09 · The Build Loop — Loop Engineering

This is the engine of the BUILD stage. You do not free-form your way through an ERP. You decompose it into **modules**, and run each module through the same fixed loop with a team of agents. The loop is deterministic; the intelligence is in the agents inside it.

## Module decomposition (do this once, right after G1)

From the locked feature/module set (P07), produce an ordered **module inventory** in `progress/state.json`. Order by dependency: foundation first, features on top.

Typical order for an ERP:
1. **Foundations** — data layer, migrations, tenant model + RLS (if multi-tenant), auth/identity (OIDC), the audit-log spine (append-only + hash chain), config/secrets.
2. **The ledger core** — chart of accounts, the double-entry posting engine (the single most correctness-critical module; property-based tested), fiscal periods, number ranges.
3. **Sub-ledgers & masters** — AP, AR, cash, customers, vendors, items.
4. **Domain modules** — per the selected features/vertical (inventory, procurement, sales, manufacturing, projects, HCM…).
5. **Cross-cutting** — reporting/BI, workflow/approvals, integration/API surface, admin/RBAC UI.
6. **UI** — per `08-design-system.md`, on top of the API.

Each module is a loop iteration. Foundation and ledger modules are prime candidates for **owner gates (Gk)** — flag them.

## The loop (per module M) — a team, not a soloist

Run via `workflows/build-module.js` so it is re-runnable and isolated from your context. Each stage is a **separate subagent**; the builder never certifies itself.

```
        ┌──────────────────────────────────────────────────────────────┐
        │  0. PLAN(M)      orchestrator writes a SPEC.md for M:          │
        │                  entities, API, invariants, acceptance tests,  │
        │                  which locked decisions apply, which security  │
        │                  scenarios apply. Test-first: list the tests   │
        │                  that must pass before any code.               │
        ├──────────────────────────────────────────────────────────────┤
        │  1. BUILD(M)     builder (Sonnet-max) implements to SPEC.md +  │
        │                  writes the tests. Confirms every library      │
        │                  symbol against the installed version first.   │
        ├──────────────────────────────────────────────────────────────┤
        │  2. QA(M)        qa-reviewer (Sonnet-max, fresh context, sees  │
        │                  only SPEC + diff): correctness, edge cases,   │
        │                  missing tests, coverage. Adversarial.         │
        ├──────────────────────────────────────────────────────────────┤
        │  3. SECURITY(M)  security-reviewer (Sonnet-max; Opus for auth/ │
        │                  payments/tenant-isolation) runs the module's  │
        │                  security/scenarios/* and tries to break it.   │
        ├──────────────────────────────────────────────────────────────┤
        │  4. VERIFY(M)    verifier (Sonnet-max) runs verify-phase.sh.   │
        │                  Exit 0 → done. Non-zero → back to BUILD with   │
        │                  the evidence. (max 3 bounces, then escalate.)  │
        ├──────────────────────────────────────────────────────────────┤
        │  5. COMMIT(M)    orchestrator: state.json + phase-log + git.    │
        │                  If M is gated (Gk): stop, surface, wait.       │
        └──────────────────────────────────────────────────────────────┘
```

QA and SECURITY run **in parallel** (both read the same diff). VERIFY runs after both pass. If QA or SECURITY finds a defect, it goes back to BUILD before VERIFY — don't waste a verify run on known-broken code.

## UI-bearing modules — the extra stage that is not optional

If the module renders a screen, the review stage gains a **third parallel reviewer, `design-qa-reviewer`**, and the builder must first run the **visual verification loop** (`playbook/12-ui-ux-visual-verification.md`): render the module, drive it with Playwright / Playwright MCP, capture screenshots in **both light and dark**, and **actually look at them** against the design tokens before handing off. VERIFY then runs the `ui_verify` gate (Playwright e2e + visual-regression + axe WCAG 2.2 AA + Lighthouse), which is fail-closed like every other gate. A UI module is not done until it was rendered, looked at, and passed design-QA — never on "it compiles." See `NORTH-STAR.md`: *you have not finished, you have only guessed*. (Non-UI modules set `verify.ui_verify` to an explicit `true # N/A` waiver.)

## SPEC.md — the anti-hallucination contract (stage 0)

Every module starts with a spec the builder implements against and the verifier checks against. Minimum contents:
- **Purpose** & scope (one paragraph).
- **Data entities** (tables/types, keys, tenant_id + RLS if multi-tenant).
- **API surface** (endpoints/functions, inputs/outputs as Zod/schema).
- **Invariants** (e.g. debit==credit; posted docs immutable; every write audit-logged).
- **Acceptance tests** (the failing tests that define done — write these first).
- **Applies:** which `locked-decisions.json` keys and which `security/scenarios/*` govern this module.

No SPEC.md → no build. This is what stops "the agent wrote something plausible."

## Recording work (every iteration)

Three writes, always (see `00-START-HERE §6`):
- `progress/state.json` — module status (`planning|building|qa|security|verify|blocked_on_gate|done`), last-good git sha.
- `progress/phase-log.md` — append: what was built, which decisions honored, autonomous decisions taken + why, verify result.
- `git commit` — `[P09/<module>] <summary> | DoD: pass | decisions: … | verify: reviews/<module>.md`.

## Bounce & escalation

- Verify fails → builder fixes with the exact evidence → re-verify. Cap at **3 bounces**; if still failing, stop and surface to the owner with the evidence (something in the spec or a locked decision may be wrong).
- A locked decision blocks correct implementation → stop, propose the change, get owner sign-off, update `locked-decisions.json` (changelog + new checksum). This is the only unscheduled owner-stop.

## Context hygiene inside the loop

The heavy reading/building happens in subagents, not in you. Between modules, if your context is above ~75%, checkpoint and `/compact`. The `state.json` + `phase-log.md` + git triad means a fresh session can resume mid-inventory with zero loss (see resume protocol).

**NEXT:** after all modules → `playbook/10-quality-gates.md` (final hardening), then `playbook/11-deployment-production.md`.
