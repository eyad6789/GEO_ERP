---
id: P03
stage: DECIDE
audience: orchestrator
read_when: after the discovery interview (P02), before dispatching the P04-P08 decision chunks
produces: project-config/decisions.html, project-config/decisions.mcq.md; on owner approval → project-config/locked-decisions.json (gate G1)
depends_on: project-config/interview-transcript.md, playbook/04-tech-stack.md, playbook/05-architecture-deployment.md, playbook/06-security-foundations.md, playbook/07-features-selection.md, playbook/08-design-system.md, playbook/templates/decision-file.html, playbook/templates/locked-decisions.schema.json
---

# 03 · The Decision File — One Page, Every Decision, One Owner Approval

P04–P08 each produce a **chunk** of proposed decisions. This phase does not add new decisions — it assembles all chunks into **one scrollable HTML memo** the owner reads once and approves once, at gate **G1**. Nothing in BUILD starts before this file is approved and written to `project-config/locked-decisions.json`.

## 1. Purpose

- One page, one scroll, no pagination. Every decision the build needs is a **card**: a proposed default (pre-selected, tagged **PROPOSED**), the alternatives, the trade-off of each, and your one-line recommendation.
- The owner's job is reduced to **skim → accept default or pick an alternative → lock**. They should never have to hunt for what's undecided or reverse-engineer a trade-off from prose.
- This is a **memo, not an app**: no backend, no network calls (CSP-safe, self-contained per `playbook/08-design-system.md` token rules — cream/paper Anthropic-language treatment, serif headings, clay accent used only for the primary "Lock decisions" affordance, hairline borders not shadows, WCAG 2.2 AA contrast, visible focus ring). All interactivity (radio selection, notes, JSON export) is client-side JS with no external dependency.
- **Every default in every card is PROPOSED, never final.** The card's pre-selected radio is a recommendation, not a decision — only the owner's explicit lock at the end of §6 makes it a decision.

## 2. The decision card — the page's only repeating unit

Every card the template renders is built from one JSON shape. Generate an array of these (§4) and the template does the rest.

```json
{
  "id": "stack.db",
  "section": "Tech Stack",
  "phase": "P04",
  "title": "Primary Database",
  "question": "Which database engine stores the system of record?",
  "default": { "value": "postgresql_18", "label": "PostgreSQL 18", "tag": "PROPOSED" },
  "options": [
    { "value": "postgresql_18", "label": "PostgreSQL 18", "tradeoff": "...", "recommended": true },
    { "value": "mysql_8", "label": "MySQL 8", "tradeoff": "..." },
    { "value": "sqlserver", "label": "SQL Server", "tradeoff": "..." }
  ],
  "recommendation": "1-2 sentence rationale; cite a knowledge-map.md anchor, not a re-derivation",
  "risk_flag": null,
  "allow_custom": true
}
```

Field rules:
- `id` **is** the exact dotted path into `locked-decisions.json` (per `playbook/templates/locked-decisions.schema.json`). This is what makes merging owner answers back mechanical (§6) — no name mapping step, no ambiguity.
- `default.tag` is always the literal string `"PROPOSED"` — never omit it, never render a default without the tag visible on the card face.
- `recommendation` must ground any concrete/time-sensitive claim (versions, mandates, benchmarks) via a `knowledge-map.md` anchor or the relevant P04-P08 doc — never invent a justification inline.
- `risk_flag: "gk-candidate"` marks decisions likely to also need a module-level **Gk** gate later (e.g. payment provider, encryption key custody, tenancy model) — the template renders these with a distinct (non-accent, semantic) badge color, never clay.
- `allow_custom: true` renders a free-text override input beside the radio group, for decisions with no closed option set (e.g. a specific compliance regime not listed).
- For **multi-select** cards (e.g. `modules[]`, `security.compliance[]`), `options` renders as a checklist, not radios; `default` becomes `defaults: [...]` (array of pre-checked values).

## 3. Exact section list → `locked-decisions.json` map

Render sections in this fixed order — it is also the owner's reading order, cheapest-to-confirm first, highest-leverage last:

| # | Section title | Source | `locked-decisions.json` path(s) | Card shape |
|---|---|---|---|---|
| 0 | Project Summary | P02 transcript | `project.name`, `project.industry`, `project.summary`, `project.scale` | confirmation card (owner corrects prose, no options) |
| 1 | Tech Stack | P04 | `stack.language`, `stack.runtime`, `stack.backend_framework`, `stack.orm`, `stack.db`, `stack.internal_api`, `stack.external_api`, `stack.frontend`, `stack.validation`, `stack.jobs` | one radio card per key |
| 2 | Architecture & Deployment | P05 | `architecture.tenancy`, `architecture.deployment`, `architecture.ha`, `architecture.backup_tier` | radio cards; `ha` is boolean (yes/no card with cost note) |
| 3 | Security Baseline | P06 | `security.authn`, `security.authz_model`, `security.audit_log`, `security.encryption`, `security.compliance[]`, `security.ai_copilot` | radio cards + one multi-select (`compliance`) |
| 4 | Feature / Module Set | P07 | `modules[]` | one multi-select card, grouped by domain (financial/HCM/SCM/…), sourced from `core/features-core.md` + the matched `verticals/*.md` |
| 5 | Design System | P08 | `design.tokens`, `design.theme` | radio cards |

The key lists above are the **minimum**, not exhaustive: P05 and P08 may inject additional cards (e.g. `design.wcag_target`, `design.command_palette`, `design.approvals_inbox`) declared in their own §keys sections — treat those sections as authoritative and render a card for every key they emit. Any key beyond `locked-decisions.schema.json` must be added to the schema (or declared an allowed extension) before G1.

`verify.*` is **never a card** — it is generated mechanically from the locked `stack` values at G1 by copying the matching block from `playbook/templates/verify-commands.map.json` (see `playbook/10-quality-gates.md`) and appended programmatically, not decided by the owner.

Each section header on the page states its gate lineage: *"Locks at G1 — see playbook/0{4-8}-….md for how these options were derived."* This is a pointer, not a re-explanation — do not restate P04-P08's content on this page.

## 4. Generating the page (template + data, no new tooling)

1. Collect the decision-card array (§2) by having the P04-P08 chunk work emit its proposed cards in that JSON shape as it runs — don't wait until the end to reverse-engineer cards from prose.
2. Read `playbook/templates/decision-file.html`. It contains a single injection point:
   ```html
   <script id="decision-data" type="application/json">/*__DECISIONS_JSON__*/</script>
   ```
   Replace `/*__DECISIONS_JSON__*/` with the full JSON payload: `{ "project": {...}, "sections": [ {title, cards:[...]} , ... ], "generated_at": "<ISO>" }`. This is a string substitution, not a build step — no bundler, no server.
3. Write the result to `project-config/decisions.html`. This is a static file; open it locally in a browser. No fetch/XHR — the template is self-contained per its own CSP-safe design (see `playbook/08-design-system.md` for the token/markup source of truth; do not re-derive tokens here).
4. From the **same** JSON payload, also emit `project-config/decisions.mcq.md`: a flat numbered mirror of every card (see §5.2) — one source of truth, two renderings, so the two response paths can never drift apart.
5. Do not hand-edit `decisions.html` after generating it from data — if a card is wrong, fix the JSON payload and regenerate. The HTML is a render artifact, not a source file.

## 5. How the owner responds — two paths, one normalized answer set

Either path produces the same normalized structure: `{ "<card.id>": { "value": ..., "note": "..." }, ... }`. Accept whichever the owner used.

### 5.1 Annotate the HTML and return
- Owner opens `decisions.html`, changes any radio/checkbox away from the pre-selected PROPOSED default where they disagree, optionally types a note per card.
- A page-level **"Copy my answers as JSON"** button (client-side only — serializes current form state, no network call) lets them copy or download `decisions.answers.json`.
- Owner hands that JSON (or the phrase "accept all defaults") back to the orchestrator in-conversation.

### 5.2 Answer the companion MCQ
- `decisions.mcq.md` lists every card as `N. <title> — (a) <default, PROPOSED> (b) <alt> (c) <alt> [free text]`, in the same order and with the same `id`s as §3.
- Owner replies inline, e.g. `1a, 2b, 3a (note: use RDS not self-hosted), 4a…`. This is the faster path for a CLI-only owner who never opens a browser.
- Parse replies positionally against the same `id` order used to generate the file — do not re-ask which card a letter refers to.

Either way: **silence on a card = the PROPOSED default stands**, but the overall file is only locked once the owner gives an explicit approval utterance ("locked", "approved", "go") — merely opening or skimming the file is not consent. If anything is ambiguous (a note that seems to contradict the chosen value, an unrecognized custom value), stop and ask; do not guess into `locked-decisions.json`.

## 6. Locking — writing `locked-decisions.json` (gate G1)

On explicit owner approval:

1. Merge the normalized answers (§5) into the schema shape in `playbook/templates/locked-decisions.schema.json` — each answer's `id` is already the exact dotted path, so this is a mechanical assign, not an interpretation step.
2. Generate `verify.*` (format/lint/typecheck/orphan/test/coverage/drift/dep_audit/secret_scan/security_scenarios/smoke) by copying the block matching the locked `stack` from `playbook/templates/verify-commands.map.json` and adapting paths/thresholds; the `drift` command is specialized per `playbook/10-quality-gates.md` § drift linter (RLS+FORCE coverage for multi-tenant). This is the only part of the file the owner did not directly choose. All 11 keys must be non-empty (verify-phase.sh is fail-closed).
3. Validate the assembled object against `locked-decisions.schema.json` (`additionalProperties: false` — a stray key means a card produced something outside the schema; fix the card, not the schema).
4. Set `locked_at` to the current ISO timestamp. Compute `sha256` over the file with `checksum` blanked; write the result into `checksum`.
5. Write `project-config/locked-decisions.json`. Commit: `[G1] lock decisions | checksum: <sha256> | source: decisions.html`.
6. Update `progress/state.json`: `locked_decisions_sha256`, `current_stage: "BUILD"`, `current_phase: "P09"`, clear the gate from `open_gates`. Move the gate record from `project-config/gates/pending/` to `gates/answered/` (see `playbook/templates/gate.template.md`).
7. This is the only point before which **zero code may be written**. `playbook/09-build-loop.md` is the very next read.

## 7. Amendments (before and after lock)

- **Before lock**: owner wants to change one card only → patch that card in the JSON payload, regenerate `decisions.html`/`decisions.mcq.md` (§4), re-send just the delta, do not force a full re-review of unchanged cards.
- **After lock**: any change to `locked-decisions.json` is a new, unscheduled owner gate — propose the change, get sign-off, append a `changelog` entry (`at`, `gate`, `change`, `reason`), recompute the checksum. Never hand-edit the checksum or the locked values directly (see `00-START-HERE.md` §3, §6 and `playbook/10-quality-gates.md`). This file's job ends at the first successful lock.

**NEXT:** `playbook/04-tech-stack.md` (first decision chunk that feeds this file) if decision cards are still being assembled; `playbook/09-build-loop.md` once G1 is locked.
