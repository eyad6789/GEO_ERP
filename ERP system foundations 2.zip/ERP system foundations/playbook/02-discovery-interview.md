---
id: P02
stage: ELICIT
audience: orchestrator
read_when: after G0 (freshness reviewed/adjusted)
produces: project-config/interview-transcript.md
depends_on: R6-ai-build-method, 00-START-HERE.md, knowledge-map.md, verticals/*
---

# 02 · Discovery Interview — Elicit Everything, Ask Only What You Must

Goal: extract enough context to write `project-config/decisions.html` (P03) and eventually lock `locked-decisions.json` at **G1**. You are not gathering trivia — every question here either (a) picks a fork the vertical/core docs can't resolve for you, or (b) surfaces the owner's actual reasoning so later autonomous decisions (P09 phase-log entries) stay aligned with intent. **Infer what you can from `verticals/*` and `core/*`; ask only the rest.** Log every inference as an assumption — the owner can correct it later, but you never silently guess on a fork that matters.

This whole phase runs in **one sitting with the owner**, in chunks. Do not dump all questions at once — decision fatigue produces garbage answers, and a garbage tenancy answer costs weeks.

---

## 1. Open with the gate schedule (say this first, verbatim intent)

> "Before we start: I'll only stop and ask you things at four points — **G0** (just did: freshness), **G1** (next: I lock every decision from this interview into a checksummed file, you approve or edit it), **Gk** (only for modules either of us flags as high-risk, e.g. payments, tenant isolation), and **G2** (before production deploy). Everything else, I decide myself and log why, so you're not peppered with questions during the build. Right now I need about 10-15 minutes of your input in short groups of questions, then a couple minutes in your own words. Let's start."

This sets expectations: the interview is bounded, the rest of the build won't interrupt them constantly.

---

## 2. The chunked MCQ protocol

- Use the **AskUserQuestion** pattern: batch the 1-3 questions of one chunk together, **2-4 options each**, one option marked **(recommended)**. Always allow free-text "other."
- One chunk → wait for the answer → write it to the transcript immediately (don't hold answers only in context) → next chunk. Never present two chunks at once.
- Every recommended option below is tagged **PROPOSED** — it is a suggestion to speed the owner's choice, not a decision. Nothing here locks anything; P03/G1 does that.
- If the owner's answer conflicts with something inferable from a vertical doc (e.g. they picked "no compliance regime" for a healthcare business), flag the conflict once, don't argue twice.
- Skip a chunk entirely if the previous chunk (or the vertical doc) already answers it with high confidence — log it as inferred instead of asking (§6).

---

## 3. Chunk order

| # | Chunk | Why this order |
|---|---|---|
| 1 | Business & industry | Everything else routes off the vertical |
| 2 | Scale | Sizes the infra conversation before deployment is discussed |
| 3 | **Tenancy** | The single biggest architectural fork — must be locked in the owner's head before hosting/budget make sense |
| 4 | Users & roles | Who touches the system, how strict SoD must be |
| 5 | Compliance & jurisdiction | Often already implied by vertical + tenancy; confirm, don't over-ask |
| 6 | Hosting & deployment | Depends on compliance answer (air-gap/on-prem forces this) |
| 7 | Budget & timeline | Constrains scope for chunk 10 |
| 8 | Integrations | Concrete named systems, never guessed |
| 9 | Data migration | Sources + how much history |
| 10 | Must-have modules | Last, because it's now scoped by everything above |
| — | Open elicitation | Unstructured, after all chunks (§5) |

---

## 4. Ready-to-use MCQ banks

### Chunk 1 — Business & industry (routes to a `verticals/*.md` file)

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Which best describes the primary business? | A) Makes/moves physical goods  B) Sells/serves directly  C) Public-benefit or regulated mission  D) Other (describe in one line) | — (pure routing; always answer, no default) | `business.category` |
| (tier 2, conditional on tier 1) Which fits best? | Pick from the matching row in the routing table below | PROPOSED: closest match by revenue model if owner is unsure | `business.vertical` |

**Routing table** (tier 1 → candidate `verticals/*.md` files):

| Tier-1 answer | Candidate vertical files |
|---|---|
| A) Physical goods | `manufacturing` · `distribution-logistics` · `construction-realestate` · `agriculture-food` · `oil-gas-energy` · `aerospace-defense` |
| B) Sell/serve directly | `retail-ecommerce` · `professional-services` · `financial-services` |
| C) Public-benefit/regulated mission | `government-publicsector` · `education` (higher-ed) · `schools` (K-12) · `nonprofit-ngo` · `healthcare-lifesciences` |
| D) Other | Ask one follow-up open question, map to closest file by feature overlap, log as an assumption for the owner to confirm at G1 |

If the answer spans two files (e.g. a distributor that also manufactures), read both, note the primary in `business.vertical` and the secondary as `business.vertical_secondary`.

### Chunk 2 — Scale

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Concurrent/named users at launch? | A) <25  B) 25-250  C) 250-2,500  D) 2,500+ | B — fits most single-entity mid-market builds | `scale.users_band` |
| Transaction volume (docs posted/day: invoices, orders, journal lines)? | A) <1k  B) 1k-50k  C) 50k-1M  D) 1M+ | B | `scale.tx_per_day_band` |

### Chunk 3 — Tenancy (the biggest fork — do not rush this one)

State the consequence before asking: *single-tenant* = one DB/schema per customer, simplest isolation, higher per-customer infra cost, fastest to build; *multi-tenant* = shared infra with `tenant_id` + RLS, cheaper at scale, materially more security-engineering work up front (see `core/architecture.md § Multi-Tenancy`).

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Will this ever serve more than one independent org (resale, franchise, subsidiaries needing hard isolation)? | A) No — one company, ever  B) Yes — a few known subsidiaries  C) Yes — SaaS/reseller, many unknown future tenants  D) Unsure | A, if the owner confirms no resale/SaaS ambition — simplest and cheapest | `architecture.tenancy` |

If C: flag a follow-up decision (pooled+RLS vs siloed-per-tenant) and route it to P05 rather than deciding here — it needs the architecture chunk's full context.

### Chunk 4 — Users & roles

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Who needs access? | A) Finance/back-office only  B) + Ops/warehouse/field  C) + External portal (customers/vendors/students/patients)  D) All of the above | B — most ERPs need at least ops | `users.access_scope` |
| Approval/segregation-of-duties strictness? | A) Informal (small trusted team)  B) Standard maker-checker on postings  C) Strict multi-level, audit/SOX-heavy | B | `security.sod_level` |

### Chunk 5 — Compliance & jurisdiction

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Primary operating jurisdiction(s)? | A) US only  B) EU/UK  C) Multi-region (name them)  D) Other/emerging market | — (fact; verify specifics via `playbook/01-freshness-check.md`) | `compliance.jurisdictions` |
| Known regulatory regimes beyond standard tax? | A) None  B) Industry-specific (HIPAA/FERPA/PCI/SOX — per vertical)  C) Government/public-procurement rules  D) Unsure | Infer from the vertical file's compliance section instead of asking, unless the owner flags something unusual | `compliance.regimes` |

### Chunk 6 — Hosting & deployment

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Where should this run? | A) Cloud managed (AWS/Azure/GCP)  B) On-prem/private datacenter  C) Hybrid  D) No preference | A, unless chunk 5 flagged an air-gap/on-prem requirement | `deployment.hosting` |
| Who operates it day 2? | A) Owner's own IT/DevOps team  B) This build hands off fully managed  C) Managed service, owner retains on-call | B, for owners without an existing platform team | `deployment.ops_model` |

### Chunk 7 — Budget & timeline

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Target time to first production module live? | A) <3 months  B) 3-6 months  C) 6-12 months  D) 12+ months / phased | B — realistic for a one-vertical MVP on this pipeline | `timeline.first_go_live` |
| Budget posture? | A) Lean/MVP — cut scope to hit budget  B) Standard — scope drives budget  C) Well-funded — comprehensiveness over speed | B | `budget.posture` |

### Chunk 8 — Integrations

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Must integrate with (name the actual systems)? | A) None at launch  B) Accounting/payroll already in use  C) E-commerce/POS/EDI trading partners  D) Industry system (LMS/EHR/CRM — per vertical) | — (always get real names; never guess a vendor) | `integrations.required` |
| Integration pattern preference? | A) REST/OpenAPI  B) Event-driven/webhooks  C) File-based batch (SFTP/EDI)  D) Whatever fits each partner | D — decide per-integration, not one global answer | `integrations.pattern` |

### Chunk 9 — Data migration

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| System(s) to migrate from? | A) None — greenfield  B) Spreadsheets/manual  C) Legacy ERP/accounting package (name it)  D) Multiple sources | — (capture verbatim; never assume a package name) | `migration.sources` |
| How much history must migrate? | A) Balances/open items only  B) 1-2 years detail  C) Full history  D) Unsure | A — fastest, sufficient for most go-lives | `migration.history_depth` |

### Chunk 10 — Must-have modules

| Ask | Options | PROPOSED | Feeds |
|---|---|---|---|
| Modules required at first go-live (beyond GL/AP/AR core)? | A) Inventory/SCM  B) Manufacturing/BOM-MRP  C) Projects/services delivery  D) HCM/payroll | The vertical file's default module set (`core/features-core.md` + `verticals/<x>.md`) — present it, let the owner add/remove | `modules.launch_set` |
| Reporting/BI needs at launch? | A) Standard built-in reports only  B) + Self-serve BI/dashboards  C) + Regulatory/statutory reports (per vertical) | A+C for regulated verticals, A otherwise | `modules.reporting_scope` |

---

## 5. Open elicitation (after all chunks, unstructured)

Ask, and **capture verbatim** — do not paraphrase-only:

> "In your own words: what does this system need to do, and why? What's broken today that pushed you to build this? What would success look like in 12 months? Any past ERP experience — good or bad — you're reacting to?" (If relevant, this is where `core/cautions.md`'s nine failure cases give you vocabulary to probe: scope creep, customization trap, data quality, vendor lock-in.)

Store the owner's exact words in a blockquote in the transcript, then add one paragraph restating your understanding for the owner to correct on the spot — this is cheaper to fix now than at G1.

---

## 5b. Advanced-depth triage (which `playbook/advanced/*` this build needs)

The advanced doctrine is optional depth — do not adopt it reflexively, but do not silently skip it either. Run each ADOPT-WHEN trigger (see `manifest.md`) against what you just heard, and record a yes/no + why in the transcript. These usually decide themselves from the answers already given:

| Ask yourself | If yes → adopt | Emits |
|---|---|---|
| Does it have a financial ledger that will ever need restatement or as-of reporting? | A1 (bitemporal ledger), A2 (provable correctness) | `architecture.temporal_model`, money/correctness keys |
| Replacing or integrating a legacy system, or >1 data source? | A3 (MDM + integration + continuous migration) | `data.mdm`, `data.integration_registry`, `data.migration_mode` |
| Will it carry client/industry-specific logic, or is it multi-tenant SaaS? | A4 (clean-core extension boundary) | `architecture.extension_model` |
| Cross-module reporting / exec KPIs? | A5 (semantic layer) | `reporting.semantic_layer` |
| Does the owner want AI features? | A6 (AI-native, propose-not-dispose) — else `ai_capability=none` | `ai_capability.*` |
| Complex approval hierarchies, regulated audit, or large green-field domain? | A7 (ReBAC / crypto anchoring / spec-gen) | `security.authz_engine`, `security.audit_anchoring` |
| Real production deployment (not a throwaway)? | A8 (process-first + benefit realization) | `process.fit_posture`, `process.benefit_plan` |
| Does it have a UI humans use? | **P12 (UI/UX + visual verification) — almost always** | `design.ui_toolchain`, `verify.ui_verify` |

Surface the adopted set to the owner as part of the G1 decision file — these are their choices too, tagged PROPOSED.

---

## 6. Infer, don't ask, when it's routine — but never on a scope-defining fork

| Infer silently (log as assumption) | Always ask explicitly |
|---|---|
| Routine vertical-standard compliance items already in `verticals/<x>.md` | Tenancy (chunk 3) |
| Typical module set for the vertical/company size | Budget/timeline, real integration partner names |
| SoD strictness implied by user count + vertical norms | Hosting preference (compliance-driven forks) |
| Standard reporting cadence for the vertical | Anything `core/cautions.md` flags as a common failure trigger — always confirm scope boundaries, never infer them |

---

## 7. Write `project-config/interview-transcript.md`

```markdown
# Interview Transcript — <project name>
Conducted: <ISO timestamp> · Orchestrator session: <id>

## Chunk answers
| Chunk | Question | Owner answer | Feeds |
|---|---|---|---|
| 1 | ... | ... | business.vertical |
...

## Inferred (not asked — logged assumption)
| Item | Inferred value | Source | Confidence |
|---|---|---|---|
| compliance.regimes | ... | verticals/healthcare-lifesciences.md § Compliance | high |

## Open elicitation (verbatim)
> <owner's exact words>

Orchestrator's restated understanding: <one paragraph, for the owner to correct>

## Carry-forward
Nothing here is locked. This transcript seeds `project-config/decisions.html` (P03); the owner
approves/edits at **G1**, which writes the checksummed `locked-decisions.json`.
```

Every field is still **PROPOSED** until G1 — do not phrase this file as decided.

**NEXT:** `playbook/03-decision-file-spec.md` — turn this transcript into the Anthropic-design HTML decision file the owner reviews and locks at G1.
