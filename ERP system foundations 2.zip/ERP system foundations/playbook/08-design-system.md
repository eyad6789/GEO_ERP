---
id: P08
stage: DECIDE + BUILD
audience: orchestrator, builder
read_when: the design-system decision chunk (after P07 modules, feeds G1); and again before writing any product-UI code in BUILD
produces: design.* keys in project-config/locked-decisions.json; playbook/templates/decision-file.html (the P03 rendering surface)
depends_on: R7-design-system, playbook/03-decision-file-spec.md
runs_with: playbook/templates/decision-file.html, playbook/09-build-loop.md (UI tier), playbook/templates/locked-decisions.schema.json
---

# 08 · Design System — Two Surfaces, One Token Vocabulary

Every ERP build needs two visually different things sharing one visual language: an **owner-facing memo surface** (the decision file, ADRs, runbooks — read once, calmly) and a **product surface** (grids, forms, dashboards — used 8+ hrs/day by experts). Same tokens, different layout grammar. All defaults below are **PROPOSED** — the owner locks the final choice into `locked-decisions.json.design` at **G1**. Nothing here is pre-decided.

## 1. The two-surface model

| Surface | Treatment | Typography | Governs |
|---|---|---|---|
| **Memos** (decision file, ADRs, runbooks, `decisions.html`) | Full Anthropic-language: warm cream paper, ink text, clay accent used sparingly, generous whitespace, hairline borders, no shadows | Serif for headings/pull-quotes, sans for everything operational | `playbook/03-decision-file-spec.md`, `playbook/templates/decision-file.html` |
| **Product UI** (the ERP app itself) | Same tokens, "instrument panel" grammar: density-first grids, master-detail, saved views, bulk-action bars, role-based nav | Sans/mono almost everywhere; serif reserved for section headers and empty-states — **never** on tabular data or form labels | §5 below, applied per module during BUILD |

Both are generated from **one CSS variable block** (§2) — an agent drops it into any HTML file and gets correct light/dark behavior immediately, per this project's own artifact-theming convention (`prefers-color-scheme` default, `data-theme` attribute wins in both directions).

## 2. PROPOSED token set — paste verbatim

```css
:root {
  /* Core palette (light) */
  --paper:#faf9f5; --paper-raised:#ffffff; --surface:#e8e6dc;
  --ink:#141413; --ink-muted:#575551; --border:#d9d6c9; --border-strong:#b0aea5;

  /* Accent family — clay is the ONE brand accent */
  --accent:#d97757; --accent-hover:#c1613f; --accent-soft:#f3ded3;
  --accent-2:#6a9bcc; /* sky, secondary/info */
  --accent-3:#788c5d; /* cactus, tertiary/dataviz */

  /* Semantic — never reuse the accent hue */
  --success:#4b7d5c; --success-soft:#e1ede3;
  --warning:#b8873a; --warning-soft:#f6ebd8;
  --danger:#b1443a;  --danger-soft:#f5e0dd;  /* brick red, distinct from clay */
  --info:#6a9bcc;    --info-soft:#e3ecf5;

  /* Categorical dataviz (8-swatch, Anthropic-derived) */
  --viz-1:#d97757; --viz-2:#6a9bcc; --viz-3:#788c5d; --viz-4:#c46686;
  --viz-5:#a68b5b; --viz-6:#8a8c5e; --viz-7:#b9ada0; --viz-8:#d8cba6;

  --font-display:"Source Serif 4",Georgia,"Iowan Old Style",serif;
  --font-body:"Public Sans","Segoe UI",system-ui,-apple-system,sans-serif;
  --font-mono:"IBM Plex Mono",ui-monospace,"SF Mono",Consolas,monospace;

  --text-xs:.75rem; --text-sm:.875rem; --text-base:1rem; --text-md:1.125rem;
  --text-lg:1.375rem; --text-xl:1.75rem; --text-2xl:2.25rem;

  --space-1:.25rem; --space-2:.5rem; --space-3:.75rem; --space-4:1rem;
  --space-5:1.5rem; --space-6:2rem; --space-7:3rem; --space-8:4rem;

  --radius-sm:4px; --radius-md:8px; --radius-lg:12px; --radius-full:999px;
  --shadow-sm:0 1px 2px rgba(20,20,19,.06); --shadow-md:0 2px 8px rgba(20,20,19,.08);
  --focus-ring:0 0 0 2px var(--paper),0 0 0 4px var(--accent); /* WCAG 2.4.13-safe */
}

@media (prefers-color-scheme:dark){ :root{
  --paper:#1c1b18; --paper-raised:#242320; --surface:#2a2925;
  --ink:#f2f0e9; --ink-muted:#b7b3a8; --border:#3a3833; --border-strong:#514e46;
  --accent:#e08e6d; --accent-hover:#eba489; --accent-soft:#4a2f22;
  --accent-2:#86b0d8; --accent-3:#92a67c;
  --success:#7fb48f; --success-soft:#22301f; --warning:#d6a768; --warning-soft:#362b17;
  --danger:#d17d72; --danger-soft:#3a211d; --info:#86b0d8; --info-soft:#1f2b36;
  --shadow-sm:0 1px 2px rgba(0,0,0,.35); --shadow-md:0 2px 10px rgba(0,0,0,.45);
}}

/* Explicit in-app toggle always wins over prefers-color-scheme, both directions */
:root[data-theme="light"]{
  --paper:#faf9f5; --paper-raised:#ffffff; --surface:#e8e6dc;
  --ink:#141413; --ink-muted:#575551; --border:#d9d6c9; --border-strong:#b0aea5;
  --accent:#d97757; --accent-hover:#c1613f; --accent-soft:#f3ded3;
  --accent-2:#6a9bcc; --accent-3:#788c5d;
  --success:#4b7d5c; --success-soft:#e1ede3; --warning:#b8873a; --warning-soft:#f6ebd8;
  --danger:#b1443a; --danger-soft:#f5e0dd; --info:#6a9bcc; --info-soft:#e3ecf5;
  --shadow-sm:0 1px 2px rgba(20,20,19,.06); --shadow-md:0 2px 8px rgba(20,20,19,.08);
}
:root[data-theme="dark"]{
  --paper:#1c1b18; --paper-raised:#242320; --surface:#2a2925;
  --ink:#f2f0e9; --ink-muted:#b7b3a8; --border:#3a3833; --border-strong:#514e46;
  --accent:#e08e6d; --accent-hover:#eba489; --accent-soft:#4a2f22;
  --accent-2:#86b0d8; --accent-3:#92a67c;
  --success:#7fb48f; --success-soft:#22301f; --warning:#d6a768; --warning-soft:#362b17;
  --danger:#d17d72; --danger-soft:#3a211d; --info:#86b0d8; --info-soft:#1f2b36;
  --shadow-sm:0 1px 2px rgba(0,0,0,.35); --shadow-md:0 2px 10px rgba(0,0,0,.45);
}
```

**Contrast (informal engineering estimate, verify with a real tool before shipping — R7 §5):** ink-on-paper ≈17:1 light / ≈15:1 dark, both far exceed the 4.5:1 AA floor. Clay-on-paper ≈3.3:1 — fine for large text/icons/borders (3:1), **not** for small body text: keep clay for links ≥14px-bold or chrome/icons, or underline links so color isn't load-bearing.

## 3. Typography — license-safe substitution

Anthropic's actual faces (Styrene sans / Tiempos serif, or the proprietary Anthropic Serif/Sans/Mono suite) are commercial or unreleased — **do not** embed them. The token block above already substitutes **open, metric-sympathetic** faces: Source Serif 4 (display/serif), Public Sans (body/UI sans — IBM Plex Sans is an acceptable alternative), IBM Plex Mono (IDs/code/ledgers). In HTML memos, rely on the system-font fallback chain (no `@font-face` data URI — keeps the file CSP-clean); in the actual ERP product, self-host the font files normally. `(verify current font licensing/version status via playbook/01-freshness-check.md)`.

## 4. Component defaults implied by the tokens

- **Buttons** — `--radius-md`; primary = `--accent` fill / `--paper` text; secondary = `1px solid --border-strong` + `--ink` text; shadow only `--shadow-sm` on hover.
- **Cards/panels** — `--paper-raised` bg, `1px solid --border`, `--radius-lg`, at most `--shadow-sm`. Borders over shadows, always.
- **Table rows** — `--paper`/`--surface` zebra, `--accent-soft` for selected row, `1px solid --border` row divider only, no vertical cell borders, `tabular-nums` on numeric columns.
- **Inputs** — `--radius-md`, `1px solid --border-strong`, `--focus-ring` on focus; error state = `--danger` border **+ icon + text**, never color alone (WCAG 1.4.1).
- **Badges/pills** — `--radius-full`, bg = `<state>-soft`, text = a darker shade of the same state hue (not `--ink`) so pills stay legible in both themes.

**Hard rule:** clay never doubles as both brand accent and error/danger color. Danger is always the distinct brick-red (`--danger`) — state and brand must never collide visually (R7 §3).

## 5. ERP product UX rules (product surface only)

| Rule | PROPOSED requirement | Anchor |
|---|---|---|
| Data grids | Sticky header + first column; inline cell-level edit for high-frequency fields (qty/price/status); row-density toggle (compact/comfortable); selection → contextual bulk-action toolbar replacing the default toolbar | R7 §1.1 |
| Master-detail | **Default for every entity list**: side-by-side (list+detail) ≥900px, stacked drill-in below; split ratio persisted per user | R7 §1.2 |
| Forms & validation | **Inline, on-blur** validation (not per-keystroke, not submit-only); every error names the field + what's wrong + how to fix; never color alone | R7 §1.3 |
| Bulk actions | Contextual toolbar on ≥1 selected row; explicit count on destructive actions ("Delete 14 invoices?"); prefer soft-delete+undo over confirm-modal except irreversible/high-blast-radius ops | R7 §1.4 |
| Saved views | Composable filter chips + "save as view"; both team-shared and user-private views must exist | R7 §1.5 |
| Dashboards | Role-scoped by default (zero shared widgets across roles); KPI tile = number + trend + sparkline; status color is semantic, never the brand accent hue | R7 §1.6 |
| Navigation | Generated from the user's role/permission set server-side (never CSS-hidden); two-tier: persistent collapsed icon rail + secondary in-module tab/subnav | R7 §1.7 |
| Approvals | Every approval = submitted → pending (named approver + SLA) → approved/rejected (reason) → done, rendered as a stepper/status pill; **cross-module "My Approvals" inbox** aggregating all pending approvals is the default post-login landing screen for approver roles; bulk-approve requires an explicit "review N items" step before one confirm | R7 §1.8 |
| Command palette | **Cmd/Ctrl+K required primitive**, not optional, on every screen; show each action's keyboard shortcut inline inside the palette itself | R7 §1.10 |
| Responsive | Master-detail collapses <900px; grids degrade to a card-per-row list on narrow viewports; horizontal scroll only inside a deliberately-scoped `overflow-x:auto` container, never the page | R7 §1.10 |

## 6. WCAG 2.2 AA — the accessibility floor

WCAG 2.2 has 87 success criteria (32 A + 24 AA + 31 AAA) and is the current normative version `(verify via playbook/01-freshness-check.md)`. **AA is the non-negotiable build floor** for every module.

| Criterion | Level | ERP relevance |
|---|---|---|
| 2.4.11 Focus Not Obscured | AA | Sticky grid headers/toolbars must never fully hide the focused element |
| 2.4.13 Focus Appearance | AAA (adopt anyway) | Focus ring must be clearly visible against paper/ink — use `--focus-ring` |
| 2.5.7 Dragging Movements | AA | Any drag-reorder (columns, kanban) needs a non-drag button/menu alternative |
| 2.5.8 Target Size (Minimum) | AA | Interactive targets ≥24×24 CSS px — binds dense-grid row-action icon buttons |
| 3.3.7 Redundant Entry | A | Never make a user re-enter data already supplied earlier in the same process |
| 3.3.8 Accessible Authentication | AA | No cognitive-function-only login step (puzzle CAPTCHA) as the sole path |

Automated tooling (axe/Lighthouse) catches only ~40% of issues — mandate a manual keyboard-only pass and a screen-reader pass per module; **budget 2–3 months of hardening for full AA compliance on a complex app**, planned into the timeline, not bolted on pre-launch (R7 §1.9).

## 7. Reconciling memo vs product (quick reference)

| Element | Memo surface | Product surface |
|---|---|---|
| Background | Full cream paper | Cream/paper for chrome, `--surface` zebra in grids |
| Serif use | Headings, pull-quotes, everywhere editorial | Section headers / empty-states only — never form labels or cell content |
| Accent (clay) | Primary CTA, links, emphasis marks | The one primary CTA/highlight per screen; row-selected state |
| Density | Generous whitespace throughout | Density toggle; compact is often the power-user default |

## 8. Emit into locked-decisions.json (at G1)

| Key | Type | PROPOSED default | Notes |
|---|---|---|---|
| `design.tokens` | string | `"anthropic-erp-v1"` | Identifies the §2 token block committed as `design/tokens.css` in the repo |
| `design.theme` | enum | `"both"` | One of `light \| dark \| both`; `both` unless the owner mandates a single look |
| `design.wcag_target` | string | `"WCAG 2.2 AA"` | Floor per §6; escalate per-module only with a named driver |
| `design.command_palette` | boolean | `true` | §5 — required primitive |
| `design.approvals_inbox` | boolean | `true` | §5 — required for any build with ≥1 approval-bearing module |

These are extension keys beyond the schema's required `tokens`/`theme` pair — the schema permits additional properties inside `design` (only the top-level object is closed). Write the owner's chosen values, not this file's proposals, at G1.

## 9. What P09 (build) needs from this chunk

- `design.tokens` + `design.theme` become the literal `design/tokens.css` file self-hosted in the product repo — §2, copied verbatim, not re-derived.
- `design.command_palette` / `design.approvals_inbox`, if true, are **foundation-tier** BUILD work (alongside auth/tenant middleware) — every module's nav and approval-bearing screens depend on them existing first.
- `playbook/templates/decision-file.html` already implements §2's tokens and the memo treatment (§1, §7) — P03 uses that template as-is; do not re-derive its CSS when generating `decisions.html`.
- Per-module UI work in the BUILD loop applies §5 + §6 as the acceptance criteria for that module's screens; the qa-reviewer checks the WCAG floor as part of the module's DoD (`10-quality-gates.md`).

**NEXT:** all P04–P08 decision chunks are now assembled — return to `playbook/03-decision-file-spec.md` to generate `project-config/decisions.html` / `decisions.mcq.md` from this and the prior chunks' cards; once the owner locks G1, proceed to `playbook/09-build-loop.md`.
