---
id: P01
stage: ORIENT
audience: orchestrator
read_when: first phase of every build, before P02 discovery and before any decision is proposed
produces: project-config/freshness-report.md
depends_on: R5-claude-code, verification-results.md (flagged-claims register)
runs_with: workflows/verify-claims.js
---

# 01 · Freshness Check — Don't Build on Stale Facts

This library was authored and verified **2026-07**. Every dated claim in it — a compliance
deadline, a standard's current revision, a framework version, a Claude Code capability — is a
snapshot, not a law of nature. P01 exists to catch drift **before** P02–P08 turn a stale fact into
a locked decision that ships wrong.

## 1. Why this matters (read this before skipping it)

Doctrine goes stale in exactly these ways, all of which have already happened once inside this
library (see the register in §3):

- **Compliance dates arrive and pass.** A mandate documented as "effective July 2026" is either
  now in force, now amended, or now superseded — the doc doesn't know which until you check.
- **E-invoicing/tax mandates roll forward in waves.** Poland KSeF, France's B2B reform, India's IRN
  reporting window, EU ViDA — each has multiple future-dated tranches; being mid-2026 doesn't mean
  the next tranche hasn't shifted.
- **Standards get revised.** EIA-748, AS9100/IA9100, PCI DSS, FIPS — version numbers and category
  names change between doctrine-authoring and build time.
- **Framework/library/DB versions move on.** Whatever `core/architecture.md`'s examples assume, and
  whatever P04 is about to lock as the tech stack, has a current-as-of-today version that may not
  match the doc.
- **Claude Code itself changes.** Model aliases, default effort levels, subagent-model env vars,
  hook/permission mechanics — the orchestrator's own operating environment — are release-cadence
  software, not fixed facts. `R5-claude-code` already flags several of these as unverified-as-of
  its own research date.

Skipping P01 means building on facts nobody re-checked. That is the same failure mode as an
hallucinated API — just at the compliance/architecture layer instead of the code layer.

## 2. Procedure

Run this once per build, at the very start, before the discovery interview. All steps dispatch to
Sonnet subagents via `workflows/verify-claims.js` — never verify claims yourself in the main
context (keep it out of your window; you only need the verdicts).

**Step 1 — Assemble the claim list.** Combine three sources into one `claims[]` array:

1. **Must-recheck rows** from the register in §3 — everything marked `PARTIALLY_CORRECT` or
   `REFUTED`, plus every `CONFIRMED` row whose "re-check by" column has passed or falls within this
   build's likely delivery window.
2. **Project-relevant compliance items not yet in the register** — once you know the project's
   industry/geography (even a rough guess pre-P02 from the owner's opening ask), pull the matching
   `verticals/*.md` compliance IDs and localization-tax mandates via `knowledge-map.md` and add them
   as new claims if not already covered.
3. **Tech-stack and Claude Code facts you're about to depend on** — before P04 locks a language/
   framework/DB/ORM version, and before you rely on any Claude Code mechanic named in `CLAUDE.md`
   (model aliases, `CLAUDE_CODE_SUBAGENT_MODEL`, effort defaults, hook exit-code semantics), add a
   claim per item. Treat every "unverified as of 2026-07" flag in `R5-claude-code` (§9–§12: model
   naming, background-task timeouts, the 70–75% compaction heuristic) as an automatic must-recheck.

**Step 2 — Run the workflow.**

```
Workflow({ scriptPath: 'workflows/verify-claims.js', args: {
  today: '<actual current date>',
  claims: [ { id, file, body }, ... ]
}})
```

It fans out one web-verifying subagent per claim (capped for parallelism), each returning
`CONFIRMED | REFUTED | PARTIALLY_CORRECT | UNVERIFIABLE` against a primary source, with correction
text when not CONFIRMED. **Never** hand-wave a verdict — `UNVERIFIABLE` is a valid, honest outcome;
guessing is not.

**Step 3 — Do not edit the shared library.** `core/*.md` and `verticals/*.md` are reused across
many builds; do not patch them from inside one project's P01 run. Instead, write every non-CONFIRMED
verdict as a **supersede note** in `project-config/freshness-report.md` (§5) — the rest of the
pipeline must treat the freshness-report correction as authoritative over the library text for this
build.

**Step 4 — Tally and gate.** Count deltas (`REFUTED` + `PARTIALLY_CORRECT` + any `CONFIRMED` whose
underlying fact changed materially since the register). Proceed to Gate G0 (§4).

## 3. The flagged-claims register (seed set — re-verify, don't re-derive)

Distilled from `verification-results.md`, the 2026-07-06 verification pass: **32 CONFIRMED, 11
PARTIALLY_CORRECT, 1 REFUTED, 0 UNVERIFIABLE** across 51 checked claim-instances. The library is
**trustworthy but dated** — nothing here was fabricated; several things have simply moved forward
in time or need a wording fix. Re-check every row whose "re-check by" has arrived.

| Cluster | Verdict | Claim (short) | Primary source | Re-check by |
|---|---|---|---|---|
| finserv-basel-pra (US) | CONFIRMED | Basel III Endgame reproposed 19 Mar 2026 by Fed/OCC/FDIC; comments due 18 Jun 2026 | federalreserve.gov | on finalization of the rule (watch for 2026–27 final rule) |
| finserv-basel-pra (UK) | CONFIRMED | UK PRA PS1/26 published 20 Jan 2026 | bankofengland.co.uk | on implementation-timeline updates |
| gartner-erp-ai | CONFIRMED | Gartner (24 Feb 2026): 30% faster close by 2028; 62% of ERP spend on embedded AI by 2027 | gartner.com press release | annually (Gartner revises forecasts) |
| gov-fedramp | PARTIALLY_CORRECT | NTC-0004 replaces Low/Mod/High with Certification Classes A–D, published 25 Feb 2026 | fedramp.gov/notices/0004 | before any gov-sector build — confirm rollout/effective timeline |
| oilgas-nerc-cip012 | CONFIRMED | CIP-012-2 (control-center comms) effective 1 Jul 2026 | nerc.com | now — this date has just arrived; confirm enforcement is live |
| oilgas-nerc-cip015 | PARTIALLY_CORRECT | CIP-015-1 (internal network monitoring) effective 2 Sep 2025 | federalregister.gov | low priority — already in force |
| security-oracle-cpu | CONFIRMED | Oracle moved to monthly CSPUs starting 28 May 2026 (was quarterly) | blogs.oracle.com | each build — confirm cadence hasn't changed again |
| security-fips140 | CONFIRMED | FIPS 140-3 supersedes 140-2 for new submissions; 140-2 validations sunset on schedule | csrc.nist.gov/CMVP | before locking crypto-module choices |
| eia-748e | PARTIALLY_CORRECT | ANSI/EIA-748E (Feb 2026): 32→27 EVMS guidelines; one category-3 label needs a name fix | sae.org | immediately, before quoting the category names verbatim |
| aerospace-dfars | CONFIRMED | DFARS Class Deviation 2026-O0011 (1 Feb 2026): EVMS threshold $20M→$50M | acq.osd.mil | before locking any DoD-contractor EVMS logic — deviation vs. permanent rule |
| aerospace-ia9100 | CONFIRMED | IAQG developing IA9100 as AS9100 Rev D successor, targeting late 2026 | iaqg.org | before any aerospace build — confirm publication status |
| healthcare-fda-ema-ai | CONFIRMED | FDA+EMA joint AI-in-drug-development guiding principles, 14 Jan 2026 | ema.europa.eu | low priority — stable guidance |
| healthcare-qmsr | CONFIRMED | 21 CFR Part 820 (QMSR) effective 2 Feb 2026 | fda.gov | low priority — already in force |
| loctax-fica | CONFIRMED | US FICA/OASDI wage base $184,500 for 2026 | ssa.gov | every January (new annual base) |
| loctax-india-irn | CONFIRMED | India: AATO ≥ ₹10cr blocked from reporting IRNs >30 days old, from 1 Apr 2025 | einvoice6.gst.gov.in | before any India build — threshold has already lowered once |
| loctax-swift-mt | CONFIRMED | SWIFT ended cross-border MT messaging 22 Nov 2025 (ISO 20022 MX only) | swift.com | low priority — already in force |
| loctax-sepa-cap | CONFIRMED | SEPA Instant per-tx cap abolished 5 Oct 2025 (→ €999,999,999.99) | europeanpaymentscouncil.eu | low priority — already in force |
| loctax-eu-poland | CONFIRMED | Poland KSeF mandatory issuing from 1 Feb 2026 (>PLN 200M); receiving mandatory for all from Feb 2026 | ksef.podatki.gov.pl | before any Poland build — later tranches still to come |
| loctax-eu-france | CONFIRMED | France B2B e-invoicing: 1 Sep 2026 (large/mid issue+receive), 1 Sep 2027 (all) | impots.gouv.fr | before any France build |
| loctax-eu-vida | REFUTED (1 sub-claim) | ViDA adopted 11 Mar 2025; exactly 5 dates (14 Apr 2025 / 1 Jan 2027 / 1 Jul 2028 / 1 Jul 2030 / 1 Jan 2035) — **no "1 Jan 2026" date exists**, correct any doc text implying one | ec.europa.eu (Implementation Strategy PDF) | fix immediately — this is a wording error, not a time-drift risk |
| sap-ecc-eol | CONFIRMED | SAP ECC EHP6–8 mainstream maintenance ends 31 Dec 2027 (extended option to 2030) | support.sap.com | before any SAP-adjacent migration build |
| case-study-figures | PARTIALLY_CORRECT | Hershey/Nike/FoxMeyer dates & dollar figures are internally inconsistent across `core/*.md` (e.g. Nike disclosure date given as both Feb 26 and Feb 27 2001) | panorama-consulting.com, cio.com, aisel.aisnet.org | fix immediately — editorial, not time-sensitive; do not propagate the inconsistency into a new doc |
| cautions-birmingham | CONFIRMED | Birmingham Oracle ERP cost £144M as of 29 Jan 2026 (still rising) | theregister.com | before citing a total cost — program is ongoing and figure moves |
| powerschool-k12 | CONFIRMED | PowerSchool: ~55M students, 17,000+ customers (Bain Capital acquisition) | baincapital.com | low priority — stable |

Full verdict text, notes, and secondary corroboration for every row live in
`verification-results.md` — pull that file (grep by cluster id) if a subagent needs the full
reasoning, not just the verdict.

## 4. Gate G0 (soft — inform, don't block)

G0 is **soft**: summarize and recommend, but the owner can wave it through in one line. Write the
gate file (`playbook/templates/gate.template.md`) to `project-config/gates/pending/G0.md` with:

- **N deltas found** (REFUTED + PARTIALLY_CORRECT + materially-changed CONFIRMED rows).
- For each: what changed, and **what it would change downstream** (e.g. "France e-invoicing tranche
  2 date moved → affects P07 module scope if this is a France build").
- Your recommendation: proceed as-is / adjust scope / re-run a deeper check on one cluster.

**PROPOSED** default threshold: if deltas = 0–2 and none touch a module already implied by the
owner's opening ask, proceed without waiting for a reply (log it, move on). If deltas ≥ 3, or any
delta touches compliance/security/tenancy, stop and wait for the owner's answer before P02. This
threshold is a recommendation only — the owner locks the actual policy (or overrides it per-build)
at G1, not here.

Move the gate file to `gates/answered/` once acknowledged; record the outcome in
`progress/phase-log.md`.

## 5. Output: `project-config/freshness-report.md`

Write this file every run of P01 (it is what P02–P08 and later builders trust instead of
re-deriving freshness themselves):

```markdown
# Freshness Report — <ISO date of this run>

## Checked
<N claims checked, source: register seed + project-specific additions>

## Deltas (non-CONFIRMED verdicts)
| Claim | Verdict | Correction | Supersedes |
|---|---|---|---|
| <id> | REFUTED/PARTIALLY_CORRECT/UNVERIFIABLE | <exact corrected text> | <core/verticals file+line this overrides for this build> |

## Unchanged (CONFIRMED, still current)
<short list or "see verification-results.md — no material change">

## Gate G0 outcome
<proceeded / owner adjusted scope — link to gates/answered/G0.md>
```

Every downstream phase that would otherwise cite a dated fact from `core/*` or `verticals/*` must
check this file's **Deltas** table first and use the correction if present.

**NEXT:** `playbook/02-discovery-interview.md` (ELICIT stage) — or, if this is a resume, back to
`00-START-HERE.md §6` resume protocol.
