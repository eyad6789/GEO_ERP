---
id: P07
stage: DECIDE
audience: orchestrator, owner
read_when: module-selection decision chunk (after P05 architecture + P06 security baseline, before P08 design)
produces: modules[] in project-config/locked-decisions.json (PROPOSED until G1); ordered module inventory for progress/state.json
depends_on: core/features-core.md, verticals/*.md, playbook/03-decision-file-spec.md, playbook/02-discovery-interview.md, R8-testing-migration
runs_with: playbook/09-build-loop.md, playbook/templates/locked-decisions.schema.json, playbook/templates/state.template.json
---

# 07 · Features / Module Selection — The DECIDE Chunk

Turns the owner's interview answers (P02) into a **locked, dependency-ordered module inventory**. This is the one artifact 09-build-loop.md consumes directly — get the order wrong here and the BUILD stage builds modules before their dependencies exist. Do not re-derive module content: every module's data model, integrations, and failure mode already lives in `core/features-core.md` (grep it via `knowledge-map.md`, never bulk-read). This file only decides **which** modules and **in what order**.

## 1. How this chunk works

1. From the interview transcript, draft a candidate module set: universal checklist (§2) + vertical additions (§3).
2. Render as a checklist in `decisions.html` §modules, grouped by domain, each row tagged **PROPOSED** with a one-line "why" and its `core/features-core.md` anchor. Owner checks/unchecks; nothing here is decided until the owner acts.
3. Owner's final checked set + any vertical compliance modules → dependency-order it (§4) → write verbatim into `modules[]`.
4. Flag Gk candidates (§5) as you order — do this before G1, not after.
5. At G1: the ordered array is written into `locked-decisions.json.modules`, checksummed. `progress/state.json.modules` is seeded 1:1 from it (`{id, status:"pending", gated, commit:null}`) — this is the literal to-do list 09-build-loop.md works through.

**Never build a module that isn't in the locked array.** If BUILD discovers a missing dependency mid-stream, that's the "locked decision blocks correct implementation" stop condition in 09-build-loop.md — propose the addition, get sign-off, changelog + re-checksum.

## 2. Universal module checklist (grouped by domain)

All rows **PROPOSED** — selection state is the owner's, not a default. "Always" = foundational; deselecting it is a Gk-worthy deviation the orchestrator must push back on. Anchor = section in `core/features-core.md`.

| Domain | Module | Anchor (`core/features-core.md §`) | Selection |
|---|---|---|---|
| Financial | General Ledger + posting engine | 1.1 | **Always** |
| Financial | Accounts Payable | 1.2 | PROPOSED if any vendor spend |
| Financial | Accounts Receivable | 1.3 | PROPOSED if any customer billing |
| Financial | Fixed Assets | 1.4 | PROPOSED if capex/leases material |
| Financial | Cash Management | 1.5 | PROPOSED if bank reconciliation needed |
| Financial | Financial Consolidation | 1.6 | PROPOSED only if >1 legal entity |
| Financial | Multi-currency | 1.7 | PROPOSED if cross-border transactions |
| Financial | Multi-entity / Intercompany | 1.8 | PROPOSED if >1 legal entity |
| Financial | Budget Management | 1.9 | PROPOSED |
| Financial | Cost Center Accounting / Controlling | 1.10 | PROPOSED |
| SCM | Procurement | 3.1 | PROPOSED if the org buys goods/services at scale |
| SCM | Purchase Orders | 3.2 | PROPOSED (usually pairs with Procurement) |
| SCM | Supplier Management | 3.3 | PROPOSED |
| SCM | RFQ / Tendering | 3.4 | PROPOSED if competitive sourcing required |
| SCM | Contract Management | 3.5 | PROPOSED |
| SCM | Inventory Management | 3.6 | PROPOSED if physical goods held |
| SCM | Warehouse Management (WMS) | 3.7 | PROPOSED only once Inventory selected and multi-bin/pick-pack complexity exists |
| SCM | Demand Planning | 3.8 | PROPOSED |
| SCM | MRP / MPS | 3.9 | PROPOSED only if Manufacturing selected |
| Sales/CRM | Lead Management | 4.1 | PROPOSED |
| Sales/CRM | Opportunity Tracking | 4.2 | PROPOSED |
| Sales/CRM | Quotation / CPQ | 4.3 | PROPOSED if configurable products |
| Sales/CRM | Order Management | 4.4 | PROPOSED if selling goods/services |
| Sales/CRM | Pricing Engine | 4.5 | PROPOSED |
| Sales/CRM | Customer Portal | 4.6 | PROPOSED |
| Sales/CRM | Sales Forecasting | 4.7 | PROPOSED |
| Sales/CRM | Commission Management | 4.8 | PROPOSED if sales comp plans exist |
| Manufacturing | Bill of Materials (BOM) | 5.1 | PROPOSED if the org manufactures |
| Manufacturing | Work Orders | 5.2 | PROPOSED |
| Manufacturing | Production Planning | 5.3 | PROPOSED |
| Manufacturing | Capacity Planning | 5.4 | PROPOSED |
| Manufacturing | Shop Floor Control | 5.5 | PROPOSED |
| Manufacturing | Quality Management | 5.6 | PROPOSED if regulated or QA-critical |
| Manufacturing | EAM / Maintenance | 5.7 | PROPOSED if own production equipment |
| HCM | Core HR | 2.1 | PROPOSED if headcount managed in-system |
| HCM | Payroll | 2.2 | PROPOSED — confirm vs. outsourced payroll (ADP etc.) |
| HCM | Benefits Administration | 2.3 | PROPOSED |
| HCM | Time & Attendance | 2.4 | PROPOSED |
| HCM | Leave Management | 2.5 | PROPOSED |
| HCM | Performance Management | 2.6 | PROPOSED |
| HCM | Recruitment (ATS) | 2.7 | PROPOSED |
| HCM | Learning Management (LMS) | 2.8 | PROPOSED if compliance training tracked |
| HCM | Succession Planning | 2.9 | PROPOSED |
| HCM | Org Chart | 2.10 | PROPOSED |
| Projects | Project Accounting | 6.1 | PROPOSED if project-based revenue/cost |
| Projects | Resource Planning | 6.2 | PROPOSED |
| Projects | Timesheets | 6.3 | PROPOSED |
| Projects | Milestone Billing | 6.4 | PROPOSED |
| Projects | Earned Value Management (EVM) | 6.5 | PROPOSED if gov't/contract-EVM required |
| BI | Dashboards & KPIs | 7.1 | **Always** (minimum viable reporting) |
| BI | Ad-hoc Reporting | 7.2 | PROPOSED |
| BI | Scheduled & Operational Reports | 7.3 | PROPOSED |
| BI | OLAP Cubes | 7.4 | PROPOSED only at real analytical scale |
| BI | Data Export | 7.5 | PROPOSED |
| Workflow | Multi-level Approvals | 9.1 | **Always** (SoD requires it — see `core/security.md`) |
| Workflow | Delegation | 9.2 | PROPOSED |
| Workflow | Escalation | 9.3 | PROPOSED |
| Workflow | Notifications | 9.4 | **Always** |
| Workflow | Document Management (§8) | 8.1–8.5 | PROPOSED if contract/e-sign/retention needs exist |
| Integration | REST APIs | 10.1 | **Always** (external boundary, see `04-tech-stack.md §3`) |
| Integration | EDI | 10.2 | PROPOSED if B2B trading partners require it |
| Integration | Webhooks | 10.3 | PROPOSED |
| Integration | Third-party Connectors | 10.4 | PROPOSED — enumerate concretely (bank feed, tax engine, payroll co-source) |
| Admin | User Management | 11.1 | **Always** |
| Admin | Role Mgmt & SoD | 11.2 | **Always** |
| Admin | Audit Logs | 11.3 | **Always** (see `06-security-foundations.md`) |
| Admin | Data Import/Export | 11.4 | **Always** |
| Admin | Localization & Multi-language | 11.5 | PROPOSED |

Do not copy module internals into `decisions.html` or here — link the anchor; the owner (or a subagent) reads `core/features-core.md` only if they need the "what breaks without it" detail.

## 3. Route to the matching vertical file

Every build reads exactly **one** `verticals/*.md`, selected from the owner's declared industry in the P02 interview. The vertical file **adds** modules (industry-specific) and **imposes** compliance modules (non-optional in that industry) on top of §2 — it does not replace the universal set.

| Owner says… | Route to |
|---|---|
| Discrete/process manufacturer | `verticals/manufacturing.md` |
| 3PL, wholesaler, freight/carrier | `verticals/distribution-logistics.md` |
| Retail chain, D2C, marketplace seller | `verticals/retail-ecommerce.md` |
| Hospital, clinic, biotech, medical device | `verticals/healthcare-lifesciences.md` |
| Government agency, municipality, public sector | `verticals/government-publicsector.md` |
| Bank, insurer, asset manager, fintech | `verticals/financial-services.md` |
| Homebuilder, contractor, property manager | `verticals/construction-realestate.md` |
| Law/accounting/consulting/agency (billable hours) | `verticals/professional-services.md` |
| University, community college, higher-ed | `verticals/education.md` |
| K-12 public or private school / district | `verticals/schools.md` |
| Charity, foundation, NGO | `verticals/nonprofit-ngo.md` |
| Upstream/midstream/downstream energy | `verticals/oil-gas-energy.md` |
| Farm, food processor, agribusiness | `verticals/agriculture-food.md` |
| Defense contractor, aerospace OEM/MRO | `verticals/aerospace-defense.md` |

If no vertical is a clean fit (conglomerate, novel business model), pick the closest analog, **say so explicitly** in `decisions.html`, and raise it as a soft flag at G1 rather than silently guessing — vertical compliance modules (e.g. a mandated e-invoicing format) are exactly the kind of thing that's expensive to bolt on after BUILD starts. Each vertical file is self-contained (modules, compliance IDs, data entities, KPIs, cautions) — dispatch a subagent to read the one matching file and report back the delta against §2, don't read it yourself.

## 4. Dependency-ordered build sequence

This is the ordering the orchestrator applies to the owner's final checked set to produce `modules[]`. It mirrors — and is consumed by — the tier list in `09-build-loop.md § Module decomposition`; do not invent a different order there.

| Tier | Contents | Ordering rule |
|---|---|---|
| 0. Foundations | Data layer/migrations, tenant model + RLS (if multi-tenant, per `05-architecture-deployment.md`), auth/identity (OIDC), append-only + hash-chained audit-log spine, config/secrets | Always first. Not owner-selectable — it exists regardless of which domain modules are chosen. |
| 1. Ledger core | Chart of accounts, the double-entry posting engine, fiscal periods, number ranges | Always second, always before any sub-ledger. See `core/architecture.md § The Double-Entry Posting Engine`. The single most correctness-critical module in the whole inventory — see §5 below. |
| 2. Sub-ledgers & masters | AP, AR, Cash, Customer/Vendor/Item masters | Order within the tier by the owner's primary transaction flow: a distribution business orders Inventory-adjacent masters before AR; a services business orders AR + Project Accounting first. Record the reasoning in `phase-log.md`, not just the array. |
| 3. Domain modules | Everything selected in §2 (SCM, Sales/CRM, Manufacturing, HCM, Projects) + vertical additions from §3 | **Topologically sort using `core/features-core.md § 12.1 Module Dependency Map`** — e.g. WMS after Inventory; MRP/MPS after BOM + Inventory; Work Orders after BOM + Routing + Inventory; Quality Mgmt after Inventory + Procurement + Manufacturing. A module with an unmet hard dependency cannot appear before the dependency in `modules[]`. |
| 4. Cross-cutting | BI/Reporting, Workflow & Approvals, Integration/API surface, Admin/RBAC UI | After domain modules exist (nothing to report on or approve yet without them), before UI. |
| 5. UI | Per `08-design-system.md`, per module, on top of the API surface | Always last per module — UI is a thin layer over an already-verified API, never built ahead of it. |

**Worked example** (distribution company; owner selected GL, AP, AR, Inventory, Procurement, WMS, Order Management, Pricing Engine, BI dashboards, Workflow approvals, Admin):

```
["foundations", "ledger-core", "ap-ar-masters",
 "inventory-management", "procurement", "purchase-orders",
 "warehouse-management", "order-management", "pricing-engine",
 "reporting-bi", "workflow-approvals", "admin-rbac",
 "ui-financial", "ui-scm", "ui-sales", "ui-admin"]
```

Note WMS ordered after Inventory (hard dependency, §12.1), and Order Management after both Inventory/WMS and AR-bearing masters (it triggers revenue posting).

## 5. Flag for owner gates (Gk)

Flag a module for a **Gk** gate (per `00-START-HERE.md § gate registry`) — not a silent build — whenever a bug in it would move real money, permanently change security posture, or destroy/leak data with no rollback. Add `"gated": true` to that module's entry in `progress/state.json`; the build loop stops and surfaces before COMMIT on any gated module (`09-build-loop.md` stage 5).

| Module / path | Why it's gated | Notes |
|---|---|---|
| Ledger core (posting engine) | Money-adjacent, irreversible once posted; single highest-leverage correctness surface | Requires property-based + mutation testing (mutation score ≥80–85%) before VERIFY passes — see `10-quality-gates.md` and R8-testing-migration Part A.2, A.7 (verify current thresholds/tooling via `01-freshness-check.md`) |
| AP payment run / bank disbursement | Money leaves the company; NACHA/SWIFT file generation | Confirm payment-provider/bank-file format choice with owner before building |
| Payroll disbursement & tax filing | Money + PII + statutory penalty exposure | Confirm in-house vs. outsourced (ADP-style) payroll before building |
| Auth/Identity, RBAC/SoD, tenant-isolation (RLS) boundary | Irreversible security posture; a gap here is a breach, not a bug | Ties to `06-security-foundations.md` baseline; Opus-level review per system facts, not Sonnet-only |
| Vertical compliance modules (e.g. e-invoicing, HIPAA/PHI handling, ITAR/export control) | Legal/regulatory irreversibility | Route to the specific vertical file's compliance section before building |
| Data migration & cutover | Irreversible production cutover; wrong reconciliation = corrupted books | Follow the 7-phase migration runbook (`core/implementation.md`; runbook detail in R8-testing-migration Part B) — control totals + GL tie-out are blocking, not advisory |

General rule for anything not on this table: **if a bug in module M either moves real money, exposes/corrupts data across tenants, or cannot be rolled back without data loss, flag it.** When in doubt, flag it — an unnecessary Gk costs one owner reply; a missed one costs an incident.

## 6. Emit into locked-decisions.json (at G1)

`modules` is a flat, ordered array of kebab-case module ids (schema: `playbook/templates/locked-decisions.schema.json`) — the array *is* the build order, position encodes dependency, not just membership:

```json
"modules": [
  "foundations", "ledger-core", "ap-ar-masters",
  "inventory-management", "procurement", "purchase-orders",
  "warehouse-management", "order-management", "pricing-engine",
  "reporting-bi", "workflow-approvals", "admin-rbac",
  "ui-financial", "ui-scm", "ui-sales", "ui-admin"
]
```

Every id above is **PROPOSED** until the owner's checked selection (§2–§3) plus the dependency sort (§4) is written into a checksummed `locked-decisions.json` at G1. Immediately after lock, seed `progress/state.json.modules` 1:1 from this array — `{ "id": "<same string>", "status": "pending", "gated": <true|false per §5>, "commit": null }` — this is the literal work queue `09-build-loop.md` iterates.

## 7. What this chunk feeds downstream

- `09-build-loop.md` reads `modules[]` in order; it is the loop's outer iteration, one SPEC.md per entry.
- `10-quality-gates.md` gate 9 (drift linter) also checks that no module *not* in this array was built.
- `08-design-system.md` builds UI only for modules already present in this array (tier 5 depends on tiers 0–4 existing).

**NEXT:** `playbook/08-design-system.md` (design decision chunk — same G1 lock), then `playbook/09-build-loop.md` once G1 is locked and BUILD starts.
