# Phase Log — <project name>

Append-only. One entry per phase/module iteration. This is the "why" record a resuming
session reads to reconstruct intent. Never edit past entries; only append.

Entry format:

---
## <ISO timestamp> · <phase-id> · <status>

- **Did:** what was built/decided this iteration.
- **Honored decisions:** which `locked-decisions.json` keys governed this work.
- **Autonomous decisions:** choices I made without an owner gate, and why (this is where
  non-gate decisions are recorded so the owner can audit them later).
- **Verify:** pass/fail + evidence path (`progress/reviews/<phase>.md`).
- **Next:** the immediate next action.
---

<!-- EXAMPLE (delete when starting) -->
## 2026-07-06T14:22:00Z · P09/posting-engine · done

- **Did:** implemented the double-entry posting engine with idempotent post via outbox;
  property-based tests for debit==credit, no-mutation-of-posted, idempotent replay.
- **Honored decisions:** stack.db=postgres, stack.orm=prisma+raw-sql (posting path uses raw
  parameterized SQL in a serializable txn), security.audit_log=append-only+hash-chain.
- **Autonomous decisions:** chose SERIALIZABLE isolation for the post txn (not READ COMMITTED)
  because concurrent posts to the same period must not interleave; logged rather than gated
  because it's an implementation detail within the locked stack.
- **Verify:** PASS — progress/reviews/P09-posting-engine.md (12/12 gates green, mutation 88%).
- **Next:** P09/accounts-payable.
