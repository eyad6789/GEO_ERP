# _project-instance — the per-build scaffold

This directory is a **template**, not live state. At the start of a new ERP build, the orchestrator copies its structure into the **target ERP project's own repository** (not this doctrine library — the library stays reusable and un-churned across many builds).

## What gets copied where

Into the target ERP repo:

```
project-config/
  locked-decisions.json     ← from playbook/templates/project-config.template.json (filled at P02/P03, locked at G1)
  decisions.html            ← generated from playbook/templates/decision-file.html
  interview-transcript.md   ← written during P02
  freshness-report.md       ← written during P01
  gates/pending/ · gates/answered/   ← gate files (from playbook/templates/gate.template.md)
progress/
  state.json                ← from playbook/templates/state.template.json
  phase-log.md              ← from playbook/templates/phase-log.template.md
  reviews/                  ← verify-phase.sh evidence, one file per phase
scripts/
  verify-phase.sh           ← from playbook/templates/verify-phase.sh
.claude/
  settings.json             ← merge playbook/templates/settings-hooks.json (enforcement hooks)
  agents/                   ← the builder / qa-reviewer / security-reviewer / verifier roles
```

The skeleton files under this directory (`progress/state.json`, `progress/phase-log.md`) are seed copies you can lift directly. See `00-START-HERE.md` §1 for the start-vs-resume decision that triggers this copy.
