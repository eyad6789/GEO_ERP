---
id: START-HERE
stage: ORIENT
audience: orchestrator
read_when: session start, always, right after CLAUDE.md
produces: a decision to enter freshness-check or resume
---

# 00 · START HERE — Orchestrator Boot ROM

Read this once per session. It is the operating procedure for building an ERP with this library. `CLAUDE.md` gave you the invariants; this file gives you the machine.

You are the **orchestrator**. You think, plan, and dispatch. Sonnet subagents at maximum effort do the reading, building, reviewing, and verifying. You keep your own context clean (see §7).

---

## 1. Are you STARTING or RESUMING?

Before anything, check for an existing **locked** build. The seed `locked-decisions.json` is copied in unlocked (checksum null) at kickoff, so its mere existence is not "resume" — test the checksum:

```
jq -e '.checksum != null' ./project-config/locked-decisions.json >/dev/null 2>&1 && echo RESUME || echo START
```

- **START** (file absent, or checksum null) → go to §2 (the pipeline, from Phase 01).
- **RESUME** (decisions locked at G1) → go to §6 (resume protocol). Do **not** re-interview or re-decide.

> The per-project files (`project-config/`, `progress/`) live in the **ERP project's own repository**, not in this doctrine library. When you kick off a build you copy the `_project-instance/` template into the target repo. This library stays reusable and un-churned across many builds.

---

## 2. The pipeline (state machine)

Five stages. Numbered phases are referenceable ("at gate G1 I lock decisions"). Phases inside DECIDE are decision *chunks* that all feed one `locked-decisions.json`; they are not separate build passes.

```
ORIENT   P01 Freshness check ........................ [GATE G0: review what changed]
ELICIT   P02 Discovery interview (chunked MCQ + open elicitation)
DECIDE   P03 Decision file (Anthropic-design HTML) → owner chooses
             ├─ P04 Tech stack        (chunk)
             ├─ P05 Architecture/deploy + tenancy (chunk)
             ├─ P06 Security baseline  (chunk)
             ├─ P07 Feature/module set (chunk)
             └─ P08 Design system      (chunk)
                                        ................ [GATE G1: LOCK locked-decisions.json]
BUILD    P09 Build loop, per module M:
             plan(M) → build(M) → QA-review(M) → security-review(M) → verify(M)
                                        ................ [GATE Gk: only for owner-flagged risky modules]
HARDEN   P10 Quality gates + security hardening pass (whole system)
SHIP     P11 Deployment / production ................ [GATE G2: approve production deploy]
```

Run phases with the **workflows**, not by hand: `workflows/verify-claims.js` (freshness), `workflows/build-module.js` (the P09 loop), `workflows/adversarial-review.js` (P10). See `manifest.md`.

---

## 3. The gate registry (the ONLY times you stop for the owner)

Announce this schedule to the owner at the start of P02 ("I will come back to you at G0, G1, per-risky-module gates, and G2; everything else I decide and log"). A gate = write a file in `project-config/gates/pending/`, set `state.json.phase_status = "blocked_on_gate"`, **stop, and surface the question**. When answered, move it to `gates/answered/`.

| Gate | After | Type | What the owner decides |
|---|---|---|---|
| **G0** | P01 | soft | "N things changed since 2026-07 — proceed / adjust scope?" |
| **G1** | P03–P08 | **hard** | The whole decision file: stack, tenancy, deployment, security baseline, modules, design. Locks `locked-decisions.json`. Nothing builds before this. |
| **Gk** | per risky module | hard | Narrow, module-specific (e.g. "approve the payment-provider choice"; "confirm the GL posting rules"). Only for modules the owner or you flagged as high-stakes. |
| **G2** | before P11 | **hard** | Approve production deployment + supply production secrets. |

Everything not on this list, you decide yourself and write to `progress/phase-log.md`. If a locked decision genuinely conflicts with reality mid-build, that is the one *unscheduled* reason to stop: surface it, propose the change, and only edit `locked-decisions.json` after owner sign-off (with a changelog entry + new checksum).

---

## 4. Roles (who does what)

You spawn subagents in these roles (defined in `.claude/agents/`). **≥90% Sonnet at max effort**; Opus only where noted.

| Role | Model | Job |
|---|---|---|
| **orchestrator** | you (Opus+) | plan, dispatch, hold the state machine, talk to the owner |
| **researcher** | Sonnet-max | web-verify a claim / gather current facts, return structured findings |
| **builder** | Sonnet-max | implement one module/task against the spec + locked decisions |
| **qa-reviewer** | Sonnet-max | correctness, tests, edge cases, coverage; adversarial toward the builder |
| **security-reviewer** | Sonnet-max (Opus for auth/payments/multi-tenant isolation) | run the relevant `security/scenarios/*` against the module; try to break it |
| **design-qa-reviewer** | Sonnet-max | for UI modules: look at the actual screenshots, drive the flows, score against the design rubric (`playbook/12-…`) |
| **verifier** | Sonnet-max | run `verify-phase.sh`, capture evidence, flip phase to done or bounce it back |

The builder and the verifier are **always different contexts**. A module is not done until QA, security, verify — and for UI modules, design-QA — all pass.

---

## 5. Definition of Done (every phase)

A phase/module is `done` only when the verifier confirms, with captured evidence in `progress/reviews/<phase>.md`, that ALL pass:

```
format ✓  ·  lint ✓  ·  typecheck/compile (strict) ✓  ·  unit+integration tests ✓
diff-coverage ≥ threshold ✓  ·  stub/empty-file scan ✓  ·  orphan/dead-code scan ✓
locked-decision drift scan ✓  ·  security scenario checks for this module ✓
dependency/secret audit ✓  ·  smoke run of the actual code path ✓
→ evidence written · phase-log appended · git committed
UI verify (UI phases): Playwright e2e light+dark · visual regression · axe WCAG 2.2 AA · Lighthouse ✓
design-QA: screenshots of every state×theme looked at, rubric ≥85, review artifact attached ✓ (UI phases)
```

Green or not done. Details and the exact commands are in `playbook/10-quality-gates.md`, `playbook/12-ui-ux-visual-verification.md`, and `playbook/templates/verify-phase.sh`.

---

## 6. Resume protocol (after a crash, compaction, or new session)

Never trust a `done` flag blindly — a crash mid-write is exactly how empty/stub files appear.

1. Read `progress/state.json` (position) and the **tail** of `progress/phase-log.md` (last actions + reasoning).
2. `git log --oneline -15` — the last real checkpoint.
3. **Re-run the verifier** on the last phase marked `done`. If it fails, that phase wasn't actually complete — resume there.
4. Resume at the first phase whose DoD fails. If `state.json`, the log, and git disagree: **git wins for "what exists," the verify script wins for "is it done."** Reconcile `state.json` to match reality before continuing.
5. If `locked-decisions.json`'s checksum doesn't match its recorded hash, stop and surface it — someone edited decisions out of band.

---

## 7. Context hygiene (keep your own window clean)

You are the orchestrator; your context is precious. Rules:

- **Delegate reads.** Don't read `core/*` or `verticals/*` yourself — send a subagent with a specific `knowledge-map.md` anchor and get back only the conclusion.
- **Never open `glossary.md` whole.** Grep it (see `knowledge-map.md` §glossary).
- **Checkpoint at ~75%.** Above ~75% context usage: write `state.json` + `phase-log.md`, then `/compact` (or rewind to the last checkpoint). Never start a new phase above 75%.
- **One phase at a time in your head.** Batch/fan-out work belongs in a `workflows/*.js` run (re-runnable, isolated), not in your main context.

---

## 8. What to read next

- Starting a build → `playbook/01-freshness-check.md` (and run `workflows/verify-claims.js`).
- Need to know which doc covers what → `manifest.md`.
- Need a fact from the knowledge library → `knowledge-map.md`.

**NEXT:** `manifest.md`, then `playbook/01-freshness-check.md`.
