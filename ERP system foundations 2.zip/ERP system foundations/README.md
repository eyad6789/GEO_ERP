# ERP Build Operating System

This folder is two things at once:

1. A **build operating system** — a guided pipeline a Claude session (Opus orchestrator + Sonnet-max subagents) reads and executes to build a production ERP, from first interview to production deployment.
2. A **knowledge library** — a dense, citation-backed engineering reference for designing ERP internals, organized as universal core concerns + 15 industry verticals + a glossary.

If you are a Claude session pointed here to build something: **stop reading this file and open [`CLAUDE.md`](CLAUDE.md), then [`00-START-HERE.md`](00-START-HERE.md).** This README is the human-facing map.

---

## The build pipeline (what happens when you build an ERP here)

```
ORIENT   01 Freshness check ....... web-verify what changed since 2026-07   [gate G0]
ELICIT   02 Discovery interview .... chunked MCQs + your own explanation
DECIDE   03 Decision file .......... Anthropic-design HTML: choose stack, tenancy,
            04–08                     deployment, security baseline, modules, design [gate G1: LOCK]
BUILD    09 Build loop ............. per module: builder → QA → security → verify  [gate Gk]
HARDEN   10 Quality gates .......... full security sweep + verification
SHIP     11 Deployment ............ production, backups, monitoring            [gate G2]
```

You are asked to decide **only at the gates** (G0/G1/Gk/G2). Everything else the orchestrator decides and logs. "Done" for any phase means the verification script exits 0 — never a claim.

### Build-OS files

| File | Role |
|---|---|
| [NORTH-STAR.md](NORTH-STAR.md) | The intent the machinery serves — read first. What "ideal" means; the three sacred things. |
| [CLAUDE.md](CLAUDE.md) | Auto-loaded orientation + the prime directives (agent roles, no-stub rule, gates, context hygiene). |
| [00-START-HERE.md](00-START-HERE.md) | The state machine, gate registry, roles, and resume-after-crash protocol. |
| [manifest.md](manifest.md) | Machine-readable catalog: what every file is and when to read it. |
| [knowledge-map.md](knowledge-map.md) | How to pull a fact from the library without bulk-loading it. |
| [playbook/](playbook/) | Phases 01–12 (incl. UI/UX + visual verification), security scenarios & checklists, templates. |
| [playbook/advanced/](playbook/advanced/) | Optional-depth doctrine (each with an ADOPT-WHEN trigger): bitemporal ledger, provable correctness, MDM/integration/migration, clean-core extensibility, semantic layer, AI-native operation, frontier authz/crypto, process & benefit realization. |
| [workflows/](workflows/) | Executable orchestration: `build-module.js`, `verify-claims.js`, `adversarial-review.js`. |
| [.claude/agents/](.claude/agents/) | The Sonnet-max roles: researcher, builder, qa-reviewer, security-reviewer, design-qa-reviewer, verifier. |

---

## Knowledge library

Read the core files first to establish architectural foundations, then drill into the vertical for your domain. **These are grep / single-section references — do not read them whole** (see [knowledge-map.md](knowledge-map.md)).

### Core references

| File | Covers |
|---|---|
| [core/architecture.md](core/architecture.md) | Posting engine, document model, chart of accounts, fiscal periods, number ranges, costing, multi-currency, multi-entity, multi-tenancy, concurrency, audit immutability, eventing, extensibility. |
| [core/features-core.md](core/features-core.md) | Every functional module (Financial, HCM, SCM, Sales/CRM, Manufacturing, Projects, BI, DMS, Workflow, Integration, Admin) → data entities, integrations, and "what breaks without it". |
| [core/security.md](core/security.md) | RBAC/ABAC/SoD, authN, encryption, audit infrastructure, compliance by region, ERP CVEs, pen-testing, backup/DR, attack vectors. |
| [core/localization-tax.md](core/localization-tax.md) | Indirect tax engines, CTC e-invoicing mandates by country, SAF-T, ISO 20022 payments, fiscal devices, payroll filings. |
| [core/implementation.md](core/implementation.md) | Methodologies, data migration, change management, go-live, integration architecture, cost/timeline benchmarks. |
| [core/cautions.md](core/cautions.md) | Nine sourced real-world failure cases + systematic failure modes (scope creep, customization trap, data quality, vendor lock-in). |

> For **building** secure ERP (threat models, multi-tenant isolation, hash-chained audit DDL, AI/LLM threats), use [playbook/06-security-foundations.md](playbook/06-security-foundations.md) and [playbook/security/scenarios/](playbook/security/scenarios/) — that is the build doctrine; `core/security.md` is the reference survey.

### Industry verticals

| File | Domain |
|---|---|
| [manufacturing](verticals/manufacturing.md) | Discrete/process/mixed: MRP II, BOM, MES/ISA-95, IATF 16949, AS9100, traceability. |
| [distribution-logistics](verticals/distribution-logistics.md) | WMS/TMS, EDI sets, landed cost, 3PL billing, FSMA 204, DSCSA, C-TPAT/AEO. |
| [retail-ecommerce](verticals/retail-ecommerce.md) | POS/OMS, omnichannel inventory, PCI DSS v4.0.1, ASC 606. |
| [healthcare-lifesciences](verticals/healthcare-lifesciences.md) | RCM (837/835, DRG), GS1 EPCIS/DSCSA, UDI, 21 CFR Part 11/QMSR, HIPAA, GxP/GAMP 5. |
| [government-publicsector](verticals/government-publicsector.md) | Fund accounting, appropriations, 2 CFR 200, FAR/DFARS, GASB/SFFAS/IPSAS, FedRAMP/FISMA/CMMC. |
| [financial-services](verticals/financial-services.md) | Parallel ledgers, IFRS 9 ECL, Basel III/IV, IFRS 17, Solvency II, FATCA/CRS, AML/KYC. |
| [construction-realestate](verticals/construction-realestate.md) | Job costing, WIP, AIA billing, retainage, certified payroll, ASC 842/606/910. |
| [professional-services](verticals/professional-services.md) | PSA, WIP, ASC 606/IFRS 15, FAR/DCAA/CAS, legal trust accounting. |
| [education](verticals/education.md) | Higher-ed: SIS, Title IV aid, sponsored research (2 CFR 200), GASB/FASB, UPMIFA, FERPA. |
| [schools](verticals/schools.md) | K-12 public districts (GASB, ESSA/IDEA, E-rate, child nutrition) + private schools (tuition, FASB, vouchers, UBIT/990, diocesan). |
| [nonprofit-ngo](verticals/nonprofit-ngo.md) | Fund accounting (ASU 2016-14), grant lifecycle (2 CFR 200), donor CRM, Form 990, USAID/ECHO/FCDO. |
| [oil-gas-energy](verticals/oil-gas-energy.md) | Upstream E&P (JIB/DOI/AFE/ARO), midstream, refining, ASC 932, FERC, NERC CIP, IFRS S2. |
| [agriculture-food](verticals/agriculture-food.md) | Farm management, FSMA 204, catch-weight, FEFO, grower settlement, commodity hedging, H-2A. |
| [aerospace-defense](verticals/aerospace-defense.md) | ITAR/EAR, DCAA project accounting, EVMS (ANSI/EIA-748-E), AS9100/AS5553E, MRO airworthiness. |

### Glossary

Split for retrieval under [glossary/](glossary/README.md) — grep it, don't open it whole: `grep -rni "^| ZATCA " glossary/`.

---

## Provenance & trust

The knowledge library was built (June 2026) via a Research→Write→Harden agent pipeline with numbered citations. In 2026-07 it was audited and 44 flagged 2025–2026 claims were re-verified against primary sources (32 confirmed, 11 corrected, 1 refuted) — the register lives in [playbook/01-freshness-check.md](playbook/01-freshness-check.md). Facts still carry dates; **re-verify fast-moving claims before building compliance logic** (that is what Phase 01 is for).

## Sources & further reading

FASB ASC · IFRS Foundation · SAP S/4HANA & Oracle Fusion & Microsoft Dynamics 365 docs · Gartner Cloud ERP Magic Quadrants · ISO/IEC 27001:2022 · NIST SP 800-53 Rev 5 · NIST SP 800-207 (Zero Trust) · OWASP ASVS / Top 10 / LLM Top 10.
