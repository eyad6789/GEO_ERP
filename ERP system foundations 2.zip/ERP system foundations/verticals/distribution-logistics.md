# ERP for Distribution & Logistics

## 1. Overview

Distribution and logistics ERP is defined by **margin compression and velocity**: the core value proposition is moving inventory faster and cheaper than competitors, not transforming raw materials or serving end consumers. Unlike manufacturing ERP — where BOM explosions, routings, and production orders dominate — distribution ERP centers on order throughput, carrier economics, and inventory accuracy across warehouse networks. Unlike retail ERP, there is no POS, no merchandising, and no consumer loyalty dimension; the customer is almost always a business buyer placing structured orders via EDI or API.

Three primary sub-segments shape requirements differently:

| Sub-segment | Inventory Ownership | Primary ERP Tension | Billing Driver |
|---|---|---|---|
| Third-Party Logistics (3PL) provider | Client-owned (never on 3PL balance sheet) | WMS custody + activity billing vs. client financial systems | Activity-based: storage positions, handling events, VAS hours |
| Wholesaler / Distributor | Self-owned; on own balance sheet | Purchasing, inventory valuation, margin tracking | Product margin on buy-sell; freight recovery |
| Last-mile / Courier carrier | Never inventory; owns delivery routes and vehicles | TMS route optimization, driver settlement, POD capture | Per-parcel or per-stop delivery fees |

The architectural fork that defines every implementation is **embedded WMS/TMS vs. best-of-breed integration**:

- **Embedded path**: SAP S/4HANA with EWM + TM, or Oracle Fusion Cloud SCM with WMS Cloud + OTM, or Microsoft D365 Supply Chain Management with its Warehouse Management and Transportation Management modules. Single data model, no middleware for inventory sync, but license cost is high and WMS functionality may lag purpose-built alternatives.
- **Best-of-breed path**: financial backbone (SAP, Oracle, NetSuite, Dynamics) integrated to standalone WMS (Manhattan Active WM, Blue Yonder WMS, Deposco) and standalone TMS (OTM, Blue Yonder TMS, Infios/MercuryGate). Stronger execution capability, but requires robust integration layer (REST/SOAP/EDI) and introduces eventual-consistency risk on inventory positions.

For 3PLs specifically, inventory is never owned, so the ERP's cost-of-goods-sold flow is absent. Instead, the system tracks **custody** (where is the client's stock at each moment, which LPN, which location) and **billable activity** (every touch generates a billing event). See `core/architecture.md` for integration patterns between financial ERP and execution systems.

---

## 2. Industry-Specific Modules

### 2.1 Warehouse Management System (WMS) Depth

#### Receiving

Receiving begins before the truck arrives. **Dock scheduling** allocates door assignments and time windows to inbound carriers, preventing dock congestion. Two receiving modes exist: **blind count** (receivers count without seeing expected quantities, forcing independent verification) and **PO-matched receiving** (system presents expected lines; receiver confirms actuals). **ASN-driven receiving** is standard for sophisticated trading partners: the carrier's EDI 856 Advance Ship Notice contains an SSCC hierarchy (pallet > case > each), and receivers scan the GS1-128 barcode (Application Identifier 00) on each SSCC to auto-populate receipt lines, reducing keying errors [1]. Discrepancies (over/under/damaged) route to a configurable exception workflow: quarantine hold, claim filing against carrier, or vendor deduction. Quality holds place LPNs in a non-allocatable location pending QC disposition.

#### Putaway

**Directed putaway** computes an optimal location for each LPN based on configurable rules: zone affinity (frozen, ambient, controlled substance), velocity class (A-items to pick face, C-items to deep storage), weight constraints (heavy floor-level only), lot integrity (same lot consolidated), and hazmat segregation (incompatible classes separated by minimum distance). The WMS tracks each pallet as a **License Plate Number (LPN)**, linked to its GS1 SSCC. Bulk pallets placed in reserve storage must be replenished to pick faces before depletion; the WMS fires replenishment tasks when pick face falls below minimum quantity.

#### Slotting Optimization

Slotting assigns SKUs to pick locations to minimize picker travel and ergonomic strain. Input variables: velocity class (ABC by picks, XYZ by quantity), cube utilization, item weight/dimensions, hazmat constraints, seasonality. WMS vendor benchmarks commonly cite reductions in average picker travel distance of 15–25% after re-slotting; no single peer-reviewed study provides a canonical figure, so treat as qualitative guidance from vendor sources. Re-slotting triggers include new SKU introduction, seasonal demand shift, and post-physical-inventory analysis. The WMS generates a slotting proposal; warehouse managers review and approve before executing moves.

#### Picking Strategies

| Strategy | Mechanism | Best For |
|---|---|---|
| Wave picking | Orders batched by carrier cut-off or ship date; released as a wave; pickers work the wave | High-volume outbound; tight carrier manifest windows |
| Zone picking | Each picker assigned to a warehouse zone; orders travel between zones via conveyor or tote; consolidated at merge point | Large warehouses with long aisles; reduces per-picker travel |
| Batch picking | Single picker fulfills N orders simultaneously, sorting to order totes at pick | Low-SKU-count orders; high order volume |
| Cluster picking | Picker carries multi-tote cart; voice or RF directs pick-and-sort per slot | E-commerce multi-line orders; carton diversity |
| Pick-to-light | LED displays at pick locations illuminate qty and confirm pick | High-speed each-pick environments |
| Voice-directed picking | WMS sends pick instructions via headset; picker responds verbally | Hands-free; cold-chain environments where gloves impede RF scanning |

#### Cycle Counting

Cycle counting replaces annual physical inventory for most distribution operations. Locations are stratified by ABC frequency: A locations counted weekly or daily, C locations quarterly. **Blind count** (system hides on-hand before count) produces more accurate results. Variance above configurable tolerance (e.g., ±2 units or ±$500) requires supervisor approval and reason code before posting an inventory adjustment journal to the financial ERP general ledger. Adjustment journals must reference the count document for auditability.

#### Cartonization

Cartonization runs a 3D bin-packing algorithm against confirmed pick lines, selecting the optimal carton type(s) by weight, volume, and overhang constraints. Output: one or more carton SSCCs linked to the outbound shipment, each with a ZPL/ZPL2 shipping label printed to a Zebra thermal printer at the pack station. The carton SSCC feeds the outbound EDI 856 ASN to the customer. Cartonization accuracy directly affects carrier dimensional weight charges; under-sized selection increases DIM weight cost.

#### Pack and Ship

After cartonization, packers confirm contents, capture actual weight on a scale integrated to the WMS, and trigger carrier label generation via the carrier's REST API (UPS, FedEx, USPS, DHL) or a multi-carrier platform (EasyPost, ShipStation, Shippo). The WMS generates a **carrier manifest** — a consolidated record of all shipments tendered to a carrier in a day, required for bulk carrier pickup.

#### Returns and Reverse Logistics

Returned merchandise arrives against an RMA (Return Merchandise Authorization). The WMS directs disposition at receipt: resell to available stock, repack/refurb to a value-added service queue, or scrap with write-off posting. Lot re-capture is required if the item is lot-controlled. 3PL returns billing captures handling events (receipt, inspection, disposition) as billable activity against the client's rate card.

---

### 2.2 Transportation Management System (TMS)

**Rate shopping** connects to carrier rate APIs (UPS Worldship API, FedEx Ship Manager API, USPS Web Tools, DHL eCommerce API) and LTL/TL broker APIs (XPO Connect, Echo Global) to return the lowest compliant rate for a given shipment — mode (parcel/LTL/FTL/intermodal), service level (ground, express, overnight), and accessorial charges (liftgate, residential delivery, fuel surcharge, oversize). Rate shopping logs rated alternatives for freight cost audit.

**Load planning** for LTL and FTL applies cubic optimization and weight/class constraints. LTL shipments require NMFC (National Motor Freight Classification) codes per item, which determine freight class (50–500) and therefore the rated price. FTL planning considers driver hours-of-service and DOT weight limits (80,000 lb gross).

**Freight audit and pay** reconciles carrier invoices against the originally rated shipment record. Common discrepancies: incorrect dimensional weight, unapplied contract rates, duplicate billings, accessorial charges not agreed to. The TMS flags exceptions for a dispute workflow before payment authorization. This function typically recovers 1–3% of freight spend when implemented rigorously (figure is qualitative guidance from freight audit practitioners; validate against your own carrier mix and contract complexity).

**Freight cost allocation** distributes actual carrier invoice amounts across purchase order lines or inventory receipt lines using one of four methods: value-based (default for customs duty), weight-based (most common for ocean freight), quantity-based (per-unit fees), or volume-based (cubic). The allocation posts to inventory cost at receipt and produces a landed cost variance when actuals differ from standard estimates.

---

### 2.3 Landed Cost Management

Landed cost captures the full cost of an imported item: supplier invoice (FOB), ocean or air freight, customs duty (determined by HTS code), import brokerage, cargo insurance, inland drayage, port handling charges, and any other fees. The 20–40% uplift over FOB price commonly cited in logistics literature is a qualitative range that varies significantly by origin lane, modal choice, and product category — validate against your actual trade lanes; do not use as a budgetary constant.

ERP implementation requires decisions on:

- **Standard vs. actual cost**: standard cost assigns a fixed landed cost per item at the beginning of a period; actual cost captures real charges. The difference posts as a purchase price variance (PPV) or a landed cost variance.
- **Currency conversion rates**: PO rate (locked at order), receipt rate (spot on receipt date), and invoice rate (spot on invoice date) can each be the governing rate for a different component. Accounting policy must define which rate applies to each cost element; inconsistency causes audit findings.
- **Duty drawback**: if imported goods are subsequently re-exported, the importer may claim a drawback (refund of duty paid). ERP must maintain the import entry reference on each lot of inventory to support drawback filing.

---

### 2.4 EDI Transaction Sets

The distribution vertical is one of the heaviest EDI consumers in any ERP implementation. ASC X12 governs U.S. domestic trading partner exchanges; UN/EDIFACT governs international trading partners [2].

| TX Set | Name | Direction | Key Fields |
|---|---|---|---|
| 850 | Purchase Order | Customer → Distributor/3PL | PO#, item, qty, price, ship-to |
| 855 | PO Acknowledgment | Distributor → Customer | Accepted/rejected lines, substitutions |
| 856 | Advance Ship Notice (ASN) | Shipper → Receiver | SSCC hierarchy, lot, serial, carrier, PRO# |
| 810 | Invoice | Distributor → Customer | Invoice#, PO#, line amounts, tax |
| 940 | Warehouse Shipping Order | Merchant → 3PL WMS | Order to pick and ship from 3PL |
| 945 | Warehouse Shipping Advice | 3PL WMS → Merchant | Confirmation of shipped items, SSCC, tracking |
| 997 | Functional Acknowledgment | Receiver → Sender | Accept/reject EDI envelope |
| 214 | Carrier Status/Tracking | Carrier → Shipper | Shipment status events and ETA |
| 204 | Motor Carrier Load Tender | Shipper → Carrier | Load tender with stop sequence |
| 990 | Response to Load Tender | Carrier → Shipper | Accept/reject 204 |

**Versions in use**: ASC X12 version 5010 is the widely mandated current standard for health-related transactions (HIPAA) and is broadly adopted in distribution EDI; legacy retail trading partners (particularly in grocery) may still mandate version 4010. Version mismatch at the ISA/GS envelope level causes wholesale rejection — agree on version in the trading partner agreement before implementation. UN/EDIFACT equivalents: ORDERS (850), ORDRSP (855), DESADV (856), INVOIC (810), WHSORD (940), WHSRSP (945).

**SSCC and EDI 856 linkage**: The GS1 SSCC (Serial Shipping Container Code) is an 18-digit numeric identifier encoded in a GS1-128 barcode (Application Identifier 00) [1]. The SSCC on the physical label is the same identifier transmitted in the EDI 856 hierarchy loop (HL segment, SSCC in REF*BM), giving the receiver a scannable link between the physical shipment and the electronic ASN. Major retailer compliance programs (Walmart Retail Link, Target Partners Online, Amazon Vendor Central) mandate ASN transmission before the shipment arrives at the DC; failure triggers chargebacks typically in the 1–3% of invoice value range (verify chargeback schedule in each retailer's compliance guide, as rates vary and change).

**Mapping engine requirements**: per-trading-partner mapping matrices are unavoidable. Even within the same X12 version, retailer-specific segment usage notes, conditional element rules, and loop counts vary. A robust EDI VAN or integration platform (SPS Commerce, TrueCommerce, Cleo Integration Cloud, OpenText Trading Grid) manages per-partner variants and provides compliance testing portals. Implement 997 functional acknowledgment monitoring with SLA alerts: un-acknowledged 997s within the agreed window indicate transmission failure or partner-side rejection that otherwise goes silent.

---

### 2.5 Cross-Docking

Cross-docking eliminates storage by moving freight from inbound dock to outbound dock within hours. Three variants:

- **Flow-through (pre-planned)**: demand is reserved against inbound ASN before goods arrive. At receipt, the WMS directs the LPN directly to a staging lane for an outbound load — no putaway transaction occurs. Common in retail store replenishment from DCs.
- **Opportunistic (dynamic)**: at time of receipt, the WMS checks open outbound orders for the item. If a match exists and the outbound load has not manifested, the system converts the putaway task to a cross-dock task. Requires real-time ATP evaluation.
- **Consolidation cross-dock**: multiple inbound shipments from different suppliers are broken down and rebuilt into store- or customer-specific outbound loads. Requires a sort plan and merge point.

ERP data requirements: dock door assignment by appointment, inbound shipment-to-outbound transfer order linkage, in-transit inventory status (received but not yet shipped), and outbound load closure with SSCC capture.

---

### 2.6 3PL Billing Module

3PL billing converts warehouse and transportation activity records into client invoices. The data model is fundamentally different from self-distribution: **every touch of a client's inventory is a potential billing event**.

| Activity Type | Billing Basis | Typical Rate Structure |
|---|---|---|
| Storage | Average occupied pallet positions over billing period | Per pallet position per week or month |
| Inbound handling | Receipt lines, cartons, or units received | Per unit, per line, or per carton |
| Outbound handling | Pick lines, cartons, or units shipped | Per unit, per pick, or per carton |
| Value-Added Services (VAS) | Labor hours, or per-unit activity counts | Per hour for labor; per unit for kitting/labeling |
| Special handling | Oversize, hazmat surcharge, refrigerated | Flat fee or surcharge per event |
| Transportation | Carrier charges passed through ± markup | Cost-plus or fixed markup % |

Rate cards are client-specific and effective-date-controlled. The billing run scans activity records (BillingEvent table) within the billing period, applies the appropriate rate, and generates a client invoice document. Disputed line items route to a dispute resolution workflow that holds the line from payment without blocking the rest of the invoice.

Multi-client inventory isolation is enforced at the LPN level: every LPN carries an `owner_client_id` that governs which client is billed for storage and which rate card applies. Row-level security in the WMS ensures client portal users see only their own inventory.

---

### 2.7 Multi-Warehouse / Multi-DC

The warehouse entity hierarchy flows: legal entity → site → warehouse → zone → aisle → bay → level → bin. ERP must support inter-company and inter-warehouse **transfer orders** with in-transit inventory visibility — goods that have left origin but not yet arrived at destination must appear in a distinct in-transit status, not double-counted at either location.

**Distributed Order Management (DOM)** routes inbound customer orders to the optimal DC based on: stock availability, proximity to ship-to address, carrier service level compliance, carrier cut-off times, and transfer cost modeling. DOM outputs a sourcing decision before order confirmation; the decision is locked at order acceptance to prevent race conditions.

**Available-to-Promise (ATP)** across DCs must net total supply (on-hand + scheduled receipts) against demand (open orders + reservations) at each location and optionally across locations with a transfer lead time penalty. ATP that does not account for in-transit stock causes overselling from one DC while another holds surplus.

---

### 2.8 Dropship

In a dropship model, the distributor accepts a customer order but never physically handles the goods; a supplier ships directly to the end customer. The ERP flow:

1. Customer order creates a **dropship purchase order** to the vendor (item, qty, ship-to = customer address).
2. Vendor acknowledges via EDI 855; ERP records vendor commit date.
3. Vendor ships and sends EDI 856 ASN; ERP captures tracking number and passes it through to customer-facing order.
4. Vendor invoices via EDI 810; ERP matches against PO, accrues COGS, and pays vendor.
5. ERP invoices customer (AR) based on confirmed ship event.

Key risk: **vendor non-performance visibility**. The ERP must age open dropship POs by expected ship date and alert procurement when a vendor has not confirmed or shipped within window. Without proactive alerting, the customer discovers late shipment before the distributor does — a material service failure.

---

### 2.9 Lot and Serial Tracking in Distribution

| Tracking Type | Granularity | Key ERP Fields | Regulatory Driver |
|---|---|---|---|
| Lot tracking | Batch of items from same production run | lot_num, supplier_lot_num, manufacture_date, expiry_date, CoA_reference | FSMA 204 (21 CFR Part 1, Subpart S), DSCSA (Public Law 113-54), EU FMD 2011/62/EU |
| Serial tracking | Individual unit | serial_num, ownership chain | DSCSA unit serialization, high-value electronics |

**FEFO enforcement** (First Expired, First Out) requires that picking tasks select the lot with the nearest expiry date first, overriding putaway sequence. WMS pick logic must enforce FEFO at task generation; manual override requires supervisor authorization and reason code.

**Genealogy queries** ("where-used" and "where-is") are the ERP deliverable for a recall. The query must traverse: supplier lot → receipt LPN → pick task → shipment → customer order → customer ship-to address, in seconds, not hours. This requires indexed lot linkage at every inventory movement transaction.

---

## 3. Regulatory & Compliance Requirements

### 3.1 Food and Cold Chain

- **FDA FSMA Rule 204 (21 CFR Part 1, Subpart S)** — Food Traceability Final Rule: mandates capture and retention of **Critical Tracking Events (CTEs)** and **Key Data Elements (KDEs)** for foods on the Food Traceability List (FTL). CTEs include: harvesting, cooling, initial packing, first land-based receiving, transformation, creation (for multi-ingredient foods), and shipping. Records must be retained for **24 months** and made available to FDA within **24 hours** on request [3]. The original compliance date was January 20, 2026; FDA announced on March 20, 2025 its intent to extend compliance 30 months, and the Federal Register published the formal compliance date extension to **July 20, 2028** on August 7, 2025 (Federal Register document 2025-14967) [3]. Major retailers including Walmart and Kroger are not delaying their own supplier requirements — verify current retailer-specific mandates directly, as some supply chains face earlier effective dates.
- **FDA 21 CFR Part 11**: electronic records and electronic signatures for food and pharmaceutical distribution; applies to computerized systems that replace paper records.
- **USDA AMS (Agricultural Marketing Service)**: commodity grading, inspection, and reporting requirements for fresh produce and meat distributors.
- **EU Food Information to Consumers Regulation (EC) No 1169/2011**: lot-level labeling obligations for products distributed in the EU; ERP must generate compliant labels per lot.
- **Global Cold Chain Alliance (GCCA) guidelines**: temperature monitoring, excursion documentation, and SOP standards for cold storage operators; not a regulation but referenced in customer contracts.

### 3.2 Pharmaceutical Distribution

- **Drug Supply Chain Security Act (DSCSA)** (U.S. federal law, Public Law 113-54): requires unit-level serialization using a 2D barcode (typically DataMatrix) encoding the product identifier, serial number, lot number, and expiry date [4]. Distributors must maintain **Transaction History (TH), Transaction Information (TI), and Transaction Statement (TS)** — collectively T3 data — for each product change of ownership. T3 records must be retained for **6 years**. **Saleable returns verification** is effective for wholesale distributors as of **August 27, 2025** (following FDA's stabilization period): distributors verifying returned product before restocking must confirm the product identifier against the manufacturer's verification system [4]. Dispenser compliance dates are phased separately; verify current FDA guidance for your trading partner tier.
- **EU Falsified Medicines Directive (FMD) 2011/62/EU**: each medicinal pack must carry a **2D DataMatrix** encoding a unique identifier; packs must be verified against the **EU Hub** (managed by EMVO — European Medicines Verification Organisation) at the point of dispensing or distribution [5]. Verify current EMVO operational documentation for any workflow changes.
- **EudraLex Vol. 4, Chapter 3 (GDP guidelines)**: Good Distribution Practice for medicinal products; governs temperature control, documentation, qualified person responsibilities, and complaint handling in pharmaceutical distribution.

### 3.3 Trade and Customs

- **C-TPAT (Customs-Trade Partnership Against Terrorism)**: CBP voluntary program with five validation tiers (Tier 1 certified through Tier 5 Trusted Trader). Importers, carriers, and freight forwarders maintaining C-TPAT status must document security profiles; ERP should record supplier and carrier C-TPAT status and flag expired certifications [6].
- **AEO (Authorized Economic Operator)**: EU equivalent of C-TPAT, defined under **Union Customs Code Regulation (EU) 952/2013**. Mutual recognition arrangements exist between the EU AEO program and C-TPAT.
- **ISO 28001:2022** — Supply chain security management: best practices framework for supply chain security threat assessment and countermeasures. Note: this is the 2022 revision (superseding ISO 28001:2007) — use the 2022 edition in new contractual or compliance contexts.
- **TAPA FSR (Freight Security Requirements)** and **TAPA TSR (Trucking Security Requirements)**: graded A/B/C requirements for facilities and trucks carrying high-value cargo (electronics, pharmaceuticals, luxury goods). ERP should record TAPA certification level for warehouse facilities and carrier partners [7].

### 3.4 Dangerous Goods

- **IATA DGR (Dangerous Goods Regulations)**: governs air transport of dangerous goods; revised annually. The **67th Edition (2026)** is current, effective January 1, 2026 [8]. The 68th Edition will apply for 2027.
- **ADR 2025**: European Agreement concerning the International Carriage of Dangerous Goods by Road; revised biennially. ADR 2025 is applicable as from January 1, 2025 and is the current edition for 2025–2026; ADR 2027 will supersede it.
- **49 CFR** (U.S. HazMat): Title 49 of the Code of Federal Regulations, administered by PHMSA (Pipeline and Hazardous Materials Safety Administration); governs U.S. domestic dangerous goods by ground and air.
- **IMDG Code Amendment 42-24**: International Maritime Dangerous Goods Code for sea transport of hazardous materials. Amendment 42-24 entered voluntary use January 1, 2025 and became mandatory January 1, 2026, superseding Amendment 41-22 [9].

### 3.5 Data and Privacy

- **GDPR Regulation (EU) 2016/679**: applies to any personal data (name, address, delivery contact) collected in EU delivery transactions; last-mile delivery platforms must implement data minimization, retention limits, and subject access request (SAR) workflows.
- **CCPA/CPRA (California Consumer Privacy Act / California Privacy Rights Act)**: applies to California consumers receiving last-mile delivery; consumer data collected by carrier or OMS must be subject to deletion and opt-out rights.

---

## 4. Key Data Entities

### 4.1 Entity Relationship Overview

Core entities: **Item**, **Warehouse**, **Location**, **LPN (License Plate Number)**, **Receipt**, **ReceiptLine**, **Wave**, **PickTask**, **Shipment**, **Carton**, **ThreePLClient**, **RateCard**, **BillingEvent**, **ClientInvoice**, **EDITransaction**, **LandedCostVoucher**, **LandedCostLine**.

The **LPN** is the atomic unit of inventory: it links a physical pallet or carton (identified by its GS1 SSCC) to an item, quantity, lot, location, and (for 3PLs) the owning client. Every warehouse movement — putaway, pick, transfer, adjustment — is a transaction against an LPN, not directly against an item/location record. This design supports FEFO enforcement, genealogy tracing, and 3PL client-level billing.

### 4.2 Schema Sketch

```sql
-- Item master
Item (
  item_id          PK,
  sku              VARCHAR(50) UNIQUE,
  description      TEXT,
  uom              VARCHAR(10),         -- EA, CS, PL
  weight_lb        DECIMAL(10,4),
  cube_in3         DECIMAL(10,4),
  hazmat_class     VARCHAR(10),         -- NULL if non-hazmat; e.g. '3', '8'
  lot_tracked      BOOL,
  serial_tracked   BOOL,
  shelf_life_days  INT,
  temp_min_f       DECIMAL(5,1),        -- NULL if not temp-controlled
  temp_max_f       DECIMAL(5,1),
  nmfc_code        VARCHAR(10),         -- LTL freight class input
  hts_code         VARCHAR(15)          -- for import duty calculation
)

-- Warehouse hierarchy
Warehouse (wh_id PK, legal_entity_id FK, name, address, timezone, temp_controlled BOOL)
Location  (
  loc_id    PK,
  wh_id     FK → Warehouse,
  zone      VARCHAR(20),
  aisle     VARCHAR(5),
  bay       VARCHAR(5),
  level     VARCHAR(5),
  bin       VARCHAR(5),
  loc_type  ENUM('receive','storage','pick','stage','ship','cross-dock','quarantine'),
  max_weight_lb DECIMAL(10,2),
  max_cube_in3  DECIMAL(12,2),
  temp_zone VARCHAR(20)                 -- 'ambient','refrigerated','frozen'
)

-- Inventory unit
LPN (
  lpn_id             PK,
  sscc               CHAR(18),          -- GS1 SSCC, unique
  item_id            FK → Item,
  qty                DECIMAL(12,4),
  lot_num            VARCHAR(50),
  supplier_lot_num   VARCHAR(50),
  expiry_date        DATE,
  manufacture_date   DATE,
  coa_reference      VARCHAR(100),      -- Certificate of Analysis doc ref
  serial_num         VARCHAR(100),      -- NULL if not serial-tracked
  loc_id             FK → Location,
  owner_client_id    FK → ThreePLClient,  -- NULL for self-distribution
  status             ENUM('available','reserved','picked','quarantine','in-transit','shipped'),
  inbound_receipt_id FK → Receipt
)

-- Receiving
Receipt (
  receipt_id   PK,
  wh_id        FK → Warehouse,
  po_id        FK,                      -- to purchasing PO
  asn_id       FK,                      -- linked EDI 856 transaction
  carrier_pro  VARCHAR(30),
  arrival_dt   TIMESTAMP,
  available_dt TIMESTAMP,              -- when stock becomes allocatable
  status       ENUM('scheduled','arrived','in-progress','complete','exception')
)
ReceiptLine (
  line_id       PK,
  receipt_id    FK → Receipt,
  item_id       FK → Item,
  qty_expected  DECIMAL(12,4),
  qty_received  DECIMAL(12,4),
  lot_num       VARCHAR(50),
  serial_num    VARCHAR(100),
  lpn_id        FK → LPN,
  discrepancy_code VARCHAR(20)
)

-- Outbound waves and picks
Wave (
  wave_id          PK,
  wh_id            FK → Warehouse,
  release_dt       TIMESTAMP,
  carrier_cutoff_dt TIMESTAMP,
  pick_strategy    ENUM('wave','zone','batch','cluster')
)
PickTask (
  task_id       PK,
  wave_id       FK → Wave,
  loc_id        FK → Location,
  item_id       FK → Item,
  lpn_id        FK → LPN,
  lot_num       VARCHAR(50),
  qty_to_pick   DECIMAL(12,4),
  qty_picked    DECIMAL(12,4),
  picker_user_id FK,
  assigned_dt   TIMESTAMP,
  completed_dt  TIMESTAMP
)

-- Shipment and packaging
Shipment (
  shipment_id      PK,
  wh_id            FK → Warehouse,
  carrier_id       FK,
  tracking_num     VARCHAR(100),
  carrier_service  VARCHAR(50),
  weight_lb        DECIMAL(10,2),
  carton_count     INT,
  freight_cost     DECIMAL(12,2),
  currency         CHAR(3),
  manifest_dt      TIMESTAMP,
  label_url        TEXT
)
Carton (
  carton_id    PK,
  shipment_id  FK → Shipment,
  sscc         CHAR(18),
  weight_lb    DECIMAL(10,2),
  dim_l_in     DECIMAL(8,2),
  dim_w_in     DECIMAL(8,2),
  dim_h_in     DECIMAL(8,2),
  carton_type  VARCHAR(30)
)

-- 3PL billing
ThreePLClient (client_id PK, name VARCHAR(200), billing_currency CHAR(3), billing_cycle ENUM('weekly','monthly'))
RateCard (
  rate_id        PK,
  client_id      FK → ThreePLClient,
  activity_code  VARCHAR(30),           -- e.g. 'STORAGE_PALLET','INBOUND_UNIT','VAS_LABOR'
  rate_basis     ENUM('pallet','unit','lb','hour','order','carton'),
  rate_amount    DECIMAL(12,4),
  effective_date DATE,
  expiry_date    DATE
)
BillingEvent (
  event_id      PK,
  client_id     FK → ThreePLClient,
  rate_id       FK → RateCard,
  activity_dt   TIMESTAMP,
  qty           DECIMAL(12,4),
  amount        DECIMAL(12,2),
  source_doc_id VARCHAR(100)            -- receipt_id, pick_task_id, shipment_id, etc.
)
ClientInvoice (
  invoice_id   PK,
  client_id    FK → ThreePLClient,
  period_start DATE,
  period_end   DATE,
  total_amount DECIMAL(14,2),
  status       ENUM('draft','issued','disputed','paid')
)

-- EDI
EDITransaction (
  txn_id       PK,
  partner_id   FK,
  tx_set       CHAR(3),                 -- '850','856','940', etc.
  direction    ENUM('in','out'),
  isa_ctrl_num VARCHAR(9),
  raw_payload  TEXT,
  status       ENUM('received','mapped','processed','errored','acked'),
  received_dt  TIMESTAMP,
  ack_dt       TIMESTAMP               -- populated when 997 received
)

-- Landed cost
LandedCostVoucher (
  voucher_id           PK,
  receipt_id           FK → Receipt,
  vendor_invoice_num   VARCHAR(50),
  freight_amt          DECIMAL(14,2),
  duty_amt             DECIMAL(14,2),
  broker_fee           DECIMAL(14,2),
  insurance_amt        DECIMAL(14,2),
  other_amt            DECIMAL(14,2),
  allocation_method    ENUM('value','weight','qty','volume'),
  fx_rate              DECIMAL(18,8),
  fx_rate_date         DATE
)
LandedCostLine (
  line_id          PK,
  voucher_id       FK → LandedCostVoucher,
  receipt_line_id  FK → ReceiptLine,
  allocated_cost   DECIMAL(14,2),
  posting_status   ENUM('pending','posted','reversed')
)
```

### 4.3 Key Relationships

- **LPN → SSCC**: one LPN has exactly one SSCC; the SSCC is the physical barcode identity scanned at every dock and conveyance point.
- **Wave → PickTask → LPN → Carton → Shipment**: the outbound fulfillment chain. Wave aggregates pick tasks; pick tasks consume LPN quantities; cartonization creates Carton records with SSCCs; Cartons aggregate to a Shipment.
- **BillingEvent fires on**: Receipt (inbound handling), Putaway (storage start), PickTask completion (outbound handling), Carton creation (per-carton fees), Shipment (freight pass-through), VAS work order completion.
- **EDITransaction.ack_dt** must be populated within the SLA window after sending; absent ack_dt triggers an alert.
- **LandedCostVoucher links receipt_id to the original PO receipt**: the voucher arrives after goods may already be sold; allocation posts to inventory adjustment or variance account depending on valuation method.

---

## 5. Critical Integrations

| System Category | Real Products | Integration Method | Data Exchanged |
|---|---|---|---|
| Parcel carrier | UPS Worldship API, FedEx Ship Manager API, USPS Web Tools API, DHL eCommerce API | REST API | Rate shop, label (ZPL/ZPL2), tracking number, void |
| LTL/TL carrier and broker | XPO Connect, Echo Global Logistics, project44, FourKites | REST / EDI 204/990/214 | Load tender, tracking events, ETA, POD |
| EDI VAN / AS2 platform | SPS Commerce, TrueCommerce, Cleo Integration Cloud, OpenText Trading Grid | AS2 / SFTP / REST API | 850, 855, 856, 810, 940, 945, 997 and partner-specific variants |
| Standalone WMS | Manhattan Active WM, Blue Yonder WMS, Deposco Bright Suite, Infor WMS, Korber/Infios WMS | REST/SOAP / flat-file / proprietary API | Order release, inventory positions, ASN, receipt confirmations |
| Standalone TMS | Oracle Transportation Management Cloud (OTM), Blue Yonder TMS, Infios (MercuryGate), Transplace | REST / EDI | Freight orders, carrier rates, tracking events, freight audit data |
| eCommerce / OMS | Shopify (REST Admin API), Salesforce Commerce Cloud, Adobe Commerce (Magento) | REST API | Customer orders, inventory sync, tracking number passthrough |
| Marketplace | Amazon Vendor Central, Walmart Supplier Center, Target Partners Online | EDI 850/856/810 + portal API | POs, ASNs, invoices, compliance labels |
| Multi-carrier parcel manifest | EasyPost, ShipStation, Shippo | REST API | Multi-carrier rate comparison, label generation, tracking aggregation |
| Temperature monitoring | Sensitech TempTale, Emerson Connected Fresh Chain, Controlant | IoT API / MQTT | Temperature readings per logger per LPN, excursion events and alerts |
| Last-mile delivery | OnTrac, LaserShip/LSO, Veho, Roadie | REST API | Delivery order creation, tracking, proof of delivery (POD) |
| Customs broker / freight forwarder | Flexport, Customs City, Descartes OCR | EDI 7575 / REST API | Customs entry filing, duty amounts, HTS classification, broker fee invoices |
| Label and thermal printing | Zebra (ZPL2 direct TCP/IP), SATO, Honeywell | Direct IP print socket / Labelary API (ZPL preview) | Shipping labels, pick labels, license plate labels |
| Warehouse automation (WCS) | Dematic, Swisslog, AutoStore | TCP/IP / proprietary WCS protocol | Conveyor control commands, ASRS put/retrieve tasks, sorter induction |

Integration failure modes to engineer against: carrier API rate limits (especially during peak season label surges), EDI 997 non-receipt masking downstream failures, WMS inventory sync lag causing ERP ATP to show stale positions, and temperature logger MQTT message loss creating gaps in cold-chain audit trail.

---

## 6. KPIs & Metrics

| KPI | Definition | Formula |
|---|---|---|
| OTIF (On Time In Full) | Orders delivered complete and on schedule | (Orders on-time AND in-full) / Total orders × 100 |
| Perfect Order Rate | Orders with no errors: on-time, complete, undamaged, accurate documentation | (Error-free orders / Total orders) × 100 |
| Order Fill Rate | % of ordered quantity shipped on initial shipment (no backorder) | (Units shipped / Units ordered) × 100 |
| Inventory Accuracy | Physical count matches WMS system record | (Accurate location counts / Total locations counted) × 100 |
| Dock-to-Stock Time | Hours from carrier arrival to inventory in allocatable status in WMS | avg(available_dt − arrival_dt) per receipt |
| Pick Accuracy | Correct items and quantities picked vs. total picks | (Correct picks / Total picks) × 100 |
| Picks Per Hour (PPH) | Picker productivity | Total units or lines picked / Total labor hours on picking |
| Warehouse Space Utilization | % of usable storage positions occupied | (Occupied locations / Total locations) × 100 |
| Freight Cost per Unit Shipped | Carrier spend efficiency | Total freight cost / Total units shipped |
| Freight Cost as % of Revenue | Carrier spend relative to net revenue | (Total freight cost / Net revenue) × 100 |
| Inventory Turns | How often total inventory cycles per year | COGS / Average inventory value (at cost) |
| Days Sales in Inventory (DSI) | Days of inventory on hand at current consumption rate | (Average inventory value / COGS) × 365 |
| Carrier On-Time Performance | % of carrier deliveries meeting committed ETA | (On-time deliveries / Total deliveries by carrier) × 100 |
| Return Rate | % of shipped orders returned | (Returns / Total shipments) × 100 |
| 3PL Storage Utilization | Billable client pallet positions as % of total capacity | (Occupied billable positions / Total pallet capacity) × 100 |
| Cross-Dock Throughput Rate | Inbound units processed as cross-dock (no putaway) | (Units cross-docked / Total inbound units) × 100 |
| Cycle Count Variance Rate | Frequency of inventory discrepancies discovered during cycle counts | (Count adjustments posted / Total count events) × 100 |
| EDI Compliance Rate | % of EDI transactions that pass validation without error | (Valid transactions / Total EDI transactions received) × 100 |
| Freight Audit Recovery Rate | $ recovered through freight audit vs. total carrier spend | (Carrier invoice disputes resolved in shipper's favor / Total carrier spend) × 100 |

OTIF benchmark: world-class is 95%+ across all orders; below 85% signals a systemic process or data-quality issue. Inventory accuracy below 99% in a FEFO environment is a regulatory and service risk for food and pharma.

---

## 7. Major ERP Vendors for this Vertical

### 7.1 SAP S/4HANA

**SAP Extended Warehouse Management (EWM)** is the most functionally complete embedded WMS in the enterprise ERP market. It supports all picking strategies, SSCC-level LPN tracking, directed putaway, cartonization, wave management, RF and voice-directed tasks, slotting, labor management, and yard logistics integration. Deployment options: embedded in the S/4HANA database (zero latency, no RFC), or decentralized (dedicated EWM system for very large DC volumes).

**SAP Transportation Management (TM)** handles freight order management, multi-modal carrier selection, EDI 204/990/214 tendering, freight audit and pay, and freight cost settlement back to purchasing. **SAP Global Trade Services (GTS)** manages customs compliance: import/export declarations, AEO/C-TPAT status tracking, sanctioned party list screening. **SAP Yard Logistics** adds dock appointment scheduling.

SAP dominates large 3PLs (DHL Supply Chain, XPO Logistics use SAP) and global distributors. Implementation cost and licensing are the highest in the market. SAP ECC mainstream maintenance ends 2027 (extended to 2030), making S/4HANA migration the active project for any SAP ECC distribution customer. See `core/cautions.md` for ECC end-of-maintenance migration risks.

### 7.2 Oracle Fusion Cloud SCM

**Oracle Warehouse Management Cloud (WMS Cloud)** is cloud-native, delivered via browser and mobile RF interface, with no on-premise deployment. It supports 3PL multi-client billing, multi-warehouse inventory, lot/serial tracking, directed picking, and wave management. Native integration to **Oracle Transportation Management (OTM)** — enterprise-grade TMS covering multi-modal freight management, carrier collaboration, real-time freight audit and pay, and a shipper-facing carrier portal. **Oracle Global Trade Management (GTM)** adds import/export compliance and landed cost management.

Strong position in large enterprises already on Oracle Financials Cloud or JD Edwards. OTM is one of the two dominant enterprise TMS platforms (the other being Blue Yonder TMS).

### 7.3 Microsoft Dynamics 365 Supply Chain Management (D365 SCM)

D365 SCM's **Warehouse Management module** implements the directed work concept: work orders are generated by the system and consumed by mobile workers. Supports wave processing, cluster picking, SSCC/license plate tracking, cartonization, and slotting. The **Transportation Management module** provides rate engine configuration, carrier integration, and freight audit. The **Landed Cost module** (sold separately from the core SCM license) manages multi-leg shipment cost allocation to item layer cost in inventory.

Strong integration with Azure IoT, Power BI for warehouse analytics, and Power Automate for workflow extensions. Preferred mid-market and large enterprise platform for organizations already in the Microsoft ecosystem. Note: Gartner no longer publishes a single ERP Magic Quadrant — the WMS and TMS capabilities are evaluated in separate Gartner Magic Quadrant reports for those categories.

### 7.4 Manhattan Associates (Manhattan Active WM / TM)

Purpose-built for complex distribution and 3PL; not a full ERP. Manhattan integrates with SAP, Oracle, NetSuite, and Dynamics for financials while delivering industry-leading WMS and TMS execution. **Manhattan Active WM** is cloud-native with a continuous deployment model (no version upgrades; features ship continuously) — a significant operational advantage over traditional release cycles. Capabilities include AI-driven slotting recommendations, dynamic wave optimization, robotics integration (AMRs, ASRS, goods-to-person systems), and a 3PL client portal.

Manhattan Associates reported full-year 2024 revenue of **$1.042 billion**, a 12% increase over 2023, with cloud revenue growing 32% year-over-year [10]. **Manhattan Active Transportation** handles carrier management and last-mile optimization.

Dominates high-velocity retail distribution, 3PL for major retailers, and e-commerce fulfillment. Typical customer has high order volume and complex carrier mix.

### 7.5 Blue Yonder (formerly JDA Software)

**Blue Yonder Warehouse Management** serves 1,100+ customers across 19 industries; approximately 50% of its WMS customer base is outside North America. The **Luminate Platform** adds AI/ML demand sensing and workforce management layered over WMS and TMS execution. On May 5, 2025, GXO Logistics — one of the world's largest 3PL providers — announced a multi-year strategic agreement designating Blue Yonder as a preferred WMS provider for GXO's global network, with implementations covering WMS, Labor Management, Order Management, Warehouse Execution, and Billing Management [11].

### 7.6 Infor (CloudSuite WMS / LN / M3)

**Infor WMS** (part of the Infor Supply Chain Execution suite): multi-client 3PL billing module built in, labor management, slotting, voice integration. **Infor LN**: ERP backbone for industrial distributors; tight native WMS integration without middleware. **Infor M3**: distribution-focused ERP with particular depth in food and beverage distribution and fashion distribution; supports lot management, quality control, and multi-site inventory. Infor was acquired by Koch Industries; cloud deployment runs on AWS.

### 7.7 NetSuite (Oracle NetSuite)

**NetSuite WMS** is embedded in the NetSuite ERP platform: RF-enabled wave, zone, and batch picking; bin/lot/serial tracking; cartonization; putaway rules. **SuiteCommerce** adds omnichannel inventory sync for distributors with a B2B or D2C storefront. Strengths: single platform eliminates WMS-ERP integration; strong for mid-market distributors and 3PLs that need a unified system. Gaps vs. SAP EWM or Manhattan Active WM: limited cartonization algorithm sophistication, no native voice-directed picking, and limited native TMS (relies on SPS Commerce, EasyPost, and ShipStation integrations for carrier management).

### 7.8 Acumatica

**Acumatica Distribution Edition**: multi-warehouse, lot/serial tracking, advanced replenishment (min/max, reorder point, forecast-based), matrix items (size/color/style). WMS functionality is extended via mobile scanning add-on and partner ISV solutions (notably Tasklet Factory for directed put-away and picking). Unlimited-user licensing model makes it cost-effective for warehouse operations with large headcounts. Targets small-to-mid distributors; less suitable for high-complexity 3PL or very high-volume parcel operations.

### 7.9 CargoWise One (WiseTech Global)

Purpose-built for **freight forwarders and customs brokers** (asset-light logistics service providers); not used as a primary ERP for asset-based distributors or 3PLs. Deep capabilities in EDI, customs filing, carrier accounting, multi-currency forwarding P&L, and document management. Integrates to financial ERP for general ledger. Dominates the CHB (Custom House Broker) and freight forwarding segment.

### 7.10 Deposco and SMB 3PL Platforms

**Deposco Bright Suite**: 3PL-specific WMS with client portal, multi-client billing, and rapid trading partner onboarding. API-native trading partner integrations (Shopify, direct API clients) can be onboarded in days; EDI-based integrations still typically require 2–6 weeks for per-partner mapping configuration. **Extensiv** (formerly 3PL Central): cloud WMS purpose-built for the small-to-mid 3PL market; strong in e-commerce fulfillment 3PLs. Both platforms target the segment of the 3PL market that cannot justify SAP or Manhattan implementations.

---

## 8. Implementation Cautions

### 8.1 Big-Bang ERP + WMS + TMS Simultaneously

The most cited distribution ERP failure is **Hershey 1999**: simultaneous go-live of SAP R/3, Siebel CRM, and Manugistics SCM, compressing a vendor-recommended four-year timeline to 30 months to pre-empt Y2K [12]. The go-live executed in July 1999, directly ahead of the Halloween and Christmas candy season. Inadequate testing caused the systems to be unable to process orders and route shipments correctly. Hershey was unable to fulfill approximately $100 million in orders — primarily Kisses and Jolly Ranchers — despite having inventory on hand. The company reported a 19% drop in quarterly profits and an 8% decline in stock price in Q3 1999 [12]. The primary lessons: (1) decouple WMS and TMS go-lives from the financial ERP go-live, (2) never cut over a distribution system during peak season, and (3) never compress the testing phase to meet a calendar date.

### 8.2 Carrier Label and Retailer Compliance

Major retailer compliance programs (Walmart, Target, Amazon, Kroger) specify exact GS1-128 label formats, SSCC structure, carton barcode placement, and EDI 856 ASN transmission timing — ASNs are often required to arrive at the retailer's EDI system before the physical shipment arrives at the DC. Non-compliant labels or late/missing ASNs trigger automated chargebacks; verify the specific rate and conditions in each retailer's compliance guide, as these change. Thoroughly test label output against each retailer's compliance specification and validate through their compliance portals (Walmart Retail Link, Target Partners Online) before go-live.

### 8.3 EDI Trading Partner Variability

Never assume that the same X12 transaction set works identically across trading partners. EDI 850 and EDI 856 implementations vary by retailer, including different loop structures, segment usage notes, and conditional element rules — even within the same X12 version. The version mismatch between 4010 and 5010 causes ISA envelope rejection; agree on version in the trading partner agreement. A missing or delayed 997 functional acknowledgment silently blocks transaction flow downstream; implement 997 receipt monitoring with SLA-based alerts. Allocate significant time in project schedules for per-partner EDI mapping — this is routinely underestimated.

### 8.4 Lot and Serial Data Quality at Cutover

Historical lot data in legacy systems is rarely clean: missing expiry dates, inconsistent lot number formats, lots spanning multiple physical pallets not linked in the system. Clean lot data is mandatory for FEFO enforcement post-go-live. Recommended approach: freeze lot changes 30 days pre-cutover; conduct a full physical inventory with lot-level capture (scan each pallet, capture supplier lot and expiry); use the physical count as the opening balance. Do not migrate historical lot data from the old system without validation — discrepancies discovered after go-live in a FEFO environment cause pick errors and potential regulatory violations.

### 8.5 3PL Client Onboarding Underestimation

Each new 3PL client requires a distinct implementation mini-project: item master setup (often thousands of client SKUs), rate card configuration, EDI trading partner setup (940/945 for the client's OMS, 850/856/810 for the client's customers), label format configuration per client customer, billing rule setup, and client portal access configuration. Average onboarding time for an EDI-connected client is 2–6 weeks. API-native clients (Shopify-connected) can be faster. Project plans for new 3PL go-lives routinely underestimate the aggregate onboarding labor when the 3PL has multiple clients launching simultaneously — treat each client onboarding as a tracked work stream.

### 8.6 Landed Cost Timing Mismatches

Ocean freight invoices typically arrive 3–8 weeks after goods are received and may already be partially sold. The ERP must accrue estimated landed cost at the time of receipt (standard cost or estimated rate) and post a true-up variance when the actual freight invoice arrives. If the accounting policy requires currency conversion at receipt date but the freight invoice is paid in a different currency at payment date, the FX exposure must be recognized correctly. Failure to define FX rate selection per cost element — PO rate, receipt rate, or payment rate — before implementation results in systematic audit findings.

### 8.7 Multi-DC ATP Integrity

ATP calculations that do not update in real time across DCs create overselling risk: two orders received simultaneously may both commit against the same stock at a single DC. In-transit inventory (transferred from DC-A but not yet received at DC-B) must be visible but not allocatable at DC-B until confirmed receipt. Transfer order lead time must be incorporated into ATP promise dates. Test ATP under concurrency load before go-live — ATP race conditions are nearly impossible to detect in sequential unit testing.

### 8.8 Cold Chain FSMA 204 CTE/KDE Capture

ERP and WMS must be configured to write immutable CTE records (with timestamps, location, lot, and KDE fields) at every food traceability event in the supply chain [3]. Records must be retained for 24 months and made available to FDA within 24 hours. If the WMS is a separate system from the financial ERP, the integration must propagate CTE records in real time — batch overnight sync is insufficient for a 24-hour FDA response requirement. The federal compliance deadline is July 20, 2028 (Federal Register 2025-14967); major retailers are applying their own earlier supplier requirements — verify with each retail customer.

---

## 9. Security & Compliance Depth

### 9.1 Reference

See `core/security.md` for Segregation of Duties (SoD) matrix design, role-based access control model, audit trail baseline requirements, and data encryption standards applicable to all ERP verticals.

### 9.2 Cargo Theft and Physical Security

**ISO 28001:2022** provides the framework for supply chain security threat assessment and countermeasures (supersedes ISO 28001:2007). **C-TPAT** (CBP) imposes minimum security criteria across five validated tiers for importers, carriers, brokers, and freight forwarders [6]; ERP supplier and carrier master records should include C-TPAT status, tier level, and validation expiry date, with automated alerts on expiration. **AEO** under Regulation (EU) 952/2013 is the EU equivalent; mutual recognition arrangements mean C-TPAT status can satisfy some AEO requirements and vice versa.

**TAPA FSR (Freight Security Requirements)** and **TAPA TSR (Trucking Security Requirements)** define graded (A/B/C) security criteria for warehouse facilities and trucks carrying high-value cargo — electronics, pharmaceuticals, luxury goods [7]. ERP warehouse master and carrier master should capture TAPA certification level. Contractual requirements from high-value product manufacturers often mandate specific TAPA tiers.

### 9.3 EDI Security

AS2 transmission (the dominant EDI transport for retail trading partners) uses X.509 certificates for message signing and encryption. Certificate expiry causes AS2 handshake failure and silently drops EDI messages; implement certificate expiry monitoring with 90-day, 30-day, and 7-day alerts. EDI ISA/GS segment sender and receiver IDs must be validated against the expected trading partner before processing; spoofed trading partner IDs can inject fraudulent purchase orders or ASNs. Functional acknowledgment (997) non-receipt within the agreed SLA window should auto-alert operations — an un-acked 997 can indicate a man-in-the-middle issue, transmission failure, or partner-side processing error that otherwise goes undetected.

### 9.4 3PL Data Segregation

Multi-client WMS environments are high-risk for data leakage between clients. Inventory, order, and billing data for Client A must be absolutely invisible to Client B's portal users. Implementation requirements:

- **Application layer**: row-level security (RLS) enforced on every query by `owner_client_id`; never rely on UI filtering alone.
- **Database layer**: for highest-sensitivity clients (pharma, regulated goods), consider separate schemas or separate database instances per client.
- **API layer**: client-facing API tokens must be scoped to a single client_id; no shared tokens.
- **Audit logging**: all data access by client portal users must be logged with user, timestamp, and record accessed; periodic access reviews required.
- **Warehouse operator access**: warehouse floor staff see all clients' inventory for operational efficiency, but must not see client-confidential pricing or billing rates.

### 9.5 Pharmaceutical and Food Chain of Custody

**DSCSA** requires ERP to record and be able to transmit T3 data (Transaction History, Transaction Information, Transaction Statement) for every pharmaceutical product ownership transfer [4]. T3 data must be retained for 6 years and provided to trading partners or FDA on request. Saleable returns verification (effective for wholesale distributors August 27, 2025) requires the distributor to verify each returned pack against the manufacturer's verification system before restocking — the ERP/WMS must call the verification API during the returns receiving process, not as a batch post-process.

**EU FMD 2011/62/EU** verification requires real-time API calls to the EU Hub (EMVO system) at the point of dispensing or distribution [5]. The ERP pick process must be gated on a successful verification response; a failed verification must quarantine the pack and alert the responsible person.

### 9.6 Audit Trail Requirements

Every inventory movement — receipt, putaway, pick, pack, transfer, adjustment — must be recorded in an immutable audit log with: user ID, timestamp (UTC), transaction type, item, lot, serial, LPN, from-location, to-location, before-quantity, after-quantity, and the source document (receipt ID, wave ID, adjustment document ID). Cycle count adjustments must lock after posting; retroactive modification must require a reversal transaction creating a new audit record, not an in-place edit. Reason codes are mandatory on all adjustments.

For FSMA 204 compliance: CTE records must be treated as write-once; no update or delete permitted. Recommend database-level enforcement (append-only table, no UPDATE/DELETE privileges for application user) or blockchain-anchored audit log for highest-assurance implementations.

### 9.7 System Access for Remote Workers and Carriers

- **RF/mobile device access in warehouse**: WPA3 Wi-Fi with device-level certificate authentication (not shared password); device management via MDM (Microsoft Intune, JAMF) to enforce encryption and remote wipe.
- **Carrier portal access** (load tendering, track-and-trace): OAuth 2.0 or SAML 2.0 federation to corporate IdP; MFA required for all external users; session timeout appropriate to risk level.
- **3PL client portal**: tenant-isolated HTTPS endpoints; session timeout ≤ 30 minutes; MFA required; if any cardholder data (e.g., payment card for DTC shipments) is visible, PCI DSS scope applies and additional controls are mandatory.
- **API integrations**: service account credentials must be rotated on schedule and stored in a secrets manager (AWS Secrets Manager, Azure Key Vault, HashiCorp Vault); never hardcoded in application configuration.

---

## See also

- `core/features-core.md`
- `core/architecture.md`
- `core/security.md`
- `verticals/manufacturing.md`
- `verticals/retail-ecommerce.md`
- `verticals/agriculture-food.md`

---

## Citations & Sources

1. GS1 US — Serial Shipping Container Code (SSCC) specification and GS1-128 Application Identifier (AI) 00: https://www.gs1us.org/upcs-barcodes-prefixes/serialized-shipping-container-codes
2. ASC X12 standards body — EDI transaction set definitions and version history: https://www.x12.org
3. FDA — FSMA Final Rule on Requirements for Additional Traceability Records for Certain Foods (21 CFR Part 1, Subpart S); Federal Register compliance date extension document 2025-14967 (August 7, 2025): https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-requirements-additional-traceability-records-certain-foods
4. FDA — Drug Supply Chain Security Act (DSCSA) guidance; DSCSA wholesale distributor saleable returns verification compliance date August 27, 2025: https://www.fda.gov/drugs/drug-supply-chain-integrity/drug-supply-chain-security-act-dscsa
5. EMVO (European Medicines Verification Organisation) — EU FMD 2011/62/EU hub operations and verification workflows: https://www.emvo-medicines.eu
6. CBP C-TPAT program — five validation tiers and minimum security criteria: https://www.cbp.gov/border-security/ports-entry/cargo-security/ctpat
7. TAPA (Transported Asset Protection Association) — FSR and TSR security requirements: https://www.tapaonline.org
8. IATA — Dangerous Goods Regulations 67th Edition (2026), effective January 1, 2026: https://www.iata.org/en/publications/dgr/
9. IMO / IMDG Code Amendment 42-24 — 2024 Edition, mandatory from January 1, 2026 (supersedes Amendment 41-22): identifier IMO MSC.501(108), adopted May 2024
10. Manhattan Associates — Full Year 2024 Financial Results (press release, January 28, 2025): https://www.manh.com/about-us/newsroom/press-releases/manhattan-associates-reports-record-fourth-quarter-full-year-results
11. GXO Logistics / Blue Yonder — Strategic Global Agreement announcement, May 5, 2025: https://investors.gxo.com/news-releases/news-release-details/gxo-and-blue-yonder-announce-new-strategic-global-agreement/
12. Panorama Consulting / CIO.com — Hershey 1999 ERP implementation failure case study (SAP R/3 + Siebel + Manugistics big-bang, $100M orders unfulfilled, 19% quarterly profit decline, 8% stock price decline in Q3 1999): https://www.panorama-consulting.com/hersheys-erp-failure/
13. ISO — ISO 28001:2022 Supply chain security management (supersedes ISO 28001:2007): https://www.iso.org/standard/79612.html
14. SAP — Extended Warehouse Management (EWM) documentation for S/4HANA on-premise: https://help.sap.com/docs/SAP_S4HANA_ON-PREMISE/ewm
15. Oracle — Warehouse Management Cloud documentation: https://docs.oracle.com/en/cloud/saas/warehouse-management
16. UNECE — ADR 2025: Agreement concerning the International Carriage of Dangerous Goods by Road, applicable from January 1, 2025: https://unece.org/transport/publications/agreement-concerning-international-carriage-dangerous-goods-road-adr-2025
17. Gartner — Magic Quadrant for Warehouse Management Systems (annual; verify current year edition)
18. Gartner — Magic Quadrant for Transportation Management Systems (annual; verify current year edition)
