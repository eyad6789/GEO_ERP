# ERP for Education

Education is one of the most architecturally complex ERP verticals. A single institution simultaneously manages instruction, research, fundraising, and public-service missions — each with its own revenue streams, compliance regimes, and fund accounting rules. The interplay between a Student Information System (SIS) and an ERP back-office creates an integration seam unlike any other vertical, and errors in that seam produce real regulatory liability under Title IV.

---

## 1. Overview

### Dual Mission and Multi-Entity Complexity

Higher education institutions operate under a dual (or triple) mission: instruction, research, and — at many institutions — philanthropic development. Each mission carries distinct revenue recognition, cost assignment, and reporting requirements that must coexist in a single chart of accounts. A research university may simultaneously receive tuition revenue (recognized per term), sponsored research awards (recognized as allowable costs are incurred against a sponsored project), and charitable gifts (recognized at fair value of unconditional promise per FASB ASC 958-310). No general-purpose ERP ships with all three out of the box.

### Public vs. Private Bifurcation

Public and private nonprofit institutions follow different financial reporting standards, and this bifurcation has deep ERP implications:

| Dimension | Public Universities (GASB) | Private Nonprofit Universities (FASB) |
|---|---|---|
| Governing standard | GASB Statement No. 34 (1999) + GASB Statement No. 35 (1999) | FASB ASC 958 (Not-for-Profit Entities) |
| Net asset classes | Not applicable; use fund-based + entity-wide statements | Two classes: with donor restrictions / without donor restrictions (per FASB ASU 2016-14, effective for fiscal years beginning after December 15, 2017) |
| Lease accounting | GASB Statement No. 87 (leases, effective for fiscal years beginning after June 15, 2021); GASB Statement No. 96 (SBITAs, effective FY beginning after June 15, 2022) | FASB ASC 842 (effective for most private IHEs in 2022) |
| Public-private partnerships | GASB Statement No. 94 (effective FY beginning after June 15, 2022) | FASB ASC 853 |
| Annual federal reporting | IPEDS Finance Form G (GASB) | IPEDS Finance Form F (FASB) |

FASB ASU 2016-14 replaced the prior three-class model (unrestricted, temporarily restricted, permanently restricted) with two classes. ERP chart-of-accounts design, financial statement mapping, and disclosure templates must reflect this.

### K-12 vs. Higher Education Sub-Verticals

K-12 school districts operate under a simpler compliance stack: GASB governmental fund accounting, state-level education funding formulas (average daily attendance, per-pupil allocations), and payroll-heavy HR requirements. The SIS in K-12 (PowerSchool, Tyler Technologies Infinite Campus) primarily handles attendance and scheduling, not financial aid. Higher education by contrast requires the full Title IV federal aid apparatus, sponsored research accounting, and endowment management. This file covers higher education only; for the full K-12 ERP treatment — both public school districts and private K-12 schools — see `verticals/schools.md`.

### The SIS-ERP Boundary

The most consequential architectural seam in higher education is between the Student Information System and the financial ERP:

- **SIS owns:** enrollment, course sections, academic records, degree audit, advising, admissions, financial aid packaging logic
- **ERP owns:** general ledger, accounts payable/receivable, payroll/HCM, grants accounting, endowment, plant fund, purchasing
- **Shared data at the seam:** student account balances, financial aid disbursements, tuition billing, enrollment status (which drives billing), financial holds

This boundary creates bidirectional dependency. Enrollment in the SIS drives the billing calculation in the ERP student AR module. Aid awards packaged in the SIS's FA module must be disbursed via ERP AR and reported to the Department of Education's COD system. Any latency or transformation error at this seam creates billing errors, Title IV compliance exposure, and student-facing disruption.

### Why a General-Purpose ERP Cannot Stand Alone

No standard ERP ships with: ISIR ingestion logic, R2T4 withdrawal calculation, SAP processing, SAIG connectivity, unitized endowment pool accounting, F&A rate calculation per 2 CFR Appendix III, or effort certification workflows per 2 CFR 200.430. Higher education deployments require either a purpose-built SIS (Ellucian Banner/Colleague, Oracle PeopleSoft Campus Solutions, Workday Student) as the primary student-facing system, or a heavily configured ERP platform with education-specific extensions.

### Complexity Drivers

| Driver | Detail |
|---|---|
| Fund types | Current unrestricted, current restricted, loan, endowment (true/term/quasi), plant, agency |
| Restriction levels | Without donor restrictions, with donor restrictions (purpose/time/perpetual) |
| Revenue streams | Tuition & fees, state appropriations, grants & contracts, gifts, auxiliary enterprises, investment income |
| Regulatory bodies | US Department of Education (FSA), DHHS/ONR (F&A rates), IRS, GASB, FASB, NCES (IPEDS), state agencies, accreditors |
| Reporting calendars | Academic year (FA), fiscal year (GL/audit), award period (grants), calendar year (1098-T, 990) |

---

## 2. Industry-Specific Modules

### Student Financial Aid Management

Federal financial aid processing requires deep integration with Department of Education systems:

- **Title IV programs:** Pell Grant, Federal Direct Loans (Subsidized/Unsubsidized/PLUS/Grad PLUS), Federal Perkins Loan (discontinued for new borrowers as of September 30, 2017; final disbursements permitted through June 30, 2018; legacy servicing continues) [1], FSEOG
- **ISIR ingestion:** The Central Processing System (CPS) processes FAFSA data and generates ISIRs (Institutional Student Information Records) transmitted via SAIG (Student Aid Internet Gateway). ERP/SIS must ingest ISIRs, parse the Student Aid Index (SAI, formerly Expected Family Contribution/EFC), and trigger the packaging workflow
- **Packaging engine:** Builds aid offers respecting Cost of Attendance (CoA) by enrollment type (full-time/half-time/less-than-half-time), dependency status, aggregate loan limits, and institutional policy
- **Satisfactory Academic Progress (SAP):** Quantitative (pace: credits earned/attempted) and qualitative (GPA) checks at defined evaluation points; ERP must flag non-compliant students and enforce aid holds
- **R2T4 calculation engine:** When a student withdraws, 34 CFR 668.22 requires calculating the earned vs. unearned portion of Title IV aid based on the percentage of the payment period completed. Unearned aid must be returned within 45 days. This calculation must be automated and audit-trailable.
- **Disbursement:** Aid credited to student account (credit-to-balance per 34 CFR 668.164), excess transmitted to student or parent; COD origination and disbursement records submitted via SAIG/EDI

### Tuition Billing and Cashiering

- **Tuition schedule engine:** Configurable per term, residency type (in-state/out-of-state/international), enrollment level (undergraduate/graduate/professional), enrollment status (full-time/part-time tiers), and program-specific surcharges. Must support both credit-hour rates and flat-rate models simultaneously.
- **Student AR:** Receivable per student per term; charges generated by enrollment activity in the SIS. Must support payment plans with installment schedules, late fees, and hold escalation.
- **Cashiering / POS:** Point-of-sale transactions for auxiliary enterprises (housing deposits, dining plans, parking permits, library fines, health center copays). Integrates with Touchnet (Heartland)/Nelnet Campus Commerce/CashNet (Transact) for payment processing.
- **Third-party billing:** Employer tuition assistance programs (direct billing to employer AR), VA Chapter 33 (Post-9/11 GI Bill) payments from VA direct to institution per 38 U.S.C. § 3313, and state vocational rehabilitation agency billing.
- **1098-T generation:** Annual IRS Form 1098-T (Tuition Statement) per 26 U.S.C. § 6050S; ERP must calculate amounts billed (or paid, depending on institutional election) per calendar year, excluding non-qualified expenses, and file electronically with IRS and deliver to students by January 31.

### Sponsored Program / Research Grant Accounting

This module is the most technically demanding in the higher-education ERP stack:

- **Project cost accounting:** Each sponsored award (grant, contract, cooperative agreement) established as a project with sponsor identity, CFDA number, period of performance, total budget broken down by cost element (personnel, fringe, travel, supplies, subawards, F&A)
- **F&A (Facilities and Administrative) indirect cost rate:** Per 2 CFR Appendix III to Part 200, institutions negotiate an F&A rate with their cognizant federal agency (typically DHHS Division of Cost Allocation for most universities; ONR for institutions where Department of Navy is the cognizant agency). The rate is applied to a Modified Total Direct Cost (MTDC) base that excludes equipment, capital expenditures, patient care charges, tuition remission, and subaward costs exceeding $25,000 per subaward. Non-federal entities without a negotiated rate may use a 15% de minimis MTDC rate per 2 CFR 200.414(b) (increased from 10% by the 2024 Uniform Guidance revision, effective October 1, 2024) [2]; pass-through subrecipients without a rate may similarly use up to 15% per 2 CFR 200.332. Always verify against current eCFR before applying.
- **Effort reporting:** 2 CFR 200.430 requires that compensation charged to federal awards be supported by after-the-fact personnel activity certifications. ERP must generate pre-populated effort reports from payroll actuals, route for PI and employee certification, enforce the 100% constraint (total certified effort across all activities must equal 100%), and maintain audit trail. See implementation cautions for timing risks.
- **Budget vs. actual tracking:** Real-time encumbrance accounting by cost element; budget period enforcement (prevents charging costs outside the project period or to the wrong budget period); automated carryforward requests at period end where sponsor permits.
- **Award closeout:** Final financial report (SF-425 Federal Financial Report for most federal sponsors), refund of unspent balances, FCTR (Final Cost Transfer Review), and sub-recipient monitoring closeout. 2 CFR 200.344 requires closeout within 120 days of award end date.
- **Sub-recipient monitoring:** When the institution passes federal funds to a sub-recipient, 2 CFR 200.332 requires risk assessment, monitoring, and documentation. ERP must track sub-award obligations, disbursements, and required reports from sub-recipients.

### Fund Accounting

- **Fund types and structure:** Current unrestricted (operating), current restricted (grant and gift-funded operating), loan funds, endowment funds (true/term/quasi), plant funds (unexpended plant, renewals & replacements, retirement of indebtedness, investment in plant), agency funds
- **FASB model (private):** Net assets reported in two classes per FASB ASU 2016-14: with donor restrictions and without donor restrictions. ERP must enforce restriction class at the fund level and prevent expenditure of restricted funds for non-permitted purposes.
- **GASB model (public):** Governmental fund statements (general fund, special revenue, capital projects, debt service, permanent funds) plus enterprise fund statements for business-type activities. GASB Statement No. 34 requires both fund-level and government-wide (entity-wide) statements, with reconciliation between the two.
- **Inter-fund transfers:** Allocations between funds (e.g., transfer from operating fund to plant fund for facilities projects) must follow board-authorized procedures and be tracked separately from operating revenues/expenditures to prevent distortion of operating performance metrics.
- **Pooled investment accounting:** Investments often pooled across funds; each fund holds units in the pool. Unit value calculated periodically (monthly or quarterly); income and gains allocated to participating funds proportionally.

### Endowment Management

- **Unitized pool accounting:** Each endowment fund holds units in one or more investment pools. Unit value = Pool Market Value / Total Units Outstanding. New gifts purchase units at current unit value; spending distributions reduce units proportionally.
- **Spending-rate policy:** UPMIFA (Uniform Prudent Management of Institutional Funds Act, NCCUSL 2006, adopted in 49 states + DC + USVI; Pennsylvania remains the principal non-adopting state as of 2026) [3] requires prudent spending decisions considering long-term preservation of purchasing power. Typical institutional policy: spend 4–5% of the rolling 12-quarter (3-year) average market value. ERP must compute this rolling average and generate spending distributions each fiscal year.
- **Donor restriction tracking:** True endowment (donor-restricted in perpetuity), term endowment (restriction expires after a specified period or event), quasi-endowment (board-designated; not donor-restricted; board can un-designate). ERP must maintain separate sub-ledger records for each category. Board authorization trail is required for quasi-endowment establishment or liquidation.
- **Underwater endowments:** When endowment market value falls below the historic gift value (original corpus), FASB ASU 2016-14 requires disclosure and restricts spending to the donor's specified amount (or prohibits spending entirely absent donor permission or state law authorization). ERP must flag underwater status and enforce spending restrictions automatically.
- **Gift annuity / charitable remainder trust accounting:** Split-interest agreements recorded at present value of expected remainder; actuarial adjustments each period.

### Advancement / Gift Integration

- **Pledge receivables:** Unconditional promises to give recognized at fair value per FASB ASC 958-310; discounted to present value for multi-year pledges using an appropriate discount rate. Installment schedules tracked in ERP; aging and collection workflows.
- **Gift receipt and acknowledgment:** IRS substantiation rules (26 U.S.C. § 170(f)(8) and IRS Publication 1771) require contemporaneous written acknowledgment for gifts of $250 or more, with quid pro quo disclosure for gifts where the donor receives goods/services.
- **Campaign hierarchy:** Campaign → Fund → Designation. A single gift may be designated to multiple funds; a fund may receive gifts from multiple campaigns. ERP must support multi-level hierarchy with roll-up reporting.
- **Matching gifts:** Corporate matching gift programs require tracking employee donor, corporate match amount, submission to employer, and receipt of matching payment as a separate gift from the corporation.
- **CRM integration:** Advancement ERP data flows bidirectionally with Blackbaud CRM (Raiser's Edge NXT), Salesforce Education Cloud, or other constituent relationship management tools. Gift records originate in the CRM and post to ERP GL; ERP student data informs prospect research and alumni giving history.

### Human Capital Management (Faculty-Specific)

Higher education HCM requirements diverge sharply from commercial HR:

- **Faculty contract management:** Tenure-track status, rank, contract type (tenure-track, non-tenure-track, adjunct, visiting), promotion/tenure timelines, sabbatical tracking
- **Effort allocation:** Split appointments across departments and grants are common; a faculty member may be 50% Department A, 25% Grant B, 25% Grant C. Payroll must reflect this allocation, and changes must flow to effort reporting.
- **9-month vs. 12-month conversion:** Academic-year faculty (9-month appointments) may charge summer salary to sponsored projects; ERP must correctly compute the daily rate (1/9 of AY salary per month of summer effort). Errors here are a common DCAA audit finding.
- **Graduate student stipends:** Stipends, fellowships, and tuition waivers have distinct tax treatment (26 U.S.C. § 117); ERP must distinguish between taxable and non-taxable fellowship payments and correctly issue W-2 vs. 1099-MISC vs. no tax form.
- **Adjunct payroll:** High-volume, per-course or per-credit-hour payroll with frequent changes each term; ERP must handle mass term-based appointments efficiently.

### Academic Resource Planning

- **Course section capacity and demand forecasting:** Integration with SIS enrollment data to project seat demand by course, term, and modality; input to facility planning.
- **Space utilization analytics:** Classroom, lab, and office space utilization reporting; link to plant fund accounting for capitalization and depreciation of facilities.
- **Plant fund accounting:** Capitalization of construction projects during the building phase; transfer to investment-in-plant on completion; straight-line depreciation per institutional policy; deferred maintenance tracking and accrual.

---

## 3. Regulatory and Compliance Requirements

### US Federal Financial Aid

| Citation | Scope |
|---|---|
| Higher Education Act (HEA), Title IV (20 U.S.C. § 1070 et seq.) | Authorizes all federal student financial aid programs |
| 34 CFR Part 668 | Student Assistance General Provisions: institutional eligibility, program integrity, financial responsibility standards |
| 34 CFR Part 685 | William D. Ford Federal Direct Loan Program regulations |
| 34 CFR Part 674 | Federal Perkins Loan Program (legacy servicing; no new borrowers after September 30, 2017) |
| 34 CFR 668.22 | R2T4 withdrawal calculation requirements |
| 34 CFR 668.24 | Records retention: Title IV records for 3 years from end of award year, extended if audit findings are pending |

**Program Integrity Triad:** State authorization + regional accreditation + ED Program Participation Agreement (PPA) certification — all three required for Title IV eligibility. ERP must track PPA certification status.

**Annual compliance audit:** Institutions disbursing Title IV funds require an annual independent auditor's report on compliance plus a Title IV-specific financial statements audit per 34 CFR 668.23. Institutions expending $1,000,000 or more in federal awards in a fiscal year must also undergo a Single Audit per 2 CFR 200.501 (threshold increased from $750,000 to $1,000,000 effective for new awards on or after October 1, 2024) [2].

### Research Compliance

| Citation | Scope |
|---|---|
| 2 CFR Part 200 (Uniform Guidance) | Effective December 26, 2014; most recently revised April 22, 2024 (effective October 1, 2024 for new awards) [2]; superseded OMB Circular A-21 (2 CFR Part 220) for educational institutions. Governs cost principles, administrative requirements, and audit requirements for federal awards. |
| 2 CFR 200.414 | Indirect cost rates; cognizant agency negotiation; de minimis rate (15% of MTDC as of October 1, 2024) |
| 2 CFR Appendix III to Part 200 | F&A cost identification, assignment, and rate determination specifically for IHEs |
| 2 CFR 200.430 | Compensation for personal services; effort certification standards |
| 2 CFR 200.332 | Pass-through entity requirements; sub-recipient monitoring |
| 2 CFR 200.334 | Federal award records retention: 3 years from submission of final financial report |
| 2 CFR 200.501 | Single Audit threshold: $1,000,000 in federal expenditures per fiscal year (increased from $750,000 effective October 1, 2024) [2] |

DCAA (Defense Contract Audit Agency) audits DoD-sponsored research at educational institutions. DCAA focuses on timekeeping systems, compensation practices, cost transfers, and direct vs. indirect cost classification. ERP audit trail requirements for labor cost transfers (personnel activity adjustments) must satisfy DCAA standards: documentation of reason for transfer, PI signature, restricted within 90 days of the original posting.

NIH and NSF each publish grants policy supplements that layer additional requirements on top of 2 CFR 200; ERP award setup must capture sponsor-specific terms.

### Student Data Privacy

| Law | Jurisdiction | Key Requirements |
|---|---|---|
| FERPA (20 U.S.C. § 1232g; 34 CFR Part 99) | Federal (all institutions receiving federal funding) | Governs access to education records; defines PII; requires written consent for disclosure; grants student inspection rights; defines directory information and opt-out |
| COPPA (15 U.S.C. § 6501–6506) | Federal | Applies to online services directed at children under 13; relevant for K-12 platforms |
| SOPIPA (CA AB 1584, 2014) | California | Restricts use of student data by ed-tech operators; prohibits targeted advertising using student data |
| NY Education Law § 2-d | New York | Requires data privacy agreements with vendors; parent bill of rights for data privacy |

### Financial Reporting Standards

- **Public universities:** GASB Statement No. 34 (entity-wide and fund-level financial statements, MD&A); GASB Statement No. 35 (addendum for public colleges and universities, 1999); GASB Statement No. 87 (leases, effective for fiscal years beginning after June 15, 2021); GASB Statement No. 96 (subscription-based IT arrangements/SBITAs, effective for fiscal years beginning after June 15, 2022); GASB Statement No. 94 (public-private partnerships, effective for fiscal years beginning after June 15, 2022)
- **Private nonprofit universities:** FASB ASC 958 (Not-for-Profit Entities); FASB ASU 2016-14 (now in effect, two net asset classes); FASB ASC 958-310 (contributions receivable); FASB ASC 958-320 (investments); FASB ASC 958-605 (revenue recognition for contributions); FASB ASC 842 (leases, effective for most private IHEs in 2022)
- **IPEDS:** All Title IV-eligible institutions must complete the annual IPEDS (Integrated Postsecondary Education Data System) Finance Survey administered by NCES. GASB filers use Finance Form G; FASB filers use Finance Form F. Data drives federal funding formula calculations and public accountability reporting.

### Endowment Law

UPMIFA (Uniform Prudent Management of Institutional Funds Act, NCCUSL 2006) adopted in 49 states + DC + USVI; Pennsylvania is the principal non-adopting jurisdiction as of 2026 [3]. UPMIFA imposes a prudent-investor standard for both investment and spending decisions, replaces the prior "historic dollar value" rule, and permits appropriation from underwater endowments only under specific circumstances. ERP spending-rate engine must be configurable to institutional board-adopted policy within UPMIFA parameters.

### Tax Compliance

| Obligation | Citation | ERP Requirement |
|---|---|---|
| IRS Form 990 annual filing | 26 U.S.C. § 6033 | Data aggregation for Schedule A (public charity status), Schedule D (supplemental financial), Schedule F (foreign activities), revenue/expense reconciliation |
| Unrelated Business Income Tax (UBIT) | 26 U.S.C. § 511–514 | Separate tracking of revenue and expenses by unrelated business activity; Form 990-T |
| 1098-T | 26 U.S.C. § 6050S | Calendar-year tuition billing/payment amounts; electronic filing with IRS; delivery to student by January 31 |
| Gift substantiation | 26 U.S.C. § 170(f)(8); IRS Publication 1771 | Contemporaneous written acknowledgment for gifts ≥ $250; quid pro quo disclosure above $75 |
| Federal Tax Information (FTI) safeguards | 26 U.S.C. § 6103; IRS Publication 1075 | Beginning 2024-25 FAFSA cycle, FTI from FAFSA data is tightly restricted; systems receiving FTI must implement IRS Publication 1075 safeguards: AES-256 encryption at rest, RBAC, audit logs, physical security controls, background checks for personnel with access |

---

## 4. Key Data Entities

### Core Education Data Model

```sql
-- Student and Academic Structure
Student (
  student_id          PK,
  person_id           FK → Person,
  enrollment_status   ENUM[active|inactive|graduated|withdrawn|on_leave],
  residency_type      ENUM[in_state|out_of_state|international],
  academic_level      ENUM[undergraduate|graduate|professional|doctoral],
  expected_graduation DATE,
  financial_aid_eligibility BOOLEAN,
  ferpa_directory_suppress BOOLEAN   -- Directory information opt-out flag
)

AcademicTerm (
  term_id         PK,
  term_code       VARCHAR,           -- e.g. 202509
  start_date      DATE,
  end_date        DATE,
  census_date     DATE,              -- Date enrollment is locked for billing/aid purposes
  financial_aid_year VARCHAR         -- e.g. 2025-26
)

Enrollment (
  enrollment_id   PK,
  student_id      FK → Student,
  section_id      FK → CourseSection,
  term_id         FK → AcademicTerm,
  status          ENUM[enrolled|dropped|withdrawn|auditing],
  credit_hours    DECIMAL,
  billing_hours   DECIMAL,           -- May differ from credit hours (e.g. repeats, audits)
  grade           VARCHAR
)

-- Tuition and Student Accounts
TuitionSchedule (
  schedule_id         PK,
  term_id             FK → AcademicTerm,
  residency_type      ENUM[in_state|out_of_state|international],
  enrollment_level    ENUM[undergraduate|graduate|professional],
  min_hours           DECIMAL,
  max_hours           DECIMAL,
  flat_rate_flag      BOOLEAN,
  amount_per_credit   DECIMAL,
  flat_amount         DECIMAL,
  program_surcharge   DECIMAL
)

StudentAccount (
  account_id          PK,
  student_id          FK → Student,
  balance             DECIMAL,
  billing_hold_flag   BOOLEAN,
  aid_hold_flag       BOOLEAN,
  payment_plan_id     FK → PaymentPlan
)

-- Financial Aid
FinancialAidAward (
  award_id            PK,
  student_id          FK → Student,
  term_id             FK → AcademicTerm,
  aid_year            VARCHAR,       -- e.g. 2025-26
  fund_source         ENUM[Pell|DirectLoan_Sub|DirectLoan_Unsub|PLUS|GradPLUS|FSEOG|Perkins|Institutional|State],
  amount_awarded      DECIMAL,
  amount_disbursed    DECIMAL,
  status              ENUM[packaged|accepted|originated|disbursed|cancelled],
  cod_award_id        VARCHAR        -- COD system origination ID
)

SAP_Evaluation (
  eval_id             PK,
  student_id          FK → Student,
  term_id             FK → AcademicTerm,
  cumulative_gpa      DECIMAL,
  pace_pct            DECIMAL,       -- Credits earned / credits attempted
  max_timeframe_pct   DECIMAL,       -- Credits attempted / program length
  sap_status          ENUM[satisfactory|warning|suspension|probation]
)

-- Sponsored Research
SponsoredProject (
  project_id          PK,
  award_number        VARCHAR,
  sponsor             VARCHAR,
  cfda_number         VARCHAR,       -- Catalog of Federal Domestic Assistance number
  pi_employee_id      FK → Employee,
  start_date          DATE,
  end_date            DATE,
  no_cost_ext_date    DATE,
  total_budget        DECIMAL,
  fa_rate_id          FK → FARate,
  award_type          ENUM[grant|contract|cooperative_agreement|subaward],
  mtdc_base           DECIMAL,       -- Modified Total Direct Cost base for F&A calculation
  cognizant_agency    VARCHAR
)

FARate (
  fa_rate_id          PK,
  rate_type           ENUM[MTDC|TDC|salaries_wages],
  rate_category       ENUM[on_campus_research|off_campus|instruction|other_sponsored],
  negotiated_rate_pct DECIMAL,
  effective_from      DATE,
  effective_to        DATE,
  rate_subtype        ENUM[fixed|predetermined|provisional|final],
  cognizant_agency    VARCHAR
)

EffortReport (
  effort_id           PK,
  employee_id         FK → Employee,
  period_start        DATE,
  period_end          DATE,
  project_id          FK → SponsoredProject,
  ipa_activity_id     FK → IPAActivity,   -- Non-sponsored activity (instruction, service, etc.)
  certified_effort_pct DECIMAL,           -- Must sum to 100% per employee per period
  certified_by        FK → Employee,
  certification_date  DATE,
  status              ENUM[draft|certified|revised|locked]
)

-- Fund Accounting and Endowment
Fund (
  fund_id                     PK,
  fund_code                   VARCHAR,
  fund_type                   ENUM[current_unrestricted|current_restricted|loan|endowment|plant|agency],
  restriction_class           ENUM[with_donor_restrictions|without_donor_restrictions],
  donor_restriction_description TEXT,
  purpose_code                VARCHAR,
  endowment_subtype           ENUM[true|term|quasi]  -- Null if not endowment
)

EndowmentPool (
  pool_id             PK,
  pool_name           VARCHAR,
  units_outstanding   DECIMAL,
  unit_market_value   DECIMAL,       -- Calculated each valuation date
  unit_book_value     DECIMAL,       -- Historic dollar value / units
  spending_rate_pct   DECIMAL,       -- Board-adopted rate per UPMIFA policy
  rolling_avg_mv      DECIMAL,       -- 12-quarter rolling average for spending calculation
  underwater_flag     BOOLEAN
)

EndowmentFundHolding (
  holding_id          PK,
  fund_id             FK → Fund,
  pool_id             FK → EndowmentPool,
  units_held          DECIMAL,
  inception_date      DATE,
  historic_gift_value DECIMAL,       -- Original corpus; underwater threshold
  donor_restriction   TEXT
)

-- Advancement / Gift Management
Gift (
  gift_id                 PK,
  constituent_id          FK → Constituent,
  gift_date               DATE,
  amount                  DECIMAL,
  gift_type               ENUM[outright|pledge_payment|planned|matching],
  fund_designation_id     FK → Fund,
  campaign_id             FK → Campaign,
  acknowledgment_sent     BOOLEAN,
  acknowledgment_date     DATE,
  quid_pro_quo_amount     DECIMAL,   -- Value of goods/services received in exchange
  irs_substantiation_req  BOOLEAN    -- True if amount >= 250
)

Pledge (
  pledge_id               PK,
  constituent_id          FK → Constituent,
  total_pledge_amount     DECIMAL,
  start_date              DATE,
  end_date                DATE,
  installment_frequency   ENUM[monthly|quarterly|annually],
  amount_paid_to_date     DECIMAL,
  balance_receivable      DECIMAL,
  discount_rate           DECIMAL,   -- For PV calculation per FASB ASC 958-310
  present_value           DECIMAL
)
```

---

## 5. Critical Integrations

| System / Product | Category | Integration Method | Key Data Exchanged |
|---|---|---|---|
| Ellucian Banner (Oracle DB backend, SaaS available) / Ellucian Colleague (UniData DB, SaaS) | SIS + Financial Aid + Student Finance | REST API via Ellucian Ethos Integration Layer; Banner Integration Layer (BIL) | Enrollment, grades, degree audit, person demographic, FA awards, student account charges |
| Oracle PeopleSoft Campus Solutions | SIS | Component Interface / PeopleTools REST | Student financials, enrollment, FA packaging, academic records |
| Workday Student | SIS + HCM + Finance (unified) | Workday API / EIB (Enterprise Interface Builder) / Workday Studio | Enrollment, payroll allocations, FA, student accounts; native integration within Workday platform |
| SAIG (Student Aid Internet Gateway) | Federal Aid Infrastructure | Batch file transmission via SAIG enrollment agreement with FSA | ISIR delivery, COD origination/disbursement, NSLDS enrollment reporting |
| COD (Common Origination and Disbursement) | Federal Aid Disbursement | SAIG / EDI X12 | Pell Grant and Direct Loan origination records, disbursement confirmations, reconciliation reports |
| CPS / ISIR (Central Processing System) | FAFSA Processing | SAIG batch | ISIR records with SAI (Student Aid Index), dependency status, verification selection flag |
| NSLDS (National Student Loan Data System) | Loan History / Enrollment Reporting | SAIG batch / web services | Aggregate loan balances, enrollment status reporting (required within 60 days of enrollment changes per 34 CFR 685.309) |
| PowerFAIDS (College Board) / Regent Award / FAME | FA Packaging (standalone) | API / batch file | Award packaging decisions, SAP evaluations; used at some institutions alongside Banner/PeopleSoft |
| Blackbaud CRM (Raiser's Edge NXT) / Salesforce Education Cloud | Advancement / CRM | REST API | Gift records, pledge installments, constituent data, campaign performance; ERP receives gift postings; CRM receives GL confirmation |
| COEUS / Kuali Research (KR) | Research Administration (Pre-Award) | REST API / database integration | Award setup, budget, IRB/IACUC protocol linkage, sub-award setup |
| Touchnet (Heartland) / Nelnet Campus Commerce / CashNet (Transact) | Student Payments / Cashiering | REST API / hosted payment page redirect | Student payments, payment plan enrollment, refund processing |
| Canopy (Huron) / Cayuse / Effort Reporting Solutions | Effort Certification | LDAP / SSO / SFTP | Pre-populated effort reports from payroll, certified effort percentages back to grants system |
| Canvas / Blackboard / Moodle (LMS) | Learning Management | LTI 1.3 / REST API | Course sections, enrollment rosters (real-time sync), grade passback |
| Jaggaer (formerly SciQuest) / Unimarket | eProcurement | Punchout (cXML) / EDI 850/855/810 / REST | Requisitions, purchase orders for lab supplies and equipment; contract spend by grant project |
| Workday Adaptive Planning | Budgeting / FP&A | Workday API (native if Workday ERP) | Operating budget by fund/department, revenue projections, scenario modeling |
| IPEDS Data Collection Tool (NCES) | Federal Reporting | Web-based submission / KEYHEI file format | Enrollment counts, finance survey data, completions, institutional characteristics |
| SAP S/4HANA Grants Management (PSM-GM) | Grants (if SAP ERP) | Native S/4HANA | Sponsored project budgeting, F&A calculation, award lifecycle |
| Kronos/UKG / ADP | Time and Attendance | API / batch | Hours worked for hourly staff/student workers, overtime, leave balances for effort validation |
| InCommon Federation / Shibboleth IdP | Identity / SSO | SAML 2.0 | Federated authentication for SIS, ERP, LMS, and third-party systems |

---

## 6. KPIs and Metrics

| KPI | Definition | Formula | ERP Source |
|---|---|---|---|
| Net Tuition Revenue per Student | Average revenue retained after institutional aid discounts | (Gross Tuition & Fee Revenue − Institutional Scholarships & Fellowships) / FTE Enrollment | Student AR + Financial Aid modules |
| Tuition Discount Rate | Proportion of gross tuition offset by institutional aid | Institutional Aid Awarded / Gross Tuition & Fee Revenue | Financial Aid + GL |
| F&A Recovery Rate | Indirect cost recovered as percentage of direct federal research costs | F&A Recovered / Total Direct Costs on Federal Awards | Grants/Projects module |
| Award Closeout Rate | Percentage of sponsored projects closed within 90 days of project end date | Projects Closed Within 90 Days of End Date / Total Projects Ending in Period | Project Accounting module |
| Cost Transfer Rate | Frequency of post-award budget transfers; indicator of award management quality | Cost Transfers Processed / Total Award Transactions | Grants Accounting |
| Days Cash on Hand | Operating liquidity measure | Unrestricted Cash & Short-Term Investments / (Total Operating Expenses / 365) | GL + Treasury |
| Return on Endowment | Investment return on endowment pool for a fiscal year | (Ending Market Value − Beginning Market Value + Distributions − New Contributions) / Beginning Market Value | Endowment module |
| Endowment Spending Rate | Annual endowment distribution as percentage of rolling average market value | Annual Payout / Rolling 12-Quarter Average Market Value | Endowment module |
| Endowment per FTE | Institutional wealth indicator | Total Endowment Market Value / FTE Enrollment | GL + Enrollment |
| Underwater Endowment Exposure | Percentage of endowment funds below historic gift value | Market Value of Underwater Funds / Total Endowment Market Value | Endowment module |
| Effort Certification Completion Rate | Percentage of required effort certifications completed by deadline | Certified Reports / Total Required Reports in Period | Effort Reporting module |
| Satisfactory Academic Progress (SAP) Rate | Percentage of aid-eligible students meeting SAP thresholds | Students Meeting SAP / Total Financial Aid Recipients | SIS + Financial Aid |
| R2T4 Return Amount | Dollar amount of unearned Title IV aid required to be returned upon student withdrawal | Unearned Aid % × Total Title IV Aid Disbursed in Payment Period | Financial Aid module (34 CFR 668.22) |
| Headcount to FTE Ratio | Faculty/staff workload and workforce structure indicator | Total Employee Headcount / FTE Count | HCM module |
| Facilities Cost per Gross Square Foot | Plant fund operational efficiency | Total Facilities Operations & Maintenance Expenditure / Gross Square Footage | Plant Fund / Facilities module |
| Grant Overhead Budget Variance | Actual vs. budgeted F&A charges on sponsored awards | (Actual F&A Charges − Budgeted F&A) / Budgeted F&A | Grants Accounting |
| Pledge Receivable Collectability Rate | Percentage of pledges actually collected vs. originally booked | Pledge Payments Received / Total Pledges Booked (adjusted for write-offs) | Advancement / GL |

---

## 7. Major ERP Vendors for this Vertical

### Ellucian (Banner and Colleague)

Ellucian is the dominant SIS/ERP vendor in US higher education. As of January 2025, Ellucian Banner holds approximately 24% of the North American higher-ed SIS market and Ellucian Colleague approximately 11%, giving Ellucian a combined ~35% share [4]. Globally, Ellucian partners with approximately 3,000 institutions serving more than 21 million students, of which over 2,000 institutions leverage at least one Ellucian SaaS solution. In 2024, 30 institutions went live on Banner or Colleague SaaS (a 67% year-over-year increase); in 2025, 32 institutions went live [5][6].

- **Ellucian Banner** (Oracle DB backend, SaaS available): Targets larger and mid-size institutions. Modules: Banner Student (enrollment, FA, academic records, degree audit), Banner Finance (GL, AP, AR, grants), Banner HCM (payroll, HR, benefits), Banner Advancement (gift/pledge CRM). API integration via Ellucian Ethos Integration Layer (REST-based, event-driven).
- **Ellucian Colleague** (UniData DB backend, SaaS available): Targets smaller and mid-size colleges. Functionally equivalent coverage to Banner; different technical stack.
- **Strength:** Decades of accumulated Title IV configuration, NSLDS/SAIG integration, and institutional know-how; largest higher-ed customer base for support benchmarking.
- **Weakness:** Legacy database designs (UniData, Oracle); large-scale customizations built over decades become migration liabilities; UI modernization ongoing.

### Oracle (PeopleSoft Campus Solutions)

Oracle PeopleSoft Campus Solutions has 30+ years of higher-education functional history and deep Title IV and NSLDS integration. It is typically deployed alongside PeopleSoft Financials (GL, AP, AR, Asset Management, Grants Management) and PeopleSoft HCM (Payroll, Benefits, Time and Labor). The on-premises footprint remains large; Oracle's roadmap routes institutions toward PeopleSoft on OCI (Oracle Cloud Infrastructure) or migration to Oracle Fusion Cloud. Oracle Fusion Cloud for Higher Education is an emerging offering but has fewer purpose-built SIS capabilities than Campus Solutions.

### Workday

Workday Student is a cloud-native SIS launched in the mid-2010s, extending the Workday platform (Financial Management, HCM) to cover the academic domain:

- **Modules:** Academic Records, Admissions, Financial Aid, Student Financials; unified with Workday Financial Management and Workday HCM on a single data model
- **Key strength:** No integration seam between HR, Finance, and Student within the Workday platform; single person record, single payroll, native effort reporting
- **Key weakness:** Newer product with fewer niche higher-ed configurations accumulated over decades compared to Banner/PeopleSoft; requires significant process re-engineering
- **Notable implementations:** Washington University in St. Louis (WashU) completed its Workday Student go-live for academic year 2024–25 as part of the "Student Sunrise" project, replacing 70+ legacy systems including WebSTAC, WebFAC, WebAdvising, and WUCRSL; the total project cost exceeded $265 million over seven-plus years [7]. University of Arkansas System configured 540+ business processes across 20 of 21 member institutions. University of Maryland implemented Workday HCM, Financials, and Student with independent quality assurance reviews.
- **Workday Adaptive Planning** for multi-year budgeting integrated natively.

### SAP (Student Lifecycle Management / S/4HANA)

SAP Student Lifecycle Management (SLCM) is available for SAP S/4HANA Cloud Private Edition, covering admission, student registration, academic structure management, and student accounting. Paired with SAP S/4HANA FI/CO for financial accounting, SAP Grants Management (PSM-GM) for sponsored research, and SAP Fund Management (PSM-FM) for budget control. SAP's grants management and fund management capabilities are technically strong, particularly for institutions with complex multi-source funding. SAP is more prevalent in European universities and large research universities with existing SAP footprints; precise North American IHE customer counts are unverified and should not be stated without attribution.

### Unit4 / Thesis

- **Unit4 ERP** (formerly Agresso): Strong in European higher education (UK, Nordics, Netherlands); covers Finance and HCM for higher-education back-office.
- **Thesis** (spun off from Unit4 in 2021, funded at approximately $13.6M): Separate SaaS SIS brand targeting small-to-mid US, Canada, and UK colleges. Current US market share is not publicly quantified.
- **University of Waterloo** (Canada): Documented Unit4 ERP cloud implementation used as a reference case.

### Sage Intacct

Used by smaller private colleges and community colleges. Strong multi-entity fund accounting, grant tracking, and project accounting. Lacks native SIS; integrates with Banner or standalone SIS. Viable for institutions prioritizing accounting depth over an integrated SIS experience.

### NetSuite (Oracle)

Occasional use at smaller private institutions and online-only colleges. SuiteProjects for grant and project tracking; multi-entity consolidation via OneWorld. No native SIS or Title IV integration; requires third-party education-specific extensions.

### K-12 Specifics

This table is provided only for contrast with the higher-education vendors above; for the full K-12 vendor landscape (public district finance/SIS platforms and private-school platforms) see `verticals/schools.md`.

| Vendor | Product | Role |
|---|---|---|
| PowerSchool | PowerSchool SIS | Dominant K-12 SIS (a December 2024 cyberattack — disclosed January 2025 — exposed student and teacher records across thousands of North American districts via a compromised customer-support portal credential; cybersecurity posture is a diligence factor for procurement) [8] |
| Tyler Technologies | Munis ERP | Finance, HR, procurement for school districts |
| Tyler Technologies | Infinite Campus | K-12 SIS alternative |
| Frontline Education | Frontline HCM | K-12 district HR and payroll |
| Skyward | Skyward SMS | K-12 SIS and finance |

---

## 8. Implementation Cautions

### SIS-ERP Integration Complexity

The enrollment-billing-aid cycle is the most dangerous integration seam in higher-education ERP. Enrollment in the SIS drives tuition charges in the ERP AR module; financial aid awards in the SIS FA module must be disbursed via ERP AR and reported to COD. The bidirectional data flow creates a circular dependency:

```
SIS enrollment change
  → ERP billing recalculation
    → FA award adjustment (if enrollment drops below half-time)
      → SIS financial hold flag update
        → Student registration eligibility change in SIS
```

Any lag or transformation error in this cycle can result in billing errors, Title IV over-disbursement (creating institutional repayment liability), and incorrect NSLDS enrollment status reporting. Map census-date enrollment snapshot logic precisely: mid-term drops and withdrawals affect billing period calculations and R2T4 calculations differently, and the ERP must distinguish between these scenarios.

### Data Migration from Legacy SIS

Banner and PeopleSoft data models are deeply relational and heavily customized over decades of institutional-specific configuration. Non-negotiable migration targets include: complete academic history, all financial aid award history (required for NSLDS reporting and future packaging calculations), pledge receivable schedules, endowment fund inception-date unit histories, and plant fund asset records with accumulated depreciation. Define "student record completeness" upfront in the migration charter; incomplete migration of historical FA awards blocks NSLDS reporting obligations and may trigger an ED program review.

### Title IV Configuration Risk

The R2T4 withdrawal calculation per 34 CFR 668.22 is algorithmically precise and must be tested exhaustively before go-live. Any error in Pell Grant origination records submitted to COD can trigger a program review, repayment demand, or fine. SAIG/COD connectivity must be tested in the Department of Education's test environment (TestLink) before production go-live; ED's batch-processing windows are fixed and cannot be adjusted. Allow adequate lead time for SAIG enrollment agreement processing (typically 4–6 weeks from FSA).

The 2024-25 FAFSA cycle saw ED announce significant ISIR delivery delays to institutions in early 2024 — ISIR delivery was delayed until at least March 2024 — combined with FTI (Federal Tax Information) classification changes restricting how institutions could access and share FAFSA-sourced tax data [9]. This created widespread ERP and FA system remediation work at hundreds of institutions. Systems receiving FTI must implement IRS Publication 1075 safeguards; verify compliance posture before the next cycle.

### F&A Rate Negotiation Timing

New F&A rates must be loaded into the ERP before the fiscal year start; retroactive rate adjustments to prior-period awards create complex reposting workflows and potential audit exposure. Distinguish rate subtypes: fixed rates (no retroactive adjustment), predetermined rates (no adjustment), and provisional rates (subject to final settlement). The ERP must enforce the correct rate type per award. Institutions between rate agreements default to the 15% de minimis MTDC rate per 2 CFR 200.414(b) (as of October 1, 2024) [2]; verify current eCFR for exact conditions.

### Effort Reporting Workflow

Effort certification deadlines are fixed by sponsor requirements and institutional policy; ERP workflow must implement automated email reminders and escalation trees. The 100% constraint is a hard data integrity rule: the ERP must reject or warn on any effort certification where the sum of certified percentages across all activities (sponsored and non-sponsored) for a single individual in a period does not equal 100%. Personnel cost adjustments submitted after an effort report has been certified require re-certification and a documented justification; DCAA scrutinizes unilateral cost transfers made by grants accountants without PI involvement. Document all cost transfer rationale in ERP at the transaction level.

### Fund Accounting Complexity

Chart of accounts design for higher education must simultaneously support: fund × function (instruction/research/public service/academic support/student services/institutional support/operations) × object (personnel/supplies/equipment) × program × project dimensions. Restriction tracking errors — treating temporarily restricted gift revenue as unrestricted operating revenue — are audit findings under FASB ASC 958 and can result in donor relations damage. Quasi-endowment establishment and liquidation require board-of-trustees authorization; the ERP must maintain a document trail linking the transaction to the board resolution.

### Go-Live Timing

Never go live at:
- Fiscal year-end (June 30 for most institutions) — GL close, annual financial statements, and audit fieldwork compound implementation stress
- Financial aid packaging season (February–May) — ISIR processing, award offers, and COD origination activity is at peak volume
- Term enrollment peak (August–September for fall, December–January for spring)

Recommended window: summer go-live after spring term financial close and before fall registration opens. The WashU Workday Student implementation — totaling over $265 million across seven-plus years — illustrates that process re-engineering and stakeholder alignment (particularly faculty governance) are the most underestimated risks; plan for 6–12 months of business process redesign workshops before system configuration begins [7].

### GASB/FASB Reporting Bifurcation

Multi-campus university systems may include both public (GASB) and private nonprofit (FASB) legal entities. If a single ERP serves both, it must produce GASB-compliant governmental fund statements and entity-wide statements for the public entities and FASB ASC 958-compliant statements of financial position, activities, functional expenses, and cash flows for the private nonprofit entities — from the same transaction base. Chart of accounts and reporting layer design must accommodate both models without double-coding transactions.

---

## 9. Security and Compliance Depth

### FERPA Technical Controls

FERPA (20 U.S.C. § 1232g; 34 CFR Part 99) governs access to education records at all institutions receiving federal funding. Technical enforcement requirements:

- **RBAC on student record tables:** "Legitimate educational interest" must be defined per institutional policy and enforced at the API layer, not merely the UI. Every query to a student record must be evaluated against the requestor's role and the student's directory suppression flags.
- **Directory information suppression:** Students may opt out of directory information disclosure. This flag must propagate in real time to all integrated systems: LMS, alumni directory, third-party analytics, institutional research tools. A suppressed student must not appear in any directory export regardless of the requesting system.
- **Audit logging:** All access to education records must be logged. FERPA does not specify retention duration, but NASFAA recommends 5–7 years for financial aid records; 34 CFR 668.24 mandates Title IV records for 3 years from the end of the award year (extended if audit findings are pending).
- **Disclosure consent tracking:** When a student authorizes disclosure (e.g., to a parent), the consent record and scope must be maintained in ERP/SIS and enforced.

### Title IV Data Security

- **SAIG enrollment:** Institutional participation in SAIG requires a signed enrollment agreement with Federal Student Aid (FSA). Personnel authorized to access SAIG must be individually credentialed.
- **FTI safeguards (IRS Publication 1075):** Systems receiving Federal Tax Information from FAFSA beginning with the 2024-25 cycle must implement: AES-256 encryption at rest and in transit, strict RBAC limiting FTI access to authorized personnel only, audit logs capturing every access to FTI-containing records, physical security controls for facilities housing FTI, background checks for personnel with FTI access. Annual FSA data security compliance certification is required.
- **Annual compliance certification:** Institutions must submit an annual data security compliance certification to FSA; failure to maintain compliance can result in loss of Title IV program participation.

### Research Data Security

- **CUI and NIST compliance:** DoD-sponsored research involving Controlled Unclassified Information (CUI) requires compliance with NIST SP 800-171 Rev. 3 (finalized May 14, 2024) [10]. As of 2025, DoD CMMC 2.0 Level 2 (final rule effective December 16, 2024) [11] references NIST SP 800-171 Rev. 2 for current contract assessments; DoD has indicated Rev. 3 will eventually be incorporated into DFARS 252.204-7012, but Rev. 2 remains the current CMMC baseline. ERP and research systems storing CUI must meet NIST SP 800-171 Rev. 2 controls at minimum; verify against current DFARS/CMMC requirements before configuring access controls.
- **Export control:** ITAR (22 CFR Parts 120–130) and EAR (15 CFR Parts 730–774) restrict access to controlled research data, equipment, and results by foreign nationals. ERP access controls at the sponsored project level must enforce export control restrictions; the project record should carry an export control classification flag that triggers enhanced access controls and logging.
- **Data classification:** Institutional data classification policy must be enforced at the grant project level in ERP; projects handling export-controlled or proprietary sponsor data require elevated access controls beyond standard grant accounting access.

### Identity and Access Management

Higher education has standardized on federated identity via the **InCommon Federation** (SAML 2.0 / Shibboleth) for SSO across SIS, ERP, LMS, and integrated third-party systems. ERP SSO must integrate with the institutional Identity Provider (IdP); student, faculty, staff, and external (vendor, auditor) roles must be managed centrally with role provisioning tied to authoritative HR and SIS sources. See `core/security.md` for detailed SoD and PAM patterns applicable to ERP DBA accounts (Banner/Oracle and PeopleSoft/Oracle DBA privileged access requires PAM tooling and session recording).

### Segregation of Duties in Education Context

| Domain | Required Separation |
|---|---|
| Financial Aid | FA packaging (award creation) // FA disbursement authorization // Student AR billing posting — three distinct roles per Title IV audit requirements |
| Grant Accounting | PI effort certification // Grant accountant financial review // Sponsored Programs post-award management — three-way separation per 2 CFR 200.430 |
| Endowment | Investment pool manager // Spending distribution authorization // Gift recording and pledge receipt — must be separated; same individual cannot both receive and authorize use of a gift |
| Student Accounts | Tuition billing calculation // Cash receipts posting // Write-off authorization — three roles |
| Purchasing/AP | Requisition approval // Purchase order issuance // Invoice approval // Payment release — four-way separation for high-value procurement |

### Audit and Records Retention Schedule

| Record Type | Retention Requirement | Citation |
|---|---|---|
| Title IV financial aid records | 3 years from end of award year (extended if audit findings pending) | 34 CFR 668.24 |
| Federal award records (grants/contracts) | 3 years from submission of final financial report | 2 CFR 200.334 |
| IRS Form 990 supporting documentation | 7 years (statute of limitations on tax records) | IRS guidance |
| Endowment gift instruments (donor agreements) | Permanent | Best practice; audit requirement |
| FERPA-governed education records | Institution-defined; NASFAA recommends 5–7 years for FA records | 34 CFR 668.24; NASFAA guidance |
| SAIG/COD transmission records | Minimum 3 years from end of award year | FSA program participation agreement |
| Export control records | 5 years after license expiration or transaction date | 22 CFR 122.5; 15 CFR 762.6 |

ERP document management must link original endowment gift instruments to the fund record, with version history if instruments are amended by donor or court order (cy pres). Physical or electronic document management integration is required; the ERP should not store these instruments as unstructured attachments without metadata-driven retrieval by fund_id.

---

## See Also

- `verticals/schools.md` — K-12 ERP treatment (this file covers higher education only): public school districts (GASB fund accounting, state funding formulas, IDEA/ESSA/E-rate/Child Nutrition compliance) and private K-12 schools (FASB ASC 958 fund accounting, tuition/enrollment management, advancement, accreditation, diocesan consolidation, boarding-school compliance)
- `core/features-core.md` — fund accounting and project accounting fundamentals applicable across verticals
- `core/security.md` — SoD controls, IAM patterns, PAM for DBA accounts, audit logging architecture
- `verticals/government-publicsector.md` — GASB standards overlap, federal grant compliance under 2 CFR 200, Single Audit requirements
- `verticals/nonprofit-ngo.md` — FASB ASC 958 and endowment accounting parallels; gift/pledge management
- `verticals/professional-services.md` — project-based billing and effort tracking patterns applicable to sponsored research

---

## Citations & Sources

1. US Department of Education, "Federal Perkins Loan Program" — program expired September 30, 2017; final disbursements through June 30, 2018. https://studentaid.gov/understand-aid/types/loans/perkins
2. OMB, "Final Guidance: Uniform Administrative Requirements, Cost Principles, and Audit Requirements for Federal Awards," April 22, 2024; effective October 1, 2024 for new awards. 2 CFR Part 200. https://www.ecfr.gov/current/title-2/part-200 — Key changes: Single Audit threshold raised to $1,000,000 (§ 200.501); de minimis indirect cost rate raised to 15% of MTDC (§ 200.414(b)); pass-through de minimis rate also 15% (§ 200.332).
3. NCCUSL, "Uniform Prudent Management of Institutional Funds Act" (2006). Adopted in 49 states, DC, and USVI; Pennsylvania remains principal non-adopting state as of 2026. https://www.uniformlaws.org/committees/community-home?CommunityKey=043b9067-2a8c-4001-9884-8e9de89b7b62
4. ListEdTech, "North American SIS HigherEd Market Share — January 2025 Update," January 2025. https://listedtech.com/blog/north-american-sis-highered-market-share-january-2025-update/
5. Ellucian press release, "Record Number of Higher Education Institutions Go Live on Ellucian SaaS SIS and ERP Solutions in 2024," February 2025. https://www.ellucian.com/newsroom/record-number-higher-education-institutions-go-live-ellucian-saas-sis-and-erp-solutions
6. Ellucian press release, "Ellucian Achieves Record SaaS Adoption with 32 Institutional Go-Lives in 2025." https://www.ellucian.com/newsroom/ellucian-achieves-record-saas-adoption-32-institutional-go-lives-2025
7. Washington University in St. Louis Student Life, "Breaking Down Workday's $265 Million Cost," December 10, 2025. https://www.studlife.com/news/2025/12/10/breaking-down-workdays-265-million-cost — WashU Workday Student go-live for AY 2024-25; Student Sunrise project replaced 70+ legacy systems.
8. TechCrunch, "What PowerSchool Won't Say About Its Data Breach Affecting Millions of Students," March 10, 2025. https://techcrunch.com/2025/03/10/what-powerschool-isnt-saying-about-its-massive-student-data-breach/ — December 2024 breach via compromised credential; disclosed January 2025.
9. Federal Student Aid, "Access and Use of Federal Tax Information (FTI) for Federal Student Aid Programs Beginning with the 2024-25 FAFSA Processing Cycle." https://fsapartners.ed.gov/knowledge-center/library/electronic-announcements/2023-05-12/access-and-use-federal-tax-information-fti-federal-student-aid-programs-beginning-2024-25-fafsa-processing-cycle-updated-september-17-2025 — ISIR delivery delayed until March 2024; FTI classification changes imposed new system safeguards on institutions.
10. NIST, SP 800-171 Rev. 3, "Protecting Controlled Unclassified Information in Nonfederal Systems and Organizations," May 14, 2024. https://doi.org/10.6028/NIST.SP.800-171r3
11. US Department of Defense, "Cybersecurity Maturity Model Certification (CMMC) Program" final rule, published October 15, 2024; effective December 16, 2024. 32 CFR Part 170. https://www.federalregister.gov/documents/2024/10/15/2024-21049/cybersecurity-maturity-model-certification-cmmc-program — Level 2 aligned to NIST SP 800-171; Rev. 2 is current CMMC assessment baseline.
12. IRS, Publication 1075, "Tax Information Security Guidelines for Federal, State and Local Agencies," current edition. https://www.irs.gov/pub/irs-pdf/p1075.pdf
13. GASB Statement No. 34, "Basic Financial Statements—and Management's Discussion and Analysis—for State and Local Governments" (1999). GASB Statement No. 35, "Basic Financial Statements—and Management's Discussion and Analysis—for Public Colleges and Universities" (1999). https://gasb.org/standards
14. FASB ASC 958, "Not-for-Profit Entities"; FASB ASU 2016-14, "Presentation of Financial Statements of Not-for-Profit Entities." https://asc.fasb.org
15. Federal Student Aid, SAIG / COD Technical Reference and FSA Partner Portal. https://fsapartners.ed.gov
16. US Department of Education, FERPA regulations: 34 CFR Part 99; Student Privacy Policy Office. https://studentprivacy.ed.gov
17. NACUBO (National Association of College and University Business Officers) — endowment studies, UPMIFA guidance, indirect cost resources. https://www.nacubo.org
18. NCES, IPEDS Finance Survey components and forms. https://nces.ed.gov/ipeds/use-the-data/survey-components/9/finance
19. InCommon Federation (SAML 2.0 / Shibboleth). https://www.incommon.org
20. EDUCAUSE Review — higher education ERP implementation experience library. https://er.educause.edu
