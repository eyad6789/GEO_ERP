# ERP for Government & Public Sector

## 1. Overview

Government ERP diverges from commercial ERP at a foundational level: the mission is stewardship of public funds under legal authorization, not profit maximization. Every architectural choice in a government ERP must reflect this distinction.

**Fund accounting vs. profit accounting.** Commercial entities maintain a single equity pool; government entities maintain self-balancing fund sets — each fund has its own assets, liabilities, and fund balance. There is no retained earnings account. Profit or loss is a meaningless concept; expenditures are measured against legal appropriations. The ERP chart of accounts must encode fund identity as a primary segment, and every transaction must balance within a fund before rolling to government-wide statements.

**Appropriation law as the binding constraint.** A private-sector budget is advisory; management can redirect spending with CFO approval. In government, the legislature's appropriation act is law. Spending beyond the appropriated amount is a criminal violation under the Anti-Deficiency Act, 31 USC § 1341, for US federal entities [1]. This transforms the ERP budget control engine from a soft warning system into a hard enforcement mechanism with legal consequences for failure.

**Political budget cycles and fiscal constraints.** Government fiscal years rarely align with natural business cycles. Continuing resolutions — stopgap funding measures enacted when appropriations bills are not passed on time — impose prorated spending authority and restrict new obligations. These events are not exceptional; many US federal agencies operate under continuing resolutions for months each year. ERP systems must model these transient authorities without manual journal workarounds.

**Multiple simultaneous reporting frameworks.** A US state government may be required to produce GASB-compliant financial statements for its ACFR (Annual Comprehensive Financial Report, renamed from CAFR by GASB Statement No. 98, issued October 2021 [2]), submit DATA Act spending data to USASpending.gov, report to the Single Audit clearinghouse for federal grant activity, and publish open data feeds for citizen transparency — all from the same underlying transaction data. The ERP must maintain dimensional attributes sufficient to satisfy all these reporting surfaces without redundant data entry.

**Procurement under public law, not commercial judgment.** Government procurement is governed by statute and regulation: FAR (48 CFR Chapter 1), state purchasing laws, UK Procurement Act 2023 (commenced 24 February 2025 [3]), EU Directive 2014/24/EU. Sole-source awards require documented justification. Set-aside programs mandate tracking of contractor socioeconomic status. Protests are a legal mechanism. None of this exists in commercial procurement.

**Stakeholder complexity.** The authorizing environment includes the legislature (appropriations), the executive (budget formulation and execution), oversight bodies (GAO, OIG, OMB, state auditor), bond rating agencies, federal cognizant agencies for grants, and ultimately citizens. Each stakeholder class demands different data extracts from the same ERP.

---

## 2. Industry-Specific Modules

### 2.1 Fund Accounting & General Ledger

The fund is the atomic accounting entity. Every balance sheet, every revenue/expenditure statement, every budget comparison closes within a fund.

**Fund type taxonomy** (GASB Statement No. 34, 1999 [4]):

- **Governmental funds:** General (primary operating), Special Revenue (restricted for specific purpose), Debt Service (bond repayment), Capital Projects (infrastructure construction), Permanent (principal preserved, earnings expendable)
- **Proprietary funds:** Enterprise (business-like activities billed to external users — utilities, airports), Internal Service (intra-government services — motor pool, print shop)
- **Fiduciary funds:** Pension Trust, Investment Trust, Private-Purpose Trust, Custodial (assets held for others, not available for government programs)

ERP implications: the COA must include a fund segment that fully determines the accounting basis applied. Governmental funds use **modified accrual** (revenues recognized when measurable and available, expenditures when incurred). Proprietary and government-wide statements use **full accrual**. The ERP must maintain dual-basis posting logic — a single transaction may post to both a governmental fund ledger (modified accrual) and the government-wide conversion layer (full accrual adjustment entries for long-term liabilities, capital assets, etc.).

Interfund activity requires careful tracking: interfund transfers (permanent reallocation), interfund loans (due-to/due-from), interfund services provided/used, and interfund reimbursements each have distinct accounting treatment under GASB guidance.

### 2.2 Budget & Appropriation Management (FM/Budgetary Control)

The budgetary control module is the most government-specific component in any ERP deployment. It must model the entire appropriation lifecycle:

**Legislative appropriation → Agency allotment → Sub-allotment → Object class → Project/program control**

- **Budget object codes (BOCs):** Object class is the primary control dimension (personnel compensation, contractual services, supplies, equipment). BOC assignment drives both expenditure reporting and Anti-Deficiency Act compliance.
- **Appropriation year types:** 1-year (expires end of fiscal year), multi-year (available for N fiscal years), no-year (available until expended). ERP must enforce lapsing rules automatically.
- **Pre-encumbrance:** Created at purchase requisition stage; reduces available balance before a PO is issued. This is the first line of defense against over-obligation.
- **Encumbrance:** Created at purchase order/contract award; commits budget authority. Must survive fiscal year-end for multi-year appropriations.
- **Expenditure:** Liquidates encumbrance when invoice is approved for payment. The three-stage chain (pre-encumbrance → encumbrance → expenditure) is a fundamental design pattern, not optional.
- **Apportionment tracking (US federal):** OMB apportions appropriated funds to agencies quarterly or by program under OMB Circular A-11 [5]. ERP must track apportioned amounts separately from appropriated amounts; spending against un-apportioned funds violates the Anti-Deficiency Act.
- **Continuing resolution logic:** Prorates spending authority based on prior-year enacted levels or specified percentages. Restricts new programmatic obligations. Must be configurable without requiring custom code on each CR event.
- **Position budgeting:** Government headcount is legally authorized at the position level. Vacancy rates affect budget projections. The budget module must integrate with HR position management to project salary and fringe costs.

### 2.3 Grant Management

Federal grants follow a mandated lifecycle under **2 CFR Part 200 (Uniform Guidance)** [6]:

- **Pre-award:** Application development, indirect cost rate negotiation, matching requirement computation.
- **Award:** Grant award recorded in ERP; fund created or grant project activated; period of performance established.
- **Post-award execution:** Expenditure tracking by ALN (Assistance Listing Number, formerly CFDA) program, allowable/unallowable cost determination, cost sharing tracking, time-and-effort reporting for personnel.
- **Federal reporting:** SF-425 Federal Financial Report submitted on schedule; cash draws from Payment Management System (PMS) or G-Invoicing reconciled to expenditure records.
- **Subrecipient monitoring:** Pass-through entity must monitor subrecipients' compliance per 2 CFR § 200.332; ERP should track subrecipient agreements and monitoring findings.
- **Closeout:** Liquidation of all obligations within 120 days of period of performance end (2 CFR § 200.344). ERP must hard-stop new expenditures after period of performance ends even if budget balance remains.

**Indirect cost rate management:** Negotiated rates (predetermined, fixed, provisional) must be applied correctly per cost pool and base. ERP must support multiple rate schedules for different grant programs. Rate negotiations with the cognizant federal agency produce a Negotiated Indirect Cost Rate Agreement (NICRA).

### 2.4 Procurement & Contract Management

Government procurement replaces commercial purchasing judgment with mandatory procedures:

- **Competitive bidding types:** IFB (Invitation for Bid — sealed, lowest responsive responsible bidder wins), RFP (Request for Proposals — evaluated on technical merit and price), RFQ (Request for Quotations — below simplified acquisition threshold).
- **Thresholds (US federal):** Micro-purchase (≤ $10,000 — no competition required for most commodities), Simplified Acquisition Threshold (SAT, currently $250,000 — simplified procedures), full competition (above SAT).
- **Mandatory set-asides:** 8(a) Small Business Development, HUBZone, SDVOSB (Service-Disabled Veteran-Owned), WOSB (Women-Owned Small Business). ERP must track vendor certifications and award goals vs. actuals.
- **Contract types:** FFP (Firm Fixed Price), T&M (Time and Materials), Cost-Plus-Fixed-Fee, CPAF (Cost-Plus-Award-Fee), IDIQ (Indefinite Delivery/Indefinite Quantity with task orders), BPA (Blanket Purchase Agreement).
- **FAR clause library:** The Federal Acquisition Regulation (48 CFR Chapter 1) prescribes 50+ standard clauses required in various contract types. DFARS (48 CFR Chapter 2) adds DoD-specific clauses. DFARS 252.242-7005 and 252.242-7006 define acceptable contractor business systems and accounting system adequacy standards.
- **Protest tracking:** Unsuccessful offerors may protest to GAO or COFC (Court of Federal Claims); ERP must support stop-work order issuance and hold funds pending protest resolution.
- **SAM.gov integration:** Contractor registration status, suspension/debarment, and socioeconomic certifications must be verified against SAM.gov before award. Debarred or suspended vendors must be blocked in ERP.

### 2.5 Project Accounting & Capital Improvement Planning (CIP)

Capital improvement plans span multiple fiscal years and multiple funding sources:

- Project cost accumulation by phase: planning (feasibility, NEPA/environmental), design (A/E contracts), construction, closeout.
- Multiple funding source blending: bond proceeds, federal grants, state aid, general fund transfer — each with its own restrictions on expenditure timing and eligible costs.
- Asset capitalization threshold: when a project reaches substantial completion, costs are transferred from CIP to fixed assets. Government-specific thresholds vary; GFOA guidance recommends establishing a written capitalization policy.
- Bond proceeds accounting: issuance costs, premium/discount amortization, arbitrage rebate calculation (Tax-Exempt Bond restrictions under IRC § 148).

### 2.6 Public Asset / Property Management

GASB Statement No. 34 requires reporting of all capital assets, including infrastructure (roads, bridges, drainage systems). Two depreciation approaches are available for infrastructure:

- **Standard depreciation:** Straight-line or composite; depreciation expense flows to government-wide statements.
- **Modified approach (GASB 34 §§ 23–25):** Government maintains a documented condition assessment system; demonstrates assets are being preserved at or above an established condition level; no depreciation recorded; preservation expenditures (to maintain current condition level) are expensed while improvement expenditures are capitalized.

GASB Statement No. 88 (2018) requires disclosure of additional debt-related information, including unused lines of credit and assets pledged as collateral.

Asset condition ratings (Good/Fair/Poor/Critical) must be stored and linked to maintenance work orders. Fleet management integration tracks vehicle lifecycle cost, depreciation, and scheduled maintenance intervals.

### 2.7 Revenue & Receivables

Government revenue sources have distinct ERP requirements not found in commercial AR:

- **Property tax cycle:** Assessment (CAMA system) → levy calculation → bill generation → collection → delinquency → lien/tax sale. ERP must receive assessment rolls from CAMA and generate levy amounts.
- **Utility billing:** Meter reading integration, rate schedule application (tiered rates, lifeline rates), disconnect/reconnect workflow, delinquency processing.
- **License and permit fees:** Integration with permitting systems for fee collection and posting.
- **Special assessments:** Per-parcel assessments for local improvements (sidewalks, streetlights); installment payment schedules; lien attachment.
- **Non-exchange revenue (IPSAS 23):** Tax revenues, grants received without performance obligations — recognition differs from exchange transactions.

### 2.8 Treasury & Debt Management

- **Bond issuance:** Track par value, premium/discount, issue date, maturity schedule, interest payment dates, call provisions. GASB Statement No. 88 (2018) disclosures.
- **Investment portfolio:** Fair value measurement per GASB Statement No. 31; investment policies constrain eligible instruments (US Treasuries, agency securities, money market, LGIP — Local Government Investment Pool).
- **Cash pooling:** Central treasury pools cash across funds for investment yield while maintaining fund-level accounting via internal allocation.
- **Arbitrage:** Tax-exempt bond proceeds invested at yields exceeding bond interest rate trigger IRS arbitrage rebate obligation under IRC § 148; ERP must support rebate calculation or export data to specialized arbitrage software.

### 2.9 Payroll & HR (Government-Specific)

- **Civil service classification:** Position classification under OPM GS schedule (federal) or state equivalents; step increases within grade; in-grade promotions.
- **Collective bargaining agreements (CBAs):** Multi-union environments with different pay scales, leave rules, and benefit packages per bargaining unit. CBA expiration and renegotiation cycles affect payroll setup.
- **Leave accrual:** Annual leave, sick leave, compensatory time, administrative leave, FMLA tracking. Accrued leave balances are liabilities (GASB 16 — compensated absences); ERP must compute and record these.
- **GASB 68 pension integration:** Net pension liability appears on government-wide statements. ERP must receive actuarial data from pension system and post the GASB 68 entry. Deferred outflows/inflows of resources related to pensions require multi-year tracking.
- **GASB 75 OPEB:** Other Post-Employment Benefits (retiree health, life insurance) — same recognition pattern as GASB 68 but for non-pension benefits.

### 2.10 Reporting & Transparency

- **ACFR generation:** Government-wide statements (Statement of Net Position, Statement of Activities), fund-level statements, notes, required supplementary information, statistical section. Automated MD&A narrative support.
- **DATA Act pipeline (US federal):** Agencies submit spending data (award financial data, award attribute data, account-level data) to Broker → SAM.gov/FPDS-NG → USASpending.gov. Signed May 9, 2014 (P.L. 113-101 [7]); agency submissions commenced May 2017. ERP must produce the DAIMS (DATA Act Information Model Schema) XML/JSON file formats.
- **Single Audit:** Organizations expending ≥ $750,000 in federal awards annually must have a Single Audit (2 CFR Part 200 Subpart F). ERP must produce the Schedule of Expenditures of Federal Awards (SEFA) by ALN number.
- **XBRL tagging:** SEC-registered municipal issuers may require XBRL-tagged financial data; DATA Act submissions use an XBRL-based taxonomy.
- **Open data APIs:** Citizen-facing spending transparency portals require ERP to publish standardized expenditure feeds. IATI standard applies to international development organizations.

---

## 3. Regulatory & Compliance Requirements

### 3.1 Accounting Standards

| Standard | Identifier | Scope | Key Requirement |
|---|---|---|---|
| Basic Financial Statements | GASB Statement No. 34 (1999) | US State & Local | Government-wide + fund-level statements; MD&A required supplementary information |
| Fund Balance Reporting | GASB Statement No. 54 (2009) | US State & Local | Fund balance classifications: Nonspendable, Restricted, Committed, Assigned, Unassigned |
| Pensions | GASB Statement No. 68 (2014) | US State & Local | Net pension liability on face of government-wide statements; deferred inflows/outflows |
| Leases | GASB Statement No. 87 (June 2017, eff. FY beginning after June 15, 2021) | US State & Local | Single lease model; right-to-use asset and lease liability for all leases > 12 months |
| OPEB | GASB Statement No. 75 (2017) | US State & Local | Net OPEB liability recognition; mirrors GASB 68 structure for non-pension benefits |
| Debt Disclosures | GASB Statement No. 88 (2018) | US State & Local | Additional disclosures: unused credit, assets pledged as collateral |
| ACFR Name Change | GASB Statement No. 98 (issued October 2021, eff. fiscal years ending after December 15, 2021) | US State & Local | Official rename from CAFR to ACFR; GFOA had initiated rename in 2021 due to offensive connotation of prior acronym [2] |
| Financial Reporting Model Improvements | GASB Statement No. 103 (approved April 17, 2024, eff. FY beginning after June 15, 2025) | US State & Local | Improvements to MD&A, RSI, and SI presentation; new budgetary comparison variance columns; noncapital subsidies in SRECNP; retroactive application per GASB 100 [8] |
| US Federal Accounting | SFFAS (Statements of Federal Financial Accounting Standards) | US Federal | Issued by FASAB; OMB Circular A-136 prescribes financial reporting requirements |
| International — Presentation | IPSAS 1 | International public sector | Presentation of financial statements; fair presentation, going concern, accrual basis |
| International — Budget | IPSAS 24 | International public sector | Presentation of budget information in financial statements; comparison of budget vs. actual |
| International — Non-Exchange Revenue | IPSAS 23 | International public sector | Revenue recognition for taxes, grants, transfers without direct exchange |
| International — First-Time Adoption | IPSAS 33 | International public sector | Transition guidance for entities adopting accrual IPSAS for first time |
| International — Leases | IPSAS 43 (issued January 2022, eff. January 1, 2025) | International public sector | Single right-of-use lessee model based on IFRS 16; replaces IPSAS 13 for lessees |
| International — Retirement Benefit Plans | IPSAS 49 (issued November 2023) | International public sector | Most recent standard in IPSASB 2024 Handbook; 49 accrual IPSAS issued in total [9] |

### 3.2 Procurement Regulations

| Regulation | Jurisdiction | Key Provisions |
|---|---|---|
| Federal Acquisition Regulation (FAR) — 48 CFR Chapter 1 | US Federal | Primary ruleset: competition requirements, contractor qualifications, pricing, contract administration |
| DFARS — 48 CFR Chapter 2 | US DoD | DoD-specific supplements; DFARS 252.242-7005/7006: acceptable contractor business systems, accounting system adequacy |
| 2 CFR Part 200 (Uniform Guidance) | US Federal grants | Procurement standards and cost principles for federal award recipients |
| UK Procurement Act 2023 (commenced 24 February 2025) | United Kingdom | Replaces PCR 2015; new transparency notices, debarment register, open frameworks; procurements begun before 24 Feb 2025 still governed by PCR 2015 (transitional) [3] |
| Public Contracts Regulations 2015 (PCR 2015) | UK (transitional) | Implemented EU Directive 2014/24/EU; still governs contracts begun under old regime |
| EU Directive 2014/24/EU | EU Member States | Above-threshold public contract rules; open/restricted/competitive dialogue procedures; thresholds revised biennially via delegated regulation |

**EU Directive 2014/24/EU procurement thresholds — current 2026–2027 period** (Commission Delegated Regulation (EU) 2025/2152, effective 1 January 2026 [10]):

| Contracting Authority | Contract Type | 2026–2027 Threshold |
|---|---|---|
| Central government authorities | Supplies & services | EUR 140,000 |
| Sub-central contracting authorities | Supplies & services | EUR 216,000 |
| All contracting authorities | Works contracts | EUR 5,404,000 |

Note: EU thresholds are revised biennially. Prior 2024–2025 values were EUR 143,000 / EUR 221,000 / EUR 5,538,000 respectively. Verify current thresholds at the EC procurement portal before use.

### 3.3 Transparency & Open Data Laws

- **Digital Accountability and Transparency Act of 2014 (DATA Act, P.L. 113-101) [7]:** Signed May 9, 2014. Requires US federal agencies to submit standardized spending data to USASpending.gov using the DAIMS schema. Agency submissions began May 2017. FFATA (Federal Funding Accountability and Transparency Act, 2006) is the precursor statute covering contract and grant disclosures.
- **OMB Circular A-11 [5]:** Preparation, submission, and execution of the President's Budget; governs apportionment process (Appendix F).
- **OMB Circular A-123:** Management's responsibility for enterprise risk management and internal control; analogous to SOX Section 302/404 for federal agencies. ERP must support the ICOFR (Internal Control over Financial Reporting) assessment.
- **OMB Circular A-136:** Federal financial reporting requirements; prescribes SFFAS-based financial statement format and audit requirements.

### 3.4 Cybersecurity & Cloud Certification

| Framework | Authority | ERP Relevance |
|---|---|---|
| FISMA (44 USC § 3551) | Congress / OMB / CISA | All federal information systems require ATO; NIST SP 800-53 Rev 5 is the control catalog |
| FIPS Publication 199 | NIST | Impact level categorization: Low / Moderate / High |
| FedRAMP (transitioning nomenclature) | GSA / OMB | Cloud-specific FISMA framework; current impact levels (Low/Moderate/High) are being replaced by Certification Classes A–D per NTC-0004 (published February 25, 2026; Class A = new pilot baseline, Class B = current Li-SaaS/Low, Class C = current Moderate, Class D = current High); the mechanics for transitioning existing authorizations to the new classes are deferred to the forthcoming FedRAMP Consolidated Rules for 2026 (CR26, expected ~end of June 2026) and are not yet finalized; transition to new terminology expected by end of 2026 [11] |
| NIST SP 800-53 Rev 5 | NIST | Control catalog: AC, AU, CM, IA, SC, SI families most impactful for ERP |
| NIST SP 800-171 Rev 2 | NIST | Protecting CUI in non-federal systems; 110 security requirements derived from SP 800-53 |
| CMMC 2.0 | DoD | Cybersecurity Maturity Model Certification; 32 CFR Part 170 finalized October 15, 2024, effective December 16, 2024; 48 CFR DFARS rule finalized September 10, 2025, effective November 10, 2025; Level 2 (110 practices aligned to SP 800-171) required for DoD contractors handling CUI [12] |
| ITAR (22 CFR Parts 120–130) | DDTC (State Dept) | Export control of defense articles/technical data; ERP must restrict access to US persons only; civil penalty up to $1.3M per violation [13] |
| StateRAMP | StateRAMP Inc. (est. 2021) | FedRAMP analog for state and local cloud procurement; vendors increasingly required to hold StateRAMP authorization for state contracts |

### 3.5 Financial Reporting Frameworks — Comparison

| Dimension | US GAAP (private) | GASB (US state/local) | SFFAS (US federal) | IPSAS (international) |
|---|---|---|---|---|
| Accounting basis | Full accrual | Modified accrual (funds) + full accrual (govt-wide) | Full accrual (primarily) | Full accrual |
| Standard-setter | FASB | GASB | FASAB | IPSASB |
| Budget presentation required | No | Yes (GASB 34 RSI; enhanced under GASB 103) | Yes (OMB A-136) | Yes (IPSAS 24) |
| Pension standard | ASC 715 | GASB 68 | SFFAS 5 | IPSAS 39 |
| Lease standard | ASC 842 | GASB 87 | SFFAS 54 | IPSAS 43 |
| Fund accounting required | No | Yes (self-balancing funds) | Yes (Treasury Account Symbols) | Recommended |
| Budgetary vs. proprietary ledger | No | Partial (budget comparison schedules) | Yes (two parallel ledgers required) | No |

---

## 4. Key Data Entities

### 4.1 Core Domain Entities and Relationships

| Entity | Purpose | Key Relationships |
|---|---|---|
| Fund | Self-balancing accounting entity | Parent of all financial transactions; has fund type/subtype |
| Appropriation | Legislative authorization to spend | Belongs to Fund; has fiscal year and year type (1-yr/multi-yr/no-yr) |
| Allotment | Agency-level subdivision of appropriation | Child of Appropriation; parent of encumbrances |
| Budget Object Code (BOC) | Object classification (personnel, contracts, supplies, etc.) | Control dimension on all expenditure transactions |
| Encumbrance | Reservation of budget authority (PO or contract) | Links to Allotment, BOC, Vendor, PurchaseOrder |
| Grant Award | External funding agreement with period of performance | Links to Fund; has ALN number, indirect cost rate |
| CIP Project | Multi-year capital project accumulating costs | Links to multiple Funds (blended sources); produces CapitalAsset on completion |
| Capital Asset | Depreciable asset per GASB 34 | Links to Fund, Project; has condition rating; may be infrastructure-modified-approach eligible |
| Vendor | Payee entity | Must be SAM.gov verified (federal); suspension/debarment flag |
| Contract | Legal agreement to procure goods/services | Links to Vendor, Encumbrance; has FAR clause set, contract type |
| Purchase Order | Procurement document generating encumbrance | Child of Contract or standalone; liquidated by Invoice |
| Invoice | Vendor claim for payment | Liquidates encumbrance; triggers disbursement warrant |
| Warrant/Payment | Disbursement | Posts expenditure; reconciles to treasury/bank |
| Position | Authorized FTE slot | Links to OrgUnit, BargainingUnit; drives salary encumbrance at beginning of year |

### 4.2 Schema Sketch

```sql
-- Fund (self-balancing accounting entity)
Fund (
  fund_id              VARCHAR        PRIMARY KEY,
  fund_type            ENUM('Governmental','Proprietary','Fiduciary'),
  fund_subtype         VARCHAR,       -- 'General', 'Special Revenue', 'Enterprise', 'Pension Trust', etc.
  fiscal_year          INT,
  adopted_budget       DECIMAL(18,2),
  modified_approach    BOOLEAN        -- GASB 34 infrastructure modified approach eligible
)

-- Appropriation (legislative authorization to spend)
Appropriation (
  appropriation_id     VARCHAR        PRIMARY KEY,
  fund_id              VARCHAR        REFERENCES Fund(fund_id),
  fiscal_year          INT,
  year_type            ENUM('1-year','multi-year','no-year'),
  budget_authority     DECIMAL(18,2),
  apportioned_amt      DECIMAL(18,2), -- OMB apportionment (federal, A-11)
  allotted_amt         DECIMAL(18,2),
  expiration_date      DATE,          -- NULL for no-year appropriations
  treasury_symbol      VARCHAR        -- e.g. 075X4510 (US federal TAS)
)

-- Allotment (agency-level budget subdivision)
Allotment (
  allotment_id         VARCHAR        PRIMARY KEY,
  appropriation_id     VARCHAR        REFERENCES Appropriation(appropriation_id),
  org_unit_id          VARCHAR        REFERENCES OrgUnit(org_unit_id),
  boc_id               VARCHAR        REFERENCES BudgetObjectCode(boc_id),
  period               VARCHAR,       -- e.g. 'Q1 FY2026'
  allotted_amt         DECIMAL(18,2),
  pre_encumbered_amt   DECIMAL(18,2), -- Purchase requisition reservations
  encumbered_amt       DECIMAL(18,2), -- Purchase order obligations
  expended_amt         DECIMAL(18,2), -- Actual disbursements (invoices paid)
  available_balance    DECIMAL(18,2)  GENERATED ALWAYS AS
                         (allotted_amt - pre_encumbered_amt - encumbered_amt - expended_amt)
)

-- Grant Award
GrantAward (
  grant_id             VARCHAR        PRIMARY KEY,
  grantor              VARCHAR,       -- 'US Dept of Education', 'HUD', etc.
  aln_number           VARCHAR,       -- Assistance Listing Number (formerly CFDA)
  award_amount         DECIMAL(18,2),
  period_start         DATE,
  period_end           DATE,          -- Hard-stop enforced by ERP; no expenditure after this date
  indirect_cost_rate   DECIMAL(6,4),  -- Negotiated NICRA rate
  indirect_cost_base   VARCHAR,       -- MTDC, TDC, etc.
  match_required       DECIMAL(18,2),
  match_received       DECIMAL(18,2),
  fund_id              VARCHAR        REFERENCES Fund(fund_id),
  pass_through         BOOLEAN        -- TRUE if acting as pass-through entity
)

-- Encumbrance
Encumbrance (
  encumbrance_id       VARCHAR        PRIMARY KEY,
  encumbrance_type     ENUM('Pre-Encumbrance','Encumbrance'),
  allotment_id         VARCHAR        REFERENCES Allotment(allotment_id),
  grant_id             VARCHAR        REFERENCES GrantAward(grant_id),   -- NULL if non-grant
  source_doc_type      ENUM('PurchaseRequisition','PurchaseOrder','Contract','TaskOrder'),
  source_doc_id        VARCHAR,
  original_amount      DECIMAL(18,2),
  liquidated_amt       DECIMAL(18,2),
  remaining_balance    DECIMAL(18,2)  GENERATED ALWAYS AS (original_amount - liquidated_amt),
  status               ENUM('Open','Partial','Fully Liquidated','Cancelled'),
  carry_forward        BOOLEAN,       -- Survives fiscal year-end for multi-year appropriations
  fiscal_year          INT
)

-- Capital Asset
CapitalAsset (
  asset_id             VARCHAR        PRIMARY KEY,
  gasb34_class         VARCHAR,       -- 'Land', 'Buildings', 'Infrastructure', 'Equipment', 'Intangibles'
  description          VARCHAR,
  acquisition_date     DATE,
  historical_cost      DECIMAL(18,2),
  accum_depreciation   DECIMAL(18,2),
  net_book_value       DECIMAL(18,2)  GENERATED ALWAYS AS (historical_cost - accum_depreciation),
  fund_id              VARCHAR        REFERENCES Fund(fund_id),
  cip_project_id       VARCHAR        REFERENCES CIPProject(project_id),
  condition_rating     ENUM('Good','Fair','Poor','Critical'),
  infrastructure_modified_approach BOOLEAN,
  disposal_date        DATE,
  disposal_method      VARCHAR
)

-- Position (government-specific HR entity)
Position (
  position_id          VARCHAR        PRIMARY KEY,
  position_class       VARCHAR,       -- OPM classification or state equivalent
  grade_step           VARCHAR,       -- e.g. 'GS-12 Step 4'
  org_unit_id          VARCHAR        REFERENCES OrgUnit(org_unit_id),
  bargaining_unit_id   VARCHAR        REFERENCES BargainingUnit(bu_id),
  fte                  DECIMAL(4,2),  -- 1.0 full-time, 0.5 half-time
  authorized_salary    DECIMAL(14,2),
  status               ENUM('Filled','Vacant','Frozen'),
  fund_id              VARCHAR        REFERENCES Fund(fund_id)
)
```

### 4.3 Budgetary vs. Proprietary Ledger Duality

US federal accounting requires two parallel ledgers that must balance independently:

- **Budgetary ledger:** Tracks budgetary resources (SF-132 Apportionment, SF-133 Report on Budget Execution and Budgetary Resources). Uses budgetary accounts (480000-series for unobligated balances, 490000-series for obligations).
- **Proprietary ledger:** Standard GAAP balance sheet and income statement accounts.

Every ERP transaction must post to both ledgers simultaneously. Failure to maintain this duality produces a federal TIER (Treasury Information Executive Repository) reconciliation error. SAP PSM-FM implements this via parallel account determination rules. Oracle Fusion implements it via public sector ledger configurations.

---

## 5. Critical Integrations

### 5.1 Federal / Central Government Systems

| System | Owner | Integration Purpose |
|---|---|---|
| SAM.gov (System for Award Management) | GSA | Vendor registration verification, suspension/debarment check, small business certification |
| USASpending.gov / DATA Act Broker | Fiscal Service / Treasury | DAIMS schema submission of award and financial data (DATA Act, P.L. 113-101) |
| Payment Management System (PMS) | HHS | Federal grant cash drawdown requests; reconcile to expenditures |
| G-Invoicing | Treasury Fiscal Service | Intragovernmental buy-sell order processing between federal agencies |
| OMB MAX / OMB Connect | OMB | Budget formulation; apportionment data exchange |
| FPDS-NG (Federal Procurement Data System — Next Generation) | GSA | Contract award reporting; all awards > $10,000 must be reported |
| NSS/NFC Payroll (National Finance Center) | USDA/GSA | Federal civilian payroll processing for many agencies |
| DFAS (Defense Finance and Accounting Service) | DoD | DoD payroll, travel, disbursement processing |

### 5.2 State & Local Integrations

| System | Purpose |
|---|---|
| State centralized accounting (STARS, STARS-II variants) | State treasury disbursement and warrant processing |
| CAMA (Computer Assisted Mass Appraisal) — Tyler iasWorld, Patriot Properties | Property assessment roll for tax levy calculation |
| Court case management — Tyler Odyssey, Thomson Reuters C-Track | Court fine and fee revenue posting |
| Permitting — Tyler EnerGov, Accela | Permit fee collection, inspection scheduling |
| Utility billing — Tyler Incode, Harris NorthStar | Meter reads, billing, collection posting to ERP AR |
| GIS / Property records — Esri ArcGIS, Tyler CLT | Parcel-linked asset and assessment data |
| Bid management — Bonfire, Periscope S2G, DemandStar | Solicitation publication and vendor bid receipt |
| State e-procurement portals | Purchase order transmission; NIGP commodity codes standardization |

### 5.3 Audit, Compliance & Oversight

- **Federal Audit Clearinghouse / Census Bureau:** Single Audit Package submission (SF-SAC, auditor data collection form, Schedule of Expenditures of Federal Awards).
- **GAO, OIG interfaces:** Data extracts for performance audits; improper payment reporting (IPERA/PIIA).
- **State auditor:** Annual audit data package; ACFR submission.
- **Bond rating agencies (Moody's, S&P, Fitch):** Structured data exports for municipal bond rating analysis.
- **MSRB (Municipal Securities Rulemaking Board) EMMA:** Continuing disclosure of annual financial information for SEC Rule 15c2-12 compliance (municipal bond issuers).

### 5.4 Payment & Treasury Systems

- **ACH/EFT:** Nacha standards for electronic vendor and payroll disbursements.
- **State warrant systems:** Paper warrant issuance where required by state law; positive pay file to bank.
- **P-card reconciliation:** US Bank Commercial Card, JP Morgan Purchasing Card; ERP must receive bank transaction feed, match to approved procurement, post expenditure.
- **Lockbox / remittance processing:** Tax payment, utility payment ingestion into AR module.

---

## 6. KPIs & Metrics

| KPI | Definition | Formula |
|---|---|---|
| Budget Utilization Rate | Percentage of appropriation spent | `(Actual Expenditures / Appropriated Budget) × 100` |
| Encumbrance Rate | Total commitments as % of budget | `(Encumbrances + Expenditures) / Appropriated Budget × 100` |
| Lapsed Appropriation % | Budget surrendered unspent at year-end | `Lapsed Appropriations / Original Budget × 100` (high rate signals planning failure) |
| Days Cash on Hand | Liquidity buffer | `Unrestricted Cash / (Annual Operating Expenditures / 365)` |
| Unrestricted Fund Balance % | GFOA benchmark: ≥ 2 months (~16.7%) | `Unassigned Fund Balance / Annual Expenditures × 100` |
| Grant Drawdown Efficiency | Speed and completeness of federal reimbursement draws | `Grant Expenditures Drawn / Total Grant Award Expenditures × 100` |
| Accounts Payable Days (Prompt Payment) | Average payment cycle; Prompt Payment Act (31 USC §§ 3901–3907) requires ≤ 30 days | `Total AP Balance / (Annual Expenditures / 365)` |
| Grant Match Compliance Rate | Actual match contributions vs. required | `Match Contributions / Required Match × 100` |
| Indirect Cost Recovery Rate | Overhead recovered from grants vs. eligible base | `Indirect Costs Recovered / Indirect Cost Base × 100` |
| Fringe Benefit Rate (Actual vs. Budget) | Loaded benefit cost relative to salaries | `Actual Fringe Benefits Paid / Actual Salaries × 100` |
| Debt Service Coverage Ratio | Ability to service bonds (enterprise funds) | `Net Operating Revenue / Annual Debt Service` |
| Capital Project Completion Rate | On-time and on-budget CIP delivery | `Projects Completed on Schedule and Budget / Total Projects × 100` |
| Cost Per Transaction | Finance processing efficiency | `Total Finance Department Cost / Total Financial Transactions Processed` |
| Subrecipient Monitoring Rate | Grant pass-through compliance (2 CFR § 200.332) | `Subrecipients Reviewed / Total Active Subrecipients × 100` |
| Position Fill Rate vs. Vacancy Rate | Workforce execution of authorized FTEs | `Filled FTEs / Authorized FTEs × 100` |

---

## 7. Major ERP Vendors for this Vertical

### 7.1 Vendor Landscape

| Vendor | Product / Module | Primary Market | FedRAMP Status |
|---|---|---|---|
| SAP | S/4HANA Public Sector: PSM-FM, PSM-GM, PSM-BCS, SAP TRM | Large US federal agencies, large state central accounting offices | Moderate (via SAP NS2 sovereign cloud; exact IL level beyond Moderate should be verified with NS2 directly) |
| Oracle | Fusion Cloud ERP: Public Sector Financial Management, Grants Management Cloud, Budget Preparation Cloud (PBCS/Hyperion integration), Procurement Cloud | US federal agencies, large states | Moderate confirmed (Oracle Government Cloud OC4); DoD IL2/IL4 supported; higher IL levels should be verified with Oracle |
| Workday | Government Cloud: Financial Management, HCM, Adaptive Planning | US federal agencies, large cities and counties | Moderate (achieved July 2022 [14]) |
| Tyler Technologies | Enterprise ERP (formerly Munis): GL, AP, AR, Budget, Payroll, HR, Purchasing, Contracts, Grants, Revenue; New World ERP | US state and local — cities, counties, school districts, special districts | StateRAMP (various certifications; specific levels/scope should be verified with Tyler for current status) |
| CGI | CGI Advantage: Financial Management, Human Capital Management, Procurement | US state central accounting offices, statewide ERP deployments | Varies by deployment; primarily hosted/on-premise for large state clients |
| Infor | Infor Public Sector (formerly Hansen): Financials, Asset Management, Permitting | US and UK local government | Limited FedRAMP presence; primarily on-premise or private cloud |
| Microsoft | Dynamics 365 Finance (Public Sector configuration) | Mid-market government globally | Moderate (via Azure Government cloud) |
| Deltek | Costpoint, GovWin | US federal contractors (accounting for cost-type contracts) — not agency-side ERP | Not applicable; Costpoint is contractor-side, not government-agency ERP |
| Unanet | GovCon ERP | US federal contractors — project cost, compliance, billing | Not applicable; contractor-side ERP |

### 7.2 SAP S/4HANA Public Sector

SAP's public sector suite implements fund accounting and budgetary control via the **PSM (Public Sector Management)** component set:

- **PSM-FM (Funds Management):** Funds Center hierarchy maps to agency organizational structure; Commitment Item hierarchy maps to budget object codes. Budget Control System (BCS) is the current engine — organizations on legacy Former Budgeting (FM-FBB) must complete BCS migration before S/4HANA conversion. Pre-encumbrance and encumbrance are posted automatically on purchase requisition and PO respectively.
- **PSM-GM (Grants Management):** Sponsored Program and Sponsored Class objects track grant funding; cost distribution rules enforce allowable cost assignments; period of performance controls hard-stop expenditures at grant end date.
- **PSM-BCS (Budget Control System):** Replaces former budgeting; supports availability control at multiple tolerance levels; budget workflow for revision requests.
- **SAP TRM (Treasury and Risk Management):** Debt instrument management, investment portfolio, cash position forecasting.
- **SAP NS2 (National Security Solutions):** US-citizen-only sovereign cloud environment for classified and ITAR-controlled workloads. Provides separation from SAP's global cloud infrastructure. Federal agencies with high-sensitivity data evaluate NS2 for ITAR compliance and higher IL requirements.

### 7.3 Oracle Fusion Cloud ERP for Government

- **Public Sector Financial Management Cloud:** Fund accounting extensions to Oracle Financials Cloud; government-specific COA segments; GASB/SFFAS reporting.
- **Grants Management Cloud:** Pre-award through closeout; 2 CFR Part 200 allowability rules; ALN tracking; SF-425 report generation support; indirect cost rate schedules.
- **Budget Preparation Cloud (Oracle PBCS / Hyperion integration):** Position budgeting; capital planning; integration back to Financials Cloud for budget load.
- **Oracle Government Cloud (OC4):** Purpose-built tenancy achieving FedRAMP Moderate and DoD IL2/IL4. Provides data residency within US government regions.

### 7.4 Workday Government Cloud

- **Financial Management:** Fund accounting, budgetary control, grant management as native capabilities rather than add-on modules. Worktag framework allows flexible dimensional accounting without custom COA segments.
- **HCM with position budgeting:** Tight integration between authorized positions and financial planning. Adaptive Planning enables multi-scenario position budgeting.
- **FedRAMP Moderate:** Authorization achieved July 2022 [14], enabling US federal agency adoption. Workday's financial management has historically been less mature than SAP/Oracle for complex federal multi-fund, multi-appropriation-year structures, though the gap has narrowed.

### 7.5 Tyler Technologies Enterprise ERP (formerly Munis)

Tyler Enterprise ERP is purpose-built for US state and local government. Fund types, GASB compliance, and government COA structures are native design assumptions rather than configured extensions:

- **Core financials:** General Ledger with fund self-balancing enforced, AP/AR, cash management, investment tracking.
- **Budget module:** Adopted, amended, and revised budget versions; budget transfers with approval workflow; position-level budget.
- **Grants module:** Grant award lifecycle; SEFA generation; subrecipient tracking.
- **Payroll/HR:** CBA rule tables; civil service step management; accrual balance tracking; GASB 16 compensated absences calculation.
- **Tyler ecosystem integration:** Tight API integration with Odyssey (court case management/fines), EnerGov (permitting), Incode (utility billing), and CLT (property/GIS) — reducing integration complexity for municipalities already using Tyler's vertical suite.
- **Market position:** Dominant in US cities and counties under 500,000 population; growing presence in mid-size states and districts.

### 7.6 CGI Advantage

CGI Advantage is architected for statewide financial management complexity: statewide vendor file management, position budgeting across agencies, statewide reporting. It is deployed by multiple US state central accounting offices as the core accounting system. Deployment model is primarily hosted or on-premise; CGI does not have a broadly available FedRAMP SaaS offering.

---

## 8. Implementation Cautions

### 8.1 Chart of Accounts Complexity

Government COA strings commonly span 20–40 segments: entity, fund, subfund, function, object, subobject, program, project, grant, appropriation year, cost center, revenue source. Mapping legacy COA to the new ERP segment structure is consistently the highest-scope-risk task in government ERP implementations. Critical pitfall: **appropriation year must be tracked separately from fiscal year**. A purchase order obligated in FY2024 against a no-year appropriation may still be open in FY2027; if appropriation year is conflated with transaction year, budget reporting breaks.

### 8.2 Budgetary Control Tuning

Default commercial ERP budget controls do not model government appropriation law. Pre-encumbrance checks at the requisition stage must be real-time (not batch) to prevent Anti-Deficiency Act violations. The control level (fund? sub-fund? object class? program?) must match the exact appropriation law structure, which varies by jurisdiction and by appropriation. **Continuing resolution logic is almost never pre-built**: most ERPs require a custom proration rules engine to compute CR authority, restrict new obligations, and lift restrictions when the CR expires or a full-year bill is enacted.

### 8.3 Fund Balance Classification (GASB 54)

GASB Statement No. 54 (2009) requires fund balances to be classified as Nonspendable, Restricted, Committed, Assigned, or Unassigned. Legacy government systems rarely tracked the attributes needed to make these classifications automatically. Retroactive classification during migration requires legal review of each fund's enabling legislation and board resolutions — a process that takes months and is audit-intensive.

### 8.4 Grant Closeout and Period of Performance Enforcement

The ERP must enforce a **hard stop on expenditures after the grant period of performance ends**, even if unspent budget balance exists. This is a technical control that is frequently misconfigured or left as a soft warning. Auditors regularly find improper charges to lapsed grants resulting from this failure. Subrecipient monitoring workflow (risk assessment, site visits, corrective action plan tracking) has no complete out-of-box solution in any major ERP as of this writing; it requires custom development or a companion system.

### 8.5 FAR/DFARS Clause Library Maintenance

The FAR clause library exceeds 50 standard clauses; DFARS adds DoD-specific clauses. Clauses are updated by periodic Federal Register rulemaking. The ERP's contract clause library must be maintainable without custom code for each update. Mandatory source tracking for small business set-asides requires live SAM.gov API integration for certification verification at time of award and periodic reverification during contract performance.

### 8.6 FedRAMP Authorization as an Architectural Decision

A government agency evaluating cloud ERP must make an early architectural choice: procure a vendor holding an existing FedRAMP authorization (or, in the new nomenclature, FedRAMP Certification) or pursue a custom Authority to Operate for a non-FedRAMP system. Authorization takes 18–36 months and costs several million dollars in assessment, documentation, and remediation — even for an established commercial product. Government data must remain within the FedRAMP authorization boundary; multi-tenant SaaS configurations that commingle government and commercial data may not qualify. This decision gates the entire ERP selection process.

### 8.7 Political Budget Cycle Risk

ERP go-lives timed to coincide with fiscal year-end or budget adoption create maximum risk: parallel operation of old and new systems occurs during the highest-volume period of the fiscal calendar. Elected official turnover between contract signing and go-live is a project killer — a new CFO, finance director, or council majority may have no ownership of the project, leading to scope contraction, vendor disputes, or outright cancellation.

### 8.8 Civil Service and Collective Bargaining Constraints

Staffing the ERP project team through civil service hiring procedures adds 3–9 months to resource procurement. More critically, changes to payroll processing systems may require negotiation with collective bargaining units before implementation — a process that can add 6–18 months. Failure to engage unions early has halted payroll module go-lives after years of preparation.

### 8.9 Legacy Data Migration

Government entities routinely carry 30–50+ years of financial history in legacy platforms (AS/400-based FAMIS, legacy JD Edwards, COBOL systems). Property and fixed asset records are frequently maintained only in spreadsheets. Multi-year encumbrances, open grant awards, and historical appropriation-year transactions must migrate with sufficient audit trail to satisfy a financial audit. Migrating without auditable history is not acceptable; parallel ledger maintenance during migration is standard practice but expensive.

### 8.10 ITAR and Citizenship-Based Access Controls

For defense-adjacent government entities, ITAR requirements (22 CFR Parts 120–130) impose citizenship-based access controls on ERP data relating to defense articles and technical data. The ERP user provisioning workflow must enforce citizenship verification; standard commercial ERP identity management does not include this capability. Custom access control attributes must be designed and audited. Civil penalties up to $1.3M per violation make this a non-negotiable engineering requirement [13].

---

## 9. Security & Compliance Depth

(Cross-reference: `core/security.md` for Separation of Duties fundamentals, role-based access control, and audit logging architecture.)

### 9.1 FISMA / FedRAMP Implementation in ERP

Every ERP module hosting federal information requires an Authority to Operate under FISMA (44 USC § 3551). The ATO package includes a System Security Plan (SSP), Privacy Impact Assessment (PIA), Plan of Action and Milestones (POA&M), and supporting artifacts. For cloud ERP, FedRAMP packages substitute for agency-specific assessments, but each agency must issue its own ATO accepting the P-ATO or Agency ATO.

**NIST SP 800-53 Rev 5 control families most impactful for ERP:**

| Control Family | Code | ERP Relevance |
|---|---|---|
| Access Control | AC | Role-based access, least privilege, account management, remote access |
| Audit and Accountability | AU | Immutable audit logs, log retention (minimum 7 years per NARA schedules), SIEM integration |
| Configuration Management | CM | Baseline configuration, change control, software inventory |
| Identification and Authentication | IA | PIV/CAC card enforcement (HSPD-12), MFA, password standards |
| System and Communications Protection | SC | Encryption in transit (TLS 1.2+), encryption at rest (FIPS 140-2/3 validated modules) |
| System and Information Integrity | SI | Malicious code protection, security alerts, software patching SLAs |

**Continuous monitoring (ConMon):** FedRAMP Moderate requires monthly vulnerability scans, annual penetration testing, and real-time SIEM integration with the agency Security Operations Center (SOC). ERP log volumes (transaction logs, access logs, change logs) must be scoped into the ConMon program from day one.

### 9.2 Data Classification and Handling

- **CUI (Controlled Unclassified Information):** Personnel data, contract data, budget details, and acquisition-sensitive information in ERP are frequently CUI. NIST SP 800-171 Rev 2 (110 controls) applies to federal contractors; CMMC 2.0 Level 2 codifies these for DoD contractor systems. The CMMC 2.0 program rule (32 CFR Part 170) became effective December 16, 2024; the DFARS acquisition rule (48 CFR) became effective November 10, 2025, inserting CMMC requirements directly into DoD contracts [12].
- **ITAR data:** Technical specifications, export-controlled program data stored in ERP (contract deliverables, CLIN descriptions, engineering data references) must be access-controlled to US persons only. User provisioning must enforce citizenship attribute. System administrators with global access to ERP tenant data must be US persons or access restricted via nationality-based role assignment.
- **PII:** HR and payroll modules contain PII subject to the Privacy Act of 1974 (5 USC § 552a) and OMB M-17-12 (Preparing for and Responding to a Breach of Personally Identifiable Information). A System of Records Notice (SORN) must be published for any new PII collection.

### 9.3 Separation of Duties in Government Context

Anti-Deficiency Act violations are criminal offenses under 31 USC § 1341. This makes SoD between budget entry, obligation, and disbursement a legal requirement, not merely a best-practice control:

- **Federal four-way separation minimum:** Budget Officer (allotment authority), Contracting Officer (obligation authority, FAR Part 1.6), Certifying Officer (certifies invoices for payment, DSSN holder, personally liable under 31 USC § 3528), Disbursing Officer (executes payment).
- **GAAP / OMB Circular A-123:** Federal agencies must conduct management's assessment of Internal Control over Financial Reporting (ICOFR) analogous to Sarbanes-Oxley Section 404. ERP must generate SoD conflict reports and support control testing documentation.
- **State and local:** GFOA internal control standards; single-signer for warrants above threshold; dual authorization for wire transfers.

### 9.4 Audit Trail Requirements

- OMB Circular A-123 requires complete, immutable audit trails for all financial transactions.
- **Records retention:** Federal financial records minimum 7 years per NARA General Records Schedule (GRS); some state jurisdictions require 10+ years. Audit trail must survive ERP version upgrades — archival strategy (read-only replica, data warehouse with original transaction IDs, immutable object storage) must be designed before go-live.
- Audit trails must capture: who initiated, who approved, original value, changed value, timestamp (UTC), source terminal/IP, and reason code for manual adjustments. Standard commercial ERP audit logs often lack reason codes — custom field extension required.

### 9.5 StateRAMP and State-Level Requirements

StateRAMP (launched 2021) is the FedRAMP analog for state and local cloud procurement. Cloud vendors seeking state government contracts are increasingly required to hold StateRAMP authorization. Individual states may impose additional data sovereignty requirements (data must reside in-state; specific state-designated data centers), which can conflict with multi-region SaaS architectures. Engineering must evaluate tenant isolation guarantees, data residency controls, and egress restrictions for any SaaS ERP deployed in a state context.

### 9.6 Physical Security for On-Premise and Hosted Deployments

FISMA-compliant data centers require NIST SP 800-53 PE (Physical and Environmental Protection) controls: access control, visitor logs, intrusion alarms, environmental monitoring. DoD deployments classified at IL4 or above require DISA (Defense Information Systems Agency) Security Technical Implementation Guide (STIG) compliance on all ERP application components (OS, database, middleware, web server). Classified systems (IL5/IL6) require separate physical spaces and may require certified destruction procedures for decommissioned storage media.

---

## See also

- `core/security.md` — SoD fundamentals, RBAC, audit logging, cryptographic controls
- `core/features-core.md` — General ledger, AP/AR, procurement, and HR module patterns applicable across verticals
- `verticals/aerospace-defense.md` — ITAR, DFARS, CMMC, and cost-type contract accounting overlap with defense agencies
- `verticals/nonprofit-ngo.md` — Fund accounting parallels; grant management; FASB ASC 958 vs. GASB comparison
- `verticals/education.md` — Government fund accounting in public K-12 and higher education; GASB applicability for public institutions

---

## Citations & Sources

1. Anti-Deficiency Act — 31 USC § 1341: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title31-section1341
2. GASB Statement No. 98, The Annual Comprehensive Financial Report (issued October 2021): https://gasb.org/page/Document?pdf=GASBS_98.pdf&title=GASB+STATEMENT+NO.+98,+THE+ANNUAL+COMPREHENSIVE+FINANCIAL+REPORT
3. UK Procurement Act 2023 (commenced 24 February 2025): https://www.legislation.gov.uk/ukpga/2023/54
4. GASB Statement No. 34, Basic Financial Statements — and Management's Discussion and Analysis — for State and Local Governments (1999): https://gasb.org/standards-and-guidance/pronouncements
5. OMB Circular A-11, Preparation, Submission, and Execution of the Budget: https://www.whitehouse.gov/omb/information-for-agencies/circulars/
6. 2 CFR Part 200, Uniform Administrative Requirements, Cost Principles, and Audit Requirements for Federal Awards (Uniform Guidance): https://www.ecfr.gov/current/title-2/part-200
7. Digital Accountability and Transparency Act of 2014 (DATA Act), P.L. 113-101 (signed May 9, 2014): https://www.congress.gov/113/plaws/publ101/PLAW-113publ101.pdf
8. GASB Statement No. 103, Financial Reporting Model Improvements (approved April 17, 2024): https://gasb.org/standards-and-guidance/pronouncements
9. IPSASB 2024 Handbook of International Public Sector Accounting Pronouncements (49 accrual IPSAS): https://www.ipsasb.org/publications/2024-handbook-international-public-sector-accounting-pronouncements
10. Commission Delegated Regulation (EU) 2025/2152 of 22 October 2025 (EU procurement thresholds 2026–2027, effective 1 January 2026): https://eur-lex.europa.eu/eli/reg_del/2025/2152/oj/eng
11. FedRAMP NTC-0004 (published February 25, 2026) — Class A–D certification nomenclature replacing Low/Moderate/High: https://www.fedramp.gov/notices/0004/
12. CMMC 2.0 — 32 CFR Part 170 (effective December 16, 2024); 48 CFR DFARS final rule (effective November 10, 2025): https://www.federalregister.gov/documents/2024/10/15/2024-22905/cybersecurity-maturity-model-certification-cmmc-program
13. ITAR — 22 CFR Parts 120–130, Directorate of Defense Trade Controls (DDTC), US Department of State
14. Workday FedRAMP Moderate Authorization (July 2022): https://newsroom.workday.com/2022-07-13-Workday-Achieves-FedRAMP-Authorized-Designation
15. EU Directive 2014/24/EU on public procurement: https://eur-lex.europa.eu/eli/dir/2014/24/oj/eng
16. NIST SP 800-53 Rev 5, Security and Privacy Controls for Information Systems and Organizations: https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final
17. NIST SP 800-171 Rev 2, Protecting Controlled Unclassified Information in Nonfederal Systems and Organizations: https://csrc.nist.gov/publications/detail/sp/800-171/rev-2/final
18. OMB Circular A-123, Management's Responsibility for Enterprise Risk Management and Internal Control: https://www.whitehouse.gov/wp-content/uploads/2016/07/a123.pdf
19. GFOA (Government Finance Officers Association) — Best Practices and ACFR Award Program: https://www.gfoa.org
20. SAP PSM documentation (PSM-FM, PSM-GM, PSM-BCS): https://help.sap.com (search: Public Sector Management)
21. Tyler Technologies Enterprise ERP: https://www.tylertech.com/products/enterprise-erp
22. StateRAMP: https://stateramp.org
23. FAR / DFARS: https://www.acquisition.gov
24. GASB (Governmental Accounting Standards Board) — complete pronouncements index: https://www.gasb.org
