# ERP for Professional Services

Professional services ERP addresses firms whose primary asset is human expertise delivered over time: management consulting, IT consulting and systems integration, legal, accounting and audit, creative and marketing agencies, architecture and engineering (A/E), staffing, and IT managed services. The configuration domain is fundamentally different from product-centric ERP: there is no inventory, no bill of materials, no warehouse, no physical goods movement. Revenue equals people × time × rate. The design challenge is bridging a CRM pipeline through SOW/contract execution into timesheet and expense capture, through billing, into compliant revenue recognition and analytics — with all ledger entries traceable to individual time entries on individual engagements.

---

## 1. Overview

**What distinguishes this vertical for ERP design:**

- **No inventory, no BOM.** The balance sheet carries people-related assets (capitalized contract costs under ASC 340-40, WIP, AR) rather than finished goods, raw materials, or fixed assets for production.
- **Revenue = people × time × rate.** Cost structure is dominated by direct labor (loaded rates including benefits, payroll taxes) and subcontractor spend. Utilization of billable headcount drives gross margin more than any other lever.
- **Project-based delivery vs. period-based financial reporting.** A project may span fiscal years; revenue must be recognized in the correct period, not at invoice date. This conflict between delivery cadence and reporting cadence is the central ERP design tension.
- **WIP as a balance sheet challenge.** Work-in-process (WIP) represents revenue earned but not yet billed; it sits as a current asset. Deferred revenue represents amounts billed in advance of earning; it sits as a current liability. Both must be computed per engagement per period and reconciled to the general ledger.
- **Cash flow patterns diverge by billing model.** Fixed-fee and retainer arrangements create "bill-then-deliver" cash flow (favorable); T&M arrangements create "deliver-then-bill" cash flow (unfavorable working capital). Mixed-model engagements create both simultaneously.
- **Sub-sectors with different compliance overlays:**

| Sub-sector | Distinguishing ERP requirement |
|---|---|
| Management / IT consulting | PSA core, ASC 606/IFRS 15 rev rec, SSP allocation |
| Law firms | Matter billing, IOLTA trust accounting, ethical walls |
| Accounting / audit firms | Engagement independence tracking, conflict-of-interest checks |
| Creative / marketing agencies | Media buying pass-through, retainer drawdown, production job costing |
| Architecture / engineering (A/E) | Percent-complete billing (AIA-style), multi-phase projects, government contracting |
| Staffing | High-volume time capture, contractor payroll, markup billing |
| IT managed services | Recurring revenue, SLA tracking, ticket-to-invoice integration |

The ERP data flow is: **CRM opportunity → SOW/contract → project → resource assignment → timesheet/expense → billing → revenue recognition → GL/financial statements → analytics**.

---

## 2. Industry-Specific Modules

### 2.1 Professional Services Automation (PSA) Core

PSA is the functional layer that does not exist in standard ERP for product companies. It manages the full project lifecycle: pursuit (linked from CRM) → kickoff → delivery → close.

- **Project lifecycle management:** status states (Pursuit, Active, On-Hold, Complete, Cancelled), gate reviews, kick-off checklist, close-out workflow including final WIP reconciliation and client sign-off
- **Resource and capacity planning:** named and role-based resource requests; skills/certification tagging on employee profiles; availability calendar integrating PTO from HCM; bench visibility (resources with less than a configurable forward utilization threshold); demand forecasting from probability-weighted pipeline; scenario planning (what-if capacity models across hiring, subcontracting, or pursuit-win scenarios)
- **Timesheet capture:** daily or weekly entry; approval workflow (employee → project manager → finance lock); mobile entry with offline sync; validation rules (e.g., total hours ≤ scheduled hours, project must be active, task must be open); correction workflow post-approval with mandatory reason code
- **Expense capture:** per-diem rules by geography, receipt OCR, policy enforcement (amount limits, category restrictions, advance settlement), multi-currency conversion at transaction date, billable vs. non-billable flagging, client-reimbursable vs. internal classification
- **Task/WBS tracking:** work breakdown structure (WBS) hierarchy, planned vs. actual hours per task, milestone tracking, Gantt integration (typically via Microsoft Project, Smartsheet, or native Gantt component)

### 2.2 Billing Engine

The billing engine must support multiple billing models, often mixed within a single SOW:

| Billing Model | Invoice trigger | Key ERP logic |
|---|---|---|
| Time & Materials (T&M) | Period close (weekly/monthly) | Rate card lookup per time entry; sum approved billable hours × rate + approved expenses |
| Fixed-Fee | Contract schedule or milestone | Invoice on schedule date regardless of hours consumed; revenue recognition separate from billing |
| Milestone-based | Deliverable acceptance | Invoice upon client sign-off on deliverable; trigger from milestone status change |
| Retainer | Periodic (monthly/quarterly) | Invoice on recurring date; drawdown tracking against prepaid balance; overage billing rules |
| Capped T&M | Period close with ceiling check | T&M up to contract cap; system must flag when approaching ceiling (configurable warning at 80%, 90%); halt billing at cap; overage approval workflow |
| Blended / hybrid | Mixed triggers per SOW line | Each SOW line item carries its own billing model; single invoice aggregates all lines |

Invoice workflow: draft generation → project manager review → finance approval → client delivery (PDF or e-invoicing). Credit memo and write-off workflow must create offsetting GL entries. Billing disputes generate a dispute record linked to specific invoice lines; rebill after resolution.

### 2.3 Rate Cards and Price Lists

- **Standard rate cards:** role/title-based (e.g., Principal $350/hr, Senior Consultant $250/hr, Analyst $150/hr); defined per currency
- **Client-specific negotiated rates:** override standard rate card for a specific client or engagement; lookup priority: engagement-specific rate → client-specific rate → standard rate card
- **Effective dating:** rate cards carry `effective_from` and `effective_to` dates; time entries use the rate card effective on the entry date, not the invoice date — prevents retroactive repricing
- **Currency-specific rates:** separate rate card rows per currency for multi-currency engagements
- **Blended rate cards:** single rate regardless of grade mix, used when client buys a team at a blended rate rather than role-specific rates
- **Rate card versioning and audit trail:** every rate change is a new version; prior versions are immutable; audit log captures who approved the change and when

### 2.4 WIP (Work-in-Process) Accounting

WIP arises because revenue may be earned (recognized) before invoicing. The accounting identity:

```
WIP Balance = Revenue Recognized to Date − Billed to Date  →  asset (if positive)
Deferred Revenue = Billed to Date − Revenue Recognized to Date  →  liability (if positive)
```

- **WIP ledger:** per-engagement, per-period record of hours accrued, cost accrued, revenue recognized, billed to date, and resulting WIP balance
- **Journal entries:** Dr WIP / Cr Revenue upon recognition; Dr AR / Dr Deferred Revenue / Cr WIP / Cr Revenue upon billing (with netting depending on relative balances)
- **WIP aging schedule:** flags WIP balances by age bucket (30/60/90/120+ days); stale WIP triggers write-off review workflow
- **WIP write-off workflow:** requires dual approval (PM + Finance controller); posts to a discrete GL account (e.g., 7xxx WIP Write-off) for audit traceability; generates reversing journal if write-off is subsequently recovered
- **Month-end reversing journal control:** system enforces that WIP accruals are reversed in the subsequent period when billing occurs, preventing double-counting

### 2.5 Revenue Recognition Engine (ASC 606 / IFRS 15)

See Section 3.1 for the governing standards. The ERP engine must enforce:

**Five-step model per contract:**
1. Identify the contract (collectibility assessment: probable = greater than ~75% likelihood under US GAAP [1]; probable = more likely than not, approximately >50% under IFRS 15)
2. Identify performance obligations (distinct promises; bundle vs. series analysis)
3. Determine transaction price (including variable consideration: incentive fees, bonuses, penalties — constrained to the amount unlikely to result in significant reversal)
4. Allocate transaction price to performance obligations using standalone selling price (SSP) — residual, market assessment, or expected cost-plus approaches
5. Recognize revenue when (or as) each performance obligation is satisfied

**Over-time recognition methods (ERP must support all):**

| Method | Formula | When used |
|---|---|---|
| Cost-to-cost (input) | % Complete = Costs Incurred ÷ Total Estimated Costs | Most common; ties to project cost tracking |
| Hours expended (input) | % Complete = Hours Logged ÷ Total Budgeted Hours | Simple engagements with uniform labor |
| Output — milestones | % Complete = Milestones Reached ÷ Total Milestones | When output milestones are contractually defined |
| Output — surveys of completion | Manager-assessed % complete | Exception; requires documented support |
| Point-in-time | N/A — recognize at acceptance/delivery | Discrete deliverables; product sales bundled with services |

**Contract modification handling:** prospective adjustment (treat modification as new contract) or cumulative catch-up (retrospective adjustment of recognized amounts). ERP must support both; cumulative catch-up posts an adjustment journal in the current period.

**SSP allocation:** when a single contract includes multiple performance obligations (e.g., implementation + license + annual support), the total transaction price is allocated in proportion to SSP of each obligation. A change in the SSP or in the transaction price triggers re-allocation and a catch-up adjustment.

**Deferred revenue waterfall:** report showing, by contract and performance obligation, the opening deferred balance, revenue recognized in period, amounts billed, and closing balance.

### 2.6 Resource and Capacity Planning / Bench Management

- Named resource requests: project manager nominates a specific person; resource manager approves or proposes an alternative
- Role-based resource requests: request for "Senior Java Developer with AWS certification" — system matches against skill/certification tags in employee profiles
- Capacity calendar: pulls from HCM (approved PTO, public holidays by country/state) to compute net available hours per resource per week
- Bench report: resources with less than X% forward utilization over the next 4–8 weeks; configurable threshold; exportable for partner review
- Pipeline-weighted demand: CRM opportunities at 50%+ probability generate resource demand forecasts; helps resource managers see upcoming demand before project kickoff
- Scenario planning: model impact of winning/losing a specific bid on capacity shortfall or surplus

### 2.7 Project Profitability and Engagement Accounting

- **Engagement P&L:** Revenue Recognized − Direct Labor Cost − Subcontractor Cost − Reimbursable Expenses − Allocated Overhead = Engagement Margin
- **Budget vs. actual variance:** hours budget vs. actual hours; cost budget vs. actual cost; revenue budget vs. recognized revenue; tracked at task, project, and engagement level
- **Margin at completion (MAC) forecast:** (Remaining Revenue − Remaining Estimated Cost) + Margin Earned to Date; updated each period as estimates change
- **Earned Value Management (EVM):** Earned Value (EV) = Budget at Completion × % Complete; Cost Performance Index (CPI) = EV / Actual Cost (AC); Schedule Performance Index (SPI) = EV / Planned Value (PV); CPI < 1.0 signals over budget; SPI < 1.0 signals behind schedule
- **Partner/manager profitability rollup:** aggregate margin across all engagements led by a partner or manager; used for compensation and business development decisions
- **Client-level profitability:** aggregate all engagements for a client; includes relationship cost (sales, account management) for true client ROI

### 2.8 SOW Management

The Statement of Work is a first-class contract object in the ERP — not a PDF attachment on an opportunity record:

- **SOW fields:** client, effective date, expiration date, service lines (each with billing model), not-to-exceed amounts per service line, deliverables list, acceptance criteria, payment terms, governing law, amendment history
- **Change order management:** each change order creates a new SOW version with a delta record; budget impact (increase/decrease to not-to-exceed, additional deliverables, timeline extension) is tracked; project budget is auto-updated or requires explicit approval to propagate
- **SOW → project → invoice traceability:** every invoice line must be traceable to a SOW line; every SOW line carries a remaining-budget balance updated on each invoice
- **Amendment versioning:** immutable version history; each version carries an approval timestamp and approver identity

### 2.9 Subcontractor and Pass-Through Cost Management

- **Subcontractor engagement records:** vendor record + engagement-specific authorization (max amount, markup rule, pass-through flag, project linkage)
- **Purchase orders:** POs issued against the engagement budget; PO remaining balance tracked against subcontractor invoices
- **Subcontractor time entry or invoice import:** some arrangements require subcontractors to enter time directly in the client's PSA (with restricted access); others import summarized invoices
- **Mark-up vs. pass-through-at-cost:** billing rule per SOW line — either bill subcontractor cost + markup % or bill at exact subcontractor cost
- **Three-way match:** Purchase Order → subcontractor vendor invoice → client billing; system enforces that subcontractor cost is matched before client billing
- **Compliance hooks:** 1099/W-9 collection and reporting (US IRS); Construction Industry Scheme (CIS) deductions (UK, for construction-adjacent services); IR35 worker classification assessment records

### 2.10 Retainer and Subscription Billing

- **Retainer balance ledger:** tracks prepaid balance per client/engagement; each billable time entry or expense reduces the balance
- **Drawdown reporting:** real-time balance available to client and account manager; alerts at configurable thresholds (e.g., 20% balance remaining)
- **Auto-renewal triggers:** generates draft invoice for next retainer period; notification to account manager and client N days before renewal
- **Overage billing:** when retainer hours are exhausted, overage hours can be billed at a different (often higher) rate; overage approval workflow before billing
- **Rollover vs. forfeiture:** per-contract rule for unused retainer balance at period end; rollover adds to next period balance; forfeiture posts to deferred revenue and then recognized when the period ends

---

## 3. Regulatory and Compliance Requirements

### 3.1 Revenue Recognition Standards

**FASB ASC 606 — Revenue from Contracts with Customers** [1]
- Effective for US public entities: fiscal years beginning after December 15, 2017 (calendar year 2018 for most public companies)
- Effective for US private entities: fiscal years beginning after December 15, 2018
- Five-step model (see Section 2.5); supersedes ASC 605 (legacy percentage-of-completion under SOP 81-1 for long-term contracts)
- Variable consideration constraint: recognize only amounts that are highly probable not to be reversed
- **ASC 340-40** (Other Assets and Deferred Costs — Contracts with Customers): sales commissions and other incremental contract acquisition costs are capitalized if expected to be recovered; amortized over the period of benefit (typically contract term, sometimes longer if renewals expected); practical expedient: expense if amortization period ≤ 1 year

**IFRS 15 — Revenue from Contracts with Customers (IASB)** [2]
- Final standard issued: May 28, 2014; effective for annual periods beginning on or after January 1, 2018 (mandatory effective date deferred from original January 1, 2017 by the IASB in September 2015)
- Substantially converged with ASC 606; key differences:

| Area | ASC 606 (US GAAP) | IFRS 15 |
|---|---|---|
| Collectibility threshold | Probable = greater than ~75% likelihood [1] | Probable = more likely than not (>50%) |
| Contract asset impairment reversal | Prohibited | Permitted (IFRS 9 ECL model applies) |
| Sales/usage-based royalty exception | Applies only to IP licenses | Broader scope |
| Interim disclosure requirements | SEC rules add detail | IFRS interim requirements less prescriptive |

**Related standards:**
- **ASC 820** (Fair Value Measurement): contingent consideration in engagement or firm acquisitions
- **ASC 830** (Foreign Currency Matters): translation of multi-currency engagement transactions; transaction gains/losses vs. translation adjustments
- **IAS 21** (The Effects of Changes in Foreign Exchange Rates): IFRS equivalent of ASC 830; functional currency determination, spot-rate translation of foreign currency transactions
- **IFRS 9** (Financial Instruments): expected credit loss (ECL) model for impairment of contract assets and trade receivables; replaces incurred-loss model [3]

### 3.2 US Government Contracting Compliance

For government contractors and firms serving federal agencies:

**FAR Part 31 — Contract Cost Principles and Procedures** [4]
- Establishes allowability, allocability, and reasonableness criteria for costs on cost-reimbursable contracts
- **FAR 31.201-2**: allowable cost criteria — cost must be reasonable, allocable, comply with applicable CAS or GAAP, and comply with the terms of the contract
- **FAR 31.205-33(f)**: consulting costs documentation requirements — three items required: (1) purpose and specific scope; (2) name of consultant and service provided; (3) basis for fee determination
- **FAR 52.215-2**: records retention — accounting records must be retained for 3 years after final payment on the contract; some agencies extend this requirement to 6+ years for audit purposes

**DCAA (Defense Contract Audit Agency)** [5]
- Audits accounting systems for adequacy — the DCAA Contract Audit Manual (CAM) Chapter 5 defines the criteria (reference DCAA CAM Chapter 5 directly for the current list; the criteria have been revised over time and a fixed count should not be cited)
- **Timekeeping requirements:** daily entry (not reconstructed at end of week), supervisor approval, immutable audit log of all changes with mandatory reason code, no retroactive batch update capability for non-administrators
- **Indirect rate structure:** must segregate costs into Fringe (benefits), Overhead (indirect labor and expenses supporting direct work), and G&A (general and administrative); each pool allocated on a defined base; provisional billing rates vs. final settled rates
- **Unallowable cost segregation:** costs identified as unallowable under FAR Part 31 (e.g., entertainment, advertising, interest) must be tracked in discrete GL accounts and excluded from indirect rate pools

**CAS — Cost Accounting Standards (48 CFR Part 9903)** [6]
- 19 standards governing cost measurement, assignment, and allocation on US government contracts
- **Modified CAS coverage:** applies to single CAS-covered contracts below the full coverage threshold; requires compliance with CAS 401, 402, 405, and 406
- **Full CAS coverage (pre-FY2026):** applies when a contractor receives a single CAS-covered contract award of $50 million or more, or received $50 million or more in net CAS-covered awards in the preceding cost accounting period. The FY2026 National Defense Authorization Act (NDAA) raises the full-coverage threshold to $100 million — verify 48 CFR 9903 for the current effective threshold
- Key standards for PS firms: CAS 401 (consistency in estimating, accumulating, and reporting costs), CAS 402 (consistency in allocating costs incurred for the same purpose), CAS 418 (allocation of direct and indirect costs)

**2 CFR 200 — Uniform Guidance** [7]
- Applies to federal grants and cooperative agreements to nonprofit organizations, universities, and state/local governments
- Governs allowability of costs, procurement standards, subrecipient monitoring, and audit requirements (Single Audit threshold: expenditures ≥ $750,000 in federal awards in a fiscal year)
- Professional services firms that administer grants or serve as pass-through entities must comply

### 3.3 Legal Sector Specific

- **ABA Model Rules of Professional Conduct — Rule 1.5 (Fees):** fees must be reasonable; factors include time, labor, novelty, required skill, opportunity cost, customary fee, amount involved, results obtained, experience and reputation. ERP billing engine must enforce rate reasonableness controls and flag unusual billing patterns [8]
- **ABA Model Rules — Rule 1.15 (Safekeeping Property / Trust Accounts):** client funds must be held in a segregated trust account (IOLTA or interest-bearing client trust account); funds must not be commingled with firm operating funds. Specific IOLTA requirements vary by state bar jurisdiction — the ERP must be configured per jurisdiction [8]
- **IOLTA (Interest on Lawyers Trust Accounts):** state bar rules (jurisdiction-specific); interest earned on pooled client funds goes to the state bar's IOLTA program; ERP GL must enforce a completely separate chart of accounts for trust vs. operating funds
- **Matter-level billing ethics:** anti-churning controls (system alerts if billable hours per task exceed a configurable threshold relative to task scope); no double-billing detection (same time block billed to multiple matters); billing narrative review workflow

### 3.4 Tax Compliance

- **IRC Section 451(b)** (US) [9]: for accrual-method taxpayers, income must be recognized no later than when it is included in the applicable financial statement (the "AFS rule"); this can accelerate book revenue recognition for US tax purposes relative to the timing of billing, creating a deferred tax liability. ERP must track the book-tax timing difference per engagement
- **EU VAT Directive 2006/112/EC** [10]: place-of-supply rules for services; B2B services generally supplied where the customer is established (reverse charge mechanism transfers VAT accounting obligation to the customer); B2C services use supplier location rules or specific rules by service type. ERP tax engine must determine taxability by service type and customer classification
- **IR35 / Off-Payroll Working Rules (UK):** for engagements using personal service company (PSC) contractors in medium/large businesses (rules extended to private sector from April 6, 2021); the ERP must maintain IR35 status determination records (Status Determination Statements) per contractor engagement; IR35-inside determinations require PAYE/NI processing
- **Withholding taxes on cross-border service fees:** many jurisdictions impose withholding on service fees paid to non-resident firms; ERP must capture treaty analysis results and generate withholding tax certificates
- **Transfer pricing for intercompany service allocations:** OECD Transfer Pricing Guidelines require arm's-length pricing for services between related entities; ERP intercompany billing must carry a transfer pricing method code (TNMM, CUP, cost-plus) and documentation linkage

### 3.5 Data Privacy

- **GDPR (Regulation (EU) 2016/679)** [11]: client personnel data, firm employee data, and engagement data containing personal information are subject to GDPR; lawful basis for processing must be documented; data subject rights (access, erasure, portability) must be supported by ERP data architecture; data residency may require EU-hosted ERP instances
- **CCPA/CPRA (California Consumer Privacy Act / California Privacy Rights Act):** applies to employee and client personal data held in ERP systems; opt-out of sale/sharing, deletion rights, and sensitive personal information restrictions apply
- **Attorney-client privilege / legal professional privilege:** data residency for law firm ERP is subject to professional privilege requirements; some jurisdictions require that privileged communications and related matter data remain within the jurisdiction

### 3.6 Financial Reporting

- **ASC 340-40:** capitalization of incremental contract acquisition costs (sales commissions) and contract fulfillment costs that generate or enhance resources to be used in satisfying future performance obligations; amortized systematically over the period of benefit
- **IFRS 9:** ECL (expected credit loss) model for impairment of contract assets (unbilled receivables / WIP) and trade receivables; requires forward-looking probability-weighted loss estimates, not just incurred losses [3]

---

## 4. Key Data Entities

### 4.1 Entity Overview

| Entity | Key Fields | Related Entities |
|---|---|---|
| **Client** | ClientID, Name, Industry, CreditLimit, PreferredCurrency, BillingContact, TaxID | Engagement, Invoice, RateCard |
| **Engagement** | EngagementID, ClientID, SOW_Ref, BillingModel, ContractValue, Currency, StartDate, EndDate, ProfitCenterID, RevRecMethod, Status | Client, Project, Invoice, WIP_Ledger, PerformanceObligation |
| **Project** | ProjectID, EngagementID, Name, Status, BudgetHours, BudgetCost, BudgetRevenue, PM_EmployeeID | Engagement, Task, ResourceAssignment, TimeEntry |
| **Task / WBS** | TaskID, ProjectID, ParentTaskID, PlannedHours, ActualHours, BillingMilestoneFlag | Project, TimeEntry |
| **ResourceAssignment** | AssignmentID, ProjectID, EmployeeID, Role, PlannedHours, StartDate, EndDate | Project, Employee |
| **TimeEntry** | EntryID, EmployeeID, ProjectID, TaskID, EntryDate, Hours, BillableFlag, RateCardID, ApprovalStatus, ApprovedBy, ApprovalTS, Locked | Employee, Project, Task, RateCard, Invoice |
| **ExpenseReport** | ReportID, EmployeeID, ProjectID, ExpenseLines[], TotalAmount, BillableFlag, ApprovalStatus | Employee, Project, Invoice |
| **RateCard** | RateCardID, ClientID (nullable), Role, Currency, Rate, EffectiveFrom, EffectiveTo | Engagement, TimeEntry |
| **Invoice** | InvoiceID, EngagementID, InvoiceDate, DueDate, Lines[], Status, TotalAmount, Currency | Engagement, TimeEntry, ExpenseReport |
| **WIP_Ledger** | WIPID, EngagementID, PeriodEnd, RecognizedRevenue, BilledToDate, WIPBalance (derived), CostIncurred, PctComplete | Engagement |
| **RevenueSchedule** | ScheduleID, EngagementID, PO_ID, RecognitionMethod, TotalAllocatedRevenue, RecognizedToDate | Engagement, PerformanceObligation |
| **PerformanceObligation** | ObligationID, EngagementID, Description, SSP, AllocatedTransactionPrice, RecognitionStart, RecognitionEnd | Engagement, RevenueSchedule |
| **SOW** | SOW_ID, ClientID, EffectiveDate, ExpirationDate, ServiceLines[], NTE_Amount, PaymentTerms, Status, AmendmentVersion | Client, Engagement |
| **Subcontractor** | SubID, VendorID, EngagementID, PO_Number, MaxAmount, MarkupPct, PassThroughFlag, IR35_Status | Engagement, Vendor |

### 4.2 Schema Sketch

```sql
-- Core PSA schema sketch (conceptual SQL-style)

CREATE TABLE Engagement (
  engagement_id     UUID PRIMARY KEY,
  client_id         UUID REFERENCES Client(client_id),
  sow_id            UUID REFERENCES SOW(sow_id),
  billing_model     ENUM('T_AND_M', 'FIXED_FEE', 'MILESTONE', 'RETAINER', 'CAPPED_TM', 'BLENDED'),
  contract_value    DECIMAL(18,2),
  currency          CHAR(3),
  start_date        DATE,
  end_date          DATE,
  profit_center_id  UUID,
  rev_rec_method    ENUM('COST_TO_COST', 'HOURS_EXPENDED', 'MILESTONE', 'POINT_IN_TIME'),
  status            ENUM('PURSUIT', 'ACTIVE', 'COMPLETE', 'ON_HOLD', 'CANCELLED')
);

CREATE TABLE TimeEntry (
  entry_id          UUID PRIMARY KEY,
  employee_id       UUID REFERENCES Employee(employee_id),
  project_id        UUID REFERENCES Project(project_id),
  task_id           UUID REFERENCES Task(task_id),
  entry_date        DATE,
  hours             DECIMAL(6,2) CHECK (hours > 0 AND hours <= 24),
  billable          BOOLEAN,
  rate_card_id      UUID REFERENCES RateCard(rate_card_id),
  approved_by       UUID REFERENCES Employee(employee_id),
  approval_ts       TIMESTAMP,
  locked            BOOLEAN DEFAULT FALSE,  -- set TRUE after invoice generation
  change_reason     TEXT,                   -- DCAA requirement: mandatory on any edit
  original_hours    DECIMAL(6,2)            -- preserved on correction for audit
);

CREATE TABLE WIP_Ledger (
  wip_id            UUID PRIMARY KEY,
  engagement_id     UUID REFERENCES Engagement(engagement_id),
  period_end        DATE,
  recognized_rev    DECIMAL(18,2),
  billed_to_date    DECIMAL(18,2),
  -- wip_balance = recognized_rev - billed_to_date (positive = asset, negative = deferred rev)
  wip_balance       DECIMAL(18,2) GENERATED ALWAYS AS (recognized_rev - billed_to_date) STORED,
  cost_incurred     DECIMAL(18,2),
  pct_complete      DECIMAL(5,2),
  UNIQUE (engagement_id, period_end)
);

CREATE TABLE PerformanceObligation (
  po_id             UUID PRIMARY KEY,
  engagement_id     UUID REFERENCES Engagement(engagement_id),
  description       TEXT,
  ssp               DECIMAL(18,2),          -- standalone selling price used for allocation
  allocated_price   DECIMAL(18,2),          -- after relative SSP allocation across obligations
  recognition_start DATE,
  recognition_end   DATE,
  recognition_method ENUM('COST_TO_COST', 'HOURS_EXPENDED', 'MILESTONE', 'POINT_IN_TIME')
);

CREATE TABLE RateCard (
  rate_card_id      UUID PRIMARY KEY,
  client_id         UUID REFERENCES Client(client_id) NULL,  -- NULL = standard rate card
  role              VARCHAR(100),
  currency          CHAR(3),
  rate              DECIMAL(10,2),
  effective_from    DATE,
  effective_to      DATE,
  version           INTEGER,
  approved_by       UUID REFERENCES Employee(employee_id),
  approved_ts       TIMESTAMP
);

CREATE TABLE AuditLog_TimeEntry (
  log_id            UUID PRIMARY KEY,
  entry_id          UUID REFERENCES TimeEntry(entry_id),
  changed_by        UUID REFERENCES Employee(employee_id),
  changed_ts        TIMESTAMP,
  field_changed     VARCHAR(50),
  old_value         TEXT,
  new_value         TEXT,
  reason_code       VARCHAR(100) NOT NULL,  -- mandatory per DCAA requirements
  supervisor_approved_by UUID REFERENCES Employee(employee_id),
  supervisor_approval_ts TIMESTAMP
);
```

---

## 5. Critical Integrations

| System Category | Specific Products | Integration Purpose | Key Data Flows |
|---|---|---|---|
| **CRM** | Salesforce Sales Cloud / Revenue Cloud; Microsoft Dynamics 365 Sales | Opportunity-to-project handoff; pipeline-weighted resource forecasting | Opportunity fields → Engagement record; probability-weighted resource demand; won-deal trigger creates project |
| **HCM / HRMS** | Workday HCM; SAP SuccessFactors; ADP Workforce Now | Employee calendars, PTO, skills profiles, loaded cost rates by grade | Available-hours calendar feed; skills/certification tags; cost rates for project costing |
| **Time Capture (standalone)** | Replicon; Harvest; Toggl Track | When PSA module lacks mobile app or client prefers incumbent tool | Bi-directional sync: time entries → project cost; approval status sync back |
| **Expense Management** | SAP Concur; Expensify; Brex | Receipt capture, policy enforcement, multi-currency | Approved expense reports → project cost ledger; billable expenses → billing engine |
| **Document / Contract Management** | DocuSign CLM; Ironclad; Microsoft SharePoint | SOW e-signature, change order approvals, contract clause library | Executed SOW → ERP contract record creation; amendment approval triggers budget update |
| **Billing / AR Automation** | Stripe (tech-adjacent firms); Bill.com; Billtrust | Automated invoice delivery, payment collection, cash application | ERP-generated invoice → payment platform; payment confirmation → AR clearing |
| **Revenue Recognition** | Zuora Revenue; Salesforce Revenue Cloud | Complex multi-element arrangements where native ERP rev rec is insufficient | Performance obligation schedules; recognition journals feed back to GL |
| **Business Intelligence** | Microsoft Power BI; Tableau; Looker (via Snowflake / BigQuery) | Project profitability dashboards, utilization heatmaps, partner scorecards | Nightly or real-time data pipeline from PSA/ERP operational DB to analytics layer |
| **Payroll** | ADP Workforce Now; Paychex; Gusto | Direct labor cost feed for project costing | Payroll journal → allocation to projects by timesheet distribution |
| **Tax Engines** | Avalara; Vertex | Service taxability rules by jurisdiction; VAT/GST compliance | Invoice line → tax engine API call → tax amount + jurisdiction code returned |
| **Collaboration** | Microsoft Teams; Slack | Timesheet reminders, approval notifications, project status alerts | Approval workflow notifications; weekly timesheet completion reminders; threshold alerts |
| **Legal Practice Management** | Thomson Reuters Elite 3E; Aderant Expert / Expert Sierra; Clio | Matter management, docketing, trust accounting for law firms | Matter billing data → general ledger; trust account transactions → segregated GL |

---

## 6. KPIs and Metrics

| KPI | Definition | Formula | Typical Target / Context |
|---|---|---|---|
| **Billable Utilization Rate** | % of available hours spent on billable client work | (Billable Hours / Total Available Hours) × 100 | 65–80% for delivery staff; varies by role; partners typically 40–60% |
| **Realization Rate** | % of standard-rate billable value actually invoiced after write-downs and discounts | (Invoiced Amount / (Billable Hours × Standard Rate)) × 100 | 80–90% is healthy; below 70% signals scope creep or aggressive discounting |
| **Collection Rate** | % of invoiced amount collected net of write-offs | (Cash Collected / Total Invoiced) × 100 | Target 95%+; below 90% signals credit or collections process issues |
| **Project Gross Margin** | Project-level profitability | (Revenue Recognized − Direct Project Costs) / Revenue Recognized × 100 | Varies by sector; IT consulting targets 30–45%; law firms higher |
| **Net Revenue per Billable FTE** | Annualized productivity benchmark | Total Net Revenue / Total Billable FTEs | Benchmark against industry peers; trending metric more useful than absolute |
| **WIP Days** | Average days of recognized-but-unbilled revenue outstanding | (Average WIP Balance / Trailing 12-Month Revenue) × 365 | Target < 30 days; high WIP days signal billing process bottlenecks |
| **Days Sales Outstanding (DSO)** | AR aging; average collection period | (AR Balance / Total Revenue) × Days in Period | Target 30–45 days for professional services; higher signals collections issues |
| **Revenue per Employee** | Firm-level efficiency (blended headcount including non-billable) | Total Revenue / Total Headcount (FTEs) | Benchmarked by sub-sector; management consulting typically higher than staffing |
| **Bench Rate** | % of billable FTEs currently unassigned to client-billable work | (Unassigned Billable FTEs / Total Billable FTEs) × 100 | Target 5–10%; high bench rate = excess capacity cost; low bench = burnout risk |
| **Cost Performance Index (CPI)** | EVM metric — budget efficiency | EV / AC (Earned Value / Actual Cost) | CPI > 1.0 = under budget; CPI < 1.0 = over budget |
| **Schedule Performance Index (SPI)** | EVM metric — schedule efficiency | EV / PV (Earned Value / Planned Value) | SPI > 1.0 = ahead of schedule; SPI < 1.0 = behind schedule |
| **Engagement Margin at Completion (MAC)** | Forward-looking profitability for in-flight engagements | (Remaining Revenue − Remaining Cost Estimate) + Margin Earned to Date | Negative MAC triggers mandatory escalation to managing partner |
| **Write-off Rate** | Revenue leakage from WIP and AR write-offs | (Total Write-offs / Total Billable Value) × 100 | Target < 3%; higher signals scope management or billing process failure |

---

## 7. Major ERP Vendors for this Vertical

### 7.1 Oracle NetSuite — SuiteProjects Pro

| Attribute | Detail |
|---|---|
| **Flagship PSA product** | SuiteProjects Pro (formerly OpenAir; sandbox transition January 25, 2025; production transition February 15, 2025) [12] |
| **Key modules** | SuiteProjects Pro (PSA), NetSuite ERP (GL, AR, AP), SuiteBilling, Advanced Revenue Management (ARM), SuiteAnalytics, SuiteTax |
| **Key differentiator** | Native ERP integration eliminates sync overhead between PSA and financials; single data model |
| **Revenue recognition** | NetSuite Advanced Revenue Management (ARM): supports ASC 606/IFRS 15 five-step model; performance obligation templates; automated journal generation |
| **Best fit** | Mid-market professional services firms (IT services, management consulting, digital agencies) already on NetSuite ERP; firms needing unified PSA + financials without enterprise-scale complexity |

### 7.2 Workday — Professional Services Automation + Financial Management

| Attribute | Detail |
|---|---|
| **Flagship PSA product** | Workday Professional Services Automation |
| **Key modules** | Workday PSA, Financial Management, HCM, Services CPQ (configure-price-quote for professional services engagements), Workday Adaptive Planning (FP&A) |
| **Key differentiator** | Unified data model across HCM and PSA/financials — employee records, skills, PTO, cost rates, and project assignments exist in one system with no integration required |
| **Revenue recognition** | Workday Financial Management; rev rec aligned with ASC 606/IFRS 15 |
| **Best fit** | Large enterprises with significant HR complexity; global professional services firms; organizations where HCM-to-PSA data quality is a persistent integration problem |

### 7.3 Certinia (formerly FinancialForce) — Professional Services Cloud + ERP Cloud

| Attribute | Detail |
|---|---|
| **Flagship PSA product** | Professional Services Cloud (PSA) |
| **Other modules** | ERP Cloud (financials, AR, AP), Customer Success Cloud, FP&A; rebranded from FinancialForce to Certinia on May 3, 2023 [13] |
| **Key differentiator** | 100% native Salesforce Platform — same data model, same UI, same security model as Salesforce Sales Cloud; strongest CRM-to-PSA handoff in the market; opportunity fields flow directly to project records without ETL |
| **Revenue recognition** | Certinia ERP Cloud; aligned with ASC 606/IFRS 15 |
| **Best fit** | Salesforce-centric firms; pure-play professional services organizations where Sales Cloud is the system of record; firms that want to avoid a separate ERP integration |

### 7.4 Deltek — Vantagepoint and Costpoint

| Attribute | Detail |
|---|---|
| **Flagship products** | Deltek Vantagepoint (successor to Deltek Vision; Vision active support ended December 31, 2026 with final year-end update in January 2026; Deltek Cloud access for Vision wraps up Q1 2027) [14]; Deltek Costpoint (US government contractors) |
| **Key modules** | Project Management, Resource Planning, Accounting and Financial Management, CRM, Time and Expense, Business Development; Dela AI assistant (Deltek's AI-powered business companion, integrating time entry and project insights in Microsoft Teams and Outlook) |
| **Key differentiator for AEC** | Vantagepoint is purpose-built for architecture, engineering, and environmental consulting; percent-complete billing and multi-phase project structures are native; government contract compliance deeply embedded |
| **Key differentiator for GovCon** | Deltek Costpoint: DCAA-compliant accounting system designed for US government contractors; indirect rate pool structure; CPSR (Contractor Purchasing System Review) support; CAS compliance |
| **Best fit** | A/E firms, government contractors requiring DCAA-adequate accounting; project-centric PS firms with complex multi-phase project structures |

### 7.5 Microsoft Dynamics 365 Project Operations

| Attribute | Detail |
|---|---|
| **Flagship PSA product** | Dynamics 365 Project Operations (successor to D365 Project Service Automation; D365 PSA commercial cloud end of support March 31, 2025; D365 PSA GCC end of support March 31, 2027) [15] |
| **Key modules** | Project Operations (delivery + project accounting), D365 Finance (GL, revenue recognition module), D365 Sales (pipeline), Power BI (analytics), Microsoft Project integration |
| **Key differentiator** | Deep native integration with Microsoft 365 (Teams, SharePoint, Outlook); familiar UI for Microsoft-centric organizations; strong mixed product + services scenarios |
| **Revenue recognition** | D365 Finance revenue recognition module; ASC 606/IFRS 15 support |
| **Best fit** | Microsoft-ecosystem organizations; firms with mixed product and professional services revenue; organizations already running D365 Finance and wanting unified project operations |

### 7.6 Kantata (formerly Mavenlink + Kimble)

| Attribute | Detail |
|---|---|
| **Flagship product** | Kantata (merger of Mavenlink and Kimble announced November 17, 2021; closed December 15, 2021; Kantata brand launched May 16, 2022) [16] |
| **Infrastructure options** | Kantata OX (open-platform architecture, derived from Mavenlink); Kantata SX (Salesforce-native, derived from Kimble PSA) [16] |
| **Key modules** | Project Management, Resource Management, Financial Management, Business Intelligence; Kantata Expertise Engine (AI-powered resource matching and project health scoring) |
| **Key differentiator** | Deep resource management and project health analytics; flexible deployment options (Salesforce-native or standalone); strong mid-market PS positioning |
| **Limitations** | GL/financials capabilities less mature than Certinia ERP or NetSuite; typically paired with an external ERP (NetSuite, Sage Intacct) for full financial management |
| **Best fit** | Mid-market agencies, IT services firms; firms wanting deep Salesforce integration for resource management without committing to the full Certinia ERP stack |

### 7.7 SAP S/4HANA — Project System and Customer Project Management

| Attribute | Detail |
|---|---|
| **PSA modules** | PS (Project System) in S/4HANA Private Edition; Customer Project Management in S/4HANA Cloud Public Edition (capabilities differ — Public Edition has lighter project module depth; Private Edition has full PS module) |
| **Financial integration** | SD (Sales and Distribution) for billing; CO-PA (Profitability Analysis) for engagement margin; FI (Financial Accounting) for GL; MM (Materials Management) for subcontractor procurement |
| **Revenue recognition** | S/4HANA Revenue Accounting and Reporting (RAR): IFRS 15/ASC 606 five-step model; performance obligation management; deferred revenue waterfall |
| **Best fit** | Large global enterprises with complex multi-entity structures; AEC and engineering firms already on SAP; firms requiring deep integration between project billing and SAP MM procurement for subcontractors |

### 7.8 Additional Vendors

- **Sage Intacct:** Project and Resource Management module; Time and Expense; Revenue Recognition; Contracts module; strong position with mid-market PS firms and nonprofits delivering professional services; native multi-entity and multi-currency
- **Acumatica:** Project Accounting module; Time and Expense; Billing; suitable for smaller professional services firms; open API for PSA integrations
- **Thomson Reuters Elite 3E and Aderant Expert / Expert Sierra:** legal-specific ERP for large and mid-sized law firms; matter-centric billing, IOLTA trust accounting compliance, partner profitability; billing data flows to a general ledger module or integrates to a separate financial ERP

Gartner has split its ERP Magic Quadrant into "Cloud ERP for Product-Centric Enterprises" and "Cloud ERP for Service-Centric Enterprises" — specific quadrant positions for individual vendors should be verified against a current Gartner subscription rather than cited from this reference, as positions shift annually.

---

## 8. Implementation Cautions

**1. Revenue recognition method mismatch at go-live**
Firms migrating with in-flight engagements must compute cumulative catch-up amounts for all in-progress contracts before importing to the rev rec module. The catch-up calculation (recognizing the difference between what should have been recognized under ASC 606/IFRS 15 and what was recorded under the prior method) is notoriously error-prone when done manually. Design a migration staging area that independently computes prior-period recognized amounts by engagement, validates against historical invoices and WIP balances, and generates an opening balance journal. Attempt to reconcile to prior-period financial statements before go-live.

**2. Timesheet lock timing vs. billing cycle**
If timesheets are locked too early, project managers cannot correct errors before invoicing. If too late, billing runs before all hours are approved, generating invoices with missing billable hours that must be caught by credit-and-rebill. Design configurable lock windows (e.g., T+5 business days after period close) with an exception workflow allowing finance-approved reopening of locked entries with full audit trail. The lock flag on the TimeEntry table must be enforced at the API layer, not just in UI.

**3. Rate card effective-dating gaps**
When a new rate card takes effect, time entries logged before the cutover must use the old rate; entries after must use the new rate. Many implementations fail to implement effective-dated rate card lookups, defaulting to the current (new) rate for all entries on the next billing run. This retroactively reprices historical hours, corrupting margin data and potentially violating the contractual rate agreed with the client. The rate lookup must join to the RateCard table filtering `effective_from <= entry_date AND (effective_to IS NULL OR effective_to >= entry_date)`.

**4. WIP write-off control failures**
Without enforced approval workflows, project managers write off stale WIP without finance awareness, creating phantom revenue reductions that appear only at quarter-end reconciliation. Enforce dual approval (PM + Finance Controller) as a system-enforced gate, not a policy memo. Write-offs must post to a discrete GL account (segregated from normal revenue reversal) for audit traceability. Month-end close reports should highlight write-offs by project manager as a variance explanation item.

**5. Multi-currency engagement FX complexity**
T&M engagements billed in client currency but costed in home currency create FX exposure at every billing cycle. The system must: (a) recognize revenue at the spot rate on the transaction date (ASC 830 / IAS 21); (b) translate to functional currency for GL posting; (c) capture the translation difference in a designated FX gain/loss account; (d) revalue AR at period-end closing rate with the unrealized gain/loss posted to OCI or P&L per applicable standard. Implementations that bill at a "contract rate" locked at SOW signing but recognize revenue at spot rate will generate persistent unexplained variance if the FX layer is not configured correctly.

**6. SSP allocation on contract modifications**
When a SOW amendment adds a new performance obligation or changes the total transaction price, the system must re-run SSP allocation across all performance obligations (existing and new). Many ERP implementations treat amendments as entirely new contracts, breaking the cumulative accounting trail and preventing accurate cumulative catch-up calculations. Design the amendment workflow to trigger SSP re-allocation on the original contract and post any catch-up adjustment in the current period, not as a prior-period restatement.

**7. Subcontractor pass-through billing timing**
Subcontractor invoices typically arrive 15–45 days after period close. Clients may already have been billed for estimated pass-through amounts. Design a reconciliation workflow: (a) bill estimated pass-through at period close; (b) when actual vendor invoice arrives, create a credit for the estimate and a new charge for the actual amount; (c) if the delta is within a tolerance threshold, optionally include it on the next regular invoice rather than generating a standalone credit/rebill. The three-way match (PO → vendor invoice → client billing) must be traceable in the system.

**8. DCAA timesheet compliance gaps**
Standard ERP audit logs track field-level changes (who, what, when) but frequently do not capture a mandatory "reason for change" field on timesheet corrections. This is a common finding in DCAA pre-award accounting system surveys. The `change_reason` field must be: (a) mandatory on any post-approval edit; (b) stored in an immutable audit table (not as an overwrite on the TimeEntry record); (c) linked to a re-approval by the supervisor. Implement this at the database trigger or application service layer — UI-only enforcement is insufficient because it can be bypassed via API or data import.

**9. Utilization reporting lag**
Real-time utilization reporting requires that timesheet approval be nearly complete. If project managers are slow to approve, utilization reports understate billable hours for the current week and overstate bench. Build a "submitted-but-not-approved" utilization view alongside the "approved" view so resource managers can act on leading indicators before period close. Surface the delta prominently; if submitted utilization is significantly above approved utilization, it signals an approval bottleneck, not a resource availability problem.

**10. Engagement profitability distortion by overhead allocation method**
Firms that allocate overhead as a flat percentage of direct labor cost will misstate profitability on engagements with significant subcontractor pass-through costs. A $5M engagement with $3M in pass-through subcontractor costs and only $500K of direct internal labor will show a low overhead allocation (based on $500K) even though it consumed substantial management and infrastructure resources. Use activity-based cost allocation or explicitly exclude pass-through costs from the overhead allocation base, and establish a separate overhead pool for pass-through-heavy engagement types.

---

## 9. Security and Compliance Depth

*See `core/security.md` for SoD framework, RBAC architecture, and audit trail core requirements. This section covers professional services-specific security controls beyond those baselines.*

### 9.1 Engagement-Level Row Security

Staff should see only the projects they are assigned to. Implement row-level security (RLS) on TimeEntry, Engagement, Invoice, WIP_Ledger, and RevenueSchedule tables. The access predicate is: `employee is a member of the project team OR employee holds a finance/admin role`. RLS must be enforced at the query layer (database-native RLS or ORM-layer filter), not just in the UI, to prevent API-level data leakage.

Partner-confidential engagements (sensitive clients, M&A advisory, litigation support) require explicit access lists — a `EngagementAccessList` table with an allow-list of employee IDs. Default-deny: if an employee is not on the list, they cannot see the engagement record even if they hold a manager role.

### 9.2 Ethical Walls for Law Firms

Matter-level ethical walls (also called "Chinese walls" or information barriers) require explicit access exclusion per matter, not just role-based filtering. The ERP must support:
- An exclusion list per matter: named employees who are explicitly blocked regardless of role
- Override logging: if an authorized administrator removes an exclusion (e.g., conflict waived), the event is logged with justification and cannot be done silently
- Search isolation: full-text search indexes must respect ethical wall restrictions; a blocked employee searching for a client name must not surface restricted matter records in search results

### 9.3 IOLTA and Trust Account Segregation

Client trust funds must be held in segregated bank accounts; the ERP GL must enforce a completely separate chart of accounts for trust funds vs. operating funds. Engineering controls required:
- Journal entry validation: any credit to a trust GL account must have a corresponding trust bank account debit — no commingling with operating accounts at the journal entry validation layer
- Commingling alert: real-time trigger if a trust fund balance would go negative (which implies operating funds were used to cover client funds)
- Regulatory exposure for commingling is severe (bar discipline up to disbarment); treat this as a hard system constraint, not a soft warning

### 9.4 DCAA Timekeeping Security Controls

- **Immutable audit log:** all TimeEntry changes must write to an append-only audit table (AuditLog_TimeEntry); no UPDATE or DELETE on the audit table by any application role
- **Mandatory reason code:** the `change_reason` field must be non-nullable on the audit log record; application service must reject correction requests without a reason code
- **No batch timesheet update for non-administrators:** prevent bulk-update APIs from being called by non-super-admin roles; prevents retroactive timesheet falsification
- **System access log retention:** per FAR 52.215-2, accounting records must be retained for at least 3 years after final payment; some contracts extend this to 6+ years; ERP data retention policies must not auto-purge within these windows
- **Supervisor re-approval requirement:** any post-approval correction must trigger a new approval workflow with the correcting employee's supervisor; system must block the corrected entry from billing until re-approved

### 9.5 Invoice and WIP Tamper Prevention

- Posted invoices must be immutable: no direct edit; correction is reversal-and-reissue (credit memo + new invoice), creating a full audit trail
- Recognized revenue journal entries must be immutable post-period-close: reversal-only correction
- Segregation of duties (see `core/security.md`): the person who approves time ≠ the person who generates invoices ≠ the person who posts revenue recognition journal entries ≠ the person who applies cash receipts
- Digital signature or hash on invoice PDFs: generated at time of approval; hash stored in InvoiceRecord; any tampered PDF will fail hash verification
- WIP write-off approval chain: enforced in the workflow engine, not just by policy; system blocks write-off posting without both PM and Finance Controller approval tokens

### 9.6 Multi-Tenant SaaS Isolation

Professional services firms frequently store confidential client business information — strategic plans, M&A targets, litigation strategies — in project notes, SOW attachments, and deliverable repositories within the ERP.

- Tenant isolation must be enforced at the storage layer and the search index layer: a misconfigured Elasticsearch or vector search index is a common cross-tenant data leakage vector
- Data residency: global firms may require that engagement data for EU clients reside in EU-hosted infrastructure (GDPR Article 46 transfer mechanism); the ERP deployment architecture must support region-specific data residency per tenant or per engagement [11]
- UK GDPR (post-Brexit): data transferred from EU to UK is covered by the EU adequacy decision for the UK; data transferred from UK to non-adequate countries requires a transfer mechanism (SCCs or BCRs)

### 9.7 Privileged Communication Protection (Legal)

- Privileged documents (attorney-client, work-product) must not reside in general project document repositories accessible to non-legal staff or firm administrators
- Enforce document classification tags (e.g., `PRIVILEGE_LEVEL = ATTORNEY_CLIENT`); tagged documents trigger row-level access restrictions
- **Litigation hold workflow:** ERP must support legal holds that freeze deletion of time entries, billing records, emails, and documents for specified matters; hold must be enforceable at the database layer (cannot be overridden by standard retention policy automation); hold release requires explicit authorization with logged justification

---

## See also

- `core/features-core.md` — project accounting, AR, GL fundamentals shared across all verticals
- `core/security.md` — SoD framework, RBAC architecture, and audit trail core requirements
- `core/localization-tax.md` — VAT/GST on services (EU VAT Directive 2006/112/EC), transfer pricing, IR35/Off-Payroll Working Rules
- `verticals/construction-realestate.md` — overlapping project-based billing patterns, AIA percent-complete billing, subcontractor management
- `verticals/government-publicsector.md` — FAR/DCAA compliance depth, 2 CFR 200 Uniform Guidance, CAS standards

---

## Citations & Sources

1. FASB ASC 606 — Revenue from Contracts with Customers (FASB Accounting Standards Codification Topic 606): https://asc.fasb.org/606
2. IASB IFRS 15 — Revenue from Contracts with Customers (final standard issued May 28, 2014; effective January 1, 2018): https://www.ifrs.org/issued-standards/list-of-standards/ifrs-15-revenue-from-contracts-with-customers/
3. IASB IFRS 9 — Financial Instruments (expected credit loss model): https://www.ifrs.org/issued-standards/list-of-standards/ifrs-9-financial-instruments/
4. FAR Part 31 — Contract Cost Principles and Procedures: https://www.acquisition.gov/far/part-31
5. DCAA Contract Audit Manual (CAM) Chapter 5 — Audit of Contractor's Accounting System: https://www.dcaa.mil/Guidance/Audit-Guidance/
6. 48 CFR Part 9903 — Cost Accounting Standards (CAS) Program Requirements (full coverage threshold raised to $100M under FY2026 NDAA): https://www.ecfr.gov/current/title-48/chapter-99/part-9903
7. 2 CFR Part 200 — Uniform Administrative Requirements, Cost Principles, and Audit Requirements for Federal Awards (Uniform Guidance): https://www.ecfr.gov/current/title-2/subtitle-A/chapter-II/part-200
8. ABA Model Rules of Professional Conduct — Rule 1.5 (Fees) and Rule 1.15 (Safekeeping Property): https://www.americanbar.org/groups/professional_responsibility/publications/model_rules_of_professional_conduct/
9. IRC Section 451(b) — Timing of income inclusion / AFS conformity rule: https://www.law.cornell.edu/uscode/text/26/451
10. EU VAT Directive 2006/112/EC — Common system of value added tax (place-of-supply rules for services): https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32006L0112
11. GDPR — Regulation (EU) 2016/679 of the European Parliament and of the Council: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32016R0679
12. Oracle NetSuite — SuiteProjects Pro rebrand announcement (sandbox January 25, 2025; production February 15, 2025): https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/
13. Certinia — FinancialForce rebrands to Certinia (Business Wire press release, May 3, 2023): https://www.businesswire.com/news/home/20230503005029/en/FinancialForce-Rebrands-to-Certinia-The-%E2%80%98Single-Source-of-Certainty%E2%80%99-for-Services-Businesses
14. Deltek — Vision EOL and Vantagepoint upgrade information: https://www.deltek.com/en/blog/whats-happening-with-vision-and-vantagepoint
15. Microsoft — End of Support for Dynamics 365 Project Service Automation (commercial cloud March 31, 2025; GCC March 31, 2027): https://www.microsoft.com/en-us/dynamics-365/blog/it-professional/2024/08/23/end-of-support-dynamics-365-project-service-automation/
16. Kantata — Merger of Mavenlink and Kimble Applications (Kantata brand launched May 16, 2022; OX = Mavenlink open platform; SX = Kimble Salesforce-native): https://www.kantata.com/blog/article/mavenlink-and-kimble-applications-announce-formation-of-kantata-a-global-supplier-of-purpose-built-technology-for-professional-services-organizations
17. IASB IAS 21 — The Effects of Changes in Foreign Exchange Rates: https://www.ifrs.org/issued-standards/list-of-standards/ias-21-the-effects-of-changes-in-foreign-exchange-rates/
18. FASB ASC 340-40 — Other Assets and Deferred Costs — Contracts with Customers: https://asc.fasb.org/340-40
19. Microsoft Dynamics 365 Project Operations documentation: https://learn.microsoft.com/en-us/dynamics365/project-operations/
20. Certinia Professional Services Cloud product documentation: https://certinia.com/products/professional-services-cloud/
21. Gartner Cloud ERP for Service-Centric Enterprises Magic Quadrant: available via Gartner subscription (positions change annually; verify current report for rankings)
