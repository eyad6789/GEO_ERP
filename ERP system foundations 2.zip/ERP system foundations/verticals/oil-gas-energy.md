# ERP for Oil, Gas & Energy

## 1. Overview

Oil, gas, and energy is one of the most demanding ERP verticals in existence. Several structural characteristics make off-the-shelf general-purpose ERP insufficient without significant industry-specific extension.

**Fragmented ownership structures.** Most upstream assets are not 100%-owned. A well is typically held by multiple parties under a Joint Operating Agreement (JOA). The operator drills and operates; non-operators hold working interests ranging from 2% to 60%+. Every cost incurred must be allocated to each owner's decimal interest and billed monthly. This is not a subsidiary ledger — it is a multi-party billing system with contractual, legal, and audit dimensions that general ERP GL modules do not address.

**Production-linked revenue sharing.** Revenue does not flow through a single entity. It is distributed monthly to royalty owners (mineral-interest holders), overriding royalty interest holders, and working-interest owners, each with distinct tax treatment and state-law-governed valuation rules. Revenue accounting is driven by measured volumes multiplied by prices, not by invoices.

**Regulatory intensity across sub-sectors.** Upstream operators face ONRR federal royalty reporting, state severance taxes, and SEC reserve disclosure obligations (FASB ASC 932; SEC Regulation S-K Item 1202). Midstream pipeline operators face PHMSA integrity management under 49 CFR Parts 190–199. Utilities face FERC Uniform System of Accounts, mandatory XBRL filings, and NERC CIP cybersecurity standards. Refineries face EPA GHGRP obligations under 40 CFR Part 98.

**Commodity price volatility.** Oil price swings of 30–50% in a single year are not extraordinary. ERP must integrate tightly with Commodity Trading and Risk Management (CTRM) systems to provide real-time mark-to-market P&L and hedge accounting under FASB ASC 815.

**Three distinct sub-sectors with divergent ERP requirements:**

| Sub-sector | Primary ERP concerns |
|---|---|
| Upstream (E&P) | JIB, DOI, production/revenue accounting, royalty management, land/lease, AFE, SE vs. FC accounting, ARO, reserve-driven DD&A |
| Midstream | Throughput accounting, gathering/processing margins, tariff billing, pipeline integrity records, FERC Form 2 |
| Downstream / Refining | Crude intake scheduling, blend optimization, product inventory valuation (FIFO/LIFO), refinery margin accounting |
| Utilities (power/gas distribution) | FERC Uniform System of Accounts, rate-base asset tracking, NERC CIP, demand-side management, SAIDI/SAIFI |

The core tension: general-purpose ERPs (SAP S/4HANA, Oracle Fusion) cover financials, procurement, and fixed assets, but lack native modules for JIB billing, DOI management, and production volume allocation. This forces hybrid stacks in which a specialized upstream platform (Quorum myQuorum, IFS P2 BOLO, Enertia) acts as the system of record for O&G-specific data, feeding confirmed entries to the ERP GL.

---

## 2. Industry-Specific Modules

### 2.1 Joint Venture / Joint-Interest Accounting (JIB)

Joint Interest Billing is the mechanism by which a well operator recovers its proportionate share of well costs from co-owners. The legal foundation is the Joint Operating Agreement (JOA); the accounting standard is the COPAS Model Form Accounting Procedure. **COPAS MF-8 2022** (Accounting Procedure for Joint Operations, published 2022) is the current model form, superseding the widely used 2005 form; companion interpretation document MFI-58 2022 provides detailed guidance [1]. Verify the latest form at copas.org, as COPAS publishes periodic updates. COPAS MFI-45 covers offshore marine and aircraft cost allocations.

Key data structures the JIB module must manage:

- **Well/facility master**: maps each well to its AFE, producing formation, and responsible operator.
- **Working Interest Owner (WIO)**: each co-owner with their decimal working interest (WI%) by well.
- **Net Revenue Interest (NRI)**: owner's share of gross revenue after royalties; NRI < WI when royalties are owed.
- **COPAS overhead rates**: fixed-rate or percentage-of-direct-cost methods for recovering operator overhead.

JIB billing cycle: operator accumulates direct costs (drilling, workovers, LOE) against the well cost center during the month → allocates to WIO decimals at month-end → generates JIB statement per WIO → issues cash call (if pre-payment model) or collects from billings. Cash calls are common in active drilling programs. Under COPAS MF-8 2022, the operator shall bill each non-operator on or before the last day of the month for the preceding month's joint account.

Non-operator rights include audit rights (typically 24-month look-back) and cure periods for billing errors. ERP must preserve immutable JIB billing history and support adjustment billings.

Suspense account management: revenue or cost amounts held pending resolution of ownership disputes are parked in suspense; ERP must track suspense by well, owner, and reason code, and must support escheatment per NAUPA standards when suspense ages beyond statutory periods.

### 2.2 Division of Interest (DOI) Management

The DOI is the master ownership table of the upstream ERP. For each well or pooled unit, it lists every interest owner with their decimal fraction, interest type, effective date, and end date.

Interest types:
- **Royalty Interest (RI)**: landowner's mineral-rights share; no cost burden; receives revenue only.
- **Overriding Royalty Interest (ORRI)**: carved out of lessee's WI; also revenue-only.
- **Working Interest (WI)**: bears proportionate share of all costs; receives revenue after royalties.
- **Net Profits Interest (NPI)**: receives a share of net profits (revenue minus costs) rather than gross.

The DOI must be version-controlled: interests change with assignments, farmouts, court orders, and lease expirations. Each DOI version has an effective date; production volumes allocated to a given period must use the DOI version in effect during that period. This is a compound-key, time-series data structure — implementing it as a simple flat table with no effective-dating is a common and costly mistake.

DOI drives two downstream processes: (a) royalty distribution (the revenue side — what RI/ORRI owners receive), and (b) JIB billing (the cost side — what WI owners are billed). Any DOI error propagates to both.

### 2.3 Production & Revenue Accounting

Volume capture originates in SCADA or DCS systems (field measurement). Commingled production from multiple wells flowing through a single gathering line must be allocated back to individual wells using allocation factors (ratio of test rates, meter readings, or engineering estimates). The allocation methodology is contractual and must be auditable.

Product streams: crude oil, condensate, natural gas, natural gas liquids (NGLs — ethane C2, propane C3, normal butane C4, isobutane iC4, natural gasoline C5+). Each stream has distinct pricing, measurement units (BBL vs. MCFE vs. MMBTU vs. GAL), and royalty/severance treatment.

Volume adjustments: BS&W (basic sediment and water) deduction from crude volumes; shrinkage from gas processing; measurement ticket (run ticket) volumes for truck-hauled crude.

Revenue calculation per distribution unit:

```
Gross Value = Price × Allocated Volume
Net Payable = Gross Value − Severance Tax − Royalty Deduction − Post-Production Cost Deductions − Transportation
```

Gas imbalance (balancing) accounting: when co-owners take gas in proportions that differ from their ownership interests, gas balancing agreements (GBAs) track cumulative over-takes and under-takes. Settlement may be in-kind (make-up gas) or cash. Recognition follows FASB ASC 932 guidance; ERP must carry imbalance balances per owner per well.

### 2.4 Royalty Management

Royalty management is a distinct sub-module from JIB. It handles:

- **Royalty owner deck**: separate master from WI owner deck; royalty owners receive revenue but bear no costs.
- **Valuation rules by jurisdiction**: US state laws differ significantly on allowable post-production cost deductions from royalties. Texas applies an "at-mouth" vs. "market-value" analysis depending on lease language. Wyoming, Colorado, and North Dakota have different statutory post-production cost allowances. These rules evolve through court decisions and legislation — treat any specific citation as subject to current law.
- **Federal royalties**: ONRR Form ONRR-2014 (Report of Sales and Royalty Remittance) must be filed monthly with payment by the last day of the month following the production month (per 30 CFR § 1218.50) [2]. ERP must calculate and report federal royalties by lease/agreement number.
- **1099-MISC issuance**: royalty payments to individuals require annual 1099-MISC filing with the IRS. ERP must flag payees, accumulate annual amounts, and support IRS e-file.
- **Escheatment/unclaimed property**: suspended royalty payments that age beyond state-specific dormancy periods must be reported and remitted to the state under NAUPA standards. ERP suspense module must support aging and batch escheat processing.

Texas statutory deadlines [3]: initial royalty payment is due within 120 days after the end of the first production month; thereafter, oil royalties are due 60 days after the end of the calendar month in which oil is sold, and gas royalties are due 90 days after the end of the calendar month in which gas is sold (Texas Natural Resources Code § 91.402).

### 2.5 Land & Lease Management

Lease records are the root of the upstream data hierarchy. Key fields: lessor, lessee, legal description (metes-and-bounds or section-township-range), primary term start/end date, held-by-production (HBP) flag, royalty rate, and shut-in royalty terms.

Acreage tracking distinguishes gross acres (total lease) from net acres (operator's working interest fraction). Net acres feed reserve estimates and acquisition economics.

Obligation management: delay rentals (periodic payments to hold unleased acreage), shut-in royalties (payments to keep non-producing leases alive), Pugh clause compliance (releasing depths or acreage not held by production). Missing a delay rental deadline causes automatic lease expiration — ERP alerting and workflow are critical.

GIS integration: lease polygons must be mapped against well locations; Esri ArcGIS is the dominant platform. Area of Mutual Interest (AMI) agreements restrict certain acquisitions and must be monitored.

DOI and production integration: when a well begins producing on a lease, the HBP flag must be automatically set and the lease expiration alert suppressed. ERP must maintain bidirectional links between lease records, DOI records, and production history.

### 2.6 Authorization For Expenditure (AFE)

The AFE is the capital project approval instrument for individual wells, workovers, or facilities. It defines the cost budget and triggers WBS setup in the ERP project system.

AFE lifecycle:
1. **AFE creation**: engineer prepares cost estimate by AFE category (drilling, completion, equipment, contingency).
2. **Approval workflow**: multi-level approval by AFE amount; approval thresholds vary by company policy.
3. **WBS/cost object setup**: approved AFE creates project WBS in SAP PS or cost object in Oracle PPM.
4. **Commitment tracking**: POs issued against the AFE reduce available budget; ERP must track commitments.
5. **Actuals accumulation**: invoices coded to the AFE cost center flow through accounts payable.
6. **Variance reporting**: actuals vs. AFE budget tracked throughout drilling; over-run requires supplemental AFE with fresh approval.
7. **AFE close-out**: capitalize completed well costs to fixed assets or expense per SE/FC method.

For multi-party wells: non-operators must consent to an AFE within an election period (defined in JOA, typically 30 days). Non-consenting parties may be excluded from the wellbore subject to non-consent penalty provisions. ERP must track consent status per WIO per AFE.

### 2.7 Successful-Efforts vs. Full-Cost Accounting Methods

Two permitted US GAAP methods govern capitalization of E&P costs [4]:

| Dimension | Successful Efforts (SE) | Full Cost (FC) |
|---|---|---|
| Standard | FASB ASC 932-310 | SEC Regulation S-X Rule 4-10 (17 CFR § 210.4-10) |
| Exploration costs | Expensed when incurred (G&G, dry holes) | Capitalized into cost pool regardless of outcome |
| Cost pool granularity | Well-level cost tracking by success/failure | Country-level cost pool |
| Ceiling test | Not required; ASC 360 impairment applies | Quarterly ceiling test: pool ≤ PV10 of proved reserves |
| Common users | Large independents (ConocoPhillips, EOG Resources) | Smaller E&Ps; some independent companies |
| IFRS | IFRS 6 applies pre-determination; FC not permitted post-determination | — |

ERP chart-of-accounts design is fundamentally different between SE and FC. Under SE, every exploration cost object must be tagged with outcome (success/failure) to trigger correct expense vs. capitalize treatment. Under FC, all costs accumulate to a single cost pool per country; ceiling test calculations require integration with reserve volumetrics (PV10 from engineering).

IFRS reporters: IFRS 6 Exploration for and Evaluation of Mineral Resources governs the pre-reserve-determination phase (exploration and evaluation assets). Once reserves are determined, costs transition to IAS 16 (PP&E) or IAS 38 (intangibles). Full-cost method is not permitted under IFRS.

### 2.8 Asset Retirement Obligation (ARO) / Decommissioning

Under FASB ASC 410-20 [5]: when an entity acquires an asset with a legal obligation to retire it (plugging a well, removing an offshore platform), it must recognize an ARO liability at fair value at the time the obligation is incurred. The fair value is added to the carrying value of the asset and depreciated. The liability is accreted each period using the credit-adjusted risk-free rate applicable at initial recognition.

Under IAS 37 Provisions (IFRS): decommissioning obligations are recognized when probable and reliably estimable; similar accretion logic applies; discount rate is a pre-tax rate reflecting current market assessments.

ERP requirements:
- Track ARO by asset (well, platform, pipeline segment).
- Store: estimated abandonment cost, inflation-adjusted future cost, discount rate, expected retirement date.
- Calculate annual accretion expense automatically.
- Support revision of estimates (changes in cost estimate or timing generate a new layer with current-period discount rate).
- Generate ARO roll-forward schedules for financial statement footnotes.

Offshore platform decommissioning costs are among the largest single-well liabilities in the industry — North Sea platforms routinely carry AROs in the hundreds of millions. ERP must integrate with engineering cost estimate workflows to update ARO inputs as decommissioning engineering matures.

Specialized software (ENFOS) handles complex ARO liability management and integrates with ERP for balance sheet posting.

### 2.9 Commodity Trading & Risk Management (CTRM/ETRM)

Physical and financial commodity transactions require a dedicated CTRM or ETRM system. ERP handles settlement accounting; CTRM handles the deal book, positions, and risk metrics.

Physical trading: crude oil purchase/sale contracts, gas marketing agreements, NGL fractionation contracts, pipeline capacity nominations.

Financial hedging: NYMEX WTI crude futures, Henry Hub natural gas futures, fixed-for-floating swaps, options, three-way collars. These require FASB ASC 815 (Derivatives and Hedging) treatment [6]. Designated cash-flow hedges defer MTM gains/losses in OCI until the hedged production month; un-designated positions flow through earnings immediately.

ASC 815 documentation must be created at hedge inception — retrospective designation is not permitted. ERP must capture the hedge designation date and link derivative positions to their hedged items (e.g., forecast crude production for specific months).

Risk metrics managed in CTRM: Value at Risk (VaR), delta/gamma/vega (Greeks), Mark-to-Market (MTM) P&L by position and book.

Integration pattern: CTRM holds the authoritative trade book. Daily, it generates GL journal entries (MTM revaluation, OCI movement, settled gains/losses) that post to ERP. Settlement payments flow through ERP accounts payable/receivable against CTRM-confirmed amounts.

CTRM/ETRM platforms: Openlink Endur (ION Group) for crude/gas/NGL/power trading; Allegro Horizon for broad commodity coverage; Brady Triple Point for metals and energy; Molecule Software (cloud-native, API-first). For power and gas utilities: ETRM-focused platforms include Allegro, Brady Energy modules, and Molecule's power desk capabilities.

SAP S/4HANA Commodity Management module provides a subset of CTRM functionality — adequate for companies with moderate hedging programs but typically insufficient for active commodity traders.

### 2.10 Production Sharing Agreements (PSCs/PSAs)

International E&P operations in offshore Africa, Asia, and the Middle East frequently operate under Production Sharing Contracts with host governments. ERP must model each PSC's fiscal terms uniquely:

- **Cost oil / cost recovery**: contractor recovers allowable costs from a designated portion (cost oil cap, typically 40–60% of gross production) before sharing profit oil.
- **Profit oil split**: remaining production after cost recovery is split between contractor and government per agreed percentages, which may be tiered by production rate (R-factor or production-rate tranches).
- **Government lifting**: host government frequently takes its profit oil share in-kind (physical barrels) rather than cash. ERP must track lifting entitlements and reconcile to government-issued production statements.
- **Contractor entitlement accounting**: contractor's P&L is not simply revenue minus costs — it is a function of cost recovery position, profit oil entitlement, and in-kind lifting volumes.

No two PSCs are identical. ERP customization is required per agreement per block, and fiscal scenario testing (sensitivity to production rates, cost recovery positions) must be supported.

---

## 3. Regulatory & Compliance Requirements

### 3.1 US Financial Reporting Standards

| Standard | Content | ERP Impact |
|---|---|---|
| FASB ASC 932 Extractive Activities — Oil and Gas | SE vs. FC method; supplemental reserve disclosures | COA design; well-level cost tracking; reserve integration for disclosures |
| SEC Regulation S-X Rule 4-10 (17 CFR § 210.4-10) | Full-cost method definition; quarterly ceiling test | FC ceiling test calculation engine; PV10 input from reserve system |
| SEC Regulation S-K Item 1202 | Proved reserve disclosures in SEC filings | Reserve data integration to financial reporting |
| FASB ASC 410-20 | Asset retirement obligations | Per-asset ARO tracking; accretion calculations; revision workflow |
| FASB ASC 815 | Derivatives and hedging | Hedge designation at inception; MTM accounting; OCI tracking |
| FASB ASC 606 | Revenue from contracts with customers | Gas marketing contracts; midstream processing agreements |
| FASB ASC 842 | Lease accounting | Equipment leases; surface use agreements; compressor rentals |
| FASB ASC 250 | Accounting changes and error corrections | Method-change disclosure (SE to FC or vice versa); requires SEC approval for public companies |
| IFRS 6 | Exploration for and evaluation of mineral resources | Pre-determination exploration asset classification |
| IAS 37 | Provisions, contingent liabilities and contingent assets | Decommissioning provisions under IFRS |

### 3.2 US Upstream Royalty & Production Reporting

**ONRR Form ONRR-2014 (Report of Sales and Royalty Remittance):** Monthly federal royalty report and payment due by the last day of the month following the production month (per 30 CFR § 1218.50) [2]. Filed electronically with the Office of Natural Resources Revenue. ERP must calculate federal royalties by lease/unit, generate the Form ONRR-2014 data extract, and retain audit history.

State severance tax filings: Texas Comptroller, North Dakota Industrial Commission, Wyoming Department of Revenue, New Mexico Oil Conservation Division. Each state has distinct rate structures, product definitions, and exemption provisions. ERP tax calculation must be parameterized by state/product/formation.

Gas measurement: MCFE (thousand cubic feet equivalent), MMBTU (million British Thermal Units), Btu content measurement. NGL component reporting requires component-by-component volumes and values (ethane, propane, butane fractions).

### 3.3 US Utility Regulatory Reporting (FERC)

FERC-regulated utilities (electric and gas) operate under mandatory chart-of-accounts per FERC Uniform System of Accounts (18 CFR Parts 101 and 201 for electric and gas utilities respectively) [7]. ERP chart-of-accounts cannot be freely designed — it must conform to FERC account numbering.

| Filing | Regulation | Content | Frequency |
|---|---|---|---|
| FERC Form 1 | 18 CFR § 141.1 | Annual Report of Major Electric Utilities; balance sheet, income statement, plant accounts | Annual |
| FERC Form 1-F | 18 CFR § 141.2 | Annual report of nonmajor electric utilities | Annual |
| FERC Form 2 | 18 CFR § 141.11 | Annual report of major natural gas companies | Annual |
| FERC Form 3-Q | 18 CFR § 141.400 | Quarterly financial report (electric and gas) | Quarterly |

**FERC Order No. 898 (effective 1 January 2025):** Amended the FERC Uniform System of Accounts to establish Energy Storage as a new utility function with dedicated accounts for storage assets, O&M, and related software/hardware. Utilities with battery storage or pumped hydro assets were required to adopt the new Energy Storage accounts prospectively from 1 January 2025 and cease use of legacy accounts for storage assets as of that date [8]. This is an ongoing risk — FERC account changes require ERP configuration changes, not just reporting layer updates.

FERC XBRL requirements: FERC annual and quarterly filings (Forms 1, 1-F, 2, 2-A, 3-Q electric, 3-Q natural gas, 6, 60, 714) require XBRL-tagged data. FERC taxonomy Version 2024-04-01 became effective for filings due after March 28, 2024; a 2025 taxonomy update has been published. ERP must support XBRL export or interface to a FERC reporting tool (e.g., Workiva) [9].

**NERC CIP Standards (Bulk Electric System Cybersecurity):**

| Standard | Current Version | Core Requirement |
|---|---|---|
| CIP-003 | -9 (enforcement began April 1, 2026) | Cybersecurity management controls; vendor remote access; supply chain for low-impact BES Cyber Systems |
| CIP-005 | -7 | Electronic security perimeters (ESP); access points (EAP); remote access controls |
| CIP-010 | -4 | Configuration change management; vulnerability assessment programs |
| CIP-013 | -2 | Supply chain risk management for vendor software and hardware |
| CIP-015 | -1 (effective September 2, 2025) | Internal Network Security Monitoring (INSM) within ESPs for high-impact BES Cyber Systems and medium-impact BES Cyber Systems with External Routable Connectivity (ERC); mandated by FERC Order No. 887; compliance phased in separately by September 2, 2028 (high-impact) and September 2, 2030 (medium-impact with ERC) |
| CIP-012 | -2 (effective July 1, 2026) | Protection of real-time operational data exchanged between control centers |

Verify current enforceable version numbers with NERC's standards page (nerc.com) — NERC periodically issues revised versions with extended compliance timelines [10].

### 3.4 Environmental & ESG

**IFRS S2 Climate-related Disclosures [11]:** Effective for annual reporting periods beginning on or after 1 January 2024 for IFRS reporters in adopting jurisdictions (UK, Canada, Australia, New Zealand among early adopters). The ISSB issued targeted amendments to IFRS S2 GHG emissions disclosures on 11 December 2025, addressing Scope 3 Category 15 (financed emissions) application challenges; amendments are effective for reporting periods beginning on or after 1 January 2027, with early application permitted. IFRS S2 requires Scope 1, 2, and 3 GHG disclosures integrated with financial reporting — ERP emissions data must feed sustainability disclosures.

**SEC Climate Disclosure Rule:** The SEC adopted climate disclosure rules in March 2024. The rules were immediately stayed pending litigation; the SEC ended its defense of the rules in March 2025 and as of mid-2026 is proposing to rescind the rules entirely. The rules are not enforceable for US registrants [12].

**EPA Greenhouse Gas Reporting Program (GHGRP) [13]:** 40 CFR Part 98 — facilities (and oil/gas upstream subparts) emitting ≥25,000 MT CO₂e annually must report to EPA via the e-GGRT system. ERP production and fuel-consumption data feeds calculated emissions.

**EU CSRD + ESRS E1:** The Corporate Sustainability Reporting Directive and European Sustainability Reporting Standards (ESRS E1 Climate) apply to EU-listed or large EU-operating O&G companies. ERP must capture material climate data for ESRS double-materiality disclosures.

**EU Methane Regulation (EU) 2024/1787 [14]:** Published in the Official Journal of the EU on 15 July 2024 and entered into force on 4 August 2024. Covers upstream oil and gas exploration and production infrastructure, midstream transmission/distribution, storage, and LNG processing in the EU. Imposes monitoring, reporting, and verification (MRV) requirements for methane emissions; mandates leak detection and repair surveys up to four times per year with repair within 5–15 working days; restricts routine venting and flaring. Flaring ban (except safety/emergency) with ≥99% destruction efficiency became fully applicable on 5 February 2026. Applies to operations supplying gas to or operating within the EU.

**GHG Protocol:** The underlying Scope 1/2/3 emissions accounting framework that IFRS S2, CSRD, and EPA GHGRP all reference.

### 3.5 ISO Standards

| Standard | Topic | O&G Relevance |
|---|---|---|
| ISO 50001:2018 | Energy Management Systems — Requirements with guidance for use | Refineries, compressor stations, processing plants |
| ISO 55001:2024 | Asset Management Systems — Requirements (second edition; cancels and replaces ISO 55001:2014; published July 2024) | Pipeline, refinery, and power plant asset management; organizations may certify against 2014 or 2024 during transition until 2027 |
| ISO 14001:2015 | Environmental Management Systems | E&P operations, refineries, terminals |
| ISO/IEC 27001:2022 | Information Security Management Systems | ERP hosting, cloud deployments, OT/IT interface |

### 3.6 Pipeline & Midstream Safety

US DOT PHMSA (Pipeline and Hazardous Materials Safety Administration): 49 CFR Parts 190–199. Pipeline operators must maintain integrity management plans, conduct inline inspections, and report incidents. ERP integrates with inspection/maintenance records for PHMSA incident reporting data. PHMSA reportability thresholds are defined in 49 CFR Parts 191 and 195.

FERC Certificate of Public Convenience and Necessity: interstate pipelines require FERC certification. Rate schedules and tariffs are FERC-regulated; midstream billing must reference FERC-approved tariff rates.

TSA Security Directives: following the Colonial Pipeline ransomware attack (May 2021), which shut down the primary fuel pipeline serving the US East Coast, TSA issued Security Directive Pipeline-2021-01 and subsequent revisions (designated -02, -02C, -02D; verify the current revision at tsa.dhs.gov). Requirements include: OT/IT network segmentation (ERP must be isolated from pipeline SCADA/OT networks); 12-hour incident reporting to CISA; NIST CSF gap assessment; 24/7 cybersecurity coordinator designation. Natural gas pipeline operators (not subject to NERC CIP) fall under TSA Security Directives — a common scoping confusion.

---

## 4. Key Data Entities

### 4.1 Core Entity List

| Entity | Key Fields |
|---|---|
| Well | API well number (10-digit UWI), well name, spud date, completion date, producing formation, county, state, surface coordinates, wellbore status |
| Lease | Lease number, lessor, lessee, legal description (metes-and-bounds / STR), county, state, primary term start/end, royalty rate, shut-in royalty terms, HBP flag, expiration alert date |
| Working Interest Owner (WIO) | Owner ID, tax ID (EIN/SSN), legal name, address, payment method (ACH/check), owner type (WI/ORRI/RI/NPI), 1099 flag |
| Division of Interest (DOI) Record | Well/unit ID, owner ID, decimal interest, interest type, effective date, end date, DOI version |
| AFE | AFE number, description, well/facility reference, AFE type (drilling/workover/facility), approved amount, cost category breakdown, approval workflow status, supplemental AFE chain |
| Production Record | Well ID, product stream code, production date, gross volume (with unit), BS&W%, shrinkage%, net volume, allocated volume, measurement ticket reference |
| JIB Statement Header | Billing period, operator ID, WIO ID, statement date, total billed amount, cash call amount |
| JIB Statement Line | Statement ID, well/cost center, cost category (drilling/LOE/overhead), gross amount, WI%, WIO share |
| Revenue Distribution Header | Distribution period, distribution run date, total gross value, total royalty deductions, total net paid |
| Revenue Distribution Line | Owner ID, well/unit, product stream, price, allocated volume, gross value, severance tax, royalty, transportation, post-production deductions, net payable |
| Royalty Payment | Owner ID, lease ID, well ID, distribution month, payment type, gross value, deductions, net check amount, check date, 1099-MISC flag |
| ARO Liability | Asset ID, legal obligation description, estimated future abandonment cost, inflation rate, discount rate (credit-adjusted risk-free), accretion factor, expected retirement date, revision history |
| Gas Imbalance | Well/unit ID, owner ID, cumulative over-take volume, cumulative under-take volume, settlement method (in-kind/cash), agreement reference |

### 4.2 Schema Sketch

Entity relationship (simplified ERD notation):

```sql
-- Core upstream hierarchy
WELL (api_well_number PK, lease_id FK, formation, status, coordinates)
  |--< PRODUCTION_RECORD (well_id FK, product_code, prod_date, gross_vol, net_vol)
  |--< ARO_LIABILITY (asset_id PK, well_id FK, estimated_cost, discount_rate, accretion_schedule)
  |--< AFE (afe_number PK, well_id FK, approved_amount, status)
         |--< AFE_COST_LINE (afe_id FK, cost_category, estimated_amount, actual_amount)

LEASE (lease_number PK, lessor, lessee, legal_description, hbp_flag, royalty_rate)
  |--< DOI_RECORD (doi_id PK, lease_id FK, well_id FK, owner_id FK,
                   decimal_interest, interest_type, effective_date, end_date)
         |--< REVENUE_DISTRIBUTION_LINE (doi_id FK, period, gross_value, net_payable)

OWNER (owner_id PK, tax_id, name, owner_type, payment_method)
  <--|  DOI_RECORD.owner_id
  <--|  ROYALTY_PAYMENT.owner_id

JIB_STATEMENT (statement_id PK, period, operator_id, wio_id FK, total_amount)
  |--< JIB_LINE (statement_id FK, well_id FK, cost_category, gross_amt, wi_pct, wio_share)
         -- JIB_LINE references DOI_RECORD for WI% validation

GAS_IMBALANCE (imbalance_id PK, well_id FK, owner_id FK,
               cumulative_overtake_mcf, cumulative_undertake_mcf, settlement_type)
```

Revenue distribution record JSON schema:

```json
{
  "distribution_run_id": "2025-01-RD-0042",
  "period": "2024-12",
  "run_date": "2025-01-28",
  "lines": [
    {
      "owner_id": "OWN-000123",
      "owner_name": "Permian Basin Royalties LLC",
      "well_api": "42-317-20850-0000",
      "product_code": "OIL",
      "price_per_bbl": 72.45,
      "allocated_volume_bbl": 312.8,
      "gross_value_usd": 22660.86,
      "severance_tax_usd": 518.45,
      "royalty_deduction_usd": 0.00,
      "transportation_deduction_usd": 156.40,
      "net_payable_usd": 21986.01,
      "interest_type": "RI",
      "decimal_interest": 0.125000,
      "is_1099_required": true,
      "suspense_flag": false
    }
  ]
}
```

---

## 5. Critical Integrations

### 5.1 Upstream-Specific Point Solutions

| System | Vendor | Function | Integration Pattern |
|---|---|---|---|
| myQuorum (formerly Quorum + Aucerna; merged February 2021) | Quorum Software | Production accounting, JIB, DOI, revenue accounting, land, AFE | REST APIs; GL journal feed to SAP/Oracle; AWS-hosted SaaS |
| P2 BOLO (now IFS Energy & Resources; IFS acquired P2 Energy Solutions November 2022) | IFS | Full upstream accounting suite; cloud-native as of mid-2025 | API-first; native IFS integration |
| Enertia | Enertia Software | Integrated upstream ERP (land, production, revenue, GL) | Direct GL; standalone or integrated |
| IFS iLandMan | IFS | Cloud, tract-based E&P land lifecycle management | Native IFS integration; REST API |
| Peloton LandView | Peloton | GIS-integrated lease and land records; mineral rights, DOI tracking | API to DOI module; ArcGIS integration |
| ARIES | Enverus | Petroleum economics, decline-curve analysis, reserve volumetrics | Reserve data to ERP for DD&A and ceiling test; API/file export |
| Enverus OpenInvoice | Enverus | E-invoicing for O&G field services; integrates with 25+ ERP/accounting systems | AP automation integration |

### 5.2 SCADA / Operational Technology

| System | Vendor | Function |
|---|---|---|
| AVEVA PI System (formerly OSIsoft PI) | AVEVA | Real-time historian for production volumes, pressures, temperatures; feeds production accounting |
| Emerson DeltaV / Fisher ROC | Emerson | Field measurement devices, RTUs, flow computers; SCADA telemetry |
| Quorum Energy Components (EC) SaaS | Quorum | SCADA-to-production accounting middleware on AWS; automates volume capture and allocation |

Integration pattern: SCADA historian → volume extraction layer → production accounting system → ERP GL. The production accounting system (Quorum EC, P2 BOLO, or SAP PRA) is the integration hub between field data and financial records.

### 5.3 CTRM / ETRM Systems

| System | Best For | Architecture |
|---|---|---|
| Openlink Endur (ION Group) | Crude oil, gas, NGL, power, metals trading | On-premise/private cloud; deeply configurable |
| Allegro Horizon | Broad commodity; energy focus | Cloud/hybrid |
| Brady Triple Point | Metals and energy CTRM | On-premise/SaaS |
| Molecule Software | Cloud-native E/CTRM; API-first | SaaS; REST APIs |

Integration pattern: CTRM holds trade book, open positions, MTM valuations. Feeds ERP GL with: (a) daily MTM journals, (b) OCI movement for designated hedges (ASC 815), (c) settled trade P&L, (d) margin call cash movements. ERP accounts receivable and accounts payable handle counterparty settlement.

### 5.4 Reserves Estimation

Ryder Scott, Wright & Company (reserve auditors); PHDWin, ARIES, Harmony (Sproule) for internal reserve modeling. Reserve reports feed ERP in two critical ways:
- **Depletion, Depreciation, and Amortization (DD&A)**: proved developed reserves (unit-of-production method) determine DD&A rate; ERP fixed assets module must receive updated reserve quantities each period.
- **FC ceiling test / SE impairment**: PV10 of proved reserves from reserve report is the ceiling test input for FC companies.

### 5.5 Royalty Disbursement & Owner Relations

Bank/ACH integration for payment runs to royalty owners (often thousands of payees). IRS 1099-MISC e-file integration annually. WEnergy Studio and similar land/royalty portals provide owner self-service access to payment history, reducing inquiry volume.

### 5.6 Environmental / Emissions Reporting

Cority, Intelex, Enviance: EHS/emissions management software; receive ERP production data and fuel-consumption data, calculate GHG emissions per 40 CFR Part 98 methodologies, and submit to EPA e-GGRT. CSRD/IFRS S2 reporting requires the same emissions data flow to sustainability reporting platforms (e.g., Workiva, Enablon).

### 5.7 Financial Markets / Treasury

Bloomberg, Platts (S&P Global Commodity Insights), OPIS: price feeds for daily commodity price reference data used in MTM valuation and revenue distribution pricing. Treasury Management System (TMS) integration for hedge collateral management, margin call cash flows, and counterparty credit exposure.

---

## 6. KPIs & Metrics

### 6.1 E&P Operational KPIs

| KPI | Formula | Notes |
|---|---|---|
| Production Rate | Gross or net BOE/day (or MCFE/day) | Tracked by well, field, company; gross before royalties, net after |
| Lease Operating Expense (LOE) per BOE | LOE ($) ÷ Net production (BOE) | Benchmark varies enormously by basin and commodity price; do not cite basin-specific figures as absolutes without current sourcing |
| Finding & Development Cost (F&D) | Capital expenditures ÷ Net proved reserve additions ($/BOE) | Measures capital efficiency of reserve replacement |
| Reserve Replacement Ratio (RRR) | Proved reserve additions ÷ Annual production | >100% = reserve growth; <100% = reserve depletion |
| Reserve Life Index (RLI) | Proved reserves (BOE) ÷ Annual production rate (BOE/year) | Years of remaining production at current rate |
| PV10 (Standardized Measure) | NPV of proved reserve cash flows at 10% discount rate | SEC standard reserve valuation metric (per Regulation S-K Item 1202) |
| Netback per BOE | Revenue/BOE − royalties/BOE − operating costs/BOE − transportation/BOE | Wellhead profitability per barrel |
| Spud-to-Sales Cycle Time | Days from spud date to first production date | Measure of drilling/completion program efficiency |

### 6.2 JIB & Revenue Accounting KPIs

| KPI | Formula / Target | Notes |
|---|---|---|
| JIB Billing Cycle Time | Days from month-end to JIB statement issuance | Industry target: ≤20–25 days post month-end close |
| JIB Dispute Rate | # disputed JIB line items ÷ total JIB line items | High rate signals DOI errors or cost allocation methodology gaps |
| Royalty Payment Timeliness | % payments made within statutory deadline | Texas: 60 days (oil) / 90 days (gas) after production month-end (Texas Natural Resources Code § 91.402); varies by state |
| Suspense Balance | Total USD value of suspended royalty/revenue payments | High balance signals DOI deficiencies or title curative backlog |
| Revenue Distribution Accuracy | % distribution lines passing automated reconciliation before payment run | Target: 100% reconcile before any payments released |

### 6.3 Midstream / Pipeline KPIs

| KPI | Formula | Notes |
|---|---|---|
| Throughput | MMCF/day or MBBL/day | By pipeline segment; aggregated to system |
| System Uptime / Availability | Operational hours ÷ Total hours × 100% | Planned vs. unplanned downtime tracked separately |
| Gathering & Processing (G&P) Margin | G&P Revenue − Direct G&P Operating Costs | Excludes corporate overhead; per-plant or system |
| Pipeline Integrity Incidents | PHMSA-reportable events ÷ Total pipeline miles × 1,000 | Lower = better; PHMSA reportability threshold defined in 49 CFR Parts 191/195 |
| Compression Efficiency | Horsepower-hours ÷ MMCF transported | Lower = more efficient compression |

### 6.4 Utility / Power KPIs

| KPI | Formula | Notes |
|---|---|---|
| Revenue per MWh | Total utility revenue ÷ MWh generated or distributed | — |
| Heat Rate | BTU input ÷ kWh output | Lower = higher thermal efficiency; typical combined-cycle gas turbine range varies by technology generation |
| SAIDI (System Average Interruption Duration Index) | Total duration of customer interruptions (min) ÷ Total customers served | NERC reliability metric; lower = more reliable |
| SAIFI (System Average Interruption Frequency Index) | Total number of customer interruptions ÷ Total customers served | Lower = fewer outages |
| O&M Cost per Customer | Total O&M expense ÷ Number of customers served | Regulatory rate case metric |
| Rate Base | Total regulated assets eligible for return allowance | Drives allowed revenue in rate cases; FERC-defined asset categories |

### 6.5 ESG / Emissions KPIs

| KPI | Formula | Significance |
|---|---|---|
| GHG Intensity | MT CO₂e ÷ MBOE produced | Declining trend is target for IFRS S2 / CSRD reporting |
| Methane Intensity | CH₄ emissions (MT) ÷ Gas production (MMCF) | API Methane Performance Standard; EU Methane Regulation (EU) 2024/1787 threshold |
| Flaring Rate | MCF flared ÷ Gross gas produced × 100% | State flaring regulations; World Bank Zero Routine Flaring standard; EU Methane Regulation flaring ban effective 5 February 2026 |
| Water Recycling Rate | Volume produced water recycled ÷ Total produced water generated × 100% | Permian Basin and Appalachian focus; regulatory scrutiny increasing |
| TRIR (Total Recordable Incident Rate) | (Recordable incidents × 200,000) ÷ Employee-hours worked | OSHA standard rate; ERP HR/HSE integration required |

---

## 7. Major ERP Vendors for this Vertical

### 7.1 SAP S/4HANA (IS-Oil, JVA, PRA Modules)

SAP's Industry Solution for Oil & Gas (IS-Oil) is now restructured as capabilities within S/4HANA rather than a separate product layer. Core O&G-specific modules:

- **Production Revenue Accounting (PRA)**: volume allocation, product valuation, owner statements, revenue distribution — the ERP-native alternative to standalone production accounting systems.
- **Joint Venture Accounting (JVA)**: JIB billing, COPAS overhead recovery, cash calls, non-operator billing, equity method accounting for JV investments.
- **Hydrocarbon Product Management (HPM)**: bulk material (crude/gas/NGL) inventory management, measurement, and valuation.
- **SAP PS (Project System)**: AFE implementation — WBS elements, commitment tracking, budget monitoring.
- **SAP PM (Plant Maintenance)**: well and equipment maintenance; PHMSA integrity management records.
- **SAP RE-FX (Flexible Real Estate)**: lease management for surface use agreements and land holdings.
- **SAP Commodity Management**: CTRM-lite for companies with moderate hedging programs; not sufficient for active crude traders.
- **SAP FI/CO, GRC**: core financials, controlling, and Governance/Risk/Compliance.

Strengths: integrated landscape eliminates inter-system reconciliation when PRA/JVA are implemented; best for large integrated companies with sufficient implementation budget.

Cautions: PRA and JVA implementations are among the most complex in the SAP portfolio; significant configuration effort. SAP ECC mainstream maintenance ends 2027, extended to 2030; IS-Oil customers on ECC face S/4HANA migration urgency and must verify that all PRA/JVA functional equivalents are available in S/4HANA before committing to a migration timeline.

### 7.2 Oracle (Fusion Cloud ERP + JD Edwards EnterpriseOne)

Oracle Fusion Cloud ERP provides strong financials (Revenue Management Cloud for ASC 606/932 compliance, Fixed Assets for ARO, Project Portfolio Management for AFE-equivalent). Oracle does not have a native equivalent of SAP PRA/JVA — upstream E&P deployments use Oracle as the corporate ERP with Quorum or IFS handling production/revenue accounting.

Oracle JD Edwards (JDE) EnterpriseOne is popular in mid-market E&P and midstream; it has Upstream Oil and Gas modules, Land Management, and Well Billing capabilities; on-premise legacy with expanding cloud options.

### 7.3 Quorum Software (myQuorum)

Purpose-built upstream O&G cloud platform. Quorum Software merged with Aucerna in February 2021 and simultaneously agreed to acquire TietoEVRY's Oil and Gas software business, consolidating the combined portfolio into the myQuorum suite [15]. AWS-hosted; REST API ecosystem.

Products: myQuorum Accounting (JIB/DOI/revenue distribution), myQuorum Land (lease management, AMI tracking), Quorum Energy Components (EC) upstream hydrocarbon accounting and volume allocation, EC Midstream (gathering and processing accounting).

Positioning: for mid-market operators, myQuorum may serve as both the O&G system of record and the ERP, reducing the need for a separate enterprise ERP. For large operators, myQuorum feeds the corporate SAP or Oracle GL.

### 7.4 IFS Cloud

IFS has deep upstream E&P and asset-intensive operations coverage. IFS acquired P2 Energy Solutions in November 2022; P2 BOLO (cloud-native release reported mid-2025) integrates with the IFS ecosystem [16].

Modules: IFS iLandMan (cloud, tract-based E&P land lifecycle), IFS Oil & Gas Accounting (JIB/DOI/revenue), IFS Production Operations (volume allocation, SCADA integration, regulatory reporting), IFS Asset Management (ISO 55001-aligned), IFS ERP (financials, SCM, project management).

### 7.5 Enertia Software

Niche integrated upstream ERP covering production accounting, land, revenue/royalty, and G/L. Windows-based; strong adoption among mid-market Permian Basin operators. Lower market share than Quorum or IFS but sticky in its segment.

### 7.6 Microsoft Dynamics 365 + ISV Extensions

Dynamics 365 Finance and Supply Chain Management is not natively O&G-capable. It is used primarily by oilfield services companies (not E&P operators) with ISV add-ons (PakEnergy, VNET Petro for royalty management). Not recommended as the system of record for JIB, DOI, or production accounting without significant ISV extension.

### 7.7 Vendor Comparison

| Vendor | Best For | Native JIB/DOI | Native Production Accounting | Native Land/Lease | Cloud Maturity |
|---|---|---|---|---|---|
| SAP S/4HANA (IS-Oil/PRA/JVA) | Large integrated companies; global operations | Yes (JVA) | Yes (PRA/HPM) | Partial (RE-FX) | Maturing (S/4HANA); ECC exits 2030 |
| Oracle Fusion Cloud ERP | Large companies; Oracle-standardized shops | No native | No native (use Quorum/IFS) | No native | High cloud maturity |
| Oracle JDE EnterpriseOne | Mid-market E&P, midstream | Partial | Yes | Yes | Moderate |
| Quorum myQuorum | Mid-market E&P operators; AWS-native | Yes | Yes | Yes | High (AWS SaaS) |
| IFS Cloud + P2 BOLO | International E&P; asset-intensive | Yes | Yes (P2 BOLO) | Yes (iLandMan) | High |
| Enertia | Small/mid Permian Basin E&P | Yes | Yes | Yes | Low (Windows-based) |
| Microsoft D365 + ISV | Oilfield services | Via ISV only | Via ISV only | Via ISV only | High (Azure) |

---

## 8. Implementation Cautions

### 8.1 DOI and Royalty Data Quality

DOI title chains in legacy portfolios are frequently incomplete, disputed, or contain gaps from historical assignments and court orders. Implementing an ERP and DOI module against uncleaned title data produces incorrect JIB billings and royalty payments — both carry legal liability. Royalty underpayments can trigger statutory penalties and interest; JIB overbillings trigger dispute cycles that delay cash collection.

Mitigation: pre-implementation title runsheet review for material wells; establish a suspense management strategy (rules for when to hold vs. pay) before go-live; do not assume legacy system DOI data is correct.

### 8.2 Production Volume Reconciliation Gap

Production is measured at multiple points: wellhead, lease separator, pipeline meter, plant inlet, and plant tailgate. Each measurement point has inherent uncertainty (±0.5–2% for fiscal meters). If the ERP and the production accounting system use different measurement points as the "book volume," financial statements and production reports will disagree.

Define in the system design document: (a) which measurement point is the authoritative book volume for each product stream; (b) how measurement disputes are resolved and who has adjustment authority; (c) reconciliation tolerance thresholds. Failure to resolve this before go-live is one of the most common causes of post-implementation month-end close delays in O&G.

### 8.3 SE vs. FC Method Lock-In

Chart-of-accounts and cost-object structure decisions made at ERP implementation lock in the accounting method. Under SE, the COA must support well-level cost tracking tagged by exploration outcome (success = capitalize, dry hole = expense). Under FC, costs accumulate to a country cost pool. If the wrong structure is configured, reclassification requires a chart-of-accounts redesign and historical data migration.

Switching accounting methods after the fact requires SEC approval (8-K disclosure for public companies), a change-in-accounting-principle disclosure under FASB ASC 250, and a full COA restructure. Design this correctly at the start.

### 8.4 ASC 815 Hedge Designation Timing

ASC 815 does not permit retrospective hedge designation. The hedge relationship must be formally documented — including the hedged item (specific forecast production volumes), hedging instrument (specific derivative), risk being hedged, and effectiveness testing method — before or at trade inception.

ERP and CTRM must integrate to capture hedge designation at trade entry. If hedge documentation is missing or post-dated, the derivative fails hedge accounting and its full MTM value flows through current earnings — potentially creating earnings volatility of hundreds of millions of dollars for large hedging programs.

### 8.5 Regulatory Filing Timing Dependencies

The production month close triggers a cascade of regulatory and contractual deadlines:
- ONRR Form ONRR-2014 payment: due by the last day of the month following the production month (30 CFR § 1218.50).
- State severance tax: filing and payment deadlines vary by state (typically within 30–60 days of production month-end).
- JIB billing: industry convention (COPAS MF-8 2022) targets the last day of the month following production.
- Royalty payment: Texas oil royalties due 60 days after production month-end; gas royalties due 90 days (Texas Natural Resources Code § 91.402).

ERP close-cycle design must accommodate faster close than in other industries. Any month-end bottleneck (production volume reconciliation, pricing determination, DOI dispute) delays the entire cascade. Close process mapping and bottleneck analysis are required pre-go-live.

### 8.6 FERC Uniform System of Accounts Constraints

Regulated utilities cannot freely design their chart of accounts. The FERC Uniform System of Accounts (18 CFR Parts 101 and 201) mandates specific account numbers and definitions. Any ERP implementation for a FERC-regulated utility must map to FERC account numbering as the primary COA, not as a derived reporting view.

FERC Order No. 898 (effective 1 January 2025) added new Energy Storage accounts. Utilities with battery storage or pumped hydro assets that had not completed ERP chart-of-accounts configuration by this date were out of compliance. This is an ongoing risk: FERC account changes require ERP configuration changes, not just reporting layer updates.

### 8.7 International PSC Complexity

No two Production Sharing Contracts are identical. ERP implementation teams that attempt to use a single generic PSC template for multiple international blocks routinely miscompute contractor entitlement, cost recovery positions, and government lifting volumes — leading to incorrect host-government royalty payments and potential contract violations.

Each PSC requires its own fiscal model, tested against multiple production-rate and cost-recovery scenarios before go-live. Build in a PSC configuration review with legal and commercial teams for every block.

### 8.8 ARO Estimate Volatility

ARO liability is highly sensitive to two inputs: the credit-adjusted risk-free discount rate (tied to the entity's credit spread plus the risk-free rate at initial recognition) and the engineering cost estimate. The sharp interest rate increases from 2022 onward created significant ARO balance sheet movement for companies with large abandonment liabilities. ERP must support: bulk ARO re-estimation (when engineering updates cost estimates for multiple assets simultaneously), layer-by-layer accretion calculation, and roll-forward reporting for financial statement footnotes. Manual spreadsheet-based ARO tracking is a control weakness — purpose-built ARO software (ENFOS) or a well-designed ERP fixed-asset sub-module is required.

### 8.9 Big-Bang Go-Live Risk in JIB/Revenue Context

An upstream ERP go-live without a parallel run of JIB billing and revenue distribution is a significant risk. JIB billing errors result in overbilling non-operators who are contractually entitled to dispute and withhold payment. Revenue distribution errors result in royalty owner underpayments that trigger state statutory penalties.

Industry pattern: implementations that skip parallel testing of JIB and revenue distribution against legacy system outputs and then go live with incorrect owner-statement logic face months of manual corrections, owner complaints, and potential class-action royalty litigation. Parallel run of at least two production months is the minimum standard before JIB and royalty distribution go-live.

---

## 9. Security & Compliance Depth

### 9.1 Cross-Reference

See `core/security.md` for SoD framework, access control design, audit logging baselines, and general ERP security architecture applicable to all verticals.

### 9.2 NERC CIP (Electric Utilities)

NERC Critical Infrastructure Protection standards apply to the Bulk Electric System (BES). Any ERP system that connects to BES Cyber Systems (energy management systems, SCADA, relay protection) must be assessed for NERC CIP scope.

| Standard | Current Version | Core Requirement |
|---|---|---|
| CIP-003 | -9 (enforcement April 1, 2026) | Cybersecurity management controls; vendor remote access; supply chain for low-impact BES Cyber Systems |
| CIP-005 | -7 | Electronic Security Perimeters (ESP); access points (EAP); remote access controls |
| CIP-010 | -4 | Configuration change management; vulnerability assessment programs |
| CIP-012 | -2 (effective July 1, 2026) | Protection of real-time operational data between control centers |
| CIP-013 | -2 | Supply chain risk management for vendor software and hardware |
| CIP-015 | -1 (effective September 2, 2025) | Internal Network Security Monitoring (INSM) within ESPs for high-impact BES Cyber Systems and medium-impact BES Cyber Systems with External Routable Connectivity (ERC); mandated per FERC Order No. 887; compliance phased in separately by September 2, 2028 (high-impact) and September 2, 2030 (medium-impact with ERC) |

Verify current enforceable version numbers with NERC's standards page (nerc.com) — NERC periodically retires and replaces versions with extended compliance timelines [10].

ERP change management processes must be aligned with CIP-010 configuration change controls for any systems within or connecting to CIP scope. Vendor access to ERP systems that interface with BES operations falls under CIP-013 supply chain review requirements.

### 9.3 TSA Security Directives (Pipeline Operators)

Following the Colonial Pipeline ransomware attack (May 2021), TSA issued Security Directive Pipeline-2021-01 and subsequent revisions (subsequently -02, -02C, -02D; verify current revision at tsa.dhs.gov). Key ERP-relevant requirements:

- **OT/IT network segmentation**: ERP (IT domain) must be segmented from pipeline SCADA and Operational Technology (OT) networks. Direct connectivity between ERP and SCADA is prohibited without approved compensating controls.
- **12-hour incident reporting**: cybersecurity incidents must be reported to CISA within 12 hours. ERP systems that are compromised must be included in incident scope assessments.
- **NIST CSF gap assessment**: operators must assess cybersecurity posture against NIST Cybersecurity Framework. ERP systems are in scope.
- **Cybersecurity coordinator**: 24/7 point of contact designation required.

Natural gas pipeline operators (not BES, therefore not under NERC CIP) are under TSA Security Directives rather than NERC CIP. This is a common scoping confusion.

### 9.4 Oil & Gas Data Classification

| Data Category | Classification | Risk |
|---|---|---|
| Reserve estimates and volumetrics | Highly confidential / material non-public information (MNPI) for public companies | Insider trading; SEC disclosure violation |
| Commodity trading positions | Market-sensitive MNPI | Insider trading risk; ERP/CTRM access tightly controlled |
| DOI / royalty owner PII | Personal data (EIN, SSN, address, payment details) | GDPR (EU-resident owners), CCPA (CA-resident owners), IRS data protection |
| PSC fiscal terms and government lifting data | Contractually confidential | Host-government confidentiality provisions; competitive intelligence |
| ONRR / FERC regulatory filings | Regulatory record | Tamper-evident audit trail required; retention per federal records schedules |
| Reservoir and seismic data | Highly confidential | Competitive value; data residency laws in some jurisdictions |

### 9.5 Segregation of Duties in O&G Context

Standard ERP SoD must be extended to cover O&G-specific workflows:

| Process | SoD Requirement |
|---|---|
| Revenue accounting | Volume entry ≠ pricing setup ≠ owner payment approval ≠ payment release |
| JIB billing | Cost recording ≠ JIB statement preparation ≠ JIB payment authorization ≠ cash call release |
| AFE process | AFE initiator ≠ approver ≠ PO issuer ≠ invoice approver ≠ asset capitalization |
| Royalty payment | DOI maintenance ≠ payment calculation ≠ payment check run ≠ payment release |
| DOI management | DOI entry ≠ DOI approval ≠ revenue distribution run |
| CTRM trade entry | Trade entry ≠ trade confirmation ≠ settlement approval ≠ GL posting |

DOI maintenance is a particularly sensitive SoD point: an individual who can modify a DOI record and also initiate a payment run could redirect royalty payments.

### 9.6 ISO/IEC 27001:2022 and International Data Residency

International E&P operations: reservoir seismic data, production data, and government contract data may be subject to host-country data residency requirements. Common jurisdictions with data residency requirements affecting O&G ERP deployments include countries in MENA, Nigeria, and Indonesia.

Cloud ERP deployment: verify the cloud provider's data center region for each country of operation. Many cloud ERP vendors offer region-specific tenants — confirm data processing and storage location in contracts. Failure to comply can result in contract violations with host governments and potential license revocations.

ISO/IEC 27001:2022 certification of cloud ERP vendors should be a baseline vendor qualification criterion for international deployments.

---

## See also

- `core/features-core.md` — general ERP module architecture applicable across all verticals
- `core/security.md` — SoD frameworks, audit logging, access control design
- `verticals/construction-realestate.md` — project costing and capital authorization parallels to AFE; JV accounting in real estate
- `verticals/financial-services.md` — hedge accounting (ASC 815), commodity trading parallels, CTRM integration patterns
- `verticals/aerospace-defense.md` — asset-intensive operations, government contracting, long-cycle capital project accounting

---

## Citations & Sources

1. COPAS (Council of Petroleum Accountants Societies) — MF-8 2022 Accounting Procedure for Joint Operations; MFI-58 2022 Model Form Accounting Procedure Interpretation: https://copas.org
2. 30 CFR § 1218.50 — Timing of ONRR royalty payment for oil and gas: https://www.law.cornell.edu/cfr/text/30/1218.50
3. Texas Natural Resources Code § 91.402 — Royalty payment timing requirements: https://codes.findlaw.com/tx/natural-resources-code/nat-res-sect-91-402/
4. FASB ASC 932 Extractive Activities — Oil and Gas (SE method); SEC Regulation S-X Rule 4-10 (17 CFR § 210.4-10) (FC method): https://www.law.cornell.edu/cfr/text/17/210.4-10
5. FASB ASC 410-20 — Asset Retirement Obligations: https://asc.fasb.org
6. FASB ASC 815 — Derivatives and Hedging: https://asc.fasb.org
7. FERC Uniform System of Accounts — 18 CFR Parts 101 (electric) and 201 (gas): https://www.ferc.gov
8. FERC Order No. 898 — Accounting and Reporting Treatment of Certain Renewable Energy Assets (Energy Storage accounts effective 1 January 2025): https://www.ferc.gov/media/order-no-898
9. FERC XBRL Taxonomy Version 2024-04-01 (effective for filings due after March 28, 2024): https://xbrl.us/xbrl-taxonomy/2024-eforms/
10. NERC CIP Standards (current enforceable versions): https://www.nerc.com/pa/Stand/Pages/CIPStandards.aspx
11. IFRS S2 Climate-related Disclosures (effective 1 January 2024); ISSB Amendments to IFRS S2 GHG disclosures issued 11 December 2025 (effective 1 January 2027): https://www.ifrs.org/issued-standards/ifrs-sustainability-standards-navigator/ifrs-s2-climate-related-disclosures/
12. SEC Climate Disclosure Rule — proposed rescission as of 2026; SEC press release on rescission proposal: https://www.sec.gov/newsroom/press-releases/2026-49-sec-proposes-rescission-climate-related-disclosure-rules
13. EPA Greenhouse Gas Reporting Program — 40 CFR Part 98: https://www.epa.gov/ghgreporting
14. EU Methane Regulation (EU) 2024/1787 — Official Journal of the European Union, 15 July 2024: https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=OJ%3AL_202401787
15. Quorum Software / Aucerna merger announcement, February 15, 2021: https://www.businesswire.com/news/home/20210215005048/en/Thoma-Bravo-Owned-Quorum-Software-and-Aucerna-to-Merge-and-Acquire-TietoEVRYs-Oil-and-Gas-Software-Business
16. IFS acquisition of P2 Energy Solutions (November 2022): https://www.ifs.com/solutions/energy-and-resources-software/p2-energy-solutions-is-now-ifs
17. ISO 55001:2024 Asset Management — Asset management system — Requirements (second edition, published July 2024; cancels and replaces ISO 55001:2014): https://www.iso.org/obp/ui/en/#!iso:std:83054:en
18. ISO 50001:2018 Energy Management Systems: https://www.iso.org/standard/69426.html
19. ISO/IEC 27001:2022 Information Security Management Systems: https://www.iso.org/standard/82875.html
20. PHMSA Pipeline Safety Regulations — 49 CFR Parts 190–199: https://www.phmsa.dot.gov
21. ONRR Minerals Revenue Reporter Handbook (royalty reporting procedures): https://onrr.gov
22. SAP S/4HANA Oil & Gas (IS-Oil, PRA, JVA): https://community.sap.com
23. Enverus (ARIES, OpenInvoice): https://www.enverus.com
