# ERP for Schools (K-12)

K-12 schools split into two architecturally distinct sub-verticals that cannot share a single ERP configuration: **public school districts** (government entities operating under GASB, state funding formulas, and federal program compliance) and **private schools** (nonprofit or for-profit entities operating under FASB or commercial GAAP, tuition-revenue-driven, with advancement and enrollment management requirements absent from public schools). A single district may operate charter schools that straddle both frameworks depending on state law and organizational structure. This file addresses each sub-vertical in dedicated sections before covering shared data entities, integrations, and security.

---

## The Public/Private Bifurcation

| Dimension | Public School Districts | Private Schools |
|---|---|---|
| Governing accounting standard | GASB Statement No. 34 (1999) + state-specific GAAP | FASB ASC 958 (nonprofit) or commercial GAAP (for-profit) |
| Primary revenue source | State per-pupil formula funding + local property tax + federal grants | Tuition & fees + development gifts + endowment distributions |
| Net asset / fund equity model | Governmental fund balance (GASB 54 five-category model) | Two net asset classes per FASB ASU 2016-14 (nonprofit) |
| Federal compliance driver | ESEA/ESSA, IDEA, 2 CFR Part 200, E-rate, Child Nutrition | ESSA equitable services, IRS Form 990, state voucher regulations |
| Student financial aid | None at the district level (federal aid is Title I/IDEA, not student aid) | Need/merit-based institutional financial aid; SSS by NAIS need analysis |
| Tuition billing | Not applicable (public schools are tuition-free) | Core revenue module; enrollment contracts, payment plans, deferred revenue |
| Fund accounting model | Governmental fund types (GASB 54) with modified accrual | Net asset class-based fund accounting (FASB) or none (for-profit) |
| Budget control | Legally adopted budget; appropriation control by fund | Board-approved budget; no statutory expenditure limits |
| Payroll complexity driver | Step-and-lane salary schedules; position control; TRS defined-benefit pension | Faculty contracts; housing allowances (faith-based); fewer certified staff distinctions |
| Annual federal reporting | ESSA consolidated report, IDEA child count, SEFA, IPEDS (if applicable) | IRS Form 990; equitable services consultation documentation |
| Audit requirement | Single Audit if ≥ $1M federal expenditures (2 CFR § 200.501, effective October 1, 2024) | Single Audit only if receiving federal pass-through funds ≥ $1M |
| SIS model | Attendance-driven SIS (ADA/ADM for funding); state longitudinal data reporting | Enrollment/admissions-driven SIS; no mandatory state reporting in most jurisdictions |

---

# Part I — Public School Districts

## 1. Overview

A public school district (Local Education Agency, or LEA) is a governmental entity. Its ERP must enforce fund accounting, position-based budgeting, multi-fund financial statements, and a compliance stack spanning at least three federal regulatory bodies (US Department of Education, USDA Food and Nutrition Service, FCC/USAC) plus the state education agency. The defining architectural pressure is that **revenue is not earned through transactions — it is determined by formulas applied to attendance counts, poverty proxies, and child characteristics**. The ERP must therefore be deeply integrated with the SIS to capture the attendance and enrollment data that drives funding.

### Fund Type Taxonomy for School Districts

School districts use a subset of the GASB governmental fund structure:

| Fund Type | Purpose | ERP Notes |
|---|---|---|
| General Fund | Primary operating fund — instruction, administration, operations & maintenance | All unrestricted state/local revenues; largest fund; GASB 54 fund balance tracked here |
| Special Revenue Funds | Legally restricted revenues — Title I, IDEA Part B, state categorical grants | One fund per major grant program is best practice; prevents co-mingling |
| Debt Service Fund | Principal and interest payments on long-term debt (bonds) | Required when district has outstanding general obligation bonds |
| Capital Projects Fund | Bond proceeds and state capital grants for construction and major equipment | Multi-year; encumbrances survive fiscal year-end |
| Permanent Fund | Principal preserved; earnings expendable for specified purpose (rare in K-12) | Uncommon; used by some districts with donated principal funds |
| Enterprise Funds | Business-type activities — food service (if self-sufficient), childcare | Modified accrual does not apply; full accrual; depreciation recorded |
| Internal Service Funds | Self-insurance pools, fleet, central warehousing | Charges back to other funds; eliminations required in government-wide statements |
| Fiduciary Funds — Agency | Student activity funds, payroll clearing | Assets held for others; not available for district programs; reported separately |

GASB Statement No. 34 requires both **fund-level financial statements** (modified accrual for governmental funds) and **government-wide financial statements** (full accrual). The ERP must maintain dual-basis posting logic or a conversion layer that produces full-accrual government-wide statements from modified-accrual fund ledgers.

### Chart of Accounts Structure

School district COA dimensions, in order of significance:

| Dimension | Description | Example |
|---|---|---|
| Fund | Self-balancing fund set (GASB 54) | 10 = General Fund, 24 = Title I Special Revenue |
| Function | What the expenditure is for (instruction vs. support vs. operations) | 1000 = Instruction, 2100 = Student Support, 2600 = Operations |
| Object | What was purchased (personnel, supplies, equipment, services) | 1110 = Certificated Salaries, 4300 = Supplies, 5000 = Capital Outlay |
| Location / Site | School site or district office | 001 = District Office, 050 = Lincoln Elementary |
| Program | Specific program within a function | Program 30 = Special Education, Program 50 = Career Technical |
| Project | Grant project identifier | Ties to GrantAward record for 2 CFR Part 200 tracking |

State education agencies publish mandatory COA structures (e.g., California's SACS — Standardized Account Code Structure; Texas's FASRG — Financial Accountability System Resource Guide; New York's Uniform Chart of Accounts). ERP COA must conform to the state-mandated structure for state financial reporting submission.

---

## 2. Industry-Specific Modules — Public School Districts

### 2.1 Fund Accounting and General Ledger

The fund accounting engine for school districts operates under the same principles as government-publicsector.md (see that file for GASB 34 dual-basis posting logic), with school-district-specific extensions:

- **GASB 54 fund balance categories** (effective for fiscal years beginning after June 15, 2010 [1]): Nonspendable (inventory, prepaid items, permanent fund principal), Restricted (externally imposed by law or grantor), Committed (board resolution required to impose and remove), Assigned (board intent; CFO can assign), Unassigned (residual in General Fund only). ERP must classify fund balance at period-end automatically based on restriction flags on revenue sources.
- **Fund balance policy compliance:** GFOA recommends a minimum unrestricted fund balance of two months of regular general fund operating revenues or expenditures (~16.7%); many state laws set minimum fund balance requirements. ERP must compute and flag fund balance ratios at each fiscal year-end.
- **GASB 68 pension liability (effective FY beginning after June 15, 2014 [2]):** Districts participating in state Teacher Retirement Systems (TRS) must recognize their proportionate share of the net pension liability on the government-wide statement of net position. ERP must receive allocation data from the state TRS or actuary annually and post the adjusting entries. This entry does not affect governmental fund statements (pension expense appears only in government-wide statements); the ERP must maintain the dual-basis separation.
- **GASB 75 OPEB liability (effective FY beginning after June 15, 2017 [3]):** Same structure as GASB 68 but for other post-employment benefits (retiree health insurance). Actuarial data from the state OPEB trust or district's own actuary required annually.
- **GASB 87 lease accounting (effective FY beginning after June 15, 2021 [4]):** Right-of-use assets and corresponding lease liabilities recognized for leases with terms greater than 12 months. School districts commonly lease copiers, buses, and portable classrooms. ERP lease module must amortize right-of-use assets and accrete interest on lease liabilities.
- **GASB 96 SBITAs (effective FY beginning after June 15, 2022 [5]):** Subscription-Based IT Arrangements (e.g., SaaS contracts) treated similarly to leases. ERP must evaluate all IT subscription contracts against GASB 96 criteria.

### 2.2 Budget Adoption and Control

School district budgets are legally adopted instruments:

- **Annual budget cycle:** Superintendent/CFO prepares proposed budget (typically January–April); board holds public hearing; board adopts budget before fiscal year start (July 1 for most states). Some states require state agency approval or notification.
- **Position-based budgeting:** Expenditure budgets are built by authorized position number, not by individual employee. Each position has an associated fund, function, object, location, salary range, and FTE. When a position is filled, the actual salary is encumbered against the position budget. Vacant positions carry budget authority; vacancy savings are tracked separately.
- **Budget amendments:** Mid-year changes above board-established thresholds require formal board resolution. ERP must enforce the approval workflow and maintain a version history of the adopted, amended, and final budget.
- **Encumbrance accounting:** Pre-encumbrances at purchase requisition; encumbrances at purchase order approval. Encumbrances consume available budget balance before cash disbursement. At June 30, encumbrances on multi-year grants carry forward; General Fund encumbrances are typically re-appropriated via board action.
- **Carryover of special revenue funds:** IDEA and Title I unspent balances carry over to the following year (within grant period of performance). ERP must track carryover separately from current-year appropriation and enforce period-of-performance end dates.

### 2.3 State Funding Formula Management

State per-pupil funding formulas are the primary revenue source for most school districts. ERP/SIS must capture the underlying attendance data:

- **ADA (Average Daily Attendance):** Count of students present each day, summed over the reporting period, divided by the number of instructional days in the period. Used in most Western states (California, Texas, Nevada) as the primary funding basis. Formula: ADA = Σ(daily student attendance) / instructional days. Half-day students count as 0.5 ADA. Independent study students may generate ADA under different rules.
- **ADM (Average Daily Membership):** Total enrolled students regardless of whether they were present. Used in many Eastern and Midwestern states. Districts receive funding based on enrollment count on a specific census date (e.g., October count in many states).
- **Foundation programs:** Most states guarantee a per-pupil "foundation" amount (e.g., California LCFF base grant, Texas FSP allotment). State aid = Foundation amount per pupil × ADA/ADM − Local Control Property Tax Revenue. Districts with high property tax wealth receive less state equalization aid.
- **Weighted student funding:** Students with higher educational needs generate higher weights. Common weights: Special Education (1.5–3.0×), English Learner (1.1–1.2×), Low-Income/At-Risk (1.1–1.3×), Career Technical Education (1.2×), Grade level adjustments. ERP must compute weighted ADA/ADM for state revenue projection.
- **Categorical grants:** States provide additional funding for specific programs (special education excess costs, bilingual education, gifted and talented, career tech). Each categorical program has its own eligibility, application, and reporting cycle.
- **Revenue projection engine:** ERP must project state and local revenues based on current enrollment trends, ADA rates, and property assessment data. CFOs use these projections for multi-year budget modeling.

### 2.4 Federal Program Management (ESSA / Title Programs)

The Elementary and Secondary Education Act (ESEA, PL 89-10, 1965), reauthorized as the Every Student Succeeds Act (ESSA, PL 114-95, 2015), governs the largest federal K-12 programs [6]:

- **Title I-A — Improving Basic Programs (20 U.S.C. § 6311 et seq.):** Largest federal K-12 grant (~$18 billion FY2024). Formula allocation based on count of children from low-income families (Census poverty data). LEA receives allocation from state; allocates to Title I schools based on low-income student concentration. ERP must track Title I allocations per school, per student, and against allowable expenditure categories. Supplement-not-supplant rule: Title I funds cannot replace state/local funds that would otherwise be provided (20 U.S.C. § 6321). Comparability requirement: services in Title I schools must be comparable to non-Title I schools before Title I funds are applied (20 U.S.C. § 6321(c)).
- **Title I-A School Identification:** Under ESSA, schools failing to meet state academic targets are identified for Comprehensive Support and Improvement (CSI) or Targeted Support and Improvement (TSI). ERP must flag Title I schools by identification status and track required improvement plan expenditures separately.
- **Title II-A — Supporting Effective Instruction (~$2.1B FY2024):** Professional development, class-size reduction, principal training. ERP tracks expenditures by allowable category; carryover to next year requires state agency approval.
- **Title III-A — Language Instruction for ELs (~$890M FY2024):** English Learner and immigrant student support. ERP must link expenditures to EL student count and EL program type; annual performance objectives required.
- **Title IV-A — Student Support and Academic Enrichment (~$1.3B FY2024):** Three buckets: well-rounded educational opportunities (≥20%), safe and healthy students (≥20%), effective use of technology (≤80% cap). ERP must track expenditure percentages by bucket and flag violations.
- **2 CFR Part 200 (Uniform Guidance) [7]:** All federal grant recipients, including school districts, must follow Uniform Guidance for cost principles, administrative requirements, and audit requirements. Key provisions: allowable vs. unallowable costs, time-and-effort certification for personnel whose salaries are charged to federal grants, procurement standards, subrecipient monitoring.
- **Single Audit:** Districts expending ≥$1,000,000 in federal awards in a fiscal year must undergo a Single Audit per 2 CFR § 200.501 (threshold raised from $750,000 effective October 1, 2024) [7]. The audit includes a Schedule of Expenditures of Federal Awards (SEFA) listing all federal programs by ALN (Assistance Listing Number, formerly CFDA number). ERP must produce the SEFA directly from grant expenditure records tagged with ALN codes.
- **Equitable services to private schools (20 U.S.C. § 6320):** LEAs must consult with private schools in their boundaries and provide equitable services to eligible private school students using a proportionate share of Title I and Title II funds. ERP must track the per-pupil allocation to private school students and expenditures on equitable services separately from regular Title I school expenditures.

### 2.5 IDEA Special Education Management

The Individuals with Disabilities Education Act (IDEA, 20 U.S.C. § 1400 et seq.) imposes the most complex compliance obligations of any K-12 federal program [8]:

- **Part B grants to states (§ 611):** Federal grants to states for students ages 6–21; approximately $14.1 billion FY2024. States flow funds to LEAs by formula.
- **Part B Preschool grants (§ 619):** Ages 3–5; separate allocation from § 611.
- **Maintenance of Effort (MOE) per 34 CFR § 300.203 [9]:** LEAs must maintain expenditures for special education and related services at no less than the level of the prior year, measured by total or per-capita expenditure from state and local funds. Failure to maintain effort results in reduction of IDEA grant. ERP must compute MOE from payroll and direct cost allocations to special education programs and generate the MOE certification report.
- **Excess cost requirement (34 CFR § 300.202) [9]:** Before applying IDEA funds, LEAs must first spend a minimum amount from state/local sources on special education (the "excess cost" base). ERP must calculate the excess cost minimum and confirm it is met before IDEA funds are drawn down.
- **December 1 child count:** Annual submission of special education child count by disability category, educational placement (LRE), age range, race/ethnicity, and English learner status. Drives IDEA Part B formula allocation to states and LEAs.
- **IDEA expenditure tracking:** IDEA funds must be spent on special education and related services per the approved application. Expenditures coded to IDEA grants must tie to IEP service minutes and placement — a direct link between the clinical SIS data (IEP) and the financial ERP.
- **CEIS (Coordinated Early Intervening Services, 34 CFR § 300.226) [9]:** LEAs may (and those with significant disproportionality in special ed identification must) use up to 15% of Part B funds for students not yet identified but needing academic/behavioral support. ERP must enforce the 15% cap and track CEIS expenditures separately.
- **Medicaid billing for school-based services:** Many districts bill Medicaid for health-related services provided to students with IEPs (speech therapy, OT, PT, nursing). ERP must interface with the state Medicaid billing system and track Medicaid receipts as offsets to special education costs.

### 2.6 E-rate Compliance (Schools and Libraries Program)

E-rate provides federal subsidies for telecommunications, internet access, and internal network infrastructure at schools. Administered by the Universal Service Administrative Company (USAC) under FCC authority per 47 CFR Part 54, Subpart F [10]:

- **Discount calculation:** Based on free/reduced meal percentage (poverty proxy) and urban/rural status. Discount rates range from 20% (lowest poverty, urban) to 90% (highest poverty, rural).
- **Category 1 (C1):** Telecommunications services and internet access. No per-student budget cap; competitive bidding required every 5 years for multi-year contracts.
- **Category 2 (C2):** Internal connections (switches, routers, wireless access points, cabling), managed WiFi services. Rolling 5-year budget of $167 per student (or $25,000 per building minimum, whichever is higher) [10].
- **Form 470:** Posted to USAC's E-rate Productivity Center (EPC) portal to initiate competitive bidding; must be open for at least 28 days before selecting a vendor.
- **Form 471:** Funding request submitted after selecting vendor; filed during the annual filing window (typically January–March). ERP must capture vendor SPIN (Service Provider Identification Number), service type, total cost, and requested discount amount.
- **Invoicing methods:** BEAR (Billed Entity Applicant Reimbursement) — district pays vendor in full, then requests reimbursement from USAC; or SPI (Service Provider Invoice) — vendor invoices USAC for the discounted portion and bills district only for the non-discounted share.
- **CIPA compliance required (47 U.S.C. § 254(h)(5)) [11]:** E-rate funding requires the district to have adopted an internet safety policy with technology protection measures (content filtering). Annual board certification required. ERP must store CIPA certification status per fiscal year.
- **Commitment tracking:** ERP must track E-rate commitments by Funding Request Number (FRN), service year, and received vs. pending reimbursement.

### 2.7 Child Nutrition Programs

School meal programs are administered by the USDA Food and Nutrition Service under the Richard B. Russell National School Lunch Act (42 U.S.C. § 1751 et seq.) and the Child Nutrition Act of 1966 (42 U.S.C. § 1771 et seq.) [12]:

- **NSLP (National School Lunch Program, 7 CFR Part 210):** Federal reimbursement per qualifying meal served. SY 2024-25 reimbursement rates: free lunch ~$4.41, reduced-price lunch ~$4.01, paid lunch ~$0.55 (plus Commodity Value; verify annually from USDA FNS memoranda as rates are adjusted each July).
- **SBP (School Breakfast Program, 7 CFR Part 220):** Free breakfast ~$2.27, reduced ~$1.97, paid ~$0.42 (SY 2024-25, approximate; verify).
- **Eligibility categories:** Free — family income ≤130% Federal Poverty Level (FPL); Reduced — 131–185% FPL; Paid — above 185% FPL. Direct certification: students in households receiving SNAP, Medicaid (in states with direct cert agreements), TANF, or FDPIR are automatically eligible without application.
- **Community Eligibility Provision (CEP):** Schools or LEAs with ≥62.5% directly certified students may serve all students free meals. Identified student percentage (ISP) determines federal reimbursement blended rate: Reimbursement per meal = (ISP × 1.6 × free rate) + ((1 − ISP × 1.6) × paid rate). CEP election is made for 4-year cycles.
- **Counting and claiming:** Daily meal counts by category (free/reduced/paid) recorded at point of sale. Monthly claim submitted to state agency; state submits to USDA FNS for reimbursement. ERP must reconcile meal claim payments to the GL (Special Revenue Fund — Food Service).
- **POS systems:** Titan School Solutions, LINQ Connect (formerly Horizon Lunch), Mosaic, Meal Magic. POS system transmits daily meal counts to ERP for claiming. Student meal accounts reconciled against child nutrition fund.
- **Revenues from paid meals and a la carte:** ERP must track paid meal revenue separately from reimbursable meal revenue; food service fund must break even or generate surplus to maintain the program.
- **USDA commodity foods:** In-kind commodity value must be recorded as revenue in the food service fund at the state-published per-case value.

### 2.8 Position Control and Payroll

Position control is the structural core of school district HR and budget management:

- **Position master:** Each authorized position has: position number, title, classification (certified/classified), FTE, fund/function/object/location budget coding, salary range (step and lane for certificated), benefit eligibility, and filled/vacant status. The board adopts the position schedule each year; additions require board approval.
- **Step-and-lane salary schedules:** Certificated (licensed) staff are paid based on: step = years of verified experience (advanced by one step annually upon satisfactory evaluation), lane = educational attainment tier (BA, BA+30, MA, MA+30, Doctorate). The intersection of step and lane determines base salary. ERP must implement the full schedule matrix and advance steps/lanes automatically based on anniversary and transcript verification workflows.
- **Certificated vs. classified distinction:** Certificated staff (teachers, counselors, psychologists, administrators) hold state-issued credentials and are subject to tenure law, credentialing deadlines (ERP must track credential expiration and flag assignments to out-of-field positions). Classified staff (paraprofessionals, custodians, bus drivers, food service) are governed by classified HR rules, often under SEIU or other union contracts.
- **Teacher Retirement Systems (TRS/STRS):** Most states operate defined-benefit pension plans for certificated staff. Under GASB 68, the district recognizes its proportionate share of the plan's net pension liability. TRS contribution rates: employee 7–10% of salary, employer 15–25% (varies by state). ERP payroll must compute, withhold, and remit contributions on each payroll cycle and report to the state TRS on schedule (typically quarterly/annually).
- **FICA exemption:** In states where teachers are covered exclusively by TRS with no Social Security participation (e.g., California, Texas, Massachusetts, Illinois under some conditions), certificated staff do not contribute to FICA. ERP payroll must correctly flag FICA-exempt positions; misclassification creates IRS liability.
- **Substitute teacher payroll:** High-volume, per-diem payroll with daily rates varying by credential status (credentialed substitute vs. emergency credential). Integration with Frontline Absence & Substitute Management (or SubFinder/Vector Solutions) for daily absence/sub confirmation before payroll processing.
- **Extra duty pay:** Teachers receive supplemental pay for coaching, department chair stipends, after-school programs, extended day. ERP must handle supplemental payroll runs and code extra duty pay to appropriate fund/function.
- **ACA compliance:** Districts with 50+ full-time equivalent employees are Applicable Large Employers under ACA. ERP must monitor variable-hour classified employee hours to determine benefits eligibility trigger (30 hours/week measurement period threshold).

### 2.9 Procurement

- **Competitive bidding thresholds:** Set by state law; typically: informal quotes required >$5,000–$10,000; formal sealed bid required >$25,000–$75,000 (varies by state; verify against state procurement code). Formal bids require public notice, sealed submission, public opening, award to lowest responsible bidder.
- **Cooperative purchasing:** Districts can utilize contracts competitively bid by cooperative purchasing organizations, avoiding redundant bid processes. Major cooperatives: AEPA (Association of Educational Purchasing Agencies), TIPS (The Interlocal Purchasing System, Texas), Sourcewell (formerly NJPA), NASPO ValuePoint (state-aggregated), state WSCA contracts. ERP procurement module must support cooperative contract references as bid justification.
- **Davis-Bacon Act (40 U.S.C. §§ 3141–3148):** Prevailing wage requirements apply to construction projects receiving federal assistance ≥$2,000. ERP must flag federally funded capital projects and generate certified payroll reports (WH-347 form) for contractor compliance — see construction-realestate.md for WH-347 detail.
- **E-rate competitive bidding:** Separate from general procurement; Form 470 on USAC EPC portal is the mandatory competitive solicitation mechanism for E-rate-eligible services.
- **Procurement card (P-card) controls:** Transaction limits, merchant category code (MCC) restrictions, monthly statement certification, split-purchase prohibition enforcement at the ERP level.

---

## 3. Regulatory and Compliance Requirements — Public School Districts

| Citation | Scope | ERP Requirement |
|---|---|---|
| GASB Statement No. 34 (1999) [13] | Basic financial statements for state and local governments | Dual-basis (fund + government-wide) financial statements |
| GASB Statement No. 54 (2010) [1] | Fund balance reporting and governmental fund type definitions | Five-category fund balance classification engine |
| GASB Statement No. 68 (2013) [2] | Pension accounting for government employers | Net pension liability entry from actuarial/TRS data annually |
| GASB Statement No. 75 (2015) [3] | OPEB accounting | Net OPEB liability entry; actuarial data required annually |
| GASB Statement No. 87 (2017) [4] | Lease accounting | Right-of-use assets and lease liabilities for leases >12 months |
| GASB Statement No. 96 (2020) [5] | Subscription-based IT arrangements | SBITA right-to-use assets for qualifying SaaS/subscription contracts |
| ESEA/ESSA, PL 114-95 (2015) [6] | Federal K-12 education programs (Title I–IV) | Grant management per fund, supplement-not-supplant tracking, school-level allocation |
| 2 CFR Part 200 (Uniform Guidance) [7] | Federal grant administrative requirements, cost principles, audit | SEFA production, ALN tagging, time-and-effort certification, Single Audit support |
| IDEA Part B (20 U.S.C. § 1411) [8] | Special education federal grants | MOE calculation, excess cost verification, child count reporting, December 1 submission |
| 34 CFR Part 300 [9] | IDEA implementing regulations | IEP timeline enforcement (365-day annual review, 60-day initial evaluation) |
| 42 U.S.C. § 1751 / 7 CFR Part 210 [12] | National School Lunch Program | Daily meal count, monthly claim, free/reduced eligibility tracking, CEP calculation |
| 42 U.S.C. § 1771 / 7 CFR Part 220 [12] | School Breakfast Program | Same claiming and eligibility structure as NSLP |
| 47 CFR Part 54, Subpart F [10] | E-rate Schools and Libraries Program | Form 471 data, SPIN tracking, commitment tracking, CIPA certification |
| 47 U.S.C. § 254(h)(5) (CIPA) [11] | Children's Internet Protection Act | Board-adopted internet safety policy; technology protection measure; annual certification for E-rate |
| 20 U.S.C. § 1232g / 34 CFR Part 99 (FERPA) [14] | Family Educational Rights and Privacy Act | RBAC on student records; directory information suppression; audit logging of record access |
| 15 U.S.C. § 6501 (COPPA) [15] | Children's Online Privacy Protection Act | Vendor data processing agreements; school operator consent for children under 13 |
| State education code (varies) | COA structure, fund balance policy, budget adoption, procurement thresholds | State-mandated COA compliance; state financial reporting submissions |

---

# Part II — Private Schools

## 4. Overview

Private schools range from large endowed independent schools (NAIS members, $50,000+ annual tuition) to small faith-based schools charging $5,000/year. What unites them architecturally is that **revenue is generated through enrollment contracts** and, for nonprofits, through philanthropic support — not through government formulas. The ERP must handle tuition billing as a first-class financial workflow, manage advancement/fundraising, and support FASB ASC 958 fund accounting for nonprofit entities. For-profit private schools follow commercial GAAP with standard AR and revenue recognition.

### Legal Entity Categories

| Category | Accounting Standard | IRS Status | Notes |
|---|---|---|---|
| Independent nonprofit school (NAIS member) | FASB ASC 958 | 501(c)(3) | Full nonprofit accounting: fund accounting, Form 990, donor restrictions |
| Catholic / faith-based parochial school | FASB ASC 958 (diocesan level) | 501(c)(3) via diocesan group exemption | Diocesan consolidation; housing allowances for clergy employees |
| Nonprofit charter school | FASB ASC 958 or GASB depending on state law and structure | 501(c)(3) if separately incorporated | Receives public per-pupil funding but operates as nonprofit entity |
| For-profit private school / tutoring chain | Commercial GAAP (ASC) | Taxable entity | Standard AR/revenue recognition; no nonprofit accounting |
| Boarding school | FASB ASC 958 | 501(c)(3) | Room and board revenue; international student compliance (SEVIS, Form 1042-S) |
| Proprietary vocational school | Commercial GAAP | Taxable or 501(c)(3) | Title IV eligibility if accredited (governed by education.md HEA framework) |

---

## 5. Industry-Specific Modules — Private Schools

### 5.1 Tuition Billing and Revenue Management

Tuition is the primary revenue stream and must be modeled with more precision than a standard AR module provides:

- **Enrollment contract engine:** Each enrolled student generates an annual enrollment contract specifying: gross tuition, financial aid discount, net tuition obligation, payment plan selection (lump sum annual, semi-annual, 10-month, 12-month), refund schedule by withdrawal date, and supplemental fees (activity fee, technology fee, lab fees). Contract is the source document for tuition AR.
- **Revenue recognition per ASC 606:** Tuition is an exchange transaction (student/family pays; school provides instruction). Performance obligation satisfied ratably over the academic term (each instructional day is a proportional delivery of the service). ERP must recognize tuition revenue daily or monthly over the term period — upfront annual payment creates deferred revenue on receipt, drawn down as service is delivered.
- **Deferred revenue:** Enrollment deposits (typically $1,000–$5,000, paid on enrollment contract signing) are deferred until the academic year begins. Re-enrollment deposits for the following year, collected in January/February, remain deferred until the following fall. ERP must age deferred revenue by academic year and release on term start.
- **Tuition refund schedules:** Standard refund ladders (e.g., 100% before June 1, 75% before July 1, 50% before August 1, 0% after school starts) must be enforced automatically upon withdrawal. Withdrawal triggers a credit memo against the enrollment contract balance; refund processed only if payment exceeds earned tuition.
- **Supplemental billing:** After-school programs, field trips, uniform purchases, transcript fees, athletic fees — billed separately against the student account. ERP student AR module must support mixed-item billing.
- **Payment processing integration:** School tuition platforms (FACTS Management, Smart Tuition by Blackbaud, TADS) handle ACH/credit card processing and payment plan administration. These systems integrate with the school ERP (or serve as the tuition module themselves); the integration must post cash receipts to the GL and reconcile student account balances.
- **International student billing:** Non-resident alien (NRA) students may have scholarship amounts subject to 30% withholding under 26 U.S.C. § 1441, unless reduced by tax treaty. ERP must identify NRA students, apply treaty rates where applicable, withhold correctly, and generate Form 1042-S (Foreign Person's U.S. Source Income Subject to Withholding) by March 15 annually.

### 5.2 Enrollment and Admissions Management

Private school enrollment management is a revenue-critical function with no public school analogue:

- **Admissions funnel tracking:** Inquiry → Application received → Application complete → Reviewed → Accepted → Enrolled/Declined/Waitlisted → Re-enrolled. Each stage transition triggers workflow actions (acknowledgment letters, decision letters, enrollment contracts). The ERP or integrated CRM must track yield metrics at each stage.
- **Enrollment capacity management:** Each grade level has a maximum capacity (physical classroom constraint). ERP must enforce capacity limits and manage waitlist sequencing.
- **Re-enrollment workflow:** Typically January–March for the following academic year. ERP generates re-enrollment contracts, tracks signed returns, and projects the following year's enrollment (and therefore revenue) by grade level. Re-enrollment rate by grade is a critical KPI.
- **Demographic and diversity reporting:** NAIS members report enrollment demographic data through NAIS DataHub for benchmarking. ERP must store race/ethnicity, gender, nationality, financial aid recipient status for this reporting.
- **Integration with admissions platforms:** Ravenna (Finalsite), Blackbaud Enrollment Management, Veracross Admissions, School & Student Services (SSS) Online. Admissions data flows to ERP upon enrollment to create the student account and billing record.

### 5.3 Financial Aid Management (Private K-12)

Private school financial aid is a tuition discount, not a federal student aid program:

- **Need analysis:** SSS (School and Student Services) by NAIS, now administered through the NAIS School and Student Services platform (formerly by College Board), analyzes family financial statements to compute an estimated family contribution (EFC) toward tuition. Schools subscribe to SSS to receive EFC calculations and use them as one input to aid decisions. SSS does not dictate the award — the school determines the final award.
- **Aid types:** Need-based (tied to SSS EFC or internal assessment); Merit-based (academic, athletic, artistic achievement — not needs-dependent); Sibling discount; Clergy/employee discount (faith-based schools).
- **NAIS guidelines:** NAIS Principles of Good Practice for Financial Aid Administration — member schools commit to need-blind admissions (award decisions not influenced by ability to pay), single-offer (one aid offer per student, not initial low-ball offer), and confidentiality. ERP must enforce the single-offer constraint.
- **Aid accounting:** Aid awards are typically recorded as a contra-revenue reduction against gross tuition (discount model) rather than as an expense (scholarship model). The treatment affects the reported net tuition revenue figure. ERP must be configured consistently with the school's chosen policy; auditors expect consistency year over year.
- **Tuition discount rate:** Industry benchmark per NAIS is ~22–25% for member independent schools. ERP computes: Financial Aid Awarded / Gross Tuition Revenue Billed.
- **Aid budget management:** Total aid awarded is budgeted annually; ERP must track awarded vs. available aid budget in real time as aid packages are finalized during the admissions cycle (typically February–April for fall enrollment).

### 5.4 Advancement and Development

Private K-12 schools depend on philanthropic support for capital projects, financial aid endowments, and operating supplements:

- **Annual fund:** Annual unrestricted operating appeal to alumni, current parents, grandparents, and friends. Revenue recognized as unconditional contribution without donor restrictions upon receipt per FASB ASC 958-605. Annual fund goal and participation rate (% of each constituency giving, regardless of amount) are key board metrics.
- **Capital campaigns:** Multi-year, goal-oriented campaigns for building projects, endowment establishment, or technology. Major gifts are often pledged over 3–5 years. Multi-year pledges recognized as contribution revenue at present value (discounted at a risk-free rate per FASB ASC 958-310) with interest accretion each period.
- **Gift acknowledgment:** 26 U.S.C. § 170(f)(8) requires contemporaneous written acknowledgment for gifts ≥$250, stating whether any goods or services were provided in exchange. For quid pro quo contributions (e.g., auction items), the school must disclose that only the amount above the fair market value of goods received is deductible. ERP must generate acknowledgment letters and track quid pro quo disclosures.
- **Endowment:** Many established independent schools maintain endowments. UPMIFA (Uniform Prudent Management of Institutional Funds Act, NCCUSL 2006, adopted in 49 states + DC + USVI) [16] governs spending decisions. Typical policy: spend 4–5% of the rolling 12-quarter average market value annually. ERP unitized pool accounting required (same as education.md endowment section for universities; same structural requirements apply at K-12 scale).
- **CRM integration:** Blackbaud Raiser's Edge NXT is the dominant advancement CRM for private K-12. Gift records originate in Raiser's Edge and post to Financial Edge NXT (or the general ERP). Constituent data must flow bidirectionally — ERP enrollment data informs parent/alumni status in the CRM.
- **Planned giving / bequest programs:** Growing at larger independent schools. Revocable bequests not recognized in financial statements; irrevocable charitable remainder trusts and charitable gift annuities recorded at present value of expected remainder (split-interest agreement accounting per FASB ASC 958-30).

### 5.5 Fund Accounting — FASB Model (Nonprofit Private Schools)

- **Net asset classes (FASB ASU 2016-14, effective for fiscal years beginning after December 15, 2017 [17]):** Two classes: **without donor restrictions** (operating fund, board-designated funds, quasi-endowment, plant fund) and **with donor restrictions** (purpose-restricted gifts, time-restricted pledges, true endowment principal). ERP COA must enforce restriction class at the fund/account level.
- **Board-designated funds:** Funds set aside by board action (not by donor restriction) — e.g., a capital reserve, a scholarship fund funded from operating surplus. These are "without donor restrictions" because the board can reverse the designation. ERP must distinguish board-designated funds from donor-restricted funds in all financial statements.
- **Restriction release:** When a donor-restricted gift is spent for its stated purpose (e.g., a scholarship awarded from a scholarship fund), ERP posts a release from restriction — simultaneously reduces "with donor restrictions" net assets and increases "without donor restrictions" net assets. This entry does not change total net assets.
- **Financial statements required under FASB ASC 958:** Statement of Financial Position (balance sheet by net asset class), Statement of Activities (revenues and expenses by net asset class), Statement of Functional Expenses (matrix: natural expense class × program/supporting services), Statement of Cash Flows.
- **Statement of Functional Expenses:** FASB ASC 958-720-45 requires this statement for voluntary health and welfare organizations; FASB ASU 2016-14 requires it as a disclosure for all nonprofits. For private schools: Program Services (instruction by grade level or department), Management & General, and Fundraising are the functional categories. Shared costs (facilities, IT, administration) allocated across functions using documented methods (square footage, headcount, time studies).

### 5.6 HCM and Payroll — Private Schools

Private school HR differs from public districts in key ways:

- **Faculty contracts:** Annual contracts (non-tenure for most private schools, unlike public school tenure law), including salary, benefits, extra-duty assignments. Contract management module must track multi-year agreements for continuing faculty.
- **Clergy housing allowance (IRC § 107):** For faith-based schools employing ordained, licensed, or commissioned ministers, a portion of compensation may be designated as a housing allowance, excluded from federal income tax. The exclusion is limited to the lesser of: the designated amount, actual housing expenses, or the fair rental value of the home (furnished, plus utilities). The school must officially designate the allowance **before the calendar year begins** (or before employment begins, if mid-year) — retroactive designation is not permitted, so ERP payroll must carry a per-employee housing allowance designation field with the board-authorization date. The exclusion applies only to income tax: ministers remain subject to self-employment tax (SECA) on housing allowance income because they are treated as self-employed for Social Security purposes. The Seventh Circuit upheld the IRC § 107(2) exclusion in *Gaylor v. Mnuchin*, 919 F.3d 420 (7th Cir. 2019), reversing a district court ruling; the exclusion remains valid as of 2026. ERP must report the exclusion correctly on Form W-2 (Box 14 or as a non-reportable exclusion, depending on total compensation) [30][31].
- **No TRS obligation for most private schools:** Private school teachers typically participate in 403(b) plans (defined contribution) rather than defined-benefit TRS. ERP must handle 403(b) deferrals, employer matching contributions, and 415(c) contribution limits. Some private schools offer TIAA-CREF or similar vendors.
- **Faculty salaries as functional expense:** Faculty salary allocations to program services (instruction) vs. management & general vs. fundraising must be tracked and reportable for the Statement of Functional Expenses. Time study documentation required for shared-duty faculty (e.g., a teacher who also serves as department chair with administrative duties).

### 5.7 Tax Compliance for Nonprofit Private Schools

#### IRS Form 990 — Annual Information Return

Nonprofit private schools exempt under 26 U.S.C. § 501(c)(3) must file Form 990 annually with the IRS; most qualify as public charities under IRC § 170(b)(1)(A)(ii) (educational organizations). The filing variant is determined by size:

| Form | Gross Receipts Threshold | Total Assets Threshold |
|---|---|---|
| Form 990-N (e-Postcard) | ≤ $50,000 | N/A |
| Form 990-EZ | < $200,000 AND | < $500,000 |
| Form 990 (full) | ≥ $200,000 OR | ≥ $500,000 |

Filing deadline is the 15th day of the 5th month after the end of the organization's accounting period (May 15 for calendar-year filers; November 15 for schools with a June 30 fiscal year-end). Three consecutive years of failure to file triggers **automatic revocation of 501(c)(3) status**, with no appeal process — reinstatement requires a new exemption application. Form 990 Schedule A documents the basis for public charity status; schools must demonstrate a clearly defined curriculum, enrolled student body, faculty, place of instruction, and structured educational program. ERP must produce data for Schedule A, Schedule D (supplemental financial statements), and the revenue/expense reconciliation to audited financials [32].

#### Unrelated Business Income Tax (UBIT)

26 U.S.C. §§ 511–514 tax "unrelated business income" — income from a trade or business, regularly carried on, that is not substantially related to the school's exempt educational purpose:

- **Form 990-T** is required if gross income from unrelated business activities is $1,000 or more in a tax year; estimated tax payments are required if expected annual UBIT liability is $500 or more. The corporate income tax rate applies (21% flat federal rate since the Tax Cuts and Jobs Act of 2017).
- **Fragmentation rule (Treas. Reg. § 1.513-1(b)):** an activity is not automatically exempt merely because it is conducted alongside exempt activities — each discrete business activity is tested separately.
- **Common private-school scenarios:** facility rental to unrelated organizations, sale of advertising space in school publications (distinguished from qualified sponsorships under § 513(i)), bookstore sales beyond student/faculty use, outside catering, and mailing-list rentals. Passive investment income (interest, dividends, debt-free real-property rents), royalties, and gains from property sales are excluded.
- ERP must track revenue and expenses by unrelated business activity separately: since the Tax Cuts and Jobs Act, losses from one unrelated activity cannot offset income from another (the post-TCJA § 512(a)(6) "silo" rule) [33].

#### 501(c)(3) Status and Nondiscrimination Policy

*Bob Jones University v. United States*, 461 U.S. 574 (1983), held that a private school maintaining a racially discriminatory admissions policy does not operate for "charitable" purposes within the meaning of IRC §§ 170 and 501(c)(3) and is not entitled to tax-exempt status, even where the policy is grounded in sincere religious belief — affirming IRS Revenue Ruling 71-447 (the IRS revoked BJU's exemption effective December 1, 1970). Loss of 501(c)(3) status for any reason — discriminatory policy, operational failure, or failure to file Form 990 — immediately disqualifies donor deductions for contributions made after the loss of status. ERP gift-acknowledgment workflows should verify current 501(c)(3) standing before issuing contemporaneous written acknowledgments [34].

### 5.8 Voucher and Education Savings Account Compliance

As state school choice programs expand, private schools increasingly receive public funds with compliance strings:

- **Arizona Empowerment Scholarship Accounts (ESA, ARS § 15-2401 et seq.) [18]:** Families receive state funds (average ~$7,000–$10,000/year) deposited into an ESA managed by the Arizona Department of Education. Private schools are approved ESA vendors; they receive ESA payments from ADE for tuition. ERP must track ESA receipts separately from family tuition payments and maintain documentation for annual audit by ADE.
- **Florida Step Up for Students / Family Empowerment Scholarship:** Scholarship organizations receive state funds and distribute to participating private schools. Schools must be accredited by a state-approved accreditor and sign a participation agreement. ERP tracks scholarship payments by scholarship organization, separately from direct family tuition.
- **Indiana Choice Scholarship Program (IC 20-51-1 et seq.) [19]:** School must be accredited. Scholarship amount based on public school per-pupil funding in the district. ERP receives scholarship payments from Indiana DOE and applies to student accounts.
- **Wisconsin Parental Choice Program (Wis. Stat. § 119.23):** Oldest voucher program (Milwaukee, since 1990). Annual financial audit required for schools receiving ≥$500,000 in choice payments. ERP must produce audit-ready financial statements segregating choice program revenues and expenditures.
- **Reporting obligations:** Most voucher/ESA programs require annual financial reports, student count certifications, and evidence of accreditation maintenance. ERP must generate per-student voucher/scholarship revenue reports by program.

### 5.9 Accreditation

Private K-12 schools are accredited by regional and national bodies. Accreditors do not impose a uniform financial reporting template across all members — specific data requirements are set by each accreditor's self-study instrument — but the following bodies are the primary actors:

| Accreditor | Scope | Financial Standards |
|---|---|---|
| NAIS (National Association of Independent Schools), via ICAISA | Independent schools in the US and internationally; NAIS membership requires accreditation by an NAIS-approved body | NAIS Principles of Good Practice; financial sustainability is an explicit governance criterion |
| Cognia (merger of AdvancED and NWAC/WASC Senior/SACS CASI) | Nonprofit serving 36,000+ institutions in 90+ countries; applies the same process to public and private schools | Cognia Performance Standards; financial viability assessed during on-site review |
| WASC (Western Association of Schools and Colleges) | Western US, Pacific, and international | WASC Accrediting Commission for Schools (ACS) for K-12; financial health is one of five self-study focus areas |
| Regional associations | New England (NEASC), Middle States (MSA), North Central (HLC K-12 arm), Southern (SACS CASI, now Cognia), Northwest (NWAC, now Cognia) | Each publishes a self-study guide with financial sections |

Accreditors typically request: audited financial statements for the last 2–3 years (full GAAP-basis, including statements of financial position, activities, functional expenses, and cash flows); budget-vs.-actual comparisons; multi-year financial forecasts; board composition and governance structure; debt schedule and covenant compliance; endowment market value and spending policy; tuition discount rate trend (for NAIS-affiliated schools); and a deferred-maintenance facilities assessment. ERP must be able to produce consolidated FASB ASC 958-format financial statements on demand with auditor-ready trial balances. Accreditation cycles typically run 5–10 years with interim progress reports, and the ERP's financial data is the primary evidence base [35].

### 5.10 Multi-Campus and Diocesan Consolidation

Catholic dioceses operate systems of dozens to hundreds of schools, often with chart-of-accounts structures that evolved independently over decades. The central financial management challenge is consolidation: producing entity-level statements for each school alongside consolidated statements for the diocese.

**ERP architecture requirements:**
- **Standardized chart of accounts across all entities:** consolidation requires consistent account coding; COA standardization should be a prerequisite for ERP selection, not an afterthought.
- **Multi-entity consolidation with elimination entries:** intercompany transactions between diocese and schools (facilities services, administrative cost allocations, insurance pools, central purchasing) must be recorded and then eliminated in consolidation.
- **Intercompany (inter-campus) cost allocations:** dioceses typically charge schools for central services (HR, insurance, IT, legal, curriculum); ERP must support automated intercompany billing with elimination on consolidation.
- **Entity-level and roll-up reporting:** each school receives its own P&L and balance sheet; the diocese needs a consolidated view with drill-down to entity.

Platforms cited for diocesan use include **ParishSOFT Consolidation** (dynamic roll-up financial reporting, centralized chart-of-accounts management, built-in audit support), **SylogistMission ERP** (Microsoft Dynamics-based; unifies finance, fundraising, grants, and ministries), and **Sage Intacct** with its multi-entity module (strong fund accounting and dimensional reporting; also used by some independent school networks) [36].

National independent-school networks (KIPP, Achievement First, Success Academy for nonprofit charters; independent-school consortia) have similar multi-entity ERP requirements, with one key difference from diocesan systems: member schools are often independently incorporated, so consolidated reporting may require equity-method accounting for affiliate relationships rather than full consolidation. Inter-campus cost allocation methods include: direct cost pass-through (network-office costs billed to schools by headcount, square footage, or enrollment); an indirect cost rate similar to federal F&A (network overhead allocated as a percentage of school operating expenses); and shared-service agreements — a management services agreement (MSA) between the network and each school, billed hourly or flat-fee, with fees documented as arm's-length and reasonable. ERP must produce stand-alone financial statements for each legal entity (required for each school's own Form 990 filing) and either consolidated statements (if the network is a single legal entity with school divisions) or combined statements (if schools are separate legal entities combined for informational purposes).

### 5.11 Boarding School Specifics

Room and board is a distinct revenue stream from tuition at boarding schools, with separate performance obligations under ASC 606: residential housing ("room") is recognized ratably over the residential period if billed separately, or as a separate performance obligation allocated a share of a bundled contract price; meals ("board") are recognized as provided (point-in-time per meal, or ratably over the dining-plan period if access-based). Amounts billed before the period begins are deferred and recognized as services are delivered.

**Form 1042-S — Non-Resident Alien (NRA) students:** Boarding schools that award scholarships or fellowship amounts to NRA students — F-1 visa holders in their first five calendar years in the US who have not met the 183-day substantial presence test — must comply with NRA withholding and reporting under IRC § 1441 and Treas. Reg. § 1.1441-3:
- Scholarship/fellowship amounts that exceed tuition and required fees are US-source income taxable to the NRA student (the qualified-scholarship exclusion under IRC § 117 covers only tuition).
- The withholding rate is 14% on that excess, unless reduced by a tax treaty between the US and the student's country of residence; the school acts as withholding agent.
- **Form 1042-S** (amounts paid to NRA individuals subject to Chapter 3 withholding) and **Form 1042** (annual withholding tax return) are both due March 15 of the year following the calendar year of payment.
- ERP requirements: a nationality/visa-status field on the student record; a tax-treaty eligibility flag by country and treaty article (e.g., US-China Article 20); a calculation engine netting scholarship amounts against qualified expenses to determine the reportable excess; a withholding engine; and a 1042-S generation module (natively or via a vendor such as Sprintax Calculus) [37].

**SEVIS/I-20 compliance (F-1 visa):** Boarding schools enrolling F-1 students must be **SEVP-certified** (Student and Exchange Visitor Program, administered by ICE) before issuing Form I-20, which the student uses to obtain an F-1 visa. Under 8 CFR § 214.3 and 8 CFR § 214.2(f), certified schools must: maintain current SEVIS records for all active F-1 students; report within 21 days any failure to enroll, early program completion, expulsion/withdrawal, change in school level, or drop below a full course of study; issue I-20 extensions/updates as needed; and retain physical records for 3 years after a student departs or completes the program. ERP/SIS should carry I-20 issue date, program end date, and SEVIS ID on the student record (see the `BoardingStudent` entity in Section 6), with automated triggers for SEVIS reporting obligations on enrollment-status change [37].

---

## 6. Key Data Entities

### Core School Data Model (Shared)

```sql
-- Student and Enrollment
Student (
  student_id              PK,
  state_student_id        VARCHAR,          -- SSID / STAAR ID / CALPADS SSID
  person_id               FK → Person,
  district_id             FK → District,
  enrollment_status       ENUM[active|inactive|graduated|withdrawn|transferred],
  grade_level             ENUM[PK|K|1|2|3|4|5|6|7|8|9|10|11|12|adult],
  home_school_id          FK → School,
  residency_status        ENUM[resident|nonresident|interdistrict|homeless|foster|other],
  special_ed_flag         BOOLEAN,
  el_status               ENUM[EL|RFEP|EO|TBD],        -- English Learner status
  free_reduced_eligible   ENUM[free|reduced|paid|CEP],
  title1_school_flag      BOOLEAN,          -- Attends Title I school
  ferpa_directory_suppress BOOLEAN
)

School (
  school_id               PK,
  district_id             FK → District,
  school_name             VARCHAR,
  nces_school_id          VARCHAR,          -- NCES 12-digit school ID
  grade_range_low         ENUM,
  grade_range_high        ENUM,
  title1_status           ENUM[schoolwide|targeted_assist|not_title1],
  essa_identification     ENUM[CSI|TSI|ATSI|none],     -- ESSA accountability status
  cep_flag                BOOLEAN,          -- Community Eligibility Provision
  isp_pct                 DECIMAL           -- Identified student percentage for CEP
)

AcademicYear (
  year_id                 PK,
  year_code               VARCHAR,          -- e.g. 2025-26
  start_date              DATE,
  end_date                DATE,
  instructional_days      INTEGER,
  state_reporting_period  VARCHAR
)

Enrollment (
  enrollment_id           PK,
  student_id              FK → Student,
  school_id               FK → School,
  year_id                 FK → AcademicYear,
  entry_date              DATE,
  entry_code              VARCHAR,          -- State entry code (e.g. E1 = new from out of state)
  exit_date               DATE,
  exit_code               VARCHAR,          -- State exit code (e.g. W05 = transferred to private)
  grade_level             ENUM,
  program_codes           VARCHAR[]         -- State program participation codes
)

-- Attendance (Public School — ADA Funding Critical)
AttendanceDay (
  attendance_id           PK,
  student_id              FK → Student,
  school_id               FK → School,
  attendance_date         DATE,
  status                  ENUM[present|absent_excused|absent_unexcused|tardy|independent_study],
  period_count            INTEGER,          -- Periods present out of total periods (for period attendance)
  fte_count               DECIMAL,          -- ADA contribution (1.0 full day, 0.5 half day)
  independent_study_flag  BOOLEAN
)

AttendanceSummary (
  summary_id              PK,
  school_id               FK → School,
  year_id                 FK → AcademicYear,
  reporting_period        VARCHAR,          -- Monthly or annual
  total_days_of_attendance DECIMAL,         -- Sum of fte_count for present students
  total_days_of_membership INTEGER,
  ada                     DECIMAL,          -- Computed: total_days_of_attendance / instructional_days
  adm                     DECIMAL,          -- Computed: total_days_of_membership / instructional_days
  chronic_absent_count    INTEGER           -- Students absent ≥10% of days
)

-- Special Education
IEP (
  iep_id                  PK,
  student_id              FK → Student,
  eligibility_date        DATE,
  disability_category     ENUM[autism|deaf_blindness|deafness|emotional_disturbance|
                               hearing_impairment|intellectual_disability|multiple_disabilities|
                               orthopedic_impairment|other_health_impairment|specific_learning_disability|
                               speech_language_impairment|traumatic_brain_injury|visual_impairment],
  annual_review_date      DATE,             -- Must be within 365 days of prior IEP
  triennial_eval_date     DATE,
  placement_type          ENUM[general_ed_80pct_plus|general_ed_40_79pct|general_ed_lt_40pct|
                               separate_school|residential|home_hospital],
  lre_percent_gen_ed      DECIMAL,          -- % of day in general education setting
  primary_disability_id   FK → DisabilityCategory,
  case_manager_id         FK → Staff,
  status                  ENUM[active|exited|graduated|transferred]
)

IEPService (
  service_id              PK,
  iep_id                  FK → IEP,
  service_type            ENUM[special_ed_instruction|speech|OT|PT|counseling|assistive_tech|other],
  frequency_per_week      DECIMAL,
  minutes_per_session     INTEGER,
  annual_minutes          INTEGER,          -- frequency × minutes × weeks for IDEA reporting
  provider_id             FK → Staff,
  fund_source             ENUM[IDEA_611|IDEA_619|state|local|medicaid]
)

-- Public School Finance Extensions
Position (
  position_id             PK,
  position_number         VARCHAR,          -- District-assigned position control number
  title                   VARCHAR,
  classification          ENUM[certificated|classified|management|confidential],
  fte_authorized          DECIMAL,
  fund_code               VARCHAR,          -- Primary budget funding source
  function_code           VARCHAR,
  object_code             VARCHAR,
  location_id             FK → School,
  salary_range_min        DECIMAL,
  salary_range_max        DECIMAL,
  step                    INTEGER,          -- For certificated positions
  lane                    VARCHAR,          -- Education lane (BA|BA+30|MA|MA+30|DOC)
  filled_flag             BOOLEAN,
  employee_id             FK → Employee     -- Null if vacant
)

GrantAward (
  award_id                PK,
  grant_name              VARCHAR,
  aln_number              VARCHAR,          -- Assistance Listing Number (formerly CFDA)
  grantor                 VARCHAR,
  period_start            DATE,
  period_end              DATE,
  award_amount            DECIMAL,
  carryover_amount        DECIMAL,
  supplement_not_supplant_flag BOOLEAN,
  single_audit_flag       BOOLEAN,          -- Included in SEFA if true
  fund_code               VARCHAR,
  budget_by_object        JSONB             -- Budget lines by object code
)

MealAccount (
  account_id              PK,
  student_id              FK → Student,
  balance                 DECIMAL,
  eligibility_category    ENUM[free|reduced|paid|CEP_universal],
  direct_cert_flag        BOOLEAN,
  direct_cert_source      ENUM[SNAP|Medicaid|TANF|FDPIR|foster|homeless],
  application_date        DATE,
  verification_date       DATE
)

-- Private School Finance Extensions
EnrollmentContract (
  contract_id             PK,
  student_id              FK → Student,
  academic_year_id        FK → AcademicYear,
  gross_tuition           DECIMAL,
  financial_aid_amount    DECIMAL,
  net_tuition_obligation  DECIMAL,
  payment_plan_type       ENUM[annual|semi_annual|10_month|12_month],
  enrollment_deposit_paid DECIMAL,
  refund_schedule_id      FK → RefundSchedule,
  signed_date             DATE,
  status                  ENUM[pending|signed|active|withdrawn|cancelled],
  state_voucher_id        FK → StateVoucherAward  -- If tuition is voucher/ESA-funded
)

FinancialAidAward_Private (
  award_id                PK,
  student_id              FK → Student,
  academic_year_id        FK → AcademicYear,
  aid_type                ENUM[need_based|merit|sibling_discount|employee|clergy|other],
  amount                  DECIMAL,
  fund_source_id          FK → Fund,       -- Which endowed or operating fund pays the award
  sss_efc                 DECIMAL,         -- SSS Expected Family Contribution (needs-based)
  notes                   TEXT,
  approved_by             FK → Employee
)

Gift (
  gift_id                 PK,
  donor_id                FK → Constituent,
  gift_date               DATE,
  amount                  DECIMAL,
  gift_type               ENUM[cash|check|ACH|credit_card|stock|real_estate|in_kind|pledge_payment|
                               planned|matching|voucher_ESA],
  fund_designation_id     FK → Fund,
  restriction_class       ENUM[with_donor_restrictions|without_donor_restrictions],
  campaign_id             FK → Campaign,
  acknowledgment_sent     BOOLEAN,
  acknowledgment_date     DATE,
  quid_pro_quo_amount     DECIMAL,
  irs_substantiation_req  BOOLEAN           -- True if amount >= 250
)

Pledge (
  pledge_id               PK,
  donor_id                FK → Constituent,
  total_pledge_amount     DECIMAL,
  start_date              DATE,
  end_date                DATE,
  installment_frequency   ENUM[monthly|quarterly|annually],
  amount_paid_to_date     DECIMAL,
  discount_rate           DECIMAL,
  present_value           DECIMAL,
  restriction_class       ENUM[with_donor_restrictions|without_donor_restrictions],
  allowance_pct           DECIMAL,          -- Estimated uncollectible percentage (ASC 958-310)
  condition_flag          BOOLEAN,          -- TRUE if conditional (ASU 2018-08 barriers present)
  barrier_description     TEXT,
  right_of_return         BOOLEAN,
  condition_met_date      DATE              -- Date barrier was overcome; triggers revenue recognition
)

StateVoucherAward (
  voucher_id              PK,
  student_id              FK → Student,
  program_name            VARCHAR,          -- e.g. 'Arizona ESA', 'Florida FES-EO', 'Indiana Choice', 'Wisconsin WPCP'
  state_code              CHAR(2),
  award_amount            DECIMAL,
  academic_year_id        FK → AcademicYear,
  disbursement_source     VARCHAR,          -- Administering agency or SFO name
  accounting_treatment    ENUM[exchange_transaction|contribution], -- Almost always exchange_transaction
  audit_report_required   BOOLEAN,          -- Triggered by state-specific threshold
  audit_deadline          DATE,
  reserve_balance_req     BOOLEAN,          -- Wisconsin only
  reserve_balance_amount  DECIMAL
)

BoardingStudent (
  boarding_id             PK,
  student_id              FK → Student,
  room_assignment         VARCHAR,
  board_plan              VARCHAR,          -- Dining plan tier (e.g. full board, weekend board)
  room_rate               DECIMAL,
  board_rate              DECIMAL,
  nra_flag                BOOLEAN,          -- Non-resident alien; triggers 1042-S workflow
  visa_type               ENUM[F1|J1|B2|other|US_citizen_PR],
  sevis_id                VARCHAR,          -- Assigned by DHS SEVIS
  i20_issue_date          DATE,
  i20_program_end_date    DATE,
  country_of_citizenship  CHAR(3),          -- ISO 3166-1 alpha-3
  tax_treaty_country      BOOLEAN,          -- Country has US tax treaty with student exemption
  tax_treaty_article      VARCHAR,          -- e.g. 'US-China Article 20'
  withholding_rate_pct    DECIMAL,          -- 14% default; 0% if treaty applies
  form_1042s_required     BOOLEAN
)

ClergyHousingAllowance (
  allowance_id            PK,
  employee_id             FK → Employee,
  designation_date        DATE,             -- Must precede calendar year; board-authorized
  board_resolution_ref    VARCHAR,          -- Reference to board minutes/resolution
  designated_amount       DECIMAL,          -- Amount designated for calendar year
  actual_housing_expense  DECIMAL,          -- Actual expenses paid; determined at year-end
  fair_rental_value       DECIMAL,          -- FRV of home furnished, plus utilities
  excludable_amount       DECIMAL,          -- MIN(designated, actual, FRV) per IRC § 107
  seca_taxable            BOOLEAN           -- Always TRUE; housing allowance is SECA-taxable
)

CampusEntity (
  entity_id               PK,
  entity_name             VARCHAR,
  entity_type             ENUM[school|diocese_office|network_hq|parish],
  legal_structure         ENUM[separate_501c3|division_of_diocese|LLC|other],
  ein                     CHAR(9),
  form_990_required       BOOLEAN,
  parent_entity_id        FK → CampusEntity, -- For consolidation hierarchy
  consolidation_method    ENUM[full|equity_method|combined|none]
)
```

---

## 7. Critical Integrations

| System / Product | Category | Integration Method | Key Data Exchanged |
|---|---|---|---|
| PowerSchool SIS | K-12 SIS (public & some private) | REST API / SIS Interoperability (SIF) / Clever | Enrollment, attendance, grades, special ed flags, discipline, course sections, state reporting data |
| Infinite Campus (Tyler Technologies) | K-12 SIS (public) | REST API / IC Platform API | Enrollment, ADA/ADM, position-SIS link, federal program participation, state reporting |
| Skyward SMS 2.0 | K-12 SIS (public, smaller districts) | SFTP / API | Student demographics, enrollment, attendance, grades |
| Aeries SIS | K-12 SIS (California-focused public) | REST API | CALPADS-compliant data elements; ADA calculation; SPED records |
| Frontline Absence & Substitute Management | Substitute payroll control | REST API | Absence events approved by building admin → payroll creates sub assignment; sub pay drawn to correct position/fund |
| Tyler Munis ERP | Finance ERP (public districts) | Native (same vendor) | GL, AP, AR, payroll, position control — native integration within Tyler platform |
| eFinancePLUS / LINQ | Finance ERP (smaller public districts) | SFTP / API | GL, HR, payroll transactions |
| USAC EPC (E-rate Productivity Center) | E-rate compliance | Manual data entry / CSV export | Form 471 data (SPIN, FRN, service type, amount); reimbursement confirmations |
| State Longitudinal Data System (varies by state) | State reporting | SFTP batch file / REST (Ed-Fi API) | Enrollment counts, attendance, SPED child count, EL data, discipline, assessments |
| Ed-Fi ODS (Ed-Fi Alliance) | Interoperability layer | Ed-Fi REST API (OAuth 2.0) | Standardized student, enrollment, attendance, staff, assessment, program entities |
| USDA FNS Web-based Intensity of Service (WBSCM) | Child nutrition commodities | Web portal / SFTP | Commodity orders, allocations, receipts |
| POS — Titan School Solutions | Food service point of sale | REST API | Daily meal counts by category → NSLP monthly claim; student account balances |
| POS — LINQ Connect (Horizon) | Food service point of sale | API / SFTP | Same as Titan |
| NWEA MAP Growth | Assessment | Clever / API | Assessment scores → SIS for progress monitoring and ESSA reporting |
| i-Ready (Curriculum Associates) | Assessment | Clever / CSV | Diagnostic and progress monitoring scores |
| Canvas LMS / Schoology | Learning Management | LTI 1.3 / Clever / ClassLink | Course rosters from SIS, grade passback from LMS to SIS |
| Google Workspace for Education | Student identity / productivity | LDAP / GCDS / Admin SDK | Student accounts provisioned from SIS enrollment; group membership by school/grade |
| Microsoft 365 A1/A3/A5 | Student/staff identity | Azure AD Connect / SCIM | Staff provisioned from HR system; students from SIS |
| Clever / ClassLink | Identity broker / SSO | SFTP (nightly roster) / API | Single sign-on across SIS, LMS, assessment, and ed-tech tools |
| Blackbaud Financial Edge NXT | Finance ERP (private schools) | Native (Blackbaud platform) | GL, AP, AR, fund accounting, grant tracking |
| Blackbaud Raiser's Edge NXT | Advancement CRM (private) | Blackbaud SKY API | Gift records, pledge schedules, constituent data → GL posting in Financial Edge |
| FACTS Management / Smart Tuition | Tuition billing & payment (private) | SFTP / API | Enrollment contract data → billing; payment receipts → GL; financial aid awards |
| Veracross | All-in-one SIS/ERP (private) | Native / REST API | Enrollment, tuition billing, admissions, development — unified data model |
| SSS (NAIS School and Student Services) | Financial aid needs analysis (private) | Web portal / CSV | EFC calculations for enrolled applicants → financial aid module |
| SEVIS (DHS/ICE) | International student visa tracking (boarding schools) | SEVIS RTI (Real-Time Interface) | I-20 issuance, enrollment status updates, program extensions, OPT authorization |
| State Voucher/ESA portals (ADE, FL DOE, etc.) | Voucher payment tracking | Web portal / SFTP | Payment confirmations, student eligibility, annual certification |

---

## 8. KPIs and Metrics

### 8.1 Public School District KPIs

| KPI | Definition | Formula | ERP Source |
|---|---|---|---|
| Average Daily Attendance (ADA) | Mean number of students in attendance per instructional day | Sum of days-present across all enrolled students / Total instructional days in period | Attendance module |
| Average Daily Membership (ADM) | Mean number of enrolled students per instructional day | Sum of days-enrolled / Total instructional days | Enrollment module |
| Daily Attendance Rate | ADA as percentage of ADM; proxy for chronic absence | ADA / ADM × 100 | Attendance module |
| Chronic Absenteeism Rate | Share of students missing ≥10% of school days (ESSA indicator) | Students missing ≥10% of days enrolled / Total enrolled students | Attendance module |
| Per-Pupil Expenditure (Total) | Total operating expenditures per ADA | Total Operating Expenditures / ADA | GL / Budget module |
| Per-Pupil Expenditure (Instruction) | Instruction-only expenditures per ADA | Function 1000 Expenditures / ADA | GL |
| Fund Balance as % of Operating Expenditures | Fiscal health indicator; GFOA minimum: 2 months (~16.7%) | Unassigned + Assigned Fund Balance / Annual Operating Expenditures | GL — GASB 54 fund balance |
| Days Cash on Hand | Liquidity measure | (Cash + Short-Term Investments) / (Total Operating Expenditures / 365) | GL / Treasury |
| Employee Costs as % of Total Budget | Payroll dominance indicator; typically 75–85% in K-12 | (Salaries + Benefits) / Total Operating Expenditures | Payroll / GL |
| Special Education Cost per SPED Student | Special ed spending efficiency | Total Special Ed Expenditures / IDEA Child Count | GL + IDEA program fund |
| IDEA Reimbursement Rate | Federal reimbursement coverage of special ed costs | IDEA Funds Received / Total Special Ed Expenditures | Grants + GL |
| Free & Reduced Meal Percentage | Poverty proxy; drives Title I allocation | FRM-Eligible Students / Total Enrolled | Child Nutrition / Enrollment |
| Title I Allocation per Low-Income Student | Federal equity funding depth | District Title I Allocation / Count of Low-Income Students | Grants module |
| Substitute Fill Rate | Instructional continuity measure | Absences Filled by Substitute / Total Certified Staff Absence Days | Frontline / HR module |
| 4-Year Adjusted Cohort Graduation Rate | ESSA accountability metric | Students graduating within 4 years / Adjusted cohort entering 9th grade | SIS / State reporting |
| Debt Service Coverage Ratio | Bond covenant compliance | Net Operating Revenue Available for Debt Service / Annual Debt Service | GL / Debt Service fund |
| Budget Variance by Fund | Fiscal management quality | (Actual Expenditures − Adopted Budget) / Adopted Budget | Budget vs. actual module |
| MOE Compliance Margin | IDEA maintenance-of-effort headroom | Current Year SPED Expenditure from State/Local / Prior Year SPED Expenditure | GL + IDEA tracking |
| SEFA Accuracy Rate | Federal audit readiness | Federal expenditures per SEFA / Federal expenditures per GL (should = 100%) | Grants module + GL |

### 8.2 Private School KPIs

| KPI | Definition | Formula | ERP Source |
|---|---|---|---|
| Net Tuition Revenue per Student | Average retained revenue per enrolled student after aid | (Gross Tuition Revenue − Financial Aid Awarded) / Total Enrollment | Tuition billing module |
| Tuition Discount Rate | Financial aid as proportion of gross tuition; NAIS average ~22–25% | Financial Aid Awarded / Gross Tuition Revenue Billed | Financial aid module |
| Enrollment Yield Rate | Conversion from accepted to enrolled | Enrolled Students / Accepted Applicants | Admissions module |
| Re-enrollment / Retention Rate | Year-over-year student retention | Students Re-enrolled for Next Year / Current Year Enrollment | Enrollment module |
| Annual Fund Participation Rate | Breadth of donor community engagement | Donors Who Gave / Total Constituents Solicited (by segment: parents, alumni) | Advancement CRM |
| Endowment per Student | Institutional wealth per capita | Total Endowment Market Value / Total Enrollment | Endowment module / GL |
| Operating Surplus / Deficit Margin | Financial sustainability | Net Operating Surplus or Deficit / Total Operating Revenue | GL / Financial statements |
| Faculty-to-Student Ratio | Instructional intensity; NAIS average ~1:8–10 | Total Enrolled Students / FTE Faculty | HR + Enrollment |
| Debt Service as % of Operating Revenue | Debt affordability; bond covenant often ≤10% | Annual Debt Service / Total Operating Revenue | GL / Debt fund |
| Tuition Revenue Concentration | Revenue dependency risk | Net Tuition Revenue / Total Operating Revenue | GL |
| Advancement Revenue as % of Operating Revenue | Philanthropic support depth | Total Gift Revenue / Total Operating Revenue | Advancement / GL |
| Days of Cash on Hand | Liquidity | (Cash + Investments Available for Operations) / (Total Operating Expenses / 365) | GL / Treasury |

---

## 9. Major ERP Vendors

### 9.1 Public School District Platforms

#### Tyler Technologies (Munis + Infinite Campus)

Tyler Technologies is the dominant integrated vendor for K-12 public school districts. Tyler acquired Infinite Campus in 2021 for approximately $855 million, combining Munis (finance/HR/payroll ERP) with the leading mid-market K-12 SIS.

- **Tyler Munis:** Finance modules include GL, AP, AR, purchasing, budgeting, project accounting, and position control. HR/payroll covers certified and classified payroll with step-and-lane schedules, TRS remittance, substitute pay, and benefits administration. Munis is used by school districts of all sizes; strongest in mid-size to large districts that prefer tight finance/HR integration.
- **Infinite Campus:** K-12 SIS covering enrollment, attendance, scheduling, grade book, special education (IEP management), English learner tracking, behavior/discipline, state reporting, parent portal, and mobile app. Infinite Campus holds significant market share in states including Minnesota (origin state), Illinois, Wisconsin, Virginia, and others.
- **Integration:** Post-acquisition, Tyler is building native Munis–Infinite Campus integration; previously these were separate-vendor integrations requiring ETL.
- **Tyler SIS+:** Smaller SIS product line for smaller districts.
- **Weakness:** Munis is a mature product with deep functionality but a traditional UI; mid-market districts sometimes find implementation complex.

#### PowerSchool

PowerSchool is the largest K-12 SIS vendor by student count, serving approximately 55 million students across more than 17,000 customers globally as of 2024.

- **Products:** PowerSchool SIS (core), PowerSchool Unified Insights (analytics/assessment dashboard), Naviance (college and career readiness, acquired 2019), Special Programs (IEP/504/EL management), Enrollment Express, Ecollect Forms, Schoology LMS (acquired 2019), Frontline (HR — note: PowerSchool acquired Frontline in 2022 for approximately $2.8B; Frontline remained branded separately).
- **Ownership:** PowerSchool Holdings, Inc. completed its IPO (PWSC) in August 2021; Vista Equity Partners, which had taken the company private from Pearson in 2015, retained a majority stake post-IPO. The company was subsequently taken private again by Bain Capital in a transaction that closed in 2022 for approximately $5.7 billion.
- **December 2024 data breach:** A threat actor accessed PowerSchool's customer support portal (PowerSource) using a single compromised credential. The attacker exported student and educator records from the SIS databases of an undetermined number of school districts — affecting data including names, addresses, contact information, and in some districts, Social Security numbers and medical information. PowerSchool disclosed the breach to customers in January 2025. The breach affected millions of students and teachers across thousands of North American districts. FERPA breach obligations under state breach notification laws were triggered in multiple jurisdictions. The incident is a significant diligence factor for districts evaluating PowerSchool [20].
- **Strength:** Largest customer base enables broad integration ecosystem; Schoology LMS integration is native within the PowerSchool platform.
- **Weakness:** Breadth achieved through acquisition creates product fragmentation; legacy SIS codebase; December 2024 breach damaged trust.

#### Frontline Education

Frontline Education provides K-12-specific HR and workforce management products used by approximately 12,000 districts:

- **Frontline Absence & Substitute Management (formerly Aesop/SubFinder):** Absence submission, substitute job posting, sub filling (automated or manual), confirmation, and payroll integration. Dominant product in its category.
- **Frontline Recruiting & Hiring:** Applicant tracking system designed for school districts; integrates with EEOC reporting and position control.
- **Frontline Professional Growth:** Teacher evaluation, professional development tracking, goal management; aligned to state teacher effectiveness frameworks.
- **Frontline HRMS:** HR records management, onboarding, benefits administration.
- **Frontline Central:** Forms and workflow for HR processes (new hire paperwork, certification updates, position changes).
- **Note on ownership:** Frontline Education was acquired by PowerSchool in 2022; Frontline continues to operate under its own brand and product roadmap as of 2026.

#### Skyward

Skyward (Skyward, Inc., Waukesha, WI) provides an integrated SIS and finance ERP platform most commonly used by small to mid-size school districts:

- **Skyward SMS 2.0:** SIS covering enrollment, attendance, grade book, scheduling, special education, state reporting, parent/student portal.
- **Skyward Finance Management:** GL, payroll, HR, purchasing, fixed assets. Tightly integrated with SMS; single vendor for finance + SIS in smaller districts.
- **Strength:** Single-vendor integration at lower total cost; well-suited for districts with fewer than 10,000 students.
- **Weakness:** Less depth than Munis for large district finance complexity; smaller development team means slower feature velocity.

#### Aeries Technology

Aeries SIS is dominant in California, used by approximately 400+ California school districts. Deep CALPADS (California Longitudinal Pupil Achievement Data System) integration. Aeries was acquired by PowerSchool in 2021.

#### Other Public District Finance ERP Platforms

| Vendor | Product | Notes |
|---|---|---|
| LINQ (formerly EMS LINQ / Infinite Visions) | LINQ Finance, LINQ HR, LINQ Connect (nutrition) | Smaller-district finance ERP; strong in Southeast US; includes food service POS |
| Frontline Financial (formerly BusinessPLUS) | BusinessPLUS ERP | Finance and HR ERP for small/mid districts; Frontline acquired BusinessPLUS |
| Edupoint | Synergy SIS | SIS used in Pacific Northwest, Nevada, and other states |
| Forecast5 Analytics | Forecast5 | Multi-year financial forecasting tool layered over district financial data; not a full ERP |

### 9.2 Private School Platforms

#### Blackbaud K-12 Solutions

Blackbaud is the dominant technology vendor for private K-12 schools, covering advancement, finance, and (through FACTS/RenWeb) SIS and tuition management:

- **Blackbaud Financial Edge NXT:** Fund accounting ERP for nonprofit private schools; GL, AP, AR, grants, projects, endowment. Designed for FASB ASC 958 nonprofit accounting.
- **Blackbaud Raiser's Edge NXT:** Advancement CRM; gift management, pledge tracking, campaign management, constituent data. The most widely used advancement CRM in private K-12 and higher education.
- **FACTS Management (Blackbaud FACTS):** Tuition management (billing, payment plans, ACH/card processing) and financial aid assessment. Originally FACTS Financial; now part of Blackbaud. Also includes FACTS SIS (formerly RenWeb), a private school SIS with enrollment, attendance, grade book, and parent portal.
- **Blackbaud ON:** SIS/LMS platform for independent schools; covers enrollment, attendance, grades, learning management, parent portal.
- **Strength:** Integrated platform from advancement through finance; largest installed base in private K-12 nonprofit segment.
- **Weakness:** Multiple acquisitions have produced product fragmentation; pricing has increased significantly post-consolidation; some legacy modules lack modern UI.

#### Veracross

Veracross is an all-in-one independent school platform (SIS + admissions + tuition billing + development + LMS + athletics + health) on a unified data model:

- **Architecture:** Single database for all functions; no integration seams between modules. Student record, family record, constituent record all unified.
- **Modules:** Admissions, Enrollment, Billing, Development (gift management), Academics (grade book, scheduling), Health, Athletics, Alumni.
- **Market position:** Used by approximately 1,000+ independent schools globally; strong in NAIS-member boarding schools and day schools.
- **Weakness:** All-in-one approach means less depth than specialized products in each category; advancement module less mature than Raiser's Edge NXT.

#### TADS (Teachers' Aide Data Systems)

TADS provides financial aid needs assessment for independent schools, competing with SSS by NAIS. TADS also offers enrollment management and tuition payment services. Acquired by Blackbaud (merged into FACTS ecosystem).

#### Finalsite (Ravenna Enrollment)

Ravenna is the leading enrollment/admissions management platform for independent schools. Acquired by Finalsite in 2020. Used for inquiry-through-enrollment funnel management, online applications, decision communication. Integrates with Veracross, Blackbaud, and other private school ERP/SIS platforms.

#### Magnus Health (SMR)

Student medical record management for independent and private schools. Immunization tracking, medication administration, health alerts. Integrates with major private school SIS platforms. Acquired by Jonas Software.

---

## 10. Implementation Cautions

### 10.1 Public School Districts

**Never go live at school year start (August/September).** The first days of school are the highest-demand period for the SIS — scheduling, enrollment, bus assignments, meal account setup, and attendance all activate simultaneously. Any ERP/SIS malfunction at this moment is front-page news and exposes the district to immediate state reporting failures.

**LAUSD MiSiS failure (2014):** The Los Angeles Unified School District (640,000 students) deployed MiSiS (My Integrated Student Information System) at the start of the 2014–15 school year under political pressure to meet a court-ordered deadline tied to a special education compliance consent decree. The system launched with critical defects: counselors could not generate class schedules, thousands of students had no assigned courses, transcripts from the legacy system were not accessible, and IEP service logs were disrupted. Counselors and teachers manually tracked schedules on paper for weeks. The California Department of Education and the court monitor investigated. The total project cost exceeded $100 million; the root cause was a combination of insufficient pre-production testing, compressed timeline driven by external mandate, and inadequate data migration validation from the prior SIS (Data Director / MiSiS predecessor systems). This is the canonical K-12 ERP failure case [21].

**Payroll errors are catastrophically visible.** Teacher payroll errors on go-live trigger union grievances immediately. Steps and lanes must be migrated precisely; every salary schedule lane and step combination must be validated against current employee assignments before the first live payroll run. Run at minimum two parallel payrolls (live system and legacy system) and reconcile to the penny before cutting off the legacy system.

**State reporting submissions are hard deadlines.** CALPADS (California), PEIMS (Texas), EMIS (Ohio), PEIMS (Texas), and equivalent state systems have fixed submission windows. A new SIS that cannot produce state-compliant data by the first submission deadline creates legal compliance failure and may affect state funding calculations. State reporting readiness testing must be a formal gate in the go-live plan, not an afterthought.

**Position control migration is foundational.** Every authorized position — including vacant positions — must migrate to the new ERP with correct fund/function/object coding. Mid-year position control errors cause budget reporting failures, unauthorized hiring risk, and TRS remittance errors. Validate position control completeness against the board-adopted budget document before go-live.

**IDEA MOE look-back period.** IDEA Maintenance of Effort is computed against the prior year's local/state special education expenditures. If the prior year data is on a legacy system, the migration must preserve the exact prior-year numbers or the MOE calculation will fail. Document the MOE baseline from the legacy system before decommissioning.

**Charter school ERP complexity:** Charter Management Organizations (CMOs) operating multiple campuses require multi-entity consolidation. Depending on state law, each campus may be a separate legal entity (separate 990 filer, separate audit) or all campuses may be under one entity. ERP intercompany accounting must be configured before the first transaction is posted.

**Go-live timing recommendation:** End of fiscal year after June close is complete + before fall enrollment surge. Typical window: late July to early August, following completion of June 30 financial close on the legacy system and successful parallel payroll validation.

### 10.2 Private Schools

**Enrollment contract migration.** Every active enrollment contract must migrate to the new system before the first billing cycle. Errors in migrated contract amounts or payment plan structures create incorrect tuition bills — which families notice immediately. A miscalculated financial aid amount on an enrollment contract generates a relationship crisis, not just a data correction.

**Deferred revenue balance at cutover.** The deferred revenue balance at migration date must be computed precisely: sum of all tuition payments received in advance for services not yet delivered, minus any contract amounts already earned. An incorrect opening deferred revenue balance distorts the Statement of Activities for the entire year.

**Advancement data migration.** Pledge schedules, cumulative giving history, and donor relationship data are legally and relationally sensitive. Multi-year pledge balances that do not migrate correctly result in incorrect pledge receivable balances and potential incorrect acknowledgment of outstanding pledges. Validate top-100 donor records individually before go-live.

**Financial aid budget pressure during admissions season.** Admission decisions and financial aid offers happen February–April for most private schools. An ERP implementation that coincides with this window disrupts the admissions financial aid workflow at its most critical point. Plan go-live windows either before January (fall of prior year) or after May (post-enrollment confirmation season).

**IRS Form 990 first-year reporting.** The first Form 990 prepared from a new ERP system requires reconciliation of every revenue and expense category back to the prior system. Statement of Functional Expenses must foot to the GL; Schedule D (supplemental financial information) must reconcile to endowment and investment balances. Allow additional preparation time for the first-year 990 on the new platform.

**Voucher/ESA compliance onboarding.** Private schools newly participating in state voucher or ESA programs must configure their ERP to receive and track public funds separately from private tuition. Many school accounting systems are not preconfigured for government fund tracking; consult the state program administrator about required financial reporting formats before go-live.

---

## 11. Security and Compliance Depth

### FERPA in K-12 Context

FERPA (20 U.S.C. § 1232g; 34 CFR Part 99) [14] operates differently at K-12 than in higher education:

- **Rights holder:** Parents hold FERPA rights for students under 18. Rights transfer to the student ("eligible student") at age 18 or upon enrollment in a postsecondary institution. In K-12, almost all FERPA rights are held by parents.
- **Annual notification:** Schools must notify parents of FERPA rights annually. Notification may be collective (e.g., in a student handbook); individual mailing to each parent is not required.
- **Directory information:** Schools may designate certain information as directory information and disclose it without consent unless the parent opts out. Typical directory information: student name, address, telephone number, email, date and place of birth, enrollment dates, grade level, participation in activities and sports, honors and awards, most recent school attended. ERP must enforce the opt-out suppression flag across all directory exports and third-party integrations in real time.
- **School official exception:** Schools may disclose education records to "school officials" with "legitimate educational interest" without parent consent. ERP SaaS vendors are typically defined as school officials in the district's FERPA annual notice; this enables cloud-hosted SIS/ERP to operate under FERPA without triggering consent requirements for each data access.
- **FERPA and discipline records:** Disciplinary records are education records and FERPA-protected, with a narrow exception allowing disclosure of crimes of violence to victims (20 U.S.C. § 1232g(h)). ERP access controls must restrict discipline record access to authorized staff roles.

### COPPA (Children's Online Privacy Protection Act)

- **Scope (15 U.S.C. § 6501–6506; 16 CFR Part 312) [15]:** Applies to operators of websites or online services directed at children under 13, or operators with actual knowledge they are collecting personal information from children under 13.
- **School consent exception:** A school may act as an agent for parents and consent on behalf of parents to the collection of student data by ed-tech operators used for educational purposes, provided the school's authorization covers only school-authorized uses. ERP and SIS vendors relying on this exception must contractually limit data use to the school's educational purpose, prohibit targeted advertising, and not sell or disclose student data to third parties.
- **Data minimization and deletion obligations:** COPPA operators must collect only data necessary for the service; provide parents access to review and delete data; delete data when no longer needed. ERP student data purge workflows must support deletion of records for students who were under 13 at the time of data collection, on parental request.

### State Student Data Privacy Laws

| Law | Jurisdiction | Key Requirements | ERP Implication |
|---|---|---|---|
| CA AB 1584 (2014) / CA Ed Code § 49073.1 [22] | California | Contracts with ed-tech vendors must include specific privacy terms; student data cannot be used for targeted advertising; data deleted on request | All SIS/ERP vendor contracts must comply with AB 1584 terms; districts publish annual list of approved vendors |
| NY Education Law § 2-d (2014, regulations 2020) [23] | New York | Written Parent Bill of Rights required; Data Privacy Agreements (DPAs) with all vendors; district Chief Privacy Officer | All ERP/SIS vendors must execute a DPA; NYSED has a standard DPA template |
| CO Student Data Transparency and Security Act (CRS § 22-16-101) [24] | Colorado | Operator agreements required; operators prohibited from selling data, using for targeted advertising, building profiles outside ed purpose | Vendor agreements must include statutory operator obligations |
| TX Education Code § 32.151 [25] | Texas | Student privacy in ed tech; vendor contracts required; operators cannot collect, use, or share data beyond contracted ed purpose | PEIMS data handling and vendor contracts governed by TEC § 32.151 |

All 50 states have enacted breach notification laws requiring notification to affected individuals when unencrypted personal information (including student education records) is accessed by unauthorized persons. FERPA does not independently mandate breach notification, but state laws apply. Notification timelines range from 30 to 90 days; some states (e.g., Florida, Colorado) require notification within 30 days.

### CIPA (Children's Internet Protection Act, 47 U.S.C. § 254(h)(5)) [11]

Required for E-rate eligibility. ERP must maintain records of:
- Board-adopted internet safety policy (with date of adoption and most recent amendment)
- Annual public hearing/meeting at which the policy was available for comment (required before initial adoption; not required for amendments)
- Technology protection measure (content filter) in operation across all computers with internet access
- CIPA certification submitted with each E-rate Form 486 (Receipt of Service Confirmation)

### Segregation of Duties in K-12 ERP

| Domain | Required Separation |
|---|---|
| Payroll | Payroll setup (adding employees, changing rates) // Payroll processing and approval // Payroll payment release — three roles; same person cannot set up and approve their own changes |
| Purchasing | Purchase requisition // Purchase order approval // Invoice approval // Payment release — four-way separation above district-defined thresholds |
| Grant Management | Grant expenditure posting // Grant budget vs. actual review // Grant drawdown/claim submission — three roles per 2 CFR Part 200 |
| Student Accounts (private school) | Tuition billing calculation // Cash receipts posting // Financial aid award approval // Write-off authorization — four roles |
| Advancement (private school) | Gift entry // Gift acknowledgment // Fund designation // Bank deposit reconciliation — three roles |
| Child Nutrition | Meal eligibility determination // Meal count recording // Monthly claim submission — two roles minimum |

### Cybersecurity and Incident Response

**K-12 Cybersecurity Act of 2021 (Division K, Title III, Subtitle G of PL 117-58, Infrastructure Investment and Jobs Act):** Directs CISA to develop K-12-specific cybersecurity resources including a vulnerability disclosure policy, training, and best-practice guidance for school systems [26].

**Notable ransomware attacks on school districts:**
- **Los Angeles USD (September 2022):** Vice Society ransomware group attacked LAUSD infrastructure; district refused to pay ransom; approximately 500 GB of data published on Vice Society's leak site, including employee and student records. District activated incident response and engaged CISA. ERP and SIS systems were temporarily disrupted at the start of the school year [27].
- **Clark County School District, Nevada (August 2020):** Ransomware attack during COVID-19 remote learning transition; district refused ransom; attacker published data including employee SSNs [28].
- **Baltimore County Public Schools (November 2020):** Ransomware attack forced full shutdown of network systems including SIS, email, and learning management; schools were in remote-learning mode. Recovery took weeks [29].
- **PowerSchool breach (December 2024):** Threat actor accessed the PowerSchool customer support portal (PowerSource) using a compromised credential; exported student and educator database tables from thousands of North American districts. Affected data included names, contact information, dates of birth, and in some districts SSNs and medical/alert information. PowerSchool disclosed to customers January 7, 2025 [20].

**ERP-specific security controls:**
- **RBAC on student records:** Access to student records (academic, discipline, special education, health) must be role-gated at the API and database layer, not just the UI. IEP records require an additional access tier beyond general student record access.
- **Database encryption at rest:** AES-256 for all student PII, including legacy SIS databases still in production. Cloud SIS/ERP must document encryption key management.
- **Audit logging:** All create/read/update/delete operations on student records logged with user identity, timestamp, and record identifier. Retention: minimum 5 years for financial aid records (34 CFR 668.24), 3 years for federal award records (2 CFR § 200.334); longer for state-specific requirements.
- **Multifactor authentication (MFA):** Required for all administrative access to SIS/ERP systems. Staff portal MFA enforced via SSO provider (Azure AD / Google Workspace). Privileged accounts (DBA, system administrator) require MFA + session recording.
- **Vendor access controls:** Third-party ed-tech vendors accessing district SIS data must execute Data Processing Agreements defining data use limitations, breach notification obligations, and audit rights.

---

## See Also

- `verticals/education.md` — Higher education ERP (Title IV federal financial aid, sponsored research under 2 CFR 200, endowment accounting, SIS-ERP integration seam at the university level)
- `verticals/government-publicsector.md` — GASB standards foundation, fund accounting, appropriation control, 2 CFR Part 200 grant compliance, Single Audit
- `verticals/nonprofit-ngo.md` — FASB ASC 958 nonprofit accounting, donor management, functional expense allocation applicable to private schools
- `core/security.md` — RBAC/ABAC patterns, audit logging architecture, PAM for privileged accounts
- `core/features-core.md` — Core HR/payroll module fundamentals, fund accounting patterns

---

## Citations & Sources

1. GASB Statement No. 54, "Fund Balance Reporting and Governmental Fund Type Definitions" (2009, effective for fiscal years beginning after June 15, 2010). https://gasb.org/standards
2. GASB Statement No. 68, "Accounting and Financial Reporting for Pensions—an amendment of GASB Statement No. 27" (2012, effective for fiscal years beginning after June 15, 2014). https://gasb.org/standards
3. GASB Statement No. 75, "Accounting and Financial Reporting for Postemployment Benefits Other Than Pensions" (2015, effective for fiscal years beginning after June 15, 2017). https://gasb.org/standards
4. GASB Statement No. 87, "Leases" (2017, effective for fiscal years beginning after June 15, 2021). https://gasb.org/standards
5. GASB Statement No. 96, "Subscription-Based Information Technology Arrangements" (2020, effective for fiscal years beginning after June 15, 2022). https://gasb.org/standards
6. Every Student Succeeds Act (ESSA), PL 114-95, 20 U.S.C. § 6301 et seq. (2015). https://www.congress.gov/bill/114th-congress/senate-bill/1177/text
7. OMB, 2 CFR Part 200 (Uniform Guidance), final revision April 22, 2024, effective October 1, 2024 for new awards. Single Audit threshold raised to $1,000,000 at § 200.501. https://www.ecfr.gov/current/title-2/part-200
8. Individuals with Disabilities Education Act (IDEA), 20 U.S.C. § 1400 et seq. Part B Grants to States at § 1411 (ages 3–21) and § 1419 (ages 3–5). https://sites.ed.gov/idea/statute-chapter-33/subchapter-ii/
9. IDEA implementing regulations, 34 CFR Part 300. MOE at § 300.203; Excess cost at § 300.202; CEIS at § 300.226; Initial evaluation timeline (60 days) at § 300.301. https://www.ecfr.gov/current/title-34/part-300
10. FCC/USAC, E-rate Schools and Libraries Program, 47 CFR Part 54, Subpart F. C2 per-student budget and discount rates. https://www.usac.org/e-rate/
11. Children's Internet Protection Act (CIPA), 47 U.S.C. § 254(h)(5), enacted 2000, upheld in United States v. American Library Ass'n, 539 U.S. 194 (2003). https://www.fcc.gov/consumers/guides/childrens-internet-protection-act
12. Richard B. Russell National School Lunch Act, 42 U.S.C. § 1751 et seq.; National School Lunch Program regulations at 7 CFR Part 210; School Breakfast Program at 7 CFR Part 220; CEP at 42 U.S.C. § 1759a. USDA FNS reimbursement rates updated annually each July. https://www.fns.usda.gov/nslp and https://www.fns.usda.gov/sbp
13. GASB Statement No. 34, "Basic Financial Statements—and Management's Discussion and Analysis—for State and Local Governments" (1999). https://gasb.org/standards
14. Family Educational Rights and Privacy Act (FERPA), 20 U.S.C. § 1232g; implementing regulations at 34 CFR Part 99. Student Privacy Policy Office. https://studentprivacy.ed.gov
15. Children's Online Privacy Protection Act (COPPA), 15 U.S.C. § 6501–6506; FTC implementing rule at 16 CFR Part 312. https://www.ftc.gov/legal-library/browse/rules/childrens-online-privacy-protection-rule-coppa
16. NCCUSL, "Uniform Prudent Management of Institutional Funds Act" (2006); adopted in 49 states + DC + USVI. https://www.uniformlaws.org
17. FASB ASU 2016-14, "Presentation of Financial Statements of Not-for-Profit Entities" (effective for fiscal years beginning after December 15, 2017). FASB ASC 958. https://asc.fasb.org
18. Arizona Empowerment Scholarship Account (ESA) Program, ARS § 15-2401 et seq. Arizona Department of Education. https://www.azed.gov/esa
19. Indiana Choice Scholarship Program, IC 20-51-1 et seq. Indiana Department of Education. https://www.in.gov/doe/students/indiana-choice-scholarship-program/
20. PowerSchool, "Security Incident Notification," January 7, 2025 — breach of PowerSource customer support portal via compromised credential; student and educator records exported from district SIS databases; disclosed to customers January 2025. https://www.powerschool.com/security-incident/ — See also TechCrunch coverage, January 2025.
21. Los Angeles Times, "L.A. school district's troubled $95-million computer system" — LAUSD MiSiS failure, 2014; scheduling failures at school year start; court monitor involvement (related to CL v. Lemons special education consent decree). https://www.latimes.com
22. California Education Code § 49073.1 (AB 1584, 2014); California Student Privacy Alliance (CSPA) model contracts. https://leginfo.legislature.ca.gov
23. New York Education Law § 2-d (enacted 2014); implementing regulations by NYSED (effective 2020). https://www.nysed.gov/data-privacy-security
24. Colorado Student Data Transparency and Security Act, CRS § 22-16-101 et seq. https://leg.colorado.gov
25. Texas Education Code § 32.151 — student data privacy. https://statutes.capitol.texas.gov
26. K-12 Cybersecurity Act of 2021, Division K, Title III, Subtitle G of PL 117-58 (Infrastructure Investment and Jobs Act, November 15, 2021). CISA K-12 resources: https://www.cisa.gov/k-12-schools
27. CISA, "Los Angeles Unified School District Ransomware Attack" (September 2022) — Vice Society; CISA advisory AA22-249A. https://www.cisa.gov/news-events/cybersecurity-advisories/aa22-249a
28. Clark County School District ransomware attack, August 2020 — threat actor published employee PII after district refused ransom payment. Confirmed by district communications; reported by TechCrunch and ZDNet, August–September 2020.
29. Baltimore County Public Schools ransomware attack, November 24, 2020 — full network shutdown; district enrolled in CISA's free cybersecurity services post-incident. https://www.bcps.org
30. IRS Topic 417, "Earnings for Clergy"; IRS Publication 1828, "Tax Guide for Churches & Religious Organizations" — housing allowance under IRC § 107. https://www.irs.gov/taxtopics/tc417 and https://www.irs.gov/pub/irs-pdf/p1828.pdf
31. Gaylor v. Mnuchin, 919 F.3d 420 (7th Cir. 2019) — upholding IRC § 107(2) clergy housing allowance exclusion.
32. IRS, "Annual Exempt Organization Return: Who Must File" — Form 990/990-EZ/990-N filing thresholds and deadlines. https://www.irs.gov/charities-non-profits/annual-exempt-organization-return-who-must-file
33. IRS, "Unrelated Business Income Tax"; IRS Publication 598, "Tax on Unrelated Business Income of Exempt Organizations." https://www.irs.gov/charities-non-profits/unrelated-business-income-tax
34. Bob Jones University v. United States, 461 U.S. 574 (1983); IRS Revenue Ruling 71-447; IRS TEGE, "Private Schools — Discrimination Guidance," EO Topic B-84. https://www.law.cornell.edu/supremecourt/text/461/574 and https://www.irs.gov/pub/irs-tege/eotopicb84.pdf
35. NAIS ICAISA, "Approved Accreditors for NAIS Membership"; Cognia, "Accreditation for Non-Public Schools." https://www.nais.org/membership/international-council-advancing-independent-school-accreditation/approved-accreditors-for-nais-membership and https://www.cognia.org/non-public/
36. GGG LLP, "Considering ERP Financial Software for Your Diocese? Start with the Chart of Accounts Dimensions"; ParishSOFT, "Consolidation for Dioceses." https://www.gggllp.com/considering-erp-financial-software-for-your-diocese-start-with-the-chart-of-accounts-dimensions/ and https://www.parishsoft.com/consolidation-for-dioceses/
37. ICE SEVP, "Governing Regulations for Schools" (SEVIS/I-20, F-1 compliance); Sprintax, "F-1 Visa Tax Return Guide for International Students" (Form 1042-S NRA withholding). https://www.ice.gov/sevis/schools/reg and https://blog.sprintax.com/f1-visa-tax-return-guide-international-students/
