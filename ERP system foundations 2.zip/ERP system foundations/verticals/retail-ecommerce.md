# ERP for Retail & E-Commerce

<!-- kind: vertical -->

---

## 1. Overview

Retail and e-commerce impose a distinctive set of ERP requirements that diverge sharply from manufacturing or professional-services verticals. The combination of high transaction velocity, extreme SKU proliferation, multi-channel order origination, real-time customer expectations, and thin gross margins produces system demands that generic ERP architecture handles poorly without vertical-specific modules.

**Multi-channel complexity.** A mature omnichannel retailer operates concurrently across brick-and-mortar stores, a branded e-commerce site, native mobile apps, marketplace storefronts (Amazon, Walmart, eBay, TikTok Shop), and emerging social-commerce channels. Each channel generates orders with different fulfillment requirements, tax jurisdictions, payment methods, and return policies. The ERP must maintain a unified order pool and a single version of inventory truth across all of them.

**Velocity and volume.** A mid-sized e-commerce operation may process tens of thousands of orders per day; a large multi-channel retailer can spike to hundreds of thousands of transactions per hour on peak events (Black Friday, Cyber Monday). SKU counts routinely exceed 500,000 for fashion/apparel (style × color × size matrix). Batch-oriented inventory updates that suffice in manufacturing ERP cause stock-out and oversell events at retail scale.

**Customer-centricity.** Retail ERP must resolve a unified customer identity across POS swipe, web login, loyalty card scan, and marketplace guest checkout. This is qualitatively different from a goods-centric view: the same physical item may be sold to the same customer across five channels with five different transaction identifiers.

**Real-time inventory as competitive weapon.** Available-to-promise (ATP) accuracy drives conversion rate on the web, prevents BOPIS failures in-store, and determines whether ship-from-store is viable. Periodic batch inventory refresh — standard in many ERP deployments — is operationally unacceptable.

**Margin pressure and markdown precision.** Grocery operates at 1–3% net margin; apparel specialty retail at 4–8%. Markdown timing and depth decisions executed through the ERP's promotion engine directly determine whether perishable or seasonal inventory converts to margin or write-down. The difference between a 30% and 40% markdown on 20,000 units is measurable EBITDA impact.

**Regulatory surface area.** Every payment touchpoint is within PCI DSS v4.0.1 scope. Loyalty programs that collect PII trigger GDPR (EU Regulation 2016/679), CCPA (California, effective 2020), and CPRA (effective 2023). Cross-border e-commerce adds customs duty rules, EU VAT IOSS obligations, and consumer protection laws.

See `core/features-core.md` for generic ERP capabilities that apply across all verticals.

---

## 2. Industry-Specific Modules

### Point-of-Sale (POS) Integration & Unified Commerce

The ERP does not typically run POS software directly; instead it provides an adapter layer that ingests POS events in near-real-time.

- **Hardware-agnostic adapter.** Cloud POS systems (Shopify POS, Square for Retail, Lightspeed Retail, Cegid Y2) emit order and payment events via REST webhooks. Legacy thick-client POS (NCR Counterpoint) typically uses end-of-day flat-file or database-level integration. The ERP adapter must handle both patterns without requiring POS replacement.
- **Real-time tender posting to GL.** Each tender type (cash, credit/debit card, gift card, BNPL, store credit) maps to a separate GL account and must post within the same business day. Split-tender transactions (gift card + Visa) require the adapter to decompose a single transaction into multiple GL postings.
- **End-of-day reconciliation and blind close.** The blind close process posts store-reported cash totals against computed totals; variances are written to an over/short GL account. Automated reconciliation reduces manual store-level accounting labor.
- **Store-and-forward for network outage resilience.** POS must queue transactions locally during connectivity loss and replay them in sequence upon reconnection without creating duplicate GL postings. The ERP must deduplicate on transaction UUID.
- **Mobile POS (mPOS) and clienteling tablets.** mPOS devices used for line-busting or pop-up stores generate the same event stream; clienteling tablets add customer lookup, wish-list, and purchase-history read access against the ERP customer master without write permission to GL.

### Omnichannel Order Management System (OMS)

The OMS is the orchestration layer between channel platforms and fulfillment. It is often a specialized module or stand-alone system (e.g., Oracle Retail OMS Cloud Service, Manhattan Active Omni) that integrates bidirectionally with the ERP financial and inventory backbone.

- **Single order pool.** All orders — web, POS, app, marketplace, call center — enter one logical order pool. Channel of origin is an attribute, not a separate data silo.
- **Fulfillment routing engine.** The routing engine evaluates real-time ATP across the location network and applies configured priority rules: BOPIS (Buy Online, Pick Up In Store), ship-from-store (SFS), DC fulfillment, dropship, and curbside pickup. Rules account for location proximity, inventory level, carrier cut-off times, and cost-to-serve.
- **Real-time ATP (Available-to-Promise).** ATP = on-hand − reserved − safety stock + in-transit (where in-transit is confirmed). The OMS must recompute ATP at the time of order capture, not from a nightly batch.
- **Endless aisle.** Virtual inventory from the DC or supplier catalog is made visible to store associates on clienteling tablets. An endless-aisle order routes for direct shipment without requiring physical presence at the store.
- **Customer-facing order tracking.** Event-driven notification pipeline (order confirmed → allocated → picked → shipped → delivered) using carrier tracking APIs and push notification / email triggers.
- **Split-shipment and partial fulfillment.** When a multi-line order cannot be fulfilled from a single location, the OMS splits lines into sub-shipments. Each sub-shipment generates an independent fulfillment record; revenue recognizes per shipment under ASC 606 / IFRS 15 when control transfers.

### Inventory Management Across Locations

- **Store-level perpetual inventory.** Each store maintains a running SOH (stock on hand) that decrements on POS sale, increments on receiving, and adjusts on cycle count. Perpetual accuracy depends on disciplined receiving and return disposition.
- **RFID integration.** Zebra Workcloud Inventory Visibility (formerly SmartCount) and Impinj RAIN RFID fixed readers emit read events that the ERP inventory module reconciles against expected SOH. RAIN RFID raises IRA (Inventory Record Accuracy) from a typical baseline of 60–65% to 95–99% in apparel [1], which is the minimum threshold for BOPIS viability. The Auburn RFID Lab's multi-year apparel benchmarks document the move from a 63% SKU-level accuracy baseline to 95%+ post-RFID deployment.
- **Multi-node ATP with tiered safety stock.** Safety stock levels differ by location tier: flagship store > regional store > DC > 3PL. The ATP calculation respects tier-level safety stock floors.
- **Inter-store transfer orders.** Store-to-store transfers require a transfer order in the ERP with origination pick confirmation and destination receiving. GL entries debit inventory at destination, credit at origin at transfer cost (not retail).
- **Landed cost calculation.** For imported goods, the ERP allocates freight, duty, insurance, and broker fees to unit cost using a landed cost module. This feeds COGS accurately and informs markdown threshold calculations.

### Demand Forecasting & Replenishment

- **Statistical forecasting.** Retail demand forecasting applies time-series models (exponential smoothing / Holt-Winters, ARIMA) and increasingly ML-based models (gradient boosting, neural networks) to historical sales, adjusted for seasonality curves, store lifecycle stage, and assortment changes. SAP Customer Activity Repository (CAR) includes the Unified Demand Forecast (UDF) module using ML algorithms. Oracle Retail Demand Forecasting Cloud Service and Blue Yonder Luminate Planning and Relex Solutions are dedicated platforms in this space.
- **Promotional uplift modeling.** A promotional event calendar defines expected lift factors by promotion type and product category. The forecasting engine overlays uplift on the baseline statistical forecast.
- **Automated store replenishment.** When SOH − reserved < reorder point, the system generates a replenishment order (store-to-DC or DC-to-store) automatically. Min/max par levels are configurable by store × SKU or store cluster × category.
- **Vendor-managed inventory (VMI).** For large supplier programs, the ERP can emit inventory position data to the supplier's system, which triggers replenishment orders without buyer intervention.

### Merchandise & Assortment Planning

- **Assortment planning by store cluster.** Not every SKU is carried at every store. The assortment planning module defines which style/color/size combinations are ranged by store cluster, climate zone, or demographic profile. This drives the product hierarchy depth typical in retail (Division → Department → Class → Subclass → Style → Color → Size) — deeper than manufacturing's BOM-centric hierarchy.
- **Open-to-buy (OTB) budget management.** OTB tracks planned vs. committed buying budgets by department and season. The ERP enforces OTB limits on purchase order creation.
- **Planogram and space planning integration hooks.** Space planning tools (Blue Yonder Space, Quant Retail) output shelf-space allocations that drive facings and replenishment quantities; the ERP integration receives these as location-level assortment overrides.
- **Buyback and vendor return (VR) authorization management.** Slow-moving inventory may be returned to vendors under buyback agreements. VR authorization creates a credit memo expectation against the vendor's AP balance.

### Promotion & Markdown Management

| Promotion Type | Description | ERP Handling |
|---|---|---|
| Percentage off | 10% off all denim | Discount calculated at line level; contra-revenue posting |
| BOGO | Buy one get one free/50% off | Second unit priced at zero or half; requires quantity-aware discount engine |
| Threshold | Spend $100, get $20 off | Order-level discount applied when cart total crosses threshold |
| Loyalty-exclusive | Gold members only | Loyalty tier validated at POS or web checkout before applying |
| Price override | Manager override at POS | Requires SoD control; override logged with associate ID and reason code |
| Clearance markdown | Permanent price reduction | Replaces list price; markdown % recorded against original cost for GMROI tracking |

- **Stacking rules and exclusion logic.** The promotion engine must evaluate stacking eligibility — which promotions combine with others, which are mutually exclusive. Untested stacking rules are a common source of unintended margin giveaway.
- **Scheduled markdown cadence.** Initial markdown at week N, subsequent markdown at week N+4, clearance at week N+8. The markdown schedule is configured in the ERP with automated price change events.
- **Markdown optimization.** Price elasticity modeling determines the markdown depth that maximizes net revenue recovery vs. holding cost. Some retailers use dedicated markdown optimization engines (Revionics, Aptos Merchandising) integrated to the ERP.
- **Promotion accounting.** Promotional discounts are classified as contra-revenue (reduce net sales) under US GAAP and IFRS 15; cooperative advertising reimbursements from vendors may offset SG&A. Correct classification matters for gross margin reporting.

### Loyalty & Customer Programs

- **Points accrual engine.** Earn rules are configured by channel, tender type, and product category. For example: 2× points on private-label brands, no points on gift card purchases, 1 point per dollar on all other tender.
- **Tier management.** Silver/Gold/Platinum tiers with configurable promotion windows, benefit triggers, and tier-maintenance requirements. Tier changes must fire real-time events to downstream CRM and email platforms.
- **ASC 606 / IFRS 15 deferred revenue.** Loyalty points constitute a separate performance obligation under FASB ASC 606 and IFRS 15 — Revenue from Contracts with Customers. The ERP must allocate a portion of the transaction price to the points at their standalone selling price (SSP), deferring that amount until points are redeemed or expire. This creates a contract liability on the balance sheet.
- **Breakage estimation.** Not all points will be redeemed. The ERP must estimate breakage (forfeiture) and recognize the corresponding deferred revenue proportionately as redemption patterns emerge, or when redemption becomes remote. Breakage estimates require periodic actuarial true-up.
- **Integration with CDP/CRM.** The unified customer profile lives in a Customer Data Platform (CDP) such as Adobe Experience Platform or Salesforce Marketing Cloud; the ERP loyalty module is the source of truth for points balance and tier, and pushes updates to the CDP via event stream.

### Returns & RMA Management

- **Cross-channel returns (BORIS).** Buy Online, Return In Store requires the store associate to look up the original online order, validate the items, and issue the refund to the original tender without requiring the customer to have a receipt. The OMS must be the order-of-record system.
- **Return disposition routing.** Returned inventory is not automatically restocked. Disposition rules route items to: full restock (new-condition items), refurbishment (minor defects), liquidation (heavily worn), or vendor return (under VR authorization).
- **Fraud detection rules.** Configurable rules engine flags suspicious return patterns: max N returns per customer per 30 days, no-receipt return value ceiling, cross-channel return velocity. High-fraud categories (electronics, cosmetics) carry tighter thresholds.
- **Refund tender matching.** Refund to original payment method is the default. Exceptions (original card expired, marketplace order) route to store credit or ACH, with documented reason codes.
- **Reverse logistics cost capture.** Return shipping labels issued by the retailer generate carrier costs that must be allocated to the return order for true cost-of-returns analysis.

### Gift Cards

- **Physical and digital issuance.** Gift card numbers are issued through the POS or e-commerce checkout. The card number must be stored hashed or tokenized in the ERP; only the last four digits are stored in cleartext.
- **Split-tender redemption.** A single transaction may apply a partial gift card balance plus a residual payment method. The ERP must handle the split and post each tender to the correct GL account.
- **Unearned revenue liability.** Gift card proceeds are a liability (deferred revenue) until redeemed. Breakage is recognized when redemption becomes remote under ASC 606, or proportionately using the redemption pattern method.
- **State escheatment.** Unredeemed gift card balances are subject to unclaimed property laws in the US. Dormancy periods vary by state (commonly 3–5 years, with some states as low as 1 year). The ERP must track card-level issue date, last activity date, and customer domicile state to route escheatment remittances correctly. Failure to file is subject to state AG enforcement.
- **Inter-company clearing.** When a gift card is sold in one legal entity (store) and redeemed in another, the ERP must generate an inter-company payable/receivable clearing entry.

### Marketplace Integration

| Marketplace | Primary API | Order Ingestion | Inventory Push | Settlement |
|---|---|---|---|---|
| Amazon | SP-API (REST; MWS fully deprecated as of 2023) | Order webhook / polling | FBA vs. FBM inventory feeds | 14-day disbursement cycle; settlement report |
| Shopify | Admin API + webhooks | Order Created webhook | Inventory Levels API | Shopify Payments payout file |
| Walmart Marketplace | Walmart Marketplace API | Order notification | Inventory Feed API | Weekly ACH disbursement |
| eBay | eBay Sell APIs (REST; Trading API calls phased out 2025–2026) [2] | Fulfillment API / Notifications | Inventory API | eBay managed payout |
| TikTok Shop | TikTok Shop API | Order event webhook | Product inventory sync | Settlement file |

Fee/commission netting is a major GL reconciliation challenge: Amazon FBA fees, referral fees, advertising chargebacks, and returns are netted against gross sales in the settlement file. The ERP must accrue marketplace revenue daily at the order level and reconcile to settlement on disbursement, not recognize revenue at settlement date.

### Clienteling

- **360° customer view at POS/tablet.** Store associates access purchase history, open orders, wish lists, loyalty tier, notes, and product affinity data at the POS terminal or clienteling tablet. Data is read from the ERP customer master and CDP.
- **Appointment scheduling and outreach logging.** High-end specialty retail and luxury segments log associate-customer outreach (call, text, in-store appointment) against the customer record for continuity across associate handoffs.
- **Product recommendation engine.** ML-based recommendation engine surfaces top recommendations at the point of associate interaction. Integration point is a recommendation API call from POS → recommendation microservice → ERP product catalog.

### Store Replenishment

- **Automated replenishment triggers.** When SOH falls below the reorder point, the system generates a replenishment suggestion or auto-approves a transfer order from the supplying DC, depending on configured automation level.
- **DC pick wave generation.** Consolidated store replenishment orders are batched into pick waves at the DC. The WMS (e.g., Manhattan Associates WMS, Blue Yonder WMS, Deposco, ShipBob) receives wave instructions from the ERP or OMS.
- **Cross-docking.** High-velocity, predictable-demand SKUs bypass DC put-away and flow directly from inbound receiving dock to outbound store shipment lanes. The ERP must recognize cross-dock receipts and generate store ASNs without creating intermediate inventory movements.

---

## 3. Regulatory & Compliance Requirements

### Payment Card Security

**PCI DSS v4.0.1** [3] (PCI Security Standards Council) is the current active version. PCI DSS v3.2.1 was retired 2024-12-31. All future-dated requirements in PCI DSS v4.0 became mandatory 2025-03-31. Engineers should not reference v3.2.1 in new system designs.

**SAQ types by merchant configuration:**

| SAQ | Applicability | Approximate Scope |
|---|---|---|
| SAQ A | Card-not-present; payment page fully outsourced; no CHD on merchant systems. From 2025-03-31, Req 6.4.3 and 11.6.1 are NOT included; instead, merchant must attest the entire website is not susceptible to script-based attacks affecting e-commerce systems. | ~22 requirements |
| SAQ A-EP | E-commerce with payment page partially controlled by merchant; Requirements 6.4.3 and 11.6.1 apply in full | ~191 requirements |
| SAQ B | Imprint machines or standalone dial-up terminals only | ~41 requirements |
| SAQ B-IP | Standalone IP-connected terminals; no e-commerce | ~83 requirements |
| SAQ C | Payment application systems connected to internet | ~160 requirements |
| SAQ C-VT | Web-based virtual terminal (manually keyed transactions) | ~136 requirements |
| SAQ P2PE | Merchants using a PCI SSC-listed P2PE solution; significantly reduced scope vs. SAQ D | ~35 requirements |
| SAQ D | All other merchants and service providers not covered above | ~250+ requirements |

**P2PE (Point-to-Point Encryption).** A PCI-validated P2PE solution encrypts cardholder data at the hardware terminal (swipe/dip/tap) and decrypts only within the payment processor's HSM. The ERP and POS software never see a plaintext PAN. Using a PCI SSC-listed P2PE solution is the most effective scope-reduction strategy for card-present retailers.

**Tokenization.** The payment processor or Token Service Provider (TSP) replaces the PAN with a merchant token (processor-specific) or network token (Visa Token Service / VTS; Mastercard Digital Enablement Service / MDES). The ERP stores only the token for order-level reference; the PAN is never written to ERP tables.

**Key PCI DSS v4.0.1 requirements for ERP/OMS engineers:**
- **Req 6.4.3 (applies to SAQ A-EP and SAQ D, NOT SAQ A):** Maintain an inventory of all scripts on the payment page; each script must have a documented business justification, be authorized, and have its integrity verified (Subresource Integrity / SRI hashes or CSP `script-src` with hash directives).
- **Req 11.6.1 (applies to SAQ A-EP and SAQ D, NOT SAQ A):** Deploy a change/tamper detection mechanism on the payment page; assess at minimum weekly. Unauthorized changes to payment page content or HTTP headers must generate an alert.
- **Req 3.3.1:** Do not store SAD (sensitive authentication data) including CVV/CVC after authorization, even encrypted.
- **Req 3.5.1:** PAN must be masked in any display; only the first six and last four digits may be visible to personnel without business need.

**PCI SSF (Software Security Framework).** PCI SSC retired PA-DSS and replaced it with the Software Security Framework (SSF) consisting of two independent standards: the Secure Software Standard (v1.2, published December 2022, with a Web Software Module) and the Secure SLC (Software Lifecycle) Standard [4]. Any new payment application developed or purchased should be validated against the SSF, not the legacy PA-DSS.

### Consumer Privacy

| Regulation | Jurisdiction | Key Obligations for ERP/Loyalty |
|---|---|---|
| GDPR (EU Regulation 2016/679) | EU/EEA | Consent for loyalty PII collection; Art. 17 right to erasure; Art. 20 data portability; Art. 22 restrictions on automated profiling (affects recommendation engines) |
| UK GDPR | United Kingdom (post-Brexit) | Equivalent to EU GDPR; separate ICO registration required |
| CCPA (effective 2020) / CPRA (effective 2023) | California, USA | Opt-out of sale/sharing; right to deletion; right to correct; expanded sensitive personal information category |
| Canada PIPEDA | Canada | Consent-based data collection; right of access and correction. Bill C-27 (Consumer Privacy Protection Act) died on the order paper when Parliament was prorogued January 2025; a successor statute is expected in late 2025 or 2026 — verify current enactment status before relying on any CPPA provisions [5] |

### Revenue Recognition

- **FASB ASC 606 / IFRS 15 — Revenue from Contracts with Customers.** Effective for US public entities from fiscal years beginning after December 15, 2017.
  - **Gift cards:** Proceeds create a contract liability (deferred revenue). Revenue recognized at redemption. Breakage recognized proportionately as redemption occurs (if breakage is probable and can be estimated) or when redemption becomes remote.
  - **Loyalty points:** Constitute a separate performance obligation. The transaction price is allocated between the goods sold and the points at their relative standalone selling prices. Points liability deferred until redemption or expiration.
  - **Layaway sales:** Revenue deferred until the customer picks up the merchandise (no control transfer until pickup).

### Consumer Protection & Trade

- **FTC Retail Guides (US):** Advertising prices must be genuine; sale and promotional prices must represent a meaningful reduction from a bona fide former price. Violating this triggers FTC enforcement actions.
- **Truth in Lending Act (TILA):** Applies to BNPL (Buy Now Pay Later) and installment payment options displayed in checkout. Disclosure of APR, total payment, and terms is required before commitment.
- **EU Consumer Rights Directive 2011/83/EU:** Online consumers have a 14-day withdrawal right (cooling-off period). ERP return processing must support no-fault returns within this window for EU customers.
- **GDPR Art. 22:** Automated decision-making restrictions apply to profiling that produces legal or similarly significant effects. Recommendation engines that determine credit eligibility or produce segmentation with material consequences require human review safeguards.

### Import/Export & Duties

- **US Section 321 de minimis — status as of mid-2026:** [6] The $800 per-person-per-day duty-free threshold, previously available for most origins, has been suspended. The exemption was revoked for shipments from China and Hong Kong effective May 2, 2025, and subsequently suspended for all country origins effective August 29, 2025. A February 2026 White House proclamation confirmed the suspension continues indefinitely. ERP customs duty calculation modules must be updated to reflect that Section 321 relief is no longer available for most DTC cross-border shipments into the US; formal customs entry with applicable duties is now required. Verify current status before each implementation as policy may change.
- **EU VAT IOSS (Import One-Stop Shop):** Effective July 1, 2021, e-commerce goods valued at or below €150 imported into the EU are subject to VAT at point of sale (collected by the merchant at checkout) rather than at import [7]. The IOSS registration allows merchants to remit VAT monthly to a single EU member state. ERP tax calculation engines (Avalara AvaTax, Vertex O Series) must be configured to recognize IOSS-eligible transactions and generate the correct VAT at checkout. Note: the EU's VAT in the Digital Age (ViDA) reform proposes removing the €150 ceiling by 2028; verify current legislative status.
- **Country-of-origin labeling:** Required for textile and apparel products sold in the US (FTC Textile and Wool Rules) and EU (EU Textile Regulation 1007/2011). The ERP product master must carry origin attributes and enforce labeling compliance checks on product setup.

---

## 4. Key Data Entities

### Entity Overview

| Entity | Key Fields | Primary Relationships |
|---|---|---|
| Customer | customer_id, email (hashed), phone, loyalty_id, do_not_sell_flag, gdpr_consent_version | → LoyaltyAccount, → SalesOrder, → ReturnOrder |
| SalesOrder | order_id, channel, customer_id, store_id, status, fulfillment_type, placed_at | → OrderLine (1:N), → Customer, → Location, → Promotion |
| OrderLine | line_id, order_id, sku, quantity, unit_price, discount_amount, fulfillment_status | → SalesOrder, → Product, → Inventory |
| Product (SKU) | sku, style_id, color_code, size, upc, brand_id, hierarchy_node_id | → Style, → MerchandiseHierarchy, → Brand |
| ProductVariant | style_id, color_code, size, sku | → Product |
| Location | location_id, location_type (STORE/DC/3PL), address, timezone | → Inventory (1:N) |
| Inventory | sku + location_id (composite PK), on_hand, reserved, in_transit, safety_stock | → Product, → Location |
| Promotion | promo_id, type, start_date, end_date, stacking_group, eligibility_rules | → PriceList, → LoyaltyAccount (tier-gated) |
| LoyaltyAccount | loyalty_id, customer_id, tier, points_balance, deferred_rev | → Customer |
| GiftCard | card_id, card_number_hash, balance, issued_at, expiry_date, issuing_store | → Location |
| ReturnOrder | return_id, original_order_id, reason_code, disposition, refund_tender | → SalesOrder, → Customer |
| MarketplaceListing | listing_id, marketplace, asin_or_item_id, sku, price, inventory_qty_synced_at | → Product |
| PriceList | pricelist_id, effective_date, expiry_date, currency | → OrderLine (price lookup) |
| Assortment | assortment_id, store_cluster, sku, ranged_in, ranged_out_date | → Location, → Product |

### Schema Sketch

```sql
-- Simplified retail data model sketch
-- Not production DDL; illustrative of key fields and relationships

Product (
  product_id        UUID         PRIMARY KEY,
  style_id          UUID         NOT NULL REFERENCES Style(style_id),
  sku               VARCHAR(50)  UNIQUE NOT NULL,   -- leaf-level sellable variant
  color_code        VARCHAR(20),
  size              VARCHAR(20),
  upc               VARCHAR(14),
  brand_id          UUID         REFERENCES Brand(brand_id),
  hierarchy_node_id UUID         REFERENCES MerchandiseHierarchy(node_id),
  cost_standard     DECIMAL(12,4),
  landed_cost       DECIMAL(12,4),
  country_of_origin CHAR(2)      -- ISO 3166-1 alpha-2; required for FTC Textile Rules
);

Inventory (
  sku          VARCHAR(50)   NOT NULL REFERENCES Product(sku),
  location_id  UUID          NOT NULL REFERENCES Location(location_id),
  on_hand      DECIMAL(12,3) NOT NULL DEFAULT 0,
  reserved     DECIMAL(12,3) NOT NULL DEFAULT 0,   -- allocated to open, unfulfilled orders
  in_transit   DECIMAL(12,3) NOT NULL DEFAULT 0,   -- confirmed inbound not yet received
  safety_stock DECIMAL(12,3) NOT NULL DEFAULT 0,
  updated_at   TIMESTAMPTZ   NOT NULL,
  PRIMARY KEY (sku, location_id)
);

-- Computed ATP (not stored; derived at query time):
-- atp = on_hand - reserved - safety_stock + in_transit (confirmed)

SalesOrder (
  order_id         UUID        PRIMARY KEY,
  channel          TEXT        NOT NULL CHECK (channel IN
                               ('POS','WEB','APP','MARKETPLACE','CALLCENTER')),
  customer_id      UUID        REFERENCES Customer(customer_id),
  store_id         UUID        REFERENCES Location(location_id),
  status           TEXT        NOT NULL CHECK (status IN
                               ('OPEN','ALLOCATED','PICKING','SHIPPED','COMPLETE','CANCELLED')),
  fulfillment_type TEXT        CHECK (fulfillment_type IN
                               ('SHIP_FROM_DC','SHIP_FROM_STORE','BOPIS',
                                'CURBSIDE','DROPSHIP')),
  placed_at        TIMESTAMPTZ NOT NULL,
  total_gross      DECIMAL(14,2),
  tax_amount       DECIMAL(14,2),
  discount_amount  DECIMAL(14,2),
  marketplace_ref  VARCHAR(100)         -- external marketplace order ID; NULL for owned channels
);

LoyaltyAccount (
  loyalty_id     UUID        PRIMARY KEY,
  customer_id    UUID        NOT NULL UNIQUE REFERENCES Customer(customer_id),
  tier           TEXT        NOT NULL CHECK (tier IN
                             ('STANDARD','SILVER','GOLD','PLATINUM')),
  points_balance DECIMAL(12,2) NOT NULL DEFAULT 0,
  deferred_rev   DECIMAL(10,2) NOT NULL DEFAULT 0,  -- ASC 606 / IFRS 15 contract liability
  last_activity  DATE
);

GiftCard (
  card_id          UUID        PRIMARY KEY,
  card_number_hash BYTEA       NOT NULL,             -- SHA-256 hash; never store plaintext
  last_four        CHAR(4)     NOT NULL,             -- display only
  pin_hash         BYTEA,
  balance          DECIMAL(10,2) NOT NULL,
  issued_at        DATE        NOT NULL,
  last_activity    DATE,
  expiry_date      DATE,
  issuing_store    UUID        REFERENCES Location(location_id),
  customer_domicile_state CHAR(2)                   -- for US escheatment routing
);
```

---

## 5. Critical Integrations

| System Category | Real Product Examples | Integration Method | Key Data Exchanged |
|---|---|---|---|
| POS systems | Shopify POS, Square for Retail, NCR Counterpoint, Lightspeed Retail, Cegid Y2 | REST/webhook → OMS + GL adapter | Tender events, line items, shift totals, void/refund events |
| E-commerce platforms | Shopify (Admin API + webhooks), Adobe Commerce / Magento 2 (REST/GraphQL), BigCommerce, WooCommerce, Salesforce Commerce Cloud (SFCC B2C Commerce) | REST webhooks (order.created, inventory.update) | Order records, inventory adjustments, customer PII |
| Marketplace connectors | Amazon SP-API (REST; MWS deprecated 2023), Walmart Marketplace API, eBay Sell APIs (REST; Trading API calls phased out 2025–2026), TikTok Shop API | REST polling + settlement file SFTP | Orders, inventory feeds, settlement reports, fee breakdowns |
| Payment processors / gateways | Adyen, Stripe, Braintree, Authorize.Net | REST API + settlement file | Authorization tokens, settlement batch files, chargeback notifications |
| Network tokenization | Visa Token Service (VTS), Mastercard Digital Enablement Service (MDES) | TSP API (via gateway) | PAN → network token mapping; token lifecycle events |
| 3PL / WMS | Manhattan Associates WMS, Blue Yonder WMS, Deposco, ShipBob | ASN (Advance Ship Notice), GR confirmation, shipment confirmation via REST or EDI X12 856/861 | Purchase order receipt, pick/pack/ship confirmation, inventory adjustments |
| Demand forecasting / planning | SAP Customer Activity Repository (CAR) with UDF, Oracle Retail Demand Forecasting Cloud Service, Blue Yonder Luminate Planning, Relex Solutions | Batch sales history export → planning engine; replenishment orders back to ERP | Daily/weekly sales actuals, inventory positions, promotional calendar, replenishment orders |
| Loyalty & CDP | Salesforce Marketing Cloud, Adobe Experience Platform (AEP), Braze, Antavo | Real-time event stream (Kafka/webhook) + batch profile sync | Points balance, tier, transaction history, opt-in/opt-out flags |
| Tax engine | Avalara AvaTax, Vertex O Series | Synchronous REST call at order/cart creation | Ship-to address, product tax codes, calculated tax by jurisdiction |
| Carrier / last-mile | UPS API, FedEx Web Services, USPS eVS, EasyPost (multi-carrier aggregation) | REST API | Label generation, tracking events, rate shopping |
| Returns platforms | Loop Returns, Happy Returns, Narvar | REST webhook on return initiation | Return authorization, disposition instruction, refund amount |
| RFID middleware | Zebra Workcloud Inventory Visibility (formerly SmartCount), Impinj RAIN RFID readers | RFID event stream → ERP inventory adjustment API | Item-level read events, cycle count reconciliation |

---

## 6. KPIs & Metrics

| KPI | Definition | Formula |
|---|---|---|
| Sell-Through Rate (STR) | Percentage of received units sold within a period | (Units Sold ÷ Units Received) × 100 |
| GMROI (Gross Margin Return on Investment) | Gross margin dollars generated per dollar of average inventory cost | Gross Profit $ ÷ Average Inventory Cost |
| Inventory Turnover | Times inventory is sold and replaced in a period | COGS ÷ Average Inventory Value |
| Weeks of Supply (WOS) | How many weeks of current demand the on-hand inventory covers | On-Hand Units ÷ Average Weekly Sales Rate |
| Shrinkage % | Inventory loss from theft, damage, or admin error | (Book Inventory − Physical Count) ÷ Book Inventory × 100 |
| Units Per Transaction (UPT) / Basket Size | Average units sold per transaction | Total Units Sold ÷ Total Transactions |
| Average Transaction Value (ATV) | Average revenue per transaction | Total Revenue ÷ Total Transactions |
| Store Conversion Rate | Share of store traffic resulting in a purchase | Transactions ÷ Store Traffic Count |
| Web Conversion Rate | Share of sessions resulting in a completed order | Orders ÷ Sessions |
| Cart Abandonment Rate | Share of initiated checkouts not completed | 1 − (Completed Orders ÷ Initiated Checkouts) |
| Customer Lifetime Value (CLV) | Projected total revenue from a customer relationship | Average Order Value × Purchase Frequency × Average Customer Lifespan |
| Return Rate | Units returned as a share of units sold | Return Units ÷ Sold Units × 100 |
| BOPIS Pickup Rate | Share of BOPIS orders actually collected by customer | BOPIS Orders Fulfilled ÷ BOPIS Orders Placed |
| Days Sales of Inventory (DSI) | Average days to sell inventory | (Average Inventory ÷ COGS) × 365 |
| Markdown % | Markdown dollars as a share of net sales | Total Markdown $ ÷ Net Sales × 100 |
| Loyalty Redemption Rate | Share of issued points that are redeemed | Points Redeemed ÷ Points Issued × 100 |
| Inventory Record Accuracy (IRA) | Match rate between system SOH and physical count | Physical Count Units Matching SOH ÷ Total Units Counted × 100 |

---

## 7. Major ERP Vendors for this Vertical

### SAP

- **SAP S/4HANA for Fashion and Vertical Business** (also called Fashion Management System / FMS) — successor to SAP AFS (Apparel & Footwear Solution). Handles the deep style/color/size product hierarchy, OTB, and assortment management natively in S/4HANA.
- **SAP Customer Activity Repository (CAR)** with **Unified Demand Forecast (UDF)** module — near-real-time POS data aggregation platform; UDF applies ML-based demand forecasting on unified transaction data.
- **SAP Omnichannel Promotion Pricing (OPP)** — centralized promotion and pricing engine distributing rules to POS, e-commerce, and OMS in real time.
- **SAP Omnichannel Article Availability and Sourcing (OAA)** — real-time ATP and sourcing logic across the location network; integrates with the OMS fulfillment routing engine.
- **SAP Commerce Cloud** (formerly Hybris) — headless e-commerce storefront with native integration to S/4HANA.
- SAP ECC mainstream maintenance ends December 31, 2027; optional extended maintenance through December 31, 2030 is available at additional cost. SAP's flagship is S/4HANA; new retail implementations should not start on ECC [8].
- SAP is recognized in Gartner's Magic Quadrant for Cloud ERP for Product-Centric Enterprises (note: Gartner no longer publishes a single unified ERP MQ; the product-centric and service-centric quadrants are distinct annual publications).

### Oracle (Retail Global Business Unit — RGBU)

Oracle maintains a dedicated retail product group (RGBU) separate from Oracle Fusion Cloud ERP. The financial backbone for RGBU deployments is typically Oracle Fusion Cloud ERP (Financials module).

- **Oracle Retail Merchandising System (RMS)** / **Merchandising Foundation Cloud Service (MFCS)** — core merchandising, buying, cost management, and supplier management.
- **Oracle Retail Demand Forecasting Cloud Service** — statistical and ML demand forecasting integrated with RMS.
- **Oracle Retail Inventory Planning Optimization Cloud Service** — replenishment, safety stock optimization, and allocation.
- **Oracle Retail Order Management System (OMS) Cloud Service** — omnichannel order orchestration, fulfillment routing, and ATP. (Verify current module naming against oracle.com/industries/retail as cloud module names are subject to rebranding.)
- **Oracle Retail Xstore POS** — store system with offline resilience and integrated clienteling.
- **Oracle Retail Customer Engagement Cloud Service** — loyalty program management and customer analytics. (Verify current naming as above.)

### Microsoft Dynamics 365 Commerce

- **Dynamics 365 Commerce** — headless omnichannel engine spanning in-store POS, call center order entry, and online storefronts (B2C and B2B).
- **Store Commerce POS** — unified POS application model that replaced the legacy MPOS (Modern POS) and CPOS (Cloud POS) apps; runs on Windows and iOS/Android.
- **Unified Pricing Management** module — centralized promotion and pricing configuration across channels.
- Integrates tightly with **Dynamics 365 Finance** (GL, AR, AP) and **Dynamics 365 Supply Chain Management** (WMS, procurement). Single-vendor full-stack integration is a competitive differentiator for Microsoft.
- Copilot AI embedded as of 2025 releases for merchandising copy generation and inventory recommendations.
- Strongest positioning in mid-market to enterprise retail; for very large-scale retail operations with complex merchandising requirements, RGBU-equivalent depth may require third-party augmentation.

### Oracle NetSuite

- **NetSuite SuiteCommerce** — native e-commerce storefront with real-time ERP data (no middleware required for inventory and pricing sync).
- **SuiteWMS** — multi-location warehouse management for NetSuite.
- **SuiteBilling** — subscription and auto-replenishment retail (e.g., subscription boxes, consumables programs).
- **SuiteTax** — multi-jurisdiction tax compliance including IOSS configuration.
- Strong positioning for DTC (direct-to-consumer) brands and specialty omnichannel mid-market retailers that want a single-platform approach without a separate merchandising system.

### Infor

- **Infor CloudSuite Retail** — built on the Infor M3 ERP core; covers procurement, inventory, financials, and demand management for retail and fashion.
- **Infor M3** — widely used in global fashion, apparel, and distribution. Strong multi-currency, multi-legislation capability for cross-border retail.
- Infor has been recognized as a Leader in Gartner's Magic Quadrant for Cloud ERP for Product-Centric Enterprises; verify the most current annual report for positioning updates.

### Acumatica Commerce Edition

- Native pre-built connectors to Shopify, BigCommerce, and Amazon without third-party middleware.
- Multi-warehouse ATP and native inventory management.
- Positioned for SMB and lower mid-market; open REST API architecture enables connector development without expensive customization. Not suited for enterprise-scale RGBU-equivalent merchandising depth.

### Brightpearl (Sage)

- Retail-first cloud ERP; acquired by Sage in 2022. Verify current Sage product branding as naming may evolve.
- Native OMS with BOPIS and ship-from-store workflow built in.
- Pre-built connectors: Shopify, Adobe Commerce (Magento), Amazon, eBay, Walmart.
- Strongest for mid-market omnichannel retailers running on Shopify or Adobe Commerce stacks.

---

## 8. Implementation Cautions

### Inventory Record Accuracy (IRA) Prerequisites

ERP go-live with IRA below 95% causes cascading OMS failures. BOPIS orders are allocated to units that do not exist on the shelf; ship-from-store picks fail; endless-aisle promises cannot be fulfilled. These failures erode customer trust immediately and are visible in real time. Full physical count, UPC remediation, and a documented IRA improvement program are non-negotiable pre-cutover requirements. RFID deployment (Zebra Workcloud Inventory Visibility, Impinj RAIN RFID) during the implementation program can accelerate IRA from a 60–65% baseline to 95–99% in apparel [1].

### POS Cutover Timing

Never schedule a POS cutover during peak trading periods (Q4 holiday season, back-to-school, major promotional events). A POS outage during a Black Friday event is unrecoverable from a revenue and brand perspective. Store-and-forward capability must be validated under network outage simulation before go-live; a 30-second tender transaction timeout is standard industry practice, after which the POS must proceed in offline mode. Define and SLA the maximum register downtime tolerance before go-live, not after.

### Nike / i2 Demand Planning Integration Failure (2000–2001)

Nike deployed i2 demand-planning software alongside SAP R/3 and Siebel CRM beginning in 1999–2000. When the i2 system went live, integration between i2 and SAP R/3 used incompatible business rules and data formats, requiring manual re-exports between systems. The i2 demand planner produced erroneous forecasts — overordering Air Garnett III shoes and underordering Air Jordans, among other errors [9]. Nike announced on February 27, 2001 that the supply-chain failure would cause it to miss Q3 projections. The company reported approximately $100 million in lost sales in Q3 2001; Nike's stock fell approximately 20% on the announcement date. The architectural lesson: demand planning integration to ERP must operate on near-real-time inventory and sales feeds. Any planning system receiving stale data will optimize toward the wrong objective. Nike ultimately removed i2's demand planner for core shoe lines and returned forecasting to SAP.

### Promotion Complexity Explosion

Every additional promotion type added to the POS rules engine multiplies QA test combinations non-linearly. A retailer with 12 promotion types and 5 tender types has a combinatorial test matrix that most QA teams underestimate. Stacking rules that are not exhaustively tested will give away margin unintentionally — a 20% off + BOGO + loyalty multiplier combination that was intended to be mutually exclusive can become additive if stacking logic has gaps. Mandate promotion UAT with a regression suite covering all tender and discount combinations before every production promotion configuration change.

### Marketplace Revenue Recognition Timing

Amazon settlement files arrive on a 14-day disbursement cycle. An ERP that recognizes marketplace revenue on settlement date misses approximately 10–14 days of revenue accrual, which materially misrepresents period-end financials. The correct approach: accrue marketplace revenue daily using order-level data (order shipped or delivered per ASC 606 control transfer) and reconcile the accrual to the settlement file on disbursement. FBA fees, referral fees, storage fees, and advertising chargebacks are netted in the settlement file and must be disaggregated into appropriate GL accounts (cost of sales, fulfillment cost, marketing expense) — a common GL reconciliation pain point.

### Gift Card Escheatment Complexity

Each US state has different dormancy periods (ranging from 1 to 7 years, commonly 3–5 years) and different unclaimed property filing deadlines. The ERP must track card-level issue date, last activity date, and the customer's state of domicile (or the state of the issuing store when customer address is unknown) to route escheatment remittances to the correct state. Some states apply different dormancy periods to gift cards vs. other financial instruments. Failure to file unclaimed property is subject to state attorney general enforcement, audit, and penalties. Do not rely on a single hard-coded dormancy period; implement a rule table by state.

### PCI Scope Creep During Integration Projects

Adding a new integration that touches cardholder data (CHD) — even indirectly — can silently expand the Cardholder Data Environment (CDE) scope and thereby expand PCI DSS assessment scope. A new loyalty system that receives transaction data including partial PAN for matching purposes is an example. Require a formal scope impact assessment (SIA) for every integration project that touches the payment path. Document the token/P2PE boundary explicitly in architecture diagrams and confirm with the QSA before implementation.

### Seasonal Data Volume Spikes

OLTP ERP databases sized for average daily order throughput will fail under Black Friday / Cyber Monday peak injection rates. Order volume can exceed 10× the daily average; inventory reservation contention on hot SKUs creates lock contention and latency spikes. Load-test the OMS order creation path, inventory reservation logic, and GL posting queues at sustained 10× average throughput before peak season. Pre-provision database compute and connection pool capacity. Consider read replicas for ATP queries to offload reservation contention.

### Cross-Channel Return Liability

Without a unified order record in the OMS, an in-store return of an online order creates an orphaned credit memo in the e-commerce platform and an unmatched refund transaction in the store POS GL — two ledger entries that cannot be reconciled without manual intervention. The OMS must be the system of record for order origination across all channels. Channel platforms (Shopify, Salesforce Commerce Cloud) must write back to the OMS on order creation, not maintain independent order records that later need reconciliation.

---

## 9. Security & Compliance Depth

### PCI DSS v4.0.1 Engineering Depth

**CDE scoping strategy.** Minimize CDE footprint through layered scope reduction: P2PE for card-present terminals eliminates terminal hardware from CDE; network tokenization (VTS, MDES) via a TSP eliminates PAN from the ERP order record; iFrame or hosted payment page (SAQ A configuration) removes the merchant's web application from CDE for card-not-present transactions. The ERP database should contain only tokens, never PANs.

**P2PE HSM chain.** Terminal → acquiring network decrypt: the swipe/dip/tap encrypts data in the terminal's hardware security module (HSM). Decryption occurs only within the payment processor's HSM farm. The ERP sees only a transaction ID and a token reference — never a plaintext PAN at any layer of the stack.

**SAQ P2PE conditions.** Using a PCI SSC-listed P2PE solution reduces the assessment to approximately 35 requirements, compared to SAQ D's 250+ requirements. The P2PE solution must be on the PCI SSC validated P2PE solutions list; a proprietary encryption scheme that is not PCI-validated does not qualify for SAQ P2PE scope reduction.

**Req 6.4.3 (payment page script inventory) — applies to SAQ A-EP and SAQ D.** Engineers must maintain a script inventory for every JavaScript loaded on any payment page. Each script entry requires: the script's URL or hash, a documented business justification, and an integrity mechanism (SRI `integrity` attribute or CSP `script-src` with hash directives). This requirement affects third-party analytics, A/B testing, chat widgets, and tag managers that are loaded on checkout pages — not only payment-specific scripts. Note: Req 6.4.3 was removed from SAQ A in PCI DSS v4.0.1 (effective 2025-03-31) but remains mandatory for SAQ A-EP and SAQ D [3].

**Req 11.6.1 (change/tamper detection) — applies to SAQ A-EP and SAQ D.** An automated mechanism must detect unauthorized changes to payment page HTTP headers and content and alert within a defined response timeframe. Assessments must occur at least weekly. Acceptable implementations include: client-side integrity checks using CSP violation reporting, server-side page hash diffing, or a commercial payment page monitoring service. Removed from SAQ A scope as of 2025-03-31.

**SAQ A eligibility (post-2025-03-31).** Requirements 6.4.3 and 11.6.1 were removed from SAQ A in v4.0.1. To qualify for SAQ A, the merchant must confirm that the entire merchant website (not only the payment page) is not susceptible to script-based attacks that could redirect or intercept payment data. This is a broader attestation than prior versions required and demands a security review of the entire web application [3].

**PAN handling in ERP UI and reports.** All ERP screens displaying order payment information must mask PAN to last four digits only. Any functionality that retrieves a fuller PAN representation (e.g., for dispute resolution) must log access to a SIEM with user ID, timestamp, and business justification. Log access must be reviewed periodically.

### Consumer Privacy Engineering

**Erasure cascade.** GDPR Art. 17 right to erasure requires the ability to pseudonymize or delete customer PII on request. The ERP must support an erasure cascade: Customer record → PII fields pseudonymized → linked loyalty profile PII pseudonymized → order billing/shipping address pseudonymized. Order records themselves are typically retained under legitimate interest for GL audit purposes; only PII fields are pseudonymized. Design this as a first-class operation in the data model, not a post-hoc script.

**CCPA/CPRA do-not-sell flag.** A `do_not_sell_flag` at the customer record level must propagate to all downstream analytical pipelines, data sharing agreements, and CDP exports within the required timeframe (45 days under CPRA). The ERP customer master is typically the source of truth; the flag must flow via event stream to the CDP and DMP.

**Data minimization (PCI Req 3.2 alignment).** CVV/CVC must be purged immediately following authorization. The ERP must never write CVV to any table, log file, or audit trail at any point. Logging of authorization requests that include the full card payload must be filtered before write.

**GDPR Art. 22 (automated profiling).** Recommendation engines, dynamic pricing algorithms, and loyalty tier assignment processes that produce legally or materially significant effects on consumers require a documented lawful basis (usually legitimate interest or explicit consent) and must provide a meaningful human review mechanism on request.

### Fraud Controls

- **Return fraud.** Configurable rule engine: maximum N return transactions per customer per 30-day window, maximum no-receipt return value per transaction, maximum no-receipt cumulative value per year. High-fraud SKU categories require receipt mandates.
- **Account takeover (ATO) for e-commerce.** Enforce MFA on account creation and high-risk actions (address change, payment method change). Rate-limit login endpoints; implement progressive lockout. ERP authentication events (login, failed login, password reset, profile change) must be logged to a SIEM for anomaly detection.
- **Promotion abuse.** Duplicate coupon code detection at time of application; velocity rules (same customer/IP/device applying same promo code multiple times); device fingerprinting for online promotion applications.
- **Gift card enumeration attacks.** Balance inquiry and redemption endpoints must be rate-limited per IP and per card number to prevent brute-force balance draining. Treat gift card numbers as sensitive credentials in all code paths.

See `core/security.md` for SoD controls, audit logging standards, and RBAC model that apply across all verticals.
See `core/localization-tax.md` for VAT/GST, IOSS, and multi-jurisdiction tax implementation details.

---

## See also

- `core/security.md` — SoD controls, audit logging, RBAC, penetration testing standards
- `core/features-core.md` — generic ERP capabilities common across all verticals
- `core/localization-tax.md` — VAT, GST, IOSS, multi-jurisdiction tax engine configuration
- `verticals/distribution-logistics.md` — WMS integration patterns, carrier APIs, 3PL management
- `verticals/manufacturing.md` — contrast with goods-centric ERP; BOM vs. style/color/size hierarchy

---

## Citations & Sources

1. Impinj / Auburn RFID Lab — RAIN RFID retail inventory accuracy benchmarks: baseline 60–65% IRA to 95–99% post-deployment in apparel. https://www.impinj.com/industries/retail
2. eBay Developers Program — API Deprecation Status (Trading API calls phased out 2025–2026; Finding API and Shopping API decommissioned February 5, 2025): https://www.edp.ebay.com/develop/get-started/api-deprecation-status
3. PCI Security Standards Council — PCI DSS v4.0.1 standard and SAQ documents (SAQ A updated January 2025; Req 6.4.3 and 11.6.1 removed from SAQ A scope effective 2025-03-31): https://www.pcisecuritystandards.org
4. PCI Security Standards Council — Software Security Framework (SSF): Secure Software Standard v1.2 (December 2022) and Secure SLC Standard: https://www.pcisecuritystandards.org/assessors_and_solutions/software_security_framework_assessors/
5. Parliament of Canada — Bill C-27 (Consumer Privacy Protection Act): died on order paper January 6, 2025 upon prorogation; successor statute expected in late 2025 or 2026. https://openparliament.ca/bills/44-1/C-27/
6. US Customs and Border Protection / White House — Section 321 de minimis suspension: China/Hong Kong effective May 2, 2025; all origins effective August 29, 2025; February 2026 proclamation confirmed ongoing suspension. Verify current policy before relying on de minimis exemption.
7. European Commission — EU VAT IOSS (Import One-Stop Shop) for e-commerce goods ≤€150: effective July 1, 2021. ViDA reform proposes removal of €150 ceiling by 2028 — verify current legislative status. https://vat-one-stop-shop.ec.europa.eu/one-stop-shop/ioss_en
8. SAP — SAP ECC 6 mainstream maintenance end date: December 31, 2027; optional extended maintenance through December 31, 2030. https://www.sap.com/products/erp/s4hana.html
9. Nike / i2 Technologies — supply chain failure 2000–2001: i2 demand planner went live 2000; Nike announced February 27, 2001 it would miss Q3 projections; ~$100 million in lost Q3 sales; stock fell ~20%. Sources: CIO Magazine ("Nike rebounds", 2004); CFO Magazine ("How Not to Spend $400 Million", 2001); Panorama Consulting case study.
10. FASB — ASC 606, Revenue from Contracts with Customers: https://asc.fasb.org
11. IASB — IFRS 15, Revenue from Contracts with Customers: https://www.ifrs.org/issued-standards/list-of-standards/ifrs-15/
12. EU GDPR (Regulation 2016/679): https://gdpr.eu
13. California Privacy Rights Act (CPRA) — California Privacy Protection Agency: https://cppa.ca.gov
14. Oracle Retail documentation (RGBU): https://docs.oracle.com/en/industries/retail/
15. SAP Customer Activity Repository Help Portal: https://help.sap.com/docs/SUPPORT_CONTENT/carab/
16. Microsoft Dynamics 365 Commerce release plans: https://learn.microsoft.com/en-us/dynamics365/release-plan/
17. Gartner — Magic Quadrant for Cloud ERP for Product-Centric Enterprises (annual publication — verify current year report)
18. FTC Retail Guides on deceptive pricing: https://www.ftc.gov/legal-library/browse/rules/guides-use-word-free-similar-representations
19. Zebra Technologies — Workcloud Inventory Visibility (formerly SmartCount): https://www.zebra.com/us/en/software/workcloud-solutions/workcloud-inventory-optimization-suite/workcloud-inventory-visibility.html
20. Amazon — Selling Partner API (SP-API) documentation; MWS deprecated: https://developer-docs.amazon.com/sp-api/
