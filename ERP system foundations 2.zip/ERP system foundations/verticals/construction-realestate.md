# ERP for Construction & Real Estate

## 1. Overview

Construction and real estate is among the most structurally demanding verticals for ERP because it combines project-centric accounting, long-duration revenue recognition, multi-tier subcontractor compliance, and — for developers — an ongoing property management layer that persists after construction ends. Standard commercial ERP modules designed for product or service businesses cannot satisfy these requirements without deep vertical extensions.

**Why this vertical is uniquely complex:**

- **Projects as profit centers.** Every job carries its own P&L, cost code budget, and committed cost ledger. The GL is not the primary ledger of record — the job cost ledger is. Every cost transaction must post to both simultaneously and reconcile at period close.
- **Dual-ledger reconciliation.** Job cost ledger and general ledger must agree at every period end. Discrepancies — from timing differences, miscoded transactions, or missing accruals — are a leading cause of bonding covenant violations.
- **Revenue recognized over time.** ASC 606 / IFRS 15 require over-time recognition using the cost-to-cost (percentage-of-completion) input method for most construction contracts. Revenue is not recognized at delivery of a building; it accrues proportionally as costs are incurred against the estimated cost at completion.
- **Highly fragmented supply chain.** A general contractor (GC) contracts directly with an owner and sub-contracts work to first-tier specialty contractors, who may sub-tier further. Compliance obligations — prevailing wage, lien waivers, certificates of insurance — cascade through every tier, and the GC bears legal exposure for all tiers below it.
- **Long project cycles with cash timing mismatches.** Projects spanning 18–48 months generate cash flow anomalies: retainage withheld until completion, overbilling liabilities when billing runs ahead of earned value, underbilling assets when work outpaces billing. Bonding agents and lenders scrutinize WIP schedules monthly to detect these imbalances.
- **Property management layer.** Developers who both build and operate properties must run construction accounting (project-based, temporary) in parallel with property management accounting (lease-based, perpetual). CAM reconciliation, tenant billing, and lease accounting (ASC 842 / IFRS 16) sit on top of the construction infrastructure.

---

## 2. Industry-Specific Modules

### 2.1 Job Costing

Job costing is the foundational module. Every cost transaction — labor, material, equipment, subcontract, overhead — posts to a cost code within a job. Cost codes typically follow CSI MasterFormat (50-division structure established in 2004, current edition published 2016 [1]) as a baseline, extended with company-specific subdivisions.

- **Cost types tracked per code:** labor, material, equipment, subcontract, other direct cost (ODC), overhead allocation
- **Budget vs. actual vs. committed:** committed costs = executed subcontracts + open purchase orders; actual = invoices posted + payroll; the delta is uncommitted exposure
- **Cost-to-complete (EAC — Estimate at Completion):** `EAC = Actual Cost to Date + Estimated Cost to Complete (ETC)`. PM team enters ETC; ERP computes EAC and flags cost overruns automatically
- **GL integration:** every job cost transaction generates a simultaneous GL journal entry. WIP clearing accounts bridge the timing between cost incurrence and revenue recognition
- **Equipment burden rates:** ERP maintains internal charge rates (hourly or daily) per equipment unit; charges post to the job as equipment cost and credit an internal equipment cost center

### 2.2 Project Accounting & WIP Schedules

The Work-in-Progress (WIP) schedule is the single most important financial document in construction. Bonding agents, surety underwriters, and lenders require it monthly or quarterly. It must be generated automatically from live ERP data.

| WIP Column | Description |
|---|---|
| Contract Value | Original contract + approved change orders |
| Billed to Date | Cumulative pay applications submitted |
| Earned Revenue | `Contract Value × % Complete` |
| Cost Incurred | Cumulative actual job cost posted |
| Cost at Completion | PM's current EAC estimate |
| % Complete | `Cost Incurred / Cost at Completion` |
| Overbilling (Billings in Excess) | `MAX(0, Billed to Date − Earned Revenue)` — balance sheet LIABILITY |
| Underbilling (Costs in Excess) | `MAX(0, Earned Revenue − Billed to Date)` — balance sheet ASSET |

**Percentage-of-completion (cost-to-cost method):**
```
% Complete = Cost Incurred to Date / Estimated Cost at Completion × 100%
Earned Revenue = Total Contract Value × % Complete
```

ASC 606 over-time recognition requires meeting at least one of three criteria: (a) the customer simultaneously receives and consumes the benefits as the entity performs; (b) the entity's performance creates or enhances an asset that the customer controls as it is created; (c) the entity's performance does not create an asset with an alternative use and the entity has an enforceable right to payment for work performed to date. Most construction contracts satisfy criterion (b) or (c).

### 2.3 AIA Billing (G702-2017 / G703-2017)

The American Institute of Architects pay application format is the de facto standard for commercial construction billing in the United States. The current edition of both forms is dated 2017.

- **AIA G702-2017 — Application and Certificate for Payment:** summary cover sheet; shows total scheduled value, work completed this period and to date, stored materials, retainage withheld, net amount due, and architect certification signature block
- **AIA G703-2017 — Continuation Sheet:** line-item breakdown of the schedule of values (SOV); each SOV line shows scheduled value, prior work completed, current work completed, stored materials on-site, percent complete, balance to finish, and retainage
- **Schedule of values (SOV):** locked at contract award; each line must be priced at fair value to prevent front-loading. ERP must enforce SOV lock after owner approval and require a formal change order to modify values
- **Stored materials tracking:** materials delivered to site but not yet installed may be included in the pay application; requires certified proof of delivery and, for off-site storage, specific insurance documentation
- **Workflow:** draft → PM review → notarization or electronic certification → owner submission → architect certification → payment processing
- **Electronic submission:** many owners require PDF/A or structured XML; some adopt DocuSign for AIA form authentication

### 2.4 Retainage / Retention Management

Retainage is a percentage (typically 5–10%) withheld from each progress payment as security against project completion. It creates distinct GL accounts and reporting requirements.

- **Retainage receivable:** amounts withheld by owner from GC; asset on GC's balance sheet
- **Retainage payable:** amounts withheld by GC from subcontractors; liability on GC's balance sheet
- **Release triggers:** substantial completion, final punch list sign-off, expiration of lien filing period, architect's final certification
- **Regulatory caps:**
  - California SB 61 (effective January 1, 2026, signed July 14, 2025) [2]: caps retainage at 5% per progress payment and 5% of total contract price on most private construction projects in California; exceptions apply to non-mixed-use residential projects of four stories or fewer, and where a party fails to provide required performance and payment bonds after written notice
  - Federal FAR 52.232-5 (Payments Under Fixed-Price Construction Contracts): caps retainage at 10% on federal contracts and permits reduction based on performance
  - More than 30 U.S. states regulate private project retainage through statute; rates and release timing vary
- **ERP requirement:** retainage must be tracked as a separate aging bucket, not aggregated into standard AR. A project can close with zero active work but carry retainage receivable for 12–24 months

### 2.5 Certified Payroll & Prevailing Wage

The Davis-Bacon Act (40 U.S.C. §§ 3141–3148) requires payment of locally prevailing wages and fringe benefits on federally funded construction contracts valued above $2,000 [3]. DOL publishes wage determinations by county and trade classification that must be incorporated into the ERP per project.

- **DOL Form WH-347:** the weekly certified payroll report. The DOL issued an updated WH-347 effective January 15, 2025, valid through January 31, 2028 [4]. The new form expands fringe benefit reporting (benefit names, types, plan numbers, hourly credit values) and adds journeyworker/registered apprentice classification fields. Starting October 1, 2026, the new WH-347 is the only valid form for federal certified payroll reporting. Each submission lists each worker's name, address (last four digits of SSN), trade classification, hours worked (straight time and overtime), gross wages, deductions, and net pay.
- **Submission cadence:** weekly to the contracting agency; electronic submission via DOL's WIRS (Wage and Hour Investigative Support and Reporting System) is required for many federal contracts (eCPR)
- **2023 Davis-Bacon final rule:** effective October 23, 2023 [3] — the first major regulatory overhaul in approximately 40 years. Civil penalties up to $13,508 per violation (subject to annual inflation adjustment). Expanded coverage via Davis-Bacon Related Acts for federally-assisted projects
- **State prevailing wage laws ("Little Davis-Bacon" acts):** California (DIR prevailing wage determinations), New York (Labor Law Article 8), Illinois (Prevailing Wage Act), and others impose state-specific rates that may exceed federal determinations
- **Wage classification tracking:** journeyman, apprentice (by year/percentage), laborer, operator — each with separate rates and fringe schedules
- **Fringe benefit credit:** cash payments to workers in lieu of bona fide fringe benefits are grossed into wages; the ERP must calculate the credit correctly per DOL formula — this is a common implementation defect

### 2.6 Subcontractor Management & Compliance

The GC's compliance exposure flows through its subcontractors. ERP must enforce compliance gates before any payment is released.

**Lien waiver types (four categories, common in most U.S. jurisdictions):**

| Type | Timing | Effect |
|---|---|---|
| Conditional Progress | Concurrent with progress payment | Waives lien rights upon receipt of the stated payment amount |
| Unconditional Progress | After progress payment clears | Irrevocable waiver for work through the stated date |
| Conditional Final | Concurrent with final payment | Waives all lien rights upon receipt of final payment |
| Unconditional Final | After final payment clears | Irrevocable waiver of all lien rights |

California Civil Code §§ 8132–8138 prescribe statutory lien waiver forms [5]; Texas Property Code Chapter 53 governs Texas mechanic's lien rights [6]. Using non-compliant forms in these states does not waive lien rights.

**Certificate of Insurance (COI / ACORD 25) requirements:**
- General Liability, Workers' Compensation, Employer's Liability, Umbrella/Excess Liability minimums per project tier
- ERP must track COI expiry per subcontractor per project, trigger automated alerts 30/60 days before expiry, and enforce automatic payment hold on expired COIs
- A GC whose subcontractor lacks workers' compensation coverage assumes the statutory employer liability for that sub's workers

**Additional compliance tracking:**
- Subcontractor prequalification scoring (financial capacity, EMR, past performance, bonding capacity)
- Secondary-tier (sub-sub) compliance: Davis-Bacon obligation flows down to all tiers; ERP must capture certified payroll at minimum two tiers deep

### 2.7 Change Order Management

Change orders alter the contract scope and price after execution. Unmanaged change orders are among the most common causes of job cost overruns and litigation.

- **PCO (Potential Change Order):** internal record of a scope deviation before owner approval; captures T&M costs and estimated impact; creates a contingent budget entry
- **COR (Change Order Request):** formal request submitted to owner/architect
- **CO (Change Order):** executed amendment; immediately updates revised contract value, SOV, job budget, and WIP calculation
- **Markup calculation:** typical order: direct labor × (1 + burden rate) + material × markup % + subcontractor amount × markup % + (overhead & profit) %
- **T&M documentation:** daily extra work reports (EWRs) capturing labor hours, equipment hours, and materials; required for unapproved COs billed on time-and-material basis
- **ERP enforcement:** no cost code budget increase without an approved CO; PCOs visible in committed cost reports with probability weighting optional

### 2.8 Equipment & Fleet Costing

- **Equipment master:** asset ID, description, purchase cost, depreciation method (straight-line, sum-of-years, units-of-production), current book value, internal charge rate per hour/day
- **Job charges:** internal cost transactions debit the job's equipment cost code and credit the equipment cost center at the standard rate; actual operating costs (fuel, maintenance, operator) are tracked separately to measure rate adequacy
- **Maintenance scheduling:** preventive maintenance triggers by engine hours or calendar; work order costs captured and included in ownership cost analysis
- **Utilization tracking:** billable hours (deployed to job) vs. idle hours vs. planned maintenance hours; low utilization triggers rate review
- **Rental vs. own analysis:** ERP compares internal ownership cost (depreciation + insurance + maintenance) against rental market rates to support make-or-buy decisions
- **Telematics integration:** GPS hours from Trimble, Caterpillar VisionLink, or Samsara feed directly into equipment logs; eliminates manual hour reporting and supports operator overtime verification

### 2.9 Property Management

Property management accounting is operationally distinct from construction accounting. The same developer or investment entity may run both simultaneously.

- **Lease administration:** rent roll, escalation schedules (CPI, fixed step-up), renewal options with notice dates, co-tenancy clauses
- **CAM (Common Area Maintenance) reconciliation:**
  - Monthly: estimate CAM charges billed to tenants pro-rata by square footage
  - Annual: compare actual CAM expenses (janitorial, landscaping, security, insurance, management fee) against billed estimates; issue reconciliation statements — tenant owes additional payment or receives credit
  - `CAM Rate = Actual CAM Expenses / Total Billable Square Footage`
- **Tenant billing components:** base rent, estimated CAM, property insurance pass-through, real estate tax pass-through, utility charges (if submetered)
- **Occupancy and vacancy tracking:** feeds into lease expiry concentration KPI and operational forecasting
- **Work order and maintenance management:** tenant requests, preventive maintenance, vendor dispatch, cost allocation to property or CAM pool
- **Tenant portal:** online payment, maintenance requests, document access — typically via platform integration (Yardi, MRI)

### 2.10 Lease Accounting (ASC 842 / IFRS 16)

Construction and real estate firms hold leases as both lessees (equipment, offices, ground leases) and lessors (tenant leases in owned buildings). Both positions require accounting treatment under ASC 842 or IFRS 16.

**ASC 842 (FASB — U.S. GAAP):**
- Effective for public entities for annual periods beginning after December 15, 2018 (i.e., January 1, 2019 for calendar-year reporters); private entities for fiscal years beginning after December 15, 2021 (i.e., January 1, 2022 for calendar-year reporters) [7]
- Lessee classifies as Operating or Finance:
  - **Operating:** straight-line total lease cost; ROU asset and lease liability on balance sheet
  - **Finance:** front-loaded cost (interest expense + amortization); mirrors economic substance of financed purchase
- Short-term lease exemption: leases with a term of 12 months or less at commencement may be excluded from balance sheet (policy election)

**IFRS 16 (IASB — IFRS):**
- Effective January 1, 2019 [8]
- Single lessee model: virtually all leases > 12 months treated as finance (no operating/finance lessee split — this is the key divergence from ASC 842)
- Low-value asset exemption available (IASB guidance references assets with underlying value approximately USD 5,000 or less when new)

**Engineering requirements for lease accounting module:**
- IBR (incremental borrowing rate) per lease — used to discount future payments; ground leases for developers can have terms up to 99 years; IBR selection has massive balance sheet impact
- Lease modification and remeasurement workflow: renewals exercised, amendments to terms, partial terminations — each triggers remeasurement of ROU asset and liability
- Disclosure generation: maturity analysis, weighted average discount rate, weighted average remaining lease term, variable lease payments

### 2.11 LEED Tracking

LEED (Leadership in Energy and Environmental Design) certification is increasingly required by owners, municipalities, and financing sources.

- **LEED v5** was ratified by USGBC membership on March 28, 2025, and launched publicly on April 28, 2025 [9]. USGBC opened LEED v5 project certification in November 2025. Starting July 1, 2027, LEED v5 will be the only version available for new commercial project registrations (BD+C, ID+C, O+M), with limited exceptions. LEED v5 emphasizes decarbonization, occupant wellbeing, and ecosystem resilience.
- **Rating systems:** BD+C (Building Design and Construction), ID+C (Interior Design and Construction), O+M (Operations + Maintenance)
- **Credit tracking per category:** Location & Transportation, Sustainable Sites, Water Efficiency, Energy & Atmosphere, Materials & Resources, Indoor Environmental Quality, Innovation, Regional Priority
- **Material credits:** recycled content percentage, regional sourcing radius, FSC-certified wood documentation — data must be captured at PO/submittal level and linked to cost items
- **Waste diversion:** landfill vs. recycle vs. reuse tonnage tracking per waste stream; requires construction waste management plan and hauler receipts
- **Energy metering:** LEED v5 BD+C references ANSI/ASHRAE/IES Standard 90.1-2022 as the energy baseline [9]; projects registered under LEED v5 must demonstrate compliance with this standard as part of the Energy & Atmosphere category
- **ERP integration:** LEED documentation workflows typically handled by Green Badger or the USGBC Arc platform (which replaced LEED Online); ERP links cost transactions to material submittals that carry LEED documentation metadata
- **EPDs (Environmental Product Declarations):** ISO 14025-formatted product environmental declarations are required for some LEED v5 Materials & Resources credits; ERP must link EPD references to material purchase records

---

## 3. Regulatory & Compliance Requirements

### 3.1 Revenue Recognition

**ASC 606 — Revenue from Contracts with Customers (FASB):**
- Effective for public entities for annual periods beginning after December 15, 2017; private entities December 15, 2018
- Five-step model: (1) identify the contract; (2) identify performance obligations; (3) determine transaction price; (4) allocate to performance obligations; (5) recognize as obligations are satisfied
- Over-time recognition criteria (one must be met): simultaneous consumption; customer controls asset as it is created; no alternative use + enforceable right to payment for work to date
- Input method (cost-to-cost) is the dominant method in construction under ASC 606; output methods (milestones, units delivered) are used for unit-price or phased projects

**IFRS 15 — Revenue from Contracts with Customers (IASB):**
- Converged standard with ASC 606; over-time criteria are equivalent
- Key divergence from U.S. GAAP arises in guidance interpretation and in interaction with local tax law in non-U.S. jurisdictions

**ASC 910 — Contractors — Construction (FASB):**
- Specialized GAAP for construction contractors; addresses contractor-specific issues not fully addressed by ASC 606 alone, including the WIP schedule presentation and the treatment of unapproved change orders and claims

Legacy context: ARB 45 / SOP 81-1 (percentage-of-completion under pre-606 GAAP) is superseded. Understanding legacy treatment is necessary for comparative analysis on projects bridging the transition or for acquisition due diligence on historical financials.

### 3.2 Lease Accounting

See Section 2.10 for module-level detail.

| Standard | Issuer | Lessee Operating | Lessee Finance | Effective Date |
|---|---|---|---|---|
| ASC 842 | FASB (U.S. GAAP) | On balance sheet, straight-line cost | On balance sheet, front-loaded cost | Public: Jan 1, 2019; Private: Jan 1, 2022 |
| IFRS 16 | IASB (IFRS) | Not applicable — single model | All leases > threshold treated as finance | Jan 1, 2019 |

### 3.3 Labor & Wage Laws

| Law / Regulation | Scope | Key Requirement |
|---|---|---|
| Davis-Bacon Act (40 U.S.C. §§ 3141–3148) | Federal construction contracts > $2,000 | Pay prevailing wages + fringe; submit WH-347 weekly |
| Davis-Bacon Related Acts | Federally-assisted construction (HUD, FHWA, etc.) | Same prevailing wage obligation via 60+ related statutes |
| Service Contract Act (41 U.S.C. §§ 6701–6707) | Federal O&M service contracts on government property | Wage and fringe determinations for service employees |
| FLSA (Fair Labor Standards Act) | All private employment | Overtime at 1.5× for hours > 40/week; applies to construction workers regardless of union status |
| California DIR prevailing wage | California public works > $1,000 | State wage determinations per trade per county; separate from federal determinations |
| New York Labor Law Article 8 | New York public works | State prevailing wage and supplement rates by county and trade |

DOL Form WH-347 (updated January 15, 2025, valid through January 31, 2028; mandatory for federal projects from October 1, 2026) [4] is the mandatory certified payroll form for Davis-Bacon compliance. The 2023 Davis-Bacon final rule (effective October 23, 2023) [3] represents the first major regulatory overhaul of the program in approximately 40 years, broadening coverage and increasing civil penalties to up to $13,508 per violation (indexed to inflation).

### 3.4 Federal Acquisition Contracting

| FAR Clause | Subject |
|---|---|
| FAR 52.232-5 | Payments under fixed-price construction; retainage cap 10%; reduction permitted on performance |
| FAR 52.222-6 | Davis-Bacon Act contract clause; incorporates prevailing wage schedule |
| FAR 52.222-8 | Certified payroll obligation and recordkeeping |

Electronic Certified Payroll Reporting (eCPR) via DOL's WIRS system is required on many federally funded projects; consult the DOL Wage and Hour Division (dol.gov/agencies/whd) for current eCPR requirements.

### 3.5 Lien Laws

Mechanic's lien rights are creatures of state statute; there is no federal lien statute for private construction projects. Key frameworks:

- **California Civil Code §§ 8000–8848** (2012 consolidated lien law) [5]: covers preliminary notices (20 days from first furnishing for sub-tier parties), stop payment notices, lien filing deadlines (90 days after completion of work), and statutory lien waiver forms (§§ 8132–8138)
- **Texas Property Code Chapter 53** [6]: governs mechanic's and materialman's liens; requires monthly sworn statements from subcontractors; constitutional lien provisions apply to residential projects
- **Notice of Commencement:** required in Florida, Georgia, and other states before lien rights attach; GC files at project start
- **Preliminary notice / Notice to Owner:** required within 20–45 days of first furnishing depending on state; failure extinguishes lien rights for sub-tier claimants
- **Lien filing deadlines:** typically 60–120 days after last day of furnishing; varies by state

### 3.6 Building Codes & Sustainability

- **IBC (International Building Code):** model code published by ICC; adopted by all 50 U.S. states with state and local amendments; governs structural, fire, and life-safety requirements
- **LEED v5 (USGBC, publicly launched April 28, 2025)** [9]: current standard for new commercial project registrations from July 1, 2027; replaces LEED v4.1
- **ENERGY STAR (EPA):** commercial building portfolio manager certification; tracked separately from LEED but compatible
- **ANSI/ASHRAE/IES Standard 90.1-2022:** energy efficiency standard for commercial buildings; the energy baseline referenced in LEED v5 BD+C [9]

### 3.7 Financial Reporting

- **FASB ASC 910 (Contractors — Construction):** specialized GAAP for construction; WIP schedule is required presentation
- **Completed-contract method:** permissible only under narrowly defined circumstances post-ASC 606; not an option for long-duration contracts with over-time recognition criteria met
- **IFRS 15:** applicable for IFRS-reporting entities (developers listed on non-U.S. exchanges, multinational joint ventures); equivalent over-time framework

---

## 4. Key Data Entities

### 4.1 Entity Map

Core domain entities and their relationships:

| Entity | Key Relationships |
|---|---|
| Project (Job) | Parent of CostCode, Contract, Subcontract, PayApplication, WIPEntry, CertifiedPayrollRecord |
| CostCode | Child of Project; aggregates BudgetLine, LaborTransaction, MaterialTransaction, EquipmentTransaction |
| Contract (Prime) | Child of Project; parent of ScheduleOfValuesLine, PayApplication |
| Subcontract | Child of Project and Vendor; carries LienWaiver, COIRecord |
| ChangeOrder | References Contract or Subcontract; triggers revision of budget and SOV |
| ScheduleOfValuesLine | Child of Contract; drives G703-2017 line items |
| PayApplication | Child of Contract; references period SOV state; generates AR invoice |
| WIPEntry | Snapshot per Project per period; aggregates contract, earned, billed, cost data |
| CertifiedPayrollRecord | Per employee per job per week; drives WH-347 output |
| Lease | References Property and Tenant; parent of LeasePaymentSchedule, RouAssetAmortization |
| CAMPool | References Property per fiscal year; drives tenant CAM billing |
| EquipmentUnit | Parent of EquipmentTransaction; linked to current Project (nullable) |

### 4.2 Schema Sketch

```sql
-- Core project accounting entities

CREATE TABLE Project (
    job_id                  INTEGER PRIMARY KEY,
    job_number              VARCHAR(20) NOT NULL,        -- e.g., "2024-0142"
    description             VARCHAR(255),
    owner_id                INTEGER REFERENCES Customer(customer_id),
    status                  VARCHAR(20) CHECK (status IN ('bid','active','complete','closeout')),
    start_date              DATE,
    scheduled_completion    DATE,
    original_contract_value NUMERIC(15,2),
    revised_contract_value  NUMERIC(15,2),               -- after approved COs
    est_cost_at_completion  NUMERIC(15,2),
    project_manager         INTEGER REFERENCES Employee(employee_id),
    billing_method          VARCHAR(20) CHECK (billing_method IN ('aia_g702','t_and_m','lump_sum','cost_plus'))
);

CREATE TABLE CostCode (
    cost_code_id    INTEGER PRIMARY KEY,
    job_id          INTEGER REFERENCES Project(job_id),
    division        VARCHAR(10),                          -- CSI MasterFormat 2016 division
    code            VARCHAR(20) NOT NULL,
    description     VARCHAR(100),
    cost_type       VARCHAR(20) CHECK (cost_type IN ('labor','material','equipment','subcontract','overhead')),
    budget_amount   NUMERIC(15,2),
    committed       NUMERIC(15,2),                        -- executed subcontracts + open POs
    actual_cost     NUMERIC(15,2),
    cost_to_complete NUMERIC(15,2)
);

CREATE TABLE Contract (
    contract_id       INTEGER PRIMARY KEY,
    job_id            INTEGER REFERENCES Project(job_id),
    owner_id          INTEGER REFERENCES Customer(customer_id),
    contract_type     VARCHAR(20) CHECK (contract_type IN ('lump_sum','unit_price','cost_plus_fee','gmp')),
    original_amount   NUMERIC(15,2),
    approved_co_total NUMERIC(15,2),
    retainage_pct     NUMERIC(5,2)
);

CREATE TABLE Subcontract (
    sub_contract_id       INTEGER PRIMARY KEY,
    job_id                INTEGER REFERENCES Project(job_id),
    vendor_id             INTEGER REFERENCES Vendor(vendor_id),
    scope_description     TEXT,
    original_amount       NUMERIC(15,2),
    approved_co_total     NUMERIC(15,2),
    paid_to_date          NUMERIC(15,2),
    retainage_withheld    NUMERIC(15,2),
    lien_waiver_status    VARCHAR(30) CHECK (lien_waiver_status IN
                            ('none','conditional_progress','unconditional_progress',
                             'conditional_final','unconditional_final')),
    coi_expiry_date       DATE,
    coi_verified          BOOLEAN DEFAULT FALSE
);

CREATE TABLE ScheduleOfValuesLine (
    sov_line_id         INTEGER PRIMARY KEY,
    contract_id         INTEGER REFERENCES Contract(contract_id),
    line_number         INTEGER NOT NULL,
    description         VARCHAR(255),
    scheduled_value     NUMERIC(15,2),
    work_in_place_prev  NUMERIC(15,2),
    work_in_place_curr  NUMERIC(15,2),
    stored_materials    NUMERIC(15,2),
    pct_complete        NUMERIC(5,2),                    -- computed: (prev + curr + stored) / scheduled
    balance_to_finish   NUMERIC(15,2),
    retainage_pct       NUMERIC(5,2)
);

CREATE TABLE PayApplication (
    pay_app_id              INTEGER PRIMARY KEY,
    contract_id             INTEGER REFERENCES Contract(contract_id),
    application_number      INTEGER NOT NULL,
    period_ending           DATE,
    scheduled_value         NUMERIC(15,2),
    work_completed_prev     NUMERIC(15,2),
    work_completed_curr     NUMERIC(15,2),
    stored_materials        NUMERIC(15,2),
    retainage_amount        NUMERIC(15,2),
    net_amount_due          NUMERIC(15,2),
    status                  VARCHAR(20) CHECK (status IN ('draft','submitted','certified','paid')),
    architect_cert_date     DATE
);

CREATE TABLE WIPEntry (
    wip_id              INTEGER PRIMARY KEY,
    job_id              INTEGER REFERENCES Project(job_id),
    period_end_date     DATE NOT NULL,
    total_contract      NUMERIC(15,2),
    earned_revenue      NUMERIC(15,2),                   -- total_contract × pct_complete
    billed_to_date      NUMERIC(15,2),
    cost_incurred       NUMERIC(15,2),
    cost_at_completion  NUMERIC(15,2),
    pct_complete        NUMERIC(5,2),                    -- cost_incurred / cost_at_completion
    overbilling         NUMERIC(15,2),                   -- MAX(0, billed_to_date - earned_revenue) [LIABILITY]
    underbilling        NUMERIC(15,2)                    -- MAX(0, earned_revenue - billed_to_date) [ASSET]
);

CREATE TABLE CertifiedPayrollRecord (
    cpr_id                  INTEGER PRIMARY KEY,
    job_id                  INTEGER REFERENCES Project(job_id),
    week_ending             DATE NOT NULL,
    employee_id             INTEGER REFERENCES Employee(employee_id),
    trade_classification    VARCHAR(50),                 -- e.g., "Carpenter", "Ironworker Foreman"
    worker_type             VARCHAR(20) CHECK (worker_type IN ('journeyworker','registered_apprentice')),
    wage_determination_id   VARCHAR(50),                 -- DOL wage determination reference
    straight_time_hours     NUMERIC(5,2),
    overtime_hours          NUMERIC(5,2),
    gross_wages             NUMERIC(10,2),
    fringe_health           NUMERIC(10,2),
    fringe_pension          NUMERIC(10,2),
    fringe_plan_number      VARCHAR(50),                 -- required by WH-347 (Jan 2025 revision)
    fringe_other            NUMERIC(10,2),
    submission_status       VARCHAR(20) CHECK (submission_status IN ('pending','submitted','accepted'))
);

CREATE TABLE Lease (
    lease_id                INTEGER PRIMARY KEY,
    property_id             INTEGER REFERENCES Property(property_id),
    tenant_id               INTEGER REFERENCES Tenant(tenant_id),
    lease_type              VARCHAR(20) CHECK (lease_type IN ('operating','finance','ground')),
    accounting_standard     VARCHAR(10) CHECK (accounting_standard IN ('asc_842','ifrs_16')),
    commencement_date       DATE,
    expiration_date         DATE,
    base_rent_monthly       NUMERIC(12,2),
    cam_estimate_monthly    NUMERIC(12,2),
    rou_asset               NUMERIC(15,2),
    lease_liability         NUMERIC(15,2),
    discount_rate           NUMERIC(6,4),                -- incremental borrowing rate (IBR)
    option_to_renew         BOOLEAN,
    option_exercise_deadline DATE
);

CREATE TABLE CAMPool (
    cam_pool_id                 INTEGER PRIMARY KEY,
    property_id                 INTEGER REFERENCES Property(property_id),
    fiscal_year                 INTEGER NOT NULL,
    total_actual_cam_expense    NUMERIC(12,2),
    total_billable_area_sqft    NUMERIC(10,2),
    cam_rate_per_sqft           NUMERIC(8,4)             -- actual_expense / billable_area
);

CREATE TABLE EquipmentUnit (
    equipment_id            INTEGER PRIMARY KEY,
    asset_number            VARCHAR(30) NOT NULL,
    description             VARCHAR(100),
    purchase_cost           NUMERIC(12,2),
    depreciation_method     VARCHAR(30) CHECK (depreciation_method IN
                              ('straight_line','sum_of_years','units_of_production')),
    current_book_value      NUMERIC(12,2),
    internal_rate_per_hour  NUMERIC(8,2),
    current_job_id          INTEGER REFERENCES Project(job_id),   -- NULL when idle/yard
    total_hours_ytd         NUMERIC(8,2)
);
```

---

## 5. Critical Integrations

### 5.1 Construction Project Management

**Procore** is the dominant field operations and project management platform in the U.S. It is not an ERP — it lacks a full GL — but it is the system of record for RFIs, submittals, daily reports, photos, safety incidents, subcontract commitments, and change orders for most mid-to-large GCs.

- Procore ERP Connector Platform (announced July 15, 2021) [10]: provides real-time or near-real-time bidirectional data sync between Procore and back-office ERP systems, covering budgets, cost codes, subcontract commitments, and cost transactions
- Certified Procore ERP integrations include: Sage 300 CRE, Sage Intacct, Viewpoint Vista, Viewpoint Spectrum, CMiC, Acumatica Construction Edition, Yardi Voyager, MRI Platform X, QuickBooks, Xero
- **Integration data flows:** approved subcontract in Procore → subcontract commitment in ERP; cost invoice approved in ERP → payment status in Procore; change order approved in ERP → revised budget in Procore

### 5.2 Estimating

- **Trimble Estimation** (formerly WinEst), **STACK**, **PlanSwift**, **Bluebeam Revu** (quantity takeoff): estimating tools generate cost code budgets that must import into ERP job cost module at project award
- Integration requirement: estimated cost codes must map 1:1 to ERP cost code structure; mismatches at import are a leading cause of cost tracking failures

### 5.3 Scheduling

- **Oracle Primavera P6**, **Microsoft Project**, **Procore Schedule**: schedule milestones drive billing event triggers and over-time revenue recognition checkpoints
- The ERP must link schedule activities to SOV lines; milestone dates trigger billing eligibility windows and earned value updates

### 5.4 Field Workforce & Timekeeping

- **Procore Time**, **Autodesk Build**, **Raken**, **ExakTime**, **ClockShark**: mobile-first timekeeping with GPS location validation
- Time entries flow to: job cost labor posting per cost code + certified payroll module for WH-347 generation
- GPS coordinates at clock-in support prevailing wage compliance by confirming worker was at the job site

### 5.5 Document Management

- **Procore**, **PlanGrid (Autodesk Build)**, **Bluebeam Studio**: store lien waivers, COIs, submittals, and RFI responses with metadata linking to subcontract and project records in ERP

### 5.6 Banking & Treasury

- ACH / wire payment runs for subcontractors; ERP generates NACHA file
- Pay-when-paid and pay-if-paid clause enforcement: ERP must track owner payment receipt before releasing sub payment in jurisdictions where this is legally enforceable
- Positive pay file to bank (check reconciliation fraud prevention)

### 5.7 Payroll Processing

- **ADP**, **Paycom**, **Paylocity**, **Paychex**: certified payroll data export; WH-347 generation via integration with ERP payroll module
- DOL WIRS (Wage and Hour Investigative Support and Reporting System): eCPR submission endpoint for federal Davis-Bacon projects; new WH-347 (Jan 2025 revision) mandatory from October 1, 2026

### 5.8 Equipment Telematics

- **Trimble**, **Caterpillar VisionLink**, **Samsara**, **Teletrac Navman**: engine hours, idle hours, and GPS position feed into ERP equipment utilization reports
- Eliminates manual hour reporting; supports operator overtime auditing and equipment billing accuracy

### 5.9 LEED & Sustainability

- **Green Badger**: LEED documentation SaaS; tracks credits, gathers contractor documentation, generates submittals [11]
- **USGBC Arc platform** (arcskoru.com): replaced LEED Online as the primary LEED project certification portal; performance score inputs for O+M rating systems [12]
- **EPDs (Environmental Product Declarations):** ISO 14025-formatted documents providing product-level environmental impact data; required for some LEED v5 Materials & Resources credits; must be linked to material purchase records in ERP

### 5.10 Property Management Platforms

- **Yardi Voyager** and **MRI Platform X** serve as primary platforms for large property owners; construction-to-property handoff requires mapping from job cost entity (Project) to property management entity (Property/Asset)
- **CoStar Real Estate Manager**: ASC 842 / IFRS 16 lease accounting SaaS layer; used by tenants and landlords managing large lease portfolios across ERP systems
- Integration handoff: at project completion, the capitalized cost from ERP job cost becomes the asset cost basis in fixed asset / property management

### 5.11 Geographic Information Systems (GIS)

- **Esri ArcGIS**: site and portfolio mapping; integrates with parcel databases and property records for real estate development pipeline management
- Useful for proximity analysis (zoning, comparable sales, utility availability) during site acquisition phase

---

## 6. KPIs & Metrics

| KPI | Definition | Formula |
|---|---|---|
| Job Cost Variance | Budget vs. actual cost by cost code | `(Budget − Actual) / Budget × 100%` |
| Cost at Completion (EAC) | Projected total job cost | `Actual Cost to Date + Estimated Cost to Complete` |
| Gross Margin % | Job-level gross profit rate | `(Earned Revenue − Total Job Cost) / Earned Revenue × 100%` |
| % Complete (cost-to-cost) | Project completion progress | `Actual Cost to Date / EAC × 100%` |
| Overbilling (Billings in Excess) | Billed more than earned — balance sheet liability | `MAX(0, Billed to Date − Earned Revenue)` |
| Underbilling (Costs in Excess) | Earned more than billed — balance sheet asset | `MAX(0, Earned Revenue − Billed to Date)` |
| Retainage Outstanding | Retainage receivable aging | Sum of withheld retainage by owner, segmented by project closeout date bucket |
| Subcontractor Commitment vs. Billed | Uncommitted sub exposure | `Subcontract Value − Sub Invoices Approved to Date` |
| Change Order Approval Rate | Owner acceptance of COs | `Approved COs ($) / Total Submitted COs ($) × 100%` |
| Schedule Performance Index (SPI) | Earned vs. planned progress | `Earned Value / Planned Value` (earned value management) |
| Cost Performance Index (CPI) | Cost efficiency on work performed | `Earned Value / Actual Cost` |
| Days Sales Outstanding (DSO) | AR collection speed | `(AR Balance / Revenue) × Days in Period` |
| WIP Adjustment Magnitude | Period-over-period change in net WIP position | Change in (Total Underbilling − Total Overbilling) from prior period |
| Occupancy Rate | Leased proportion of portfolio | `Leased Area (sq ft) / Total GLA (sq ft) × 100%` |
| CAM Recovery Rate | CAM billing efficiency | `CAM Billed to Tenants / Actual CAM Expenses Incurred × 100%` |
| Lease Expiry Concentration | Short-term lease rollover risk | `GLA expiring within 12 months / Total GLA × 100%` |
| Equipment Utilization Rate | Productive use of fleet | `Billable Hours / (Available Hours − Planned Maintenance Hours) × 100%` |
| Prevailing Wage Compliance Rate | On-time WH-347 submissions | `Timely WH-347 Submissions / Total Required Submissions × 100%` |
| Lien Waiver Collection Rate | Payment-conditional compliance | `Lien Waivers Collected Before Payment Release / Total Payments Released × 100%` |

---

## 7. Major ERP Vendors for this Vertical

### 7.1 Sage 300 CRE (Sage Construction and Real Estate)

The dominant mid-market construction and property management ERP in the United States; formerly Timberline Office, acquired by Sage. Marketed as "Sage 300 Construction and Real Estate."

**Modules:** Job Cost, Project Management, Accounts Payable, Accounts Receivable, Payroll (with state prevailing wage tables and certified payroll WH-347 generation), Equipment Cost, AIA Billing (G702-2017/G703-2017 native), Property Management, Estimating.

**Strengths:** deep AIA billing natively; certified payroll module includes DOL wage determination tables; open database (Actian/Pervasive) enables third-party reporting tools; long-established Procore ERP Connector certification; broad adoption means available talent pool.

**Weaknesses:** Windows-based client-server architecture; cloud hosting available but not cloud-native; UI modernization has lagged newer entrants.

### 7.2 Viewpoint Vista & Viewpoint Spectrum (Trimble Construction One)

Trimble completed its acquisition of Viewpoint Construction Software on July 2, 2018 [13]; Vista and Spectrum are maintained as separate products within the Trimble Construction One suite.

- **Vista:** enterprise-class; SQL Server backend; Windows client; deep union payroll and certified payroll; suitable for large GCs with complex multi-state operations
- **Spectrum:** cloud-native for mid-market; similar module breadth to Vista with modern browser UI

**Modules (Vista):** Job Cost, Payroll (union payroll, certified payroll, multi-state), AP/AR, GL, Subcontract Management, Equipment Management, Project Management, Document Control, AIA Billing, WIP Reporting.

**Strengths:** deepest union payroll handling in the market; strong certified payroll; well-established for ENR 400-level specialty contractors.

### 7.3 CMiC

Pure-play construction ERP; available cloud and on-premise; marketed to mid-to-large GCs and ENR 400 contractors.

**Modules:** Financial Management (GL, AP, AR, Billing), Project Controls (budget, cost, committed cost, change orders), Project Management (RFIs, submittals, document management), Human Capital Management (payroll, certified payroll, HR), Field Operations, Analytics (embedded BI).

**Strengths:** unified single-database architecture eliminates middleware synchronization between project management and financial modules — a significant advantage over Procore + ERP combinations; strong for large GCs where data latency between field and finance is unacceptable.

**Caution:** cross-reference current CMiC product documentation for exact current module names, as naming evolves.

### 7.4 Procore (ERP Integrations)

Procore is a construction project management platform, not a full ERP. It lacks a native GL. It is relevant here because it is the most common field operations system paired with a back-office ERP.

**Procore ERP Connector Platform** (July 15, 2021) [10]: supports real-time bidirectional cost data sync with certified integrations to Sage 300 CRE, Sage Intacct, Viewpoint Vista, Viewpoint Spectrum, CMiC, Acumatica, Yardi Voyager, MRI Platform X, QuickBooks, and Xero.

**ERP-relevant Procore modules:** Financial Management (subcontracts, change orders, commitments, owner contracts, AIA billing G702-2017/G703-2017), Workforce Management, Field Operations.

### 7.5 Yardi Voyager

Dominant property management platform for residential and commercial real estate in the United States.

**Modules:** Accounting (GL, AP, AR), Leasing & Rents, Maintenance (work orders, vendor dispatch), Procurement, Investment Management, CAM Reconciliation, Budgeting and Forecasting, Resident/Tenant Portal, Yardi Construction (extends into procurement and project accounting for developers).

**Strengths:** end-to-end residential and commercial property management at large scale; strong CAM reconciliation engine; native tenant portal; wide third-party integration library.

### 7.6 MRI Software (MRI Platform X)

Strong in commercial real estate (office, retail, industrial, mixed-use); competes with Yardi for institutional and fund-level owners.

**Modules:** Property Management, Commercial Lease Administration, Financial Modeling, Investment Management, CAM Reconciliation, ASC 842 / IFRS 16 Lease Accounting, Open API integration layer.

**Strengths:** open platform architecture with extensive API; strong mixed-use commercial portfolio support; deep tax lot and property tax management; widely deployed by REITs and institutional investors.

### 7.7 Acumatica Construction Edition

Cloud-native ERP with consumption-based licensing (not per-seat) — relevant for rapidly scaling contractors.

**Modules:** Project Accounting, Job Cost, Subcontract Management, Change Order Management, AIA Billing (G702-2017/G703-2017), Payroll, Equipment Management.

**Strengths:** modern browser-based UI; open REST API; certified Procore integration; attractive pricing model for firms with variable headcount.

### 7.8 Oracle Primavera P6 + Oracle Fusion Cloud ERP

Used primarily by large program owners, infrastructure developers, and capital program managers rather than specialty contractors.

- **Primavera P6:** industry-standard schedule and project controls platform
- **Oracle Fusion Cloud ERP (Project Portfolio Management module):** provides financial project accounting at the program level

Relevant for: highway departments, utility capital programs, large airport or stadium developers. Not the typical choice for GCs or specialty subcontractors.

---

## 8. Implementation Cautions

### 8.1 Cost Code Structure Design

The cost code structure is the most consequential design decision in a construction ERP implementation. It must accommodate every trade, phase, and cost type across all project types the firm executes — now and in the foreseeable future. Retrofitting cost code structure after go-live requires restatement of all historical job cost data, disrupts ongoing project reporting, and can corrupt WIP calculations.

**Recommendation:** Use CSI MasterFormat 2016 as the division-level framework (50 divisions) with company-specific subdivisions for phases, activities, and overhead categories. Build the code structure for the largest and most complex project type the firm ever executes, not the average project.

### 8.2 WIP Schedule Accuracy Requires Period-Close Discipline

If actual costs do not post in the same accounting period in which work is performed, the WIP schedule is materially misstated. Bonding sureties and lenders covenant on WIP schedule accuracy; material misstatement can trigger covenant violations.

**Requirement:** Subcontractor invoices must be accrued even when not yet received. Establish a period-close cutoff: all cost transactions for period N must be posted before WIP is generated for period N. Labor must be posted from payroll in the same period the work was performed, not when the payroll check is issued.

### 8.3 Subcontractor Compliance Automation Gaps

Manual COI tracking universally fails at scale. The GC assumes statutory employer liability for any subcontractor worker injured on the project if that subcontractor's workers' compensation coverage has expired and the ERP did not catch it.

**Engineering requirement:** Automated COI expiry alerts at 60 and 30 days; automatic payment hold when COI expires and is not renewed. Lien waiver collection must be enforced as a payment prerequisite — the payment workflow must not permit check/ACH release without a matching waiver record for the payment amount and period.

### 8.4 Certified Payroll Fringe Benefit Calculation Complexity

Union payroll + prevailing wage + multi-state projects: the highest-risk payroll configuration in construction. Wage determination tables (DOL publishes updates; rates change frequently) must be loaded per project and updated when DOL revises them. The January 2025 WH-347 revision requires detailed fringe benefit plan data (plan name, plan number, hourly credit value) that older payroll integrations do not capture. Fringe benefit credit calculations — the amount of cash paid to workers in lieu of bona fide benefit contributions that reduces the cash wage obligation — are frequently incorrect on initial implementation.

**Testing requirement:** Compare ERP fringe credit calculations against DOL worksheet calculations for at least three trade classifications per state before certifying payroll is compliant.

### 8.5 Change Order Workflow Discipline

T&M work performed without an approved change order creates costs that may be unbillable if the owner disputes the scope. PCO (Potential Change Order) tracking must begin from the first day of out-of-scope work, even when the owner has not yet acknowledged the change.

**System design:** PCOs must post to a contingent committed cost bucket visible in job cost reports; the system must prevent these costs from being excluded from EAC projections. CO approval must simultaneously and atomically update: revised contract value, SOV, cost code budget, and WIP projection. Partial updates create reconciliation failures.

### 8.6 Retainage as a Separate Aging Bucket

Retainage receivable is commonly carried 12–24 months after project completion. Lumping retainage into standard AR aging distorts DSO metrics and obscures the true collection posture. Subcontractor retainage payable release must be coordinated with owner retainage release per pay-when-paid contract provisions — releasing sub retainage before receiving owner retainage exposes the GC to cash shortfall.

### 8.7 ASC 842 / IFRS 16 Lease Data Quality

Ground leases for developers routinely have terms of 50–99 years. The IBR selection for a 99-year lease has enormous balance sheet impact — a 1% difference in the discount rate moves the lease liability by tens of millions of dollars on a large project. Equipment operating leases (cranes, scaffolding, temporary facilities) must be individually evaluated for on-balance-sheet treatment based on term.

**Data requirement:** A complete lease inventory must be conducted before implementing the lease accounting module. Leases embedded in service contracts (e.g., long-term crane rental with operator included) must be separated into lease and non-lease components per ASC 842 / IFRS 16.

### 8.8 Integration Latency: Field to Finance

Cost posting from Procore or field timekeeping to the ERP job cost ledger must be near-real-time. End-of-month batch synchronization renders WIP reports stale for the entire month; PMs make decisions on outdated cost data. Undiscovered cost overruns are the leading cause of surprise losses in construction.

**Architecture requirement:** Event-driven integration with webhook or streaming API; cost transactions should post to the ERP within minutes of approval in the field system. Reconciliation audit logs must exist to identify any transactions that failed to sync.

### 8.9 Procore as System-of-Record Ambiguity

The most common failure pattern for GCs using Procore + a separate ERP: budgets exist in both systems without a defined authoritative source. PMs update Procore budgets; controllers update ERP budgets; they diverge within weeks. Each side reports different job margin.

**Design requirement:** Before go-live, define per data element which system is the master. For approved budgets and contract values, the ERP is typically the system of record; Procore holds the field view. Document this in integration specifications. Implement reconciliation reports that detect budget divergence between the two systems daily.

---

## 9. Security & Compliance Depth

(Cross-reference `core/security.md` for the general SoD matrix, role-based access control framework, and audit log requirements applicable to all verticals.)

### 9.1 Segregation of Duties — Construction-Specific

| Process | Role A | Role B | Role C | Role D |
|---|---|---|---|---|
| Subcontractor payment | Subcontract entry | Invoice approval | Payment release | Lien waiver verification |
| Payroll / certified payroll | Time entry | Payroll processing | WH-347 certification | Post-submission edit lock |
| Change order approval | Field PM (proposes) | Project Executive (approves) | Controller (posts to contract value) | — |
| WIP schedule | PM (ETC input) | Controller (review) | CFO/Controller (period lock) | — |

No single individual should control subcontract entry and payment release. Certified payroll data must be locked against edit by job cost personnel after submission to the contracting agency; any correction requires a superseding submission with audit trail.

### 9.2 Certified Payroll Data Privacy

WH-347 contains worker Social Security Numbers — PII protected under federal privacy law and applicable state privacy statutes. Davis-Bacon recordkeeping regulations require retention of payroll records for at least three years after project completion.

**Engineering controls:**
- Full SSN stored only in the secured payroll subsystem; all reports and exports display last four digits only
- Transmission of WH-347 to external parties (contracting agencies, DOL investigators) via encrypted channel (TLS 1.2 minimum, TLS 1.3 preferred)
- Audit log of every access to full SSN field including user, timestamp, and purpose

### 9.3 Lien Waiver Integrity

A lien waiver is a legal release of a property right. Tampered or forged lien waivers create litigation exposure for the GC and potentially constitute fraud.

**Controls:**
- Executed lien waivers must be stored with a cryptographic hash of the document at time of receipt; any subsequent modification is detectable
- Digital signatures via a qualified e-signature platform (e.g., DocuSign with Certificate of Completion) preferred; wet ink requires scan with hash stored immediately
- Audit log records: who collected the waiver, when, payment amount confirmed against, and payment transaction reference

### 9.4 Bonding and Banking Covenant Reporting

Surety bonds (bid bond, performance bond, payment bond — AIA A312-2010 form) require the GC to maintain financial capacity verified through audited or CPA-reviewed financials and WIP schedules submitted to the surety. Bonding capacity is calculated by sureties using proprietary formulas incorporating net worth, working capital, and backlog — the specific multipliers vary by surety company and are not industry-standardized.

**Access control requirement:** WIP schedule data must be locked after period close by the Controller or CFO role; unauthorized post-close adjustments must generate an exception report. WIP data in the bonding report must match ERP-generated figures exactly; manual overrides must be flagged.

### 9.5 Multi-Tier Subcontractor Compliance Data

The GC's Davis-Bacon obligation extends to all sub-tiers. Second-tier subcontractor certified payroll records (WH-347) must be collected, stored, and produced on request by the contracting agency. The GC is liable for violations by its subs.

**Data access control:** Tier-2 sub compliance records (certified payroll, COIs, lien waivers) are visible only to compliance officers and project controls staff — not to general project personnel or accounts payable staff without specific role grants.

### 9.6 Real Estate Regulatory

- **Fair Housing Act (42 U.S.C. §§ 3601–3619):** anti-discrimination requirements in residential leasing; ERP must maintain an auditable decision log for tenant application approvals and denials; any automated screening that produces disparate impact must be reviewed against FHA compliance requirements
- **FCRA (Fair Credit Reporting Act, 15 U.S.C. § 1681 et seq.):** tenant credit screening must use FCRA-compliant consumer reporting agencies; adverse action notices must be documented
- **SOC 1 Type II:** recommended for property management platforms that process tenant financial transactions; required by many institutional property owners as a vendor qualification standard for software providers handling rent and CAM payments

---

## See also

- `core/features-core.md` — GL, AR, AP, and fixed asset modules shared across all verticals
- `core/security.md` — SoD matrix, audit logging, role-based access control baseline
- `verticals/professional-services.md` — project accounting overlap for service firms
- `verticals/government-publicsector.md` — federal contracting, prevailing wage, and Davis-Bacon context from the owner/agency side
- `verticals/manufacturing.md` — equipment costing and asset management parallels

---

## Citations & Sources

1. Construction Specifications Institute (CSI), *MasterFormat 2016 Edition: Numbers and Titles*. https://www.csinet.org/masterformat
2. California Legislature, Senate Bill 61, Civil Code § 8811 (signed July 14, 2025, effective January 1, 2026). https://leginfo.legislature.ca.gov/
3. U.S. Department of Labor, Wage and Hour Division, *Updating the Davis-Bacon and Related Acts Regulations*, Final Rule, 88 Fed. Reg. 57526 (Aug. 23, 2023; eff. Oct. 23, 2023). https://www.federalregister.gov/documents/2023/08/23/2023-17221/updating-the-davis-bacon-and-related-acts-regulations
4. U.S. Department of Labor, *WH-347 Payroll Form (rev. January 2025, valid through January 31, 2028)*. https://www.dol.gov/agencies/whd/government-contracts/construction
5. California Civil Code §§ 8000–8848 (2012 lien law consolidation, including §§ 8132–8138 statutory lien waiver forms). https://leginfo.legislature.ca.gov/
6. Texas Property Code Chapter 53 (Mechanic's, Contractor's, or Materialman's Lien). https://statutes.capitol.texas.gov/
7. FASB, *ASC 842 Leases* (Accounting Standards Update 2016-02; public entity effective date January 1, 2019; private entity effective date January 1, 2022). https://asc.fasb.org/
8. IASB, *IFRS 16 Leases* (effective January 1, 2019). https://www.ifrs.org/issued-standards/list-of-standards/ifrs-16-leases/
9. U.S. Green Building Council, *LEED v5 BD+C Reference Guide, Launch Edition* (ratified March 28, 2025; publicly launched April 28, 2025; certification opened November 2025; mandatory for new registrations July 1, 2027). https://www.usgbc.org/leed/v5
10. Procore Technologies, *New Procore ERP Connector Platform Provides Real-Time Insight on Financial Health of Construction Projects* (press release, July 15, 2021). https://investors.procore.com/news/news-details/2021/New-Procore-ERP-Connector-Platform-Provides-Real-Time-Insight-on-Financial-Health-of-Construction-Projects/default.aspx
11. Green Badger LEED documentation SaaS. https://www.simplegreenbadger.com/
12. USGBC Arc platform (formerly LEED Online). https://arcskoru.com/
13. Trimble Inc., *Trimble Completes Acquisition of Viewpoint* (July 2, 2018). https://www.prnewswire.com/news-releases/trimble-completes-acquisition-of-viewpoint-300675444.html
14. American Institute of Architects, *AIA Contract Documents G702-2017 and G703-2017*. https://www.aiacontracts.org/
15. FASB, *ASC 606 Revenue from Contracts with Customers* (Accounting Standards Update 2014-09). https://asc.fasb.org/
16. FASB, *ASC 910 Contractors — Construction*. https://asc.fasb.org/
17. IASB, *IFRS 15 Revenue from Contracts with Customers* (effective January 1, 2018). https://www.ifrs.org/issued-standards/list-of-standards/ifrs-15-revenue-from-contracts-with-customers/
18. U.S. General Services Administration, *Federal Acquisition Regulation (FAR) Part 52*, Clauses 52.222-6, 52.222-8, 52.232-5. https://www.acquisition.gov/far/part-52
19. Sage Software, *Sage 300 Construction and Real Estate* product documentation. https://www.sage.com/en-us/products/sage-300-construction-and-real-estate/
20. Trimble Inc., *Viewpoint Vista and Spectrum* product documentation. https://www.trimble.com/en/products/viewpoint
21. CMiC, product documentation. https://cmicglobal.com/
22. Yardi Systems, *Yardi Voyager* product documentation. https://www.yardi.com/products/yardi-voyager/
23. MRI Software, *MRI Platform X* product documentation. https://www.mrisoftware.com/
24. Acumatica, *Construction Edition* product documentation. https://www.acumatica.com/acumatica-cloud-erp/construction-erp/
25. ANSI/ASHRAE/IES Standard 90.1-2022, *Energy Standard for Sites and Buildings Except Low-Rise Residential Buildings*. https://www.ashrae.org/technical-resources/bookstore/standard-90-1
