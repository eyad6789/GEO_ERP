# ERP for Manufacturing

## 1. Overview

Manufacturing distinguishes itself from all other ERP verticals by requiring the physical transformation of materials into finished goods — a process that generates unique data obligations (BOM explosions, routing sequences, shop-floor confirmations, lot genealogy) and introduces hard time constraints (machine capacity, takt time, scheduled maintenance windows) that purely transactional verticals never face.

### Manufacturing Paradigms and ERP Implications

| Paradigm | Defining Characteristic | ERP Implications |
|---|---|---|
| **Discrete manufacturing** | Countable, distinct units (assemblies, components) | BOM + routing, serial/lot tracking per unit, job costing per work order, engineering change control |
| **Process manufacturing** | Continuous or batch production using formulas/recipes; output is often indistinguishable bulk material | Formula/recipe management, batch records, by-product and co-product cost allocation, expiry/shelf-life tracking, cGMP batch record immutability |
| **Mixed-mode / hybrid** | Same enterprise runs both discrete and process flows (e.g., pharma tablet compression → discrete blister packaging) | Requires ERP to support multiple order types and costing methods simultaneously; complex WIP valuation |

**Production strategy axes** drive a second layer of differentiation:

| Strategy | Description | ERP Triggers |
|---|---|---|
| Make-to-Stock (MTS) | Produce to forecast; ship from stock | MRP-driven replenishment, finished goods safety stock, demand planning integration |
| Make-to-Order (MTO) | Produce only on customer order receipt | Demand-linked production orders, ATP (available-to-promise), order-specific cost accumulation |
| Configure-to-Order (CTO) | Standard options configured per order (e.g., industrial equipment) | Super-BOM / variant configuration engine, option pricing, configuration BOMs |
| Engineer-to-Order (ETO) | Custom design per order; engineering deliverables precede production | Project manufacturing overlay, PLM integration mandatory, earned value tracking |
| Repetitive | High-volume fixed-rate production (automotive, consumer electronics) | Rate-based scheduling, backflush costing, kanban pull signals |

### Historical Foundation: MRP II

Manufacturing Resource Planning (MRP II), formalized by Oliver Wight via APICS in the 1980s, extended the original Material Requirements Planning (MRP) into a closed-loop planning framework: **Master Production Schedule (MPS)** → **Material Requirements Planning (MRP)** → **Capacity Requirements Planning (CRP)** → financial integration. Every modern manufacturing ERP module is an implementation of MRP II logic; ERP extends MRP II further to enterprise-wide GL integration, HR, procurement, and CRM within a single data model.

DDMRP (Demand-Driven MRP), an APICS/ASCM-standardized methodology, represents a deliberate departure from traditional MRP nervousness: it positions strategic decoupling buffers and replenishes based on actual demand signal rather than forecasted explosion, reducing schedule instability in environments with high demand variability.

Cross-reference: `core/features-core.md` for baseline ERP capabilities common across all verticals.

---

## 2. Industry-Specific Modules

### Bill of Materials (BOM) Management

A BOM is the authoritative definition of what goes into a manufactured item. ERP must support multiple BOM types with strict revision control.

**BOM structure types:**

- **Single-level BOM:** lists immediate children of one parent only; adequate for simple assemblies.
- **Multi-level (indented) BOM:** recursive explosion to raw material level; required for MRP explosion and cost roll-up.
- **Phantom assembly:** a pass-through sub-assembly that is never stocked as a discrete item; MRP explodes directly through the phantom's BOM lines without generating a work order or pick list for the phantom itself. Used for grouping convenience in design without production impact.
- **Engineering BOM (eBOM):** design intent, maintained in PLM; may include alternate configurations, unreleased variants, and design-only annotations.
- **Manufacturing BOM (mBOM):** derived from eBOM with additions: manufacturing steps embedded as phantom operations, approved alternates, sub-contracting definitions, scrap factors. The eBOM→mBOM transformation is a discrete engineering activity, not an automatic copy.
- **Super-BOM / Variant Configuration:** a single BOM structure encoding all valid product variants via option classes and selection rules (used in automotive OEM part families, industrial capital equipment). The ERP variant configurator resolves a super-BOM against a configuration set to produce an instance BOM for each sales order.

**BOM revision control:**

- Effectivity dates (date-in / date-out per component line) govern when a component change takes effect. A component can exist on two BOM lines with overlapping windows during transition.
- Revision letters (A, B, C…) version the BOM header; open production orders reference a specific revision.
- Mass where-used analysis (implosion): identify every parent BOM consuming a given component — mandatory input to ECO impact analysis.

**BOM costing roll-up:** costs aggregate bottom-up through the multi-level structure. Child item standard cost must be established before parent roll-up runs. Circular BOM detection must be enforced by the ERP engine before any roll-up.

### Routings & Work Centers

A routing is the ordered sequence of manufacturing operations that transforms components into a finished item.

**Routing elements:**

| Attribute | Engineering Meaning |
|---|---|
| Operation sequence | Execution order; defines predecessor/successor for scheduling |
| Work center | Capacity unit performing the operation (machine, cell, labor group) |
| Setup time | Fixed time to prepare the work center regardless of quantity |
| Run time per unit | Variable time scaling linearly with order quantity |
| Queue time | Wait time before the operation begins (reflects factory floor congestion) |
| Move time | Transit time between operations |
| Scrap % | Expected yield loss at this operation; feeds MRP gross-up calculation |
| Sub-contract flag | Operation performed by an external vendor; generates a purchase order for the operation |

**Work center attributes:** calendar (shift patterns, planned downtime), efficiency factor (actual output vs. rated capacity), utilization rate, cost rates (machine rate, labor rate for costing).

**Alternate routings and alternate work centers** enable capacity leveling: if primary work center WC-LATHE-01 is overloaded, the scheduler can route to WC-LATHE-02 with a defined efficiency penalty.

### Production Scheduling

- **MPS (Master Production Schedule):** time-phased plan for finished goods and key sub-assemblies; the boundary between demand management and supply execution.
- **MRP explosion:** driven by MPS + inventory on hand + open supply orders + component lead times. Classic MRP runs in **infinite capacity mode** — it places planned orders without checking work center capacity, then generates a capacity overload report (CRP) for planners to resolve manually.
- **Finite capacity scheduling:** hard-constrains work center availability during scheduling; requires constraint-based sequencing logic. Standard MRP engines cannot do this natively; most implementations add an APS layer.
- **Advanced Planning & Scheduling (APS):** a separate computational engine (often third-party or a premium ERP module) that simultaneously optimizes material availability and capacity. APS vendors in common use: SAP APO (legacy) → SAP IBP (current); Oracle APS; Siemens Opcenter APS; PlanetTogether; Kinaxis RapidResponse (supply chain concurrent planning).
- **DDMRP:** buffer-position-based replenishment per the APICS/ASCM DDMRP standard; eliminates the MRP nervousness problem by decoupling supply from forecast at strategically placed buffer stock positions.

### Manufacturing Execution & Shop Floor

**ISA-95 / ANSI/ISA-95 (internationally IEC 62264) hierarchy:**

| Level | Name | Examples |
|---|---|---|
| L0 | Physical process | Physical machines, conveyors |
| L1 | Sensing & actuation | PLCs, sensors, drives |
| L2 | Supervisory control | SCADA, DCS |
| L3 | Manufacturing operations | MES, MOM (Manufacturing Operations Management) |
| L4 | Business planning & logistics | ERP |

**B2MML (Business to Manufacturing Markup Language):** XML schema defined in ISA-95 Part 2 (IEC 62264-2); used for the L3 (MES) ↔ L4 (ERP) data exchange (work order download, production confirmation upload, material consumption, equipment performance).

**OPC UA (IEC 62541 series):** the real-time communication standard for L1-L2 device data; provides a platform-neutral, secure pub/sub and client/server protocol. OPC UA → MQTT broker → MES is the common architectural pattern for pushing machine telemetry toward L3/L4.

**Shop Floor Data Collection (SFDC):** labor time booking, quantity reporting, scrap reporting via shop-floor terminals, barcode/RFID scanners, or mobile devices. Data collected feeds:
- Actual labor/machine hours to costing
- Quantity confirmations to inventory
- OEE calculation (availability, performance, quality events)

**Production order lifecycle:** Planned → Firmed/Released → In-Process → Technically Complete → Closed (costed). Each state transition has authorization control implications.

**Backflush vs. forward-flush:**
- **Backflush (post-deduct):** components are auto-consumed from inventory at the time of production confirmation. Simpler data entry; risks inventory inaccuracy if actual usage deviates from BOM.
- **Forward-flush (pre-issue):** components are manually issued to the work order before or during production; more accurate but higher transaction volume.

**MES integration patterns:**

| Pattern | Description | Fit |
|---|---|---|
| Embedded MES | MES is a module within the ERP (SAP Digital Manufacturing, Microsoft D365 Manufacturing Execution) | Simpler integration; less specialized functionality |
| Loosely coupled | Standalone MES integrates via B2MML/REST/OPC UA (Siemens Opcenter Execution, Rockwell FactoryTalk, GE Digital Proficy, Dassault DELMIA Apriso, Tulip) | Best-of-breed depth; requires robust integration middleware |
| Standalone MES (no ERP integration) | MES operates independently; manual reconciliation to ERP | Anti-pattern; causes WIP ghost inventory and costing gaps |

### Quality Management

Quality management in manufacturing ERP spans the full production lifecycle:

- **Incoming inspection / receiving QC:** inspection lots created at goods receipt; hold stock until disposition (accept, reject, conditional release). Sampling plans (AQL-based) determine inspection scope.
- **In-process QC:** checkpoints embedded in routing operations; results recorded against the operation before next operation can begin (electronic traveler / route card concept).
- **Final inspection:** finished goods QC before transfer to warehouse.
- **Non-Conformance Report (NCR) / CAPA:** NCR documents detected defect (item, lot, defect type, quantity, location); disposition (use-as-is, rework, scrap, return-to-vendor); root cause; linked Corrective and Preventive Action (CAPA) record.
- **Statistical Process Control (SPC):** control charts (X-bar/R, Individuals/Moving Range, p-chart, c-chart); process capability indices Cp and Cpk; real-time SPC systems (InfinityQS ProFicient) typically integrate with ERP via API for lot/batch context.
- **Gauge R&R (Measurement System Analysis):** validates that measurement systems contribute acceptable variation relative to process variation; required by IATF 16949:2016 (AIAG MSA 4th Edition core tool).
- **First Article Inspection (FAI):** per AS9102C (Revision C, July 2023) [1]; mandatory for aerospace; documents that the first production article conforms to all design requirements before series production proceeds.
- **FMEAs:** Failure Mode and Effects Analysis; AIAG-VDA FMEA Handbook 1st Edition (June 2019) is the harmonized automotive standard published jointly by AIAG and VDA [2]; referenced in IATF 16949:2016 and AS9100 Rev D contexts.
- **Control plans:** document inspection frequency, method, reaction plan for each characteristic at each operation; required by IATF 16949:2016 APQP.

### Traceability, Lot/Batch & Serial Tracking

- **Lot/batch assignment:** created at goods receipt (vendor lot → internal lot) or at production completion. Every inventory transaction (issue, transfer, sale, return) must carry lot reference.
- **Batch genealogy tree:** parent-child relationships linking input lots consumed in a production order to the output lot(s) produced. Enables:
  - **Forward trace:** given an input lot, find every finished goods lot and customer shipment that consumed it.
  - **Backward trace:** given a finished goods lot, identify every input lot that contributed to it (the "where did it come from" view).
- **Recall readiness benchmark:** world-class target is full forward trace in under 30 minutes; industry acceptable is under 2 hours. Any ERP implementation claiming recall readiness must be mock-tested against this.
- **Serial number tracking:** individual unit identity maintained from production order through customer delivery. Required for aerospace (AS9100 Rev D), defense (MIL-STD-130N w/Change 1), medical devices (21 CFR Part 820 / ISO 13485:2016), and increasingly for high-value consumer electronics.
- **Shelf life / expiration date management:** FEFO (First-Expired-First-Out) picking strategy; ERP must enforce FEFO at warehouse pick and alert on approaching expiry. Requires lot-level expiry date on the lot master.
- **Co-products and by-products (process manufacturing):**
  - **Co-products:** joint products intentionally produced from the same batch/process order (e.g., multiple petrochemical fractions from a distillation run). Cost allocation methods: market value method, physical quantity method, residual method.
  - **By-products:** incidental, lower-value outputs (e.g., steam from a chemical reaction). Typically valued at net realizable value; reduce the cost of the primary product.
  - Both require distinct lot records and their own genealogy entries.

### OEE & Lean / Six Sigma Metrics

**OEE = Availability × Performance × Quality**

- **Availability** = (Planned Production Time − Downtime) / Planned Production Time
- **Performance** = (Ideal Cycle Time × Total Count) / Run Time
- **Quality** = Good Count / Total Count

World-class benchmark for discrete manufacturing: OEE ≥ 85% (widely cited in APICS/ASCM body of knowledge and OEE industry references). An OEE of 100% means only good parts, at maximum speed, with zero unplanned downtime.

**Lean tools with ERP implications:**
- **Kanban / pull replenishment:** electronic kanban (eKanban) in ERP generates replenishment orders on consumption signal rather than MRP time-phased netting.
- **Visual management:** ERP dashboards surfacing real-time WIP location, queue depths, OEE by work center.
- **PFEP (Plan for Every Part):** defines container size, kanban quantity, number of cards, supplier cycle for every part at every point of use; stored as item/location planning parameters in ERP.

**Six Sigma DMAIC** phases map to ERP data: Define (project charter, VOC), Measure (SPC data collection in MES/ERP), Analyze (Minitab or InfinityQS analysis), Improve (ECO to update routing/BOM), Control (updated control plan, updated SPC limits in ERP).

### Costing

| Method | Mechanism | Typical Application |
|---|---|---|
| **Standard costing** | Pre-set material, labor, overhead rates; variances (price, quantity, efficiency, overhead absorption) posted to GL variance accounts | Most discrete manufacturers; enables variance analysis by period |
| **Actual costing** | Real costs accumulated per job or batch; requires lot valuation (FIFO/LIFO/WAC at lot level) | High-value discrete (aerospace, defense); process pharma under cGMP |
| **Job costing** | Costs accumulated per work order; used in discrete MTO/ETO | Job shops, custom manufacturers |
| **Process / repetitive costing** | Costs averaged over equivalent units produced in a period | High-volume MTS, process manufacturing |

**Cost element breakdown per production order:** direct material, direct labor, machine cost, fixed overhead, variable overhead, sub-contracting cost.

**Cost roll-up sequence** is critical: leaf-node items (purchased components) must have established costs before assembly-level roll-up. Multi-level roll-up must be run bottom-up. SAP S/4HANA Material Ledger enables actual costing alongside standard costing within the same system, including multi-currency and multi-valuation (legal, profit center, group valuation).

Epicor Kinetic 2025.2 introduced a **Carbon Cost Rollup** feature that incorporates CO2 emissions data as a cost element in BOM financial applications, enabling carbon-adjusted product costing.

### Engineering Change Management

**ECR → ECN → ECO workflow:**
1. **Engineering Change Request (ECR):** initiator documents the need for change (quality failure, cost reduction, design improvement, obsolete component).
2. **Engineering Change Notice (ECN):** engineering confirms feasibility; defines proposed BOM/routing changes.
3. **Engineering Change Order (ECO):** formally approved change; specifies effective date or effectivity lot/serial number; triggers BOM/routing revision.

**Change Control Board (CCB):** multi-functional approval routing (engineering, quality, manufacturing, procurement, finance); ERP workflow routes ECO for electronic approval with full audit trail.

**Impact analysis before ECO approval:** which parent assemblies reference the changing BOM line? Which open production orders are in-flight and will be affected? What existing inventory must be consumed, reworked, or scrapped?

**Effectivity enforcement:** date-effective changes take effect at a timestamp; serial/lot-effective changes take effect at a specific serial or lot number. Open production orders must auto-update their component references when the ECO effective date arrives — if ERP cannot do this automatically, manual intervention risk is high.

**PLM-ERP integration:** PLM systems (PTC Windchill, Siemens Teamcenter, Dassault Systèmes ENOVIA on 3DEXPERIENCE) are the system of record for design data; they publish released eBOM and ECO to ERP via integration middleware. SAP PLM (integrated within S/4HANA) collapses this boundary but adds implementation complexity.

### Kanban / Pull Systems

- **Electronic kanban (eKanban):** consumption of a kanban container triggers an ERP replenishment signal (internal work order or purchase order). Container quantity and number of kanban cards are defined per item/location/supplier combination.
- **Supermarket:** physical or virtual storage location between processes; replenished by upstream pull; sized by PFEP analysis.
- ERP kanban boards display card status (empty / in transit / full) and alert on stagnant cards exceeding cycle time.

---

## 3. Regulatory & Compliance Requirements

### General Quality Standards

| Standard | Scope | ERP Impact |
|---|---|---|
| **ISO 9001:2015 / Amd 1:2024** | Universal QMS baseline; Amendment 1 (2024) adds climate change consideration to Clauses 4.1 and 4.2. A full revision (ISO 9001:2026) entered FDIS ballot in April 2026 and is expected to publish approximately September 2026 [3]; organizations will have a 3-year transition period after publication. Implement against the current published standard (ISO 9001:2015/Amd 1:2024) until the new edition is officially released. | Document control, NCR/CAPA workflow, audit trail on all quality records, management review dashboards |
| **ISO 14001:2015** | Environmental management; affects waste tracking, emissions reporting, environmental aspect registers | Hazardous material tracking in item master, waste disposal records, environmental KPI dashboards |
| **ISO 45001:2018** | Occupational health and safety | Safety incident management, risk assessment records, near-miss tracking |

### Automotive

- **IATF 16949:2016:** supersedes ISO/TS 16949 (effective October 3, 2016); published by the International Automotive Task Force (IATF). Must be implemented alongside ISO 9001:2015 — it is not a standalone QMS standard. Emphasizes the five AIAG core tools: APQP, PPAP, FMEA (AIAG-VDA FMEA Handbook 1st Edition, June 2019), MSA 4th Edition, and SPC 2nd Edition.
- **APQP (Advanced Product Quality Planning):** structured phase-gate process for quality planning of new or changed parts; gates documented in ERP project or quality module.
- **PPAP (Production Part Approval Process):** 18 elements required for new/changed part approval before series production (design records, FMEA, control plan, measurement system analysis, initial process studies, qualified lab documentation, appearance approval, sample production parts, master sample, checking aids, customer-specific requirements, part submission warrant). PPAP status tracked per part-supplier combination in ERP.
- **Customer-Specific Requirements (CSRs):** Ford, GM, Stellantis, VW, Toyota each publish CSRs layered atop IATF 16949; ERP supplier quality modules must accommodate CSR-specific fields and approval processes.

### Aerospace & Defense

- **AS9100 Rev D (2016):** QMS for Aviation, Space and Defense; published by IAQG (International Aerospace Quality Group). Based on ISO 9001:2015 with aviation-specific additions: product safety clause, FAI requirements, key characteristics management, configuration management, risk management.
- **AS9102C (Revision C, July 2023):** First Article Inspection (FAI) requirements; documents conformance of first production unit to all design requirements (balloon drawing, dimensional results, material certs, SPC studies, functional test results). Rev C added a formalized FAI planning process, updated change management integration, and digital product definition support. [1]
- **AS9120:** QMS for aviation distributors.
- **NADCAP (National Aerospace and Defense Contractors Accreditation Program):** accreditation for special processes including heat treat, non-destructive testing (NDT), coatings, and chemical processing. NADCAP approval status tracked per supplier in ERP approved vendor list (AVL).
- **MIL-STD-130N w/Change 1:** identification marking requirements for US military property; active revision governs Unique Item Identification (IUID) via human-readable and machine-readable markings; affects serialization and label printing from ERP.
- **ITAR (22 CFR Parts 120–130)** and **EAR (15 CFR Parts 730–774):** export control regulations. ERP must implement technology-control plans: item ECCN (Export Control Classification Number) or USML category in item master; user access restrictions by nationality/clearance; export license tracking. Modules: SAP Global Trade Services (GTS); Oracle Global Trade Management Cloud.

### Medical Devices

- **21 CFR Part 820 / FDA QMSR (Quality Management System Regulation):** the QMSR final rule published February 2, 2024, became effective February 2, 2026 [4], aligning 21 CFR Part 820 with ISO 13485:2016. Medical device manufacturers must re-evaluate ERP quality module configuration against the new harmonized requirements; the old QSR (21 CFR Part 820 pre-QMSR) is superseded.
- **ISO 13485:2016:** medical device QMS standard; now the effective US regulatory baseline incorporated by reference into 21 CFR Part 820 under QMSR.
- Cross-reference: `verticals/healthcare-lifesciences.md`

### Pharmaceuticals / Food (Process Manufacturing)

- **21 CFR Part 211:** Current Good Manufacturing Practice (cGMP) for finished pharmaceuticals. Subpart J requires batch record immutability: once a batch is closed, no deletions are permitted — only corrections via addendum with identity of person making correction and date. Retention: 3 years post expiry date or 1 year after product discontinuation, whichever is longer.
- **21 CFR Part 11:** electronic records and electronic signatures; requires part-11-compliant e-signatures (intent statement, authentication, non-repudiation), complete audit trail on every field change, no uncontrolled data deletion. Applies to any ERP electronic batch record in FDA-regulated environments.
- **EU GMP (EudraLex Vol. 4):** EU pharmaceutical GMP; equivalent to 21 CFR Part 211 for European market. **EU Annex 11** specifically governs computerized systems in pharmaceutical manufacturing (validation, data integrity, backup/recovery, audit trail requirements for ERP/MES systems).
- **FSMA (Food Safety Modernization Act) — 21 CFR Part 1 Subpart S (Food Traceability Rule):** requires supply-chain-wide lot-level traceability for foods on the Food Traceability List (FTL). The original compliance deadline was January 20, 2026; the FDA subsequently proposed a 30-month extension and Congressional appropriations legislation directed FDA not to enforce the rule before **July 20, 2028** [5]. Implement traceability capability regardless of enforcement date — the rule is final law.
- Cross-reference: `verticals/agriculture-food.md`, `verticals/healthcare-lifesciences.md`

### Environmental / Chemical Compliance

| Regulation | Scope | ERP Implementation |
|---|---|---|
| **EU REACH (EC) No 1907/2006** | Chemical substance reporting; SVHC (Substances of Very High Concern) above 0.1% w/w in articles | Substance composition data per item/BOM component; REACH declaration generation |
| **EU RoHS Directive 2011/65/EU (recast)** | Restriction of hazardous substances in electrical/electronic equipment | Component compliance flag in item master; homogeneous material substance declarations |
| **EPA PFAS Reporting Rule (2024)** | PFAS (per- and polyfluoroalkyl substances) reporting for US chemical manufacturers | Substance tracking in formula/BOM; emerging requirement, implementation details evolving |
| **EU GPSR 2023/988** | General Product Safety Regulation; applies from December 13, 2024; replaces Directive 2001/95/EC; traceability obligations for products on EU market [6] | Lot/serial traceability from production through end customer; rapid withdrawal capability |

---

## 4. Key Data Entities

### Core Manufacturing Entities

| Entity | Key Fields | Relationships |
|---|---|---|
| **Item Master** | PN, description, UOM, item type (purchased/manufactured/phantom), planning parameters (lead time, lot size, safety stock, MRP type), costing method, ECCN, shelf life, REACH/RoHS flags | BOM parent/child, routing header, lot master |
| **BOM Header** | BOM ID, parent item, revision letter, effective from/to, BOM type (engineering/manufacturing/super), base quantity | Item master (parent), BOM lines |
| **BOM Line** | Line sequence, component item, qty per, UOM, scrap factor, phantom flag, reference designator, effectivity dates, alternate group | BOM header, item master (component) |
| **Routing Header** | Routing ID, item, revision, effective dates | Item master, routing operations |
| **Routing Operation** | Op sequence, description, work center, setup hrs, run hrs/unit, queue hrs, move hrs, scrap %, subcontract flag, vendor | Routing header, work center, vendor master |
| **Work Center** | WC ID, description, capacity type (machine/labor), capacity hrs/day, efficiency %, utilization %, cost rates, calendar | Routing operations, production order operations |
| **Production Order / Work Order** | Order #, item, planned qty, actual qty, planned start/end, actual start/end, status, BOM revision, routing revision, cost center | Item master, BOM header, routing header, production order components/operations |
| **Production Order Component** | Order #, component item, planned qty, issued qty, lot/serial references, backflush flag | Production order, item master, lot master |
| **Production Order Operation** | Order #, op sequence, work center, planned start/end, actual start/end, planned labor hrs, actual labor hrs, planned machine hrs, actual machine hrs, confirmed qty, scrap qty | Production order, work center |
| **Lot/Batch Master** | Lot #, item, origin (receipt/production), vendor lot, receipt date, expiry date, status (unrestricted/QI/blocked), qty on hand, UOM | Item master, genealogy links |
| **Serial Number Record** | SN, item, lot, production order, customer order, status, current location, event history | Item master, lot master, production order, customer order |
| **NCR** | NCR #, item, lot/SN, defect type, qty affected, location found, disposition (use-as-is/rework/scrap/RTV), CAPA link, root cause | Lot master, serial number, CAPA |
| **Engineering Change Order** | ECO #, description, status, CCB approval records, effective date, effectivity type (date/lot/serial), affected BOMs, affected routings, impact analysis | BOM header, routing header |
| **Genealogy Link** | Genealogy ID, output lot, output item, production order, input lots (lot + item + qty consumed) | Lot master, production order |

### Fenced Schema Sketch

```jsonc
// BOM Header
{
  "bom_id": "BOM-001",
  "parent_item": "FIN-WIDGET-A",
  "revision": "C",
  "effective_from": "2025-01-01",
  "effective_to": null,
  "bom_type": "manufacturing", // "engineering" | "manufacturing" | "super"
  "base_qty": 1,
  "lines": [
    {
      "line_seq": 10,
      "component_item": "RAW-STEEL-4140",
      "qty_per": 2.5,
      "uom": "KG",
      "scrap_factor": 0.02,         // 2% scrap; MRP grosses up requirement by 1/(1-0.02)
      "phantom": false,
      "reference_designator": null,
      "effectivity": {"from": "2025-01-01", "to": null}
    },
    {
      "line_seq": 20,
      "component_item": "PHANTOM-ASSY-X",
      "qty_per": 1,
      "phantom": true               // MRP explodes through; no work order created for phantom
    }
  ]
}

// Routing Operation
{
  "routing_id": "RTG-001",
  "item": "FIN-WIDGET-A",
  "revision": "C",
  "operations": [
    {
      "op_seq": 10,
      "description": "Turning",
      "work_center": "WC-LATHE-01",
      "setup_hrs": 0.5,
      "run_hrs_per_unit": 0.25,
      "move_hrs": 0.1,
      "queue_hrs": 2.0,
      "scrap_pct": 1.5,
      "subcontract": false
    },
    {
      "op_seq": 20,
      "description": "Powder Coat (Sub-contract)",
      "work_center": "WC-SUBCON",
      "subcontract": true,
      "vendor": "VENDOR-COATCO",
      "purchase_info_record": "PIR-00456"
    }
  ]
}

// Lot Genealogy Link — forward/backward trace pivot
{
  "genealogy_id": "GEN-00345",
  "output_lot": "LOT-FIN-2025-001",
  "output_item": "FIN-WIDGET-A",
  "output_qty": 100,
  "production_order": "PRD-2025-00123",
  "production_date": "2025-03-15",
  "input_lots": [
    {
      "lot": "LOT-RAW-2025-A42",
      "item": "RAW-STEEL-4140",
      "qty_consumed": 250,
      "uom": "KG"
    },
    {
      "lot": "LOT-RAW-2025-B17",
      "item": "PAINT-BLACK-HS",
      "qty_consumed": 12,
      "uom": "L"
    }
  ]
}

// Engineering Change Order header (simplified)
{
  "eco_id": "ECO-2025-0042",
  "title": "Replace RAW-STEEL-4140 with RAW-STEEL-4150 (cost reduction)",
  "status": "APPROVED",
  "effective_date": "2025-06-01",
  "effectivity_type": "DATE",   // "DATE" | "LOT" | "SERIAL"
  "affected_boms": ["BOM-001", "BOM-003"],
  "affected_routings": [],
  "approved_by": [
    {"role": "Engineering", "user": "J.CHEN", "timestamp": "2025-05-20T14:32:00Z"},
    {"role": "Quality",     "user": "M.PATEL", "timestamp": "2025-05-21T09:15:00Z"}
  ]
}
```

---

## 5. Critical Integrations

### MES / Shop Floor Systems

| System | Vendor | Integration Pattern |
|---|---|---|
| Opcenter Execution (formerly Camstar) | Siemens | B2MML XML over REST/SOAP; ISA-95 Part 2 object models |
| FactoryTalk ProductionCentre | Rockwell Automation | B2MML; OPC UA for machine data |
| Proficy Plant Applications | GE Digital | MES/MOM platform; historian integration via AVEVA PI |
| DELMIA Apriso | Dassault Systèmes | Global MES/MOM; SAP S/4HANA integration via certified connector |
| Tulip Interfaces | Tulip | Low-code MES; REST API-based ERP integration |
| SAP Digital Manufacturing (formerly SAP DMC) | SAP | Cloud-native MES; strategic replacement for on-premise SAP ME (mainstream maintenance ending December 2027) [7]; native S/4HANA integration via SAP Integration Suite |
| Microsoft D365 Manufacturing Execution | Microsoft | Embedded in D365 SCM; no separate integration layer |

**B2MML** (Business to Manufacturing Markup Language) is the XML schema specified in ISA-95 Part 2 (IEC 62264-2) for defining work orders, operations schedules, production performance, and material consumption data exchanged between L3 MES and L4 ERP.

**SAP MII (Manufacturing Integration and Intelligence):** bridges L3-L4 in on-premise SAP configurations. Mainstream maintenance ends December 2027 [7]; SAP's cloud strategy direction is to migrate MII workloads to SAP Digital Manufacturing. Organizations on SAP MII should include a migration timeline in their S/4HANA roadmap.

### PLM Systems

| System | Vendor | Key ERP Integration Point |
|---|---|---|
| Windchill | PTC | eBOM → mBOM promotion; ECO release with BOM/routing payload to ERP |
| Teamcenter | Siemens | Multi-domain BOM management; MBOM authoring; change management sync |
| ENOVIA (3DEXPERIENCE) | Dassault Systèmes | Product structure management; change order workflow to ERP |
| SAP PLM | SAP | Integrated within S/4HANA; no integration gap; direct BOM/routing management |

### CAD / Design Tools

- **Autodesk Inventor / Fusion 360:** BOM export to CSV or PDM; one-way push to ERP item master.
- **SolidWorks PDM:** BOM and part master synchronization via middleware; triggers ECN workflow on revision change.

### Quality / SPC Systems

- **InfinityQS ProFicient:** SPC data collection and real-time control charting; integrates with ERP via API for lot/batch context, triggering NCRs on out-of-control signals.
- **Minitab:** offline statistical analysis; consumes exported data from ERP/MES quality records.
- **ETQ Reliance / MasterControl:** enterprise QMS; document control, CAPA workflow, audit trails, 21 CFR Part 11 compliant e-signatures; integrates with ERP quality module for NCR/CAPA data sharing.

### Industrial IoT / SCADA / Historian

- **OPC UA (IEC 62541 series) → MQTT broker → MES → ERP:** canonical IoT data flow from machine sensors to shop floor to enterprise layer.
- **AVEVA PI System (formerly OSIsoft PI):** time-series historian; the primary source for OEE availability and performance data; integrates with MES for contextualized production data.
- **PTC ThingWorx:** IoT platform; pushes machine telemetry and asset performance data to ERP production order context.

### Warehouse Management

- **SAP EWM (Extended Warehouse Management):** embedded within S/4HANA; handles FEFO picking, hazardous goods handling, serial/lot-level warehouse transactions.
- **Manhattan Associates WMS, Blue Yonder WMS:** external WMS via REST API or EDI; must sync lot/serial data with manufacturing ERP to maintain genealogy continuity.
- Cross-reference: `verticals/distribution-logistics.md`

### Supplier Collaboration / EDI

- **Automotive EDI (AIAG standards):** EDI 830 (Planning Schedule with Release Capability), EDI 862 (Shipping Schedule), EDI 856 (Advance Ship Notice / ASN), EDI 850 (Purchase Order). These are ASC X12 transaction sets; automotive customers send 830/862 schedules daily or weekly; ERP must translate directly to production orders or purchase orders without manual intervention.
- **AIAG B2B standards** also include MMOG/LE (Materials Management Operations Guideline/Logistics Evaluation) for supplier assessment.
- Modern supplier portals in ERP (SAP Ariba, Oracle Supplier Portal) supplement or replace EDI for smaller suppliers.

---

## 6. KPIs & Metrics

### Production Efficiency

| KPI | Formula | World-Class Benchmark |
|---|---|---|
| **OEE** | Availability × Performance × Quality | ≥ 85% (discrete manufacturing) |
| Availability | (Planned Production Time − Downtime) / Planned Production Time | |
| Performance | (Ideal Cycle Time × Total Count) / Run Time | |
| Quality | Good Count / Total Count | |
| **Throughput** | Good units produced per unit of time | Site-specific |
| **Cycle Time** | Elapsed time per unit from start to finish of a process step | Target ≤ Takt Time |
| **Takt Time** | Available Production Time / Customer Demand Rate | Set by customer demand |
| **Schedule Attainment** | Actual output / Planned output × 100% for the shift/day/week | ≥ 95% |

### Quality

| KPI | Formula | Notes |
|---|---|---|
| **First Pass Yield (FPY)** | Units passing all inspections first time / Total units started | Compound FPY across all operations for rolled throughput yield (RTY) |
| **Scrap Rate** | Scrap Qty / Total Production Qty × 100% | Track by operation and by material |
| **DPMO** | (Defects / (Units × Opportunities per Unit)) × 1,000,000 | Six Sigma quality = 3.4 DPMO |
| **Cpk** | min[(USL − μ) / (3σ), (μ − LSL) / (3σ)] | ≥ 1.33 automotive minimum; ≥ 1.67 for safety-critical characteristics |
| **Customer Return Rate** | Parts returned / Parts shipped × 1,000,000 (PPM) | Automotive OEM target: < 50 PPM |
| **Warranty Return Rate** | Warranty claims / Units sold × 100% | |

### Schedule & Delivery

| KPI | Formula |
|---|---|
| **On-Time Delivery (OTD)** | Orders delivered on or before promised date / Total orders × 100% |
| **Schedule Adherence** | Completed orders on-schedule / Total scheduled orders × 100% |
| **Manufacturing Lead Time** | Queue time + Setup time + Run time + Wait time + Move time (sum across all routing operations) |

### Inventory & Materials

| KPI | Formula |
|---|---|
| **Inventory Turnover** | COGS / Average Inventory Value |
| **Days of Supply (DOS)** | On-Hand Inventory Value / (COGS / 365) |
| **WIP Value** | Sum of all open production order actual costs not yet transferred to finished goods |
| **Material Yield** | Actual Output Qty / Theoretical Output Qty × 100% |
| **Purchase Price Variance (PPV)** | (Standard Price − Actual Price) × Actual Quantity Purchased |

### Cost

| KPI | Formula |
|---|---|
| **Manufacturing Cost Variance** | Actual Cost − Standard Cost; decomposed into material price variance, material usage variance, labor efficiency variance, overhead absorption variance |
| **Cost of Poor Quality (COPQ)** | Internal Failure + External Failure + Appraisal + Prevention costs |
| **Direct Labor Efficiency** | Standard Hours Earned / Actual Hours Worked × 100% |

### Maintenance (linked to OEE Availability)

| KPI | Formula |
|---|---|
| **MTBF (Mean Time Between Failures)** | Total Uptime / Number of Failures |
| **MTTR (Mean Time To Repair)** | Total Downtime / Number of Repairs |
| **Planned Maintenance %** | Planned Maintenance Hours / Total Maintenance Hours × 100% |

---

## 7. Major ERP Vendors for this Vertical

### Vendor Comparison

| Vendor | Product | Target Segment | Key Manufacturing Modules / Editions |
|---|---|---|---|
| SAP | S/4HANA | Large enterprise | PP (Production Planning), PP-PI (Process Industries — pharma/chemical/food), QM (Quality Management), SAP Manufacturing Execution (ME, on-premise; mainstream maintenance ends December 2027), SAP Digital Manufacturing (cloud-native MES), SAP MII (L3-L4 bridge, on-premise; mainstream maintenance ends December 2027), SAP IBP (Integrated Business Planning — APS/supply chain), SAP PLM, EWM, Global Trade Services (GTS), Material Ledger (actual + standard costing) |
| Oracle | Fusion Cloud SCM + Manufacturing | Large / mid enterprise | Oracle Manufacturing Cloud, Oracle Quality Management Cloud, Oracle Cost Management Cloud, Oracle IoT Intelligent Applications, Oracle APS, Oracle PLM Cloud, Oracle Supply Chain Orchestration, Oracle Global Trade Management Cloud |
| Microsoft | Dynamics 365 Supply Chain Management | Mid-market to enterprise | Production Control (discrete, process, lean/kanban modes), Manufacturing Execution (embedded), Master Planning (MRP/MPS/CRP), Inventory Management, Warehouse Management |
| Infor | CloudSuite Industrial / SyteLine | Mid-market discrete | Production planning, MRP, shop floor control, quality, APS via Infor OS (includes Birst analytics, Coleman AI, ION integration middleware) |
| Infor | LN (CloudSuite Industrial Enterprise) | Large/global discrete + project | Full MRP II, project manufacturing, aerospace & defense edition, earned value management |
| Infor | M3 | Process/food/pharma/distribution | Recipe/formula management, batch traceability, ingredient tracking, regulated process industries |
| Epicor | Kinetic | Mid-market discrete / job shop | BOM/routing, job costing, APS, MES integration connectors, engineering change order (ECO), Carbon Cost Rollup (2025.2 release) |
| QAD | QAD Adaptive ERP | Automotive / industrial | IATF 16949 support, APQP/PPAP workflow, automotive EDI (830/862/856), supplier quality management |
| Plex Systems (Rockwell Automation) | Plex Manufacturing Cloud | Automotive / metal / food | Native MES+ERP combined platform with direct machine/sensor connectivity, SPC, automotive-focused |
| Acumatica | Manufacturing Edition | SMB discrete | BOM, MRP, APS, production orders, kanban, job costing |
| DELMIAworks (Dassault Systèmes) | DELMIAworks ERP | SMB discrete / job shop | ECO, shop floor, quality, job costing (formerly IQMS; verify current branding at time of engagement) |
| Aptean | Process Manufacturing ERP | SMB process / food / chemical | Formula/recipe management, batch production, regulatory compliance |
| Odoo | Manufacturing (Community / Enterprise) | SMB | BOM, work orders, MRP, quality (limited SPC; no native APS) |
| ERPNext | Manufacturing module | SMB / open source | BOM, work orders, MRP; limited APS; active community development |

### SAP S/4HANA Deep Notes

- **PP-PI (Production Planning for Process Industries):** recipe management (master recipe replacing routing), process orders (replacing production orders), batch classification with class characteristics, PI sheets (process instruction sheets) for electronic batch records. The natural fit for pharmaceutical, chemical, and food manufacturers.
- **SAP Material Ledger:** enables actual costing alongside standard costing within the same S/4HANA system; supports multi-currency valuation and multi-valuation approaches (legal valuation, profit center valuation, group valuation) — essential for multinational manufacturers consolidating costs across legal entities.
- **SAP Digital Manufacturing (formerly SAP Digital Manufacturing Cloud / DMC):** cloud-native MES; the strategic replacement for on-premise SAP ME. Integrates natively with S/4HANA via SAP Integration Suite. On-premise SAP ME and SAP MII mainstream maintenance ends December 2027 [7]; customers should include cloud MES migration in their S/4HANA roadmap.
- SAP ECC (Business Suite 7) mainstream maintenance ends December 31, 2027; optional extended maintenance available at a premium through December 31, 2030 [8]. Approximately 85% of SAP's installed base continues to run ECC as of 2025; customers on ECC must plan S/4HANA migration.

### Gartner Market Coverage Note

Gartner no longer publishes a single "ERP Magic Quadrant." The analyst firm split coverage into two separate reports:
- **Magic Quadrant for Cloud ERP for Product-Centric Enterprises** — covers manufacturing and distribution ERP (SAP, Oracle, Infor, Microsoft, Epicor, QAD, etc.)
- **Magic Quadrant for Cloud ERP for Service-Centric Enterprises** — covers professional services, financial services, and related verticals

Always cite the correct quadrant name when referencing Gartner positioning for manufacturing ERP vendors.

### Plex Acquisition Note

Plex Systems was acquired by Rockwell Automation (completed August 31, 2021) [9]. The product continues as **Plex Manufacturing Cloud**; the combination positions Rockwell as an OT/IT convergence vendor offering connected shop-floor automation hardware (Allen-Bradley PLCs, FactoryTalk SCADA) alongside a native cloud ERP/MES platform. Verify current branding with Rockwell if material.

---

## 8. Implementation Cautions

### BOM Data Quality

BOM accuracy below 98% causes cascade planning failures. Phantom vs. real assembly misclassification generates ghost pick lists for non-existent sub-assemblies and suppresses pick lists for real components. Key pre-go-live requirement: independent BOM accuracy audit against physical components on production floor.

Engineering BOMs imported directly from PDM/PLM without mBOM transformation commonly include design variants not yet approved for production, alternate configurations that should not be manufactured, and missing manufacturing-specific fields (scrap factors, sub-contracting operations, operation-specific quality checks). The eBOM→mBOM transformation step must be a defined, gated process — not an automated copy.

### Routing and Capacity Data

Work center calendars and efficiency factors are almost universally wrong at go-live. Finite-capacity APS engines produce unworkable schedules when fed inaccurate capacity data — and rejected APS output destroys user trust in the system faster than almost any other failure mode.

Setup times are systematically underestimated by engineering and production management. SMED (Single-Minute Exchange of Die) improvement events and accurate changeover time studies should precede ERP go-live, not follow it. An APS loaded with 15-minute setup times against actual 90-minute changeovers will schedule unachievable daily output rates.

### Costing Setup

Standard cost roll-up sequence is non-negotiable: leaf nodes before parent nodes, bottom-up. Circular BOM detection must be enforced by the ERP engine — any circular reference will cause an infinite loop or system error in the roll-up. Cost center and overhead absorption rate assignments must align with GL account structure defined by finance before the first roll-up.

Overhead absorption rate changes mid-fiscal-year cause large inventory revaluation postings. Align cost period freeze dates with fiscal calendar policy and secure finance sign-off before any mid-year rate revision.

Mixed standard/actual costing across divisions (e.g., a parent company on standard cost with an acquired subsidiary on actual cost) requires careful GL account design to prevent crossed variance postings.

### MES/ERP Boundary and Data Latency

WIP inventory and production confirmation data delayed from MES to ERP causes phantom inventory (ERP shows components in WIP; they were consumed hours ago) and MRP nervousness (MRP re-plans orders against inventory that no longer exists). Define a maximum latency SLA for MES→ERP confirmations — for automotive just-in-time environments, 15 minutes is a common target; exceeding it risks false MRP signals.

The ISA-95 boundary question — who owns the production schedule, the ERP MPS or the MES finite scheduler? — must be resolved in the design phase. A common failure mode is dual scheduling: ERP and MES each independently generate schedules that contradict each other. Establish a single scheduling authority and define the direction of schedule publishing (ERP→MES for planned orders; MES→ERP for actuals).

### Lot/Serial Traceability Gaps

Backflushing bulk materials without lot assignment completely breaks genealogy. If 250 kg of RAW-STEEL-4140 is auto-consumed via backflush without specifying which lot, the genealogy record has an unresolved input and mock recall produces incomplete results. Every input lot must be explicitly assigned at component issue or consumption posting, not assumed from the default stock pool.

Merge and split transactions (splitting one lot into sub-lots for different work orders, or combining remnant lots at period end) must generate explicit genealogy table entries. Many SMB ERP implementations handle straight-through lot tracking but silently break genealogy on merge/split — test these scenarios specifically during UAT.

### Engineering Change Orders (ECO)

ECO effective date propagation to open production orders is a common gap: if the ERP does not automatically update BOM component references on open orders when the ECO effective date arrives, production technicians will build to the old revision using wrong components. The fix (manually updating hundreds of open orders) is error-prone and audit trail–deficient.

Dual-BOM transition periods — where old and new revision components must be consumed simultaneously while clearing old stock — must be modeled with BOM effectivity dates on individual component lines, not by creating two separate BOM versions. Copying a BOM and manually editing the copy creates version management debt that compounds with every subsequent ECO.

### Historical Big-Bang Failure: Hershey 1999

In 1999, Hershey Foods simultaneously went live with SAP R/3, Siebel CRM, and Manugistics demand planning on a compressed 30-month timeline (versus the recommended 48-month deployment), choosing a July go-live immediately ahead of the peak Halloween candy season [10]. Integration failures and data migration issues prevented fulfillment of orders despite inventory being physically on hand; Hershey reported approximately $100 million in lost sales and a 19% drop in third-quarter profits. This is the canonical ERP big-bang cautionary case for seasonal manufacturing environments. The lesson: complex multi-system simultaneous go-live in a seasonal business is a maximum-risk configuration; phased rollout with a protected peak-season blackout is the evidence-based alternative.

Cross-reference: `core/cautions.md` for general implementation pitfalls and `core/implementation.md` for phased rollout strategies.

### Automotive EDI Tight Coupling

Automotive customers transmit daily or weekly production schedules via EDI 862 (Shipping Schedule) and EDI 830 (Planning Schedule); the ERP must translate these inbound EDI messages directly into production orders and purchase orders without manual intervention. Any break in the EDI-to-MRP automated feed — whether from message format error, translation failure, or network outage — causes the manufacturer to build to the wrong quantities or miss a customer line-stop signal. Automotive-specific ERP implementations (QAD Adaptive ERP, Plex Manufacturing Cloud, SAP with Automotive EDI add-on) treat EDI as a first-class operational interface, not a batch reporting afterthought.

---

## 9. Security & Compliance Depth

### Segregation of Duties in Manufacturing

Manufacturing ERP SoD conflicts with direct financial impact:

| Conflict | Risk |
|---|---|
| Production order creation AND confirmation | Phantom production: create fictitious order, confirm inflated output, inflate inventory |
| BOM change authority AND production release | Unauthorized BOM changes masked by immediate production use |
| ECO approval AND ECO implementation | Self-approval of unauthorized design changes |
| Quality disposition authority AND production confirmation | Passing non-conforming material without independent quality review |
| Inventory adjustment AND production costing closure | Concealing material theft through costing entries |

ISO 9001:2015 Clause 8.7 and IATF 16949:2016 Clause 8.7.1 require controlled processing of nonconforming output with documented disposition authority. ERP must enforce role-based restriction on quality disposition changes with full audit trail.

Cross-reference: `core/security.md` for SoD framework and role design.

### Electronic Records & Signatures

**21 CFR Part 11** (FDA) applies to any electronic batch record in a pharmaceutical or regulated medical device manufacturing environment. Requirements on ERP electronic batch records:
- E-signature must capture identity of signer, meaning of signature (intent/approval/review), and date/time stamp.
- Audit trail must record every create, modify, and delete action with user identity, timestamp, and before/after values. Audit trail itself must be protected from modification.
- Closed batch records must be protected from deletion; corrections permitted only via addendum with attribution.

**EU Annex 11** (EudraLex Vol. 4, Annex 11 — Computerized Systems) is the European equivalent. Additional Annex 11 requirements include: validation documentation (URS, FS, DS, IQ/OQ/PQ), data integrity risk assessment, backup and recovery testing, business continuity planning for ERP system failures in production environments, and physical/logical access controls to manufacturing data.

### Export Control

**ITAR (22 CFR Parts 120–130)** and **EAR (15 CFR Parts 730–774)** impose legal obligations on manufacturers producing defense articles, dual-use goods, or controlled technology. ERP implementation requirements:

- **Item classification field:** ECCN (Export Control Classification Number) or USML (United States Munitions List) category in item master; required for every part subject to export control.
- **User access by nationality/clearance:** employees without appropriate authorization must be restricted from accessing technical data (BOM, drawing references, manufacturing instructions) for ITAR-controlled items. ERP role model must accommodate nationality-based data visibility restrictions.
- **Export license tracking:** licenses with authorized quantities, expiry dates, and consignee restrictions must be checked against shipping transactions.
- **Modules:** SAP Global Trade Services (GTS) — ECCN/USML classification management, sanctioned party screening, license determination; Oracle Global Trade Management Cloud — equivalent functionality.

ITAR violations carry civil penalties up to $1,000,000 per violation and criminal penalties up to $1,000,000 and 20 years imprisonment; the ERP cannot be the sole control, but must support the Technology Control Plan (TCP) with appropriate access logging and data handling controls. Cross-reference: `core/security.md`.

### Batch Record Integrity

Per **21 CFR Part 211 Subpart J**, once a batch production record is closed:
- No records may be deleted. Only corrections via addendum (with identity of person making correction and date) are permitted.
- Retention period: 3 years after the expiry date of the batch, or 1 year after product discontinuation, whichever is longer.
- Electronic batch records must meet 21 CFR Part 11 requirements for audit trail and access control.

ERP implementation must ensure batch record tables are append-only after batch closure, with DB-level or application-level controls preventing DELETE operations on closed batch records.

### OT/IT Network Segmentation

**ISA/IEC 62443 series** (multi-part: 62443-1-x through 62443-4-x) governs cybersecurity for industrial automation and control systems. Manufacturing ERP that accepts direct OT connectivity must respect the zone and conduit model defined in ISA/IEC 62443-1-1 and 62443-3-3:

- Production floor (L0-L2) is a distinct security zone.
- MES (L3) operates in a manufacturing DMZ.
- ERP (L4) resides in enterprise IT.
- Conduits (data paths between zones) are defined, documented, and protected.
- No direct internet access from L0-L2 equipment; all external connectivity passes through the DMZ.

The **Purdue Reference Model** (ISA-95/ISA-99 conceptual framework, still widely referenced alongside ISA/IEC 62443) reinforces this segmentation conceptually; ISA/IEC 62443 is the current normative standard for implementation.

ERP integrations with OPC UA endpoints on the shop floor must terminate at a DMZ-resident OPC UA aggregation server, not connect directly to L1-L2 PLCs from the enterprise network.

### Product Safety and Recall

**EU GPSR 2023/988** (applies from December 13, 2024) [6]: manufacturers and importers placing products on the EU market must maintain traceability information to support rapid market surveillance, withdrawal, and recall. ERP lot/serial tracking and genealogy must be capable of producing a complete affected-product list within timeframes acceptable for regulatory notification.

**CPSC (Consumer Product Safety Commission)** reporting requirements for US consumer product manufacturers: Section 15(b) of the Consumer Product Safety Act requires manufacturers to report products with potential serious hazard. ERP recall readiness capability directly supports this obligation.

Practical ERP recall readiness test: execute a mock recall drill using forward-trace query against a production lot; target time to complete customer list is under 30 minutes for world-class readiness, under 2 hours as a minimum acceptable benchmark.

---

## See also

- `core/features-core.md` — baseline ERP capabilities shared across all verticals
- `core/implementation.md` — phased rollout strategies and go-live risk management
- `core/security.md` — SoD framework, role design, and general ERP security controls
- `verticals/distribution-logistics.md` — WMS, carrier integration, 3PL; downstream of manufacturing
- `verticals/aerospace-defense.md` — AS9100, ITAR, NADCAP, MIL-STD compliance in depth
- `verticals/agriculture-food.md` — FSMA, food traceability, process manufacturing overlap
- `verticals/healthcare-lifesciences.md` — ISO 13485, 21 CFR Part 820/QMSR, medical device manufacturing

---

## Citations & Sources

1. SAE International / IAQG. *AS9102C: Aerospace Series — First Article Inspection Requirement*. Revision C, July 2023. <https://www.sae.org/standards/content/as9102c/>
2. AIAG & VDA. *Failure Mode and Effects Analysis (FMEA) Handbook*, 1st Edition. June 2019. <https://www.aiag.org/quality/automotive-core-tools/fmea>
3. ISO. *ISO/FDIS 9001 — Quality management systems — Requirements* (FDIS ballot opened April 2026; publication expected approximately September 2026). <https://www.iso.org/standard/88464.html>
4. FDA. *Quality Management System Regulation (QMSR)*. Final rule published February 2, 2024; effective February 2, 2026. 21 CFR Part 820. <https://www.fda.gov/medical-devices/postmarket-requirements-devices/quality-management-system-regulation-qmsr>
5. FDA / Federal Register. *Requirements for Additional Traceability Records for Certain Foods: Compliance Date Extension*. Effective enforcement date deferred to July 20, 2028 by Congressional appropriations legislation (Continuing Appropriations Act 2026). 21 CFR Part 1 Subpart S. <https://www.federalregister.gov/documents/2025/08/07/2025-14967/requirements-for-additional-traceability-records-for-certain-foods-compliance-date-extension>
6. EUR-Lex. *Regulation (EU) 2023/988 of the European Parliament and of the Council — General Product Safety Regulation*. Applies from December 13, 2024. <https://eur-lex.europa.eu/eli/reg/2023/988/oj/eng>
7. SAP. *SAP Digital Manufacturing FAQ*. SAP ME and SAP MII mainstream maintenance ends December 2027; SAP Digital Manufacturing is the cloud successor. SAP Community pages. Verify current timeline at <https://pages.community.sap.com/topics/digital-manufacturing/faq>
8. SAP. *End of Mainstream Maintenance for SAP Business Suite 7 (ECC)*. Mainstream maintenance ends December 31, 2027; extended maintenance at premium available through December 31, 2030. <https://support.sap.com/en/offerings-programs/strategy.html>
9. Rockwell Automation. *Rockwell Automation Completes Acquisition of Plex Systems*. Press release, August 31, 2021. <https://www.rockwellautomation.com/en-us/company/news/press-releases/Rockwell-Automation-Completes-Acquisition-of-Plex-Systems.html>
10. CIO Magazine / Panorama Consulting. Hershey Foods 1999 ERP go-live failure (SAP R/3 + Siebel + Manugistics, compressed 30-month timeline, July 1999 go-live preceding Halloween peak season; ~$100M estimated lost sales, 19% Q3 profit drop). Multiple secondary sources corroborate; original reporting: CIO Magazine 1999. <https://www.cio.com/article/270245/supply-chain-management-supply-chain-hershey-s-bittersweet-lesson.html>
11. IATF (International Automotive Task Force). *IATF 16949:2016 — Quality Management System Requirements for Automotive Production and Relevant Service Parts Organizations*. Effective October 3, 2016. <https://www.iatfglobaloversight.org>
12. IAQG (International Aerospace Quality Group). *AS9100 Rev D (2016) — Quality Management Systems — Requirements for Aviation, Space, and Defense Organizations*. <https://iaqg.org>
13. ISA. *ANSI/ISA-95 (IEC 62264) — Enterprise-Control System Integration*. <https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard>
14. ISA. *ISA/IEC 62443 — Security for Industrial Automation and Control Systems*. Multi-part series. <https://www.isa.org/standards-and-publications/isa-standards/isa-99-manufacturing-and-control-systems-security>
15. ISO. *ISO 9001:2015/Amd 1:2024 — Quality management systems — Requirements*. Amendment 1 adds climate change clauses 4.1/4.2. <https://www.iso.org/standard/87712.html>
16. FDA eCFR. *21 CFR Part 11 — Electronic Records; Electronic Signatures*. <https://www.ecfr.gov/current/title-21/chapter-I/subchapter-A/part-11>
17. FDA eCFR. *21 CFR Part 211 — Current Good Manufacturing Practice for Finished Pharmaceuticals*. <https://www.ecfr.gov/current/title-21/chapter-I/subchapter-C/part-211>
18. European Commission. *EudraLex Vol. 4 — EU Guidelines for Good Manufacturing Practice, Annex 11: Computerised Systems*. <https://health.ec.europa.eu/medicinal-products/eudralex/eudralex-volume-4_en>
19. ECHA. *EU REACH Regulation (EC) No 1907/2006*. <https://echa.europa.eu/regulations/reach/understanding-reach>
20. SAP Help Portal. *PP, PP-PI, QM, ME, MII, Material Ledger module documentation*. <https://help.sap.com>
21. Oracle. *Fusion Cloud Manufacturing documentation*. <https://docs.oracle.com/en/cloud/saas/supply-chain-and-manufacturing/index.html>
22. APICS/ASCM. *CPIM Body of Knowledge* — MRP II, DDMRP, scheduling concepts. <https://www.ascm.org/cpim/>
