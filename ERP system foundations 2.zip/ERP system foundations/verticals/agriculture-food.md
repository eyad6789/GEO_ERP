# ERP for Agriculture & Food

## 1. Overview

Agri-food ERP is materially different from generic discrete or process manufacturing ERP because the supply chain begins with a biological organism in a field, not a factory input queue. This creates a class of variance — weather, pest pressure, disease, frost, drought — with no industrial equivalent and no deterministic scheduling model. The key distinctions an ERP architect must plan for:

**Dual nature of production assets.** Crops and livestock are biological assets that grow, die, or are harvested on natural timelines. IAS 41 (Agriculture) governs their fair-value measurement under IFRS; US GAAP has no direct equivalent and typically carries these at cost. ERP must handle the transition from biological asset to manufactured inventory at the point of harvest or slaughter — a transformation event that is both a cost-recognition trigger and a lot-creation event.

**Supply chain origin is a field, not a factory.** Yield per hectare, harvest timing, and quality grade are uncertain until actual harvest. Production planning cannot use standard BOM explosion from a static routing; it must integrate agronomic forecast models and real field data. Geo-referenced field records replace work center master data.

**Regulatory stack spans multiple federal agencies.** A single fresh produce operation faces EPA oversight (pesticides, FIFRA), USDA oversight (farm programs, organic certification, phytosanitary certificates), FDA oversight (FSMA food safety rules, traceability), and DOL oversight (agricultural labor, H-2A). No other manufacturing vertical crosses this many enforcement agencies in routine operations.

**Perishability imposes unique inventory logic.** FEFO (First Expired, First Out) supersedes FIFO throughout warehouse and distribution operations. ERP must track days-to-expiry at lot level, enforce minimum remaining shelf-life (MRSL) rules per customer, and automatically quarantine lots at expiry. Standard ERP FIFO inventory logic is incorrect for perishable food without explicit configuration.

**Seasonality creates extreme burst capacity.** Harvest windows compress months of production into days or weeks. ERP systems, WMS, EDI middleware, and HR/payroll platforms must be load-tested at peak volumes (a qualitative engineering heuristic, not a published statistic — validate against client operational data). Workforce headcount may triple during peak harvest.

**Farm-to-fork traceability is a federal legal mandate, not a feature.** FSMA Section 204 (21 CFR Part 1, Subpart S) requires multi-step traceability records with specific Key Data Elements at Critical Tracking Events, for foods on the Food Traceability List. The Final Rule (87 FR 70752, 21 Nov 2022) originally set a compliance date of 20 Jan 2026; FDA formally proposed a 30-month extension to **20 Jul 2028** (90 FR [2025-14967], 7 Aug 2025), subsequently made binding through the Continuing Appropriations, Agriculture, Legislative Branch, Military Construction and Veterans Affairs, and Extensions Act of 2026 (enacted Nov 2025) [1]. ERP traceability architecture must be designed to meet this rule in substance regardless of timing deferrals.

**Commodity pricing and basis risk require treasury-grade integration.** Agricultural commodities are priced against futures markets (CME Group CBOT for grains and oilseeds). Managing basis (cash price minus futures price), price-to-be-fixed contracts, and hedge accounting under ASC 815 (US GAAP) or IFRS 9 requires a commodity management module that most generic ERP platforms lack.

For cold-chain logistics and warehouse management overlap, see `verticals/distribution-logistics.md`.

---

## 2. Industry-Specific Modules

### 2.1 Farm Management & Field Operations

The foundational master data structure in agri-food ERP replaces the factory work-center hierarchy with a geographic one:

- **Field / Block / Parcel master**: geo-referenced via GIS polygon (ESRI shapefile or GeoJSON), recording area in hectares, soil classification, irrigation zone, and drainage characteristics. GeoID enables spatial joins to agronomic data feeds.
- **Crop lifecycle management**: sequential status tracking across planning → land preparation → planting → input application → irrigation scheduling → harvesting. Each stage generates time-stamped events linked to the field record.
- **Input management**: seeds, fertilizers, pesticides tracked from purchase order through warehouse storage to field application. Each input item carries pesticide registration number (EPA Reg. No.), restricted-use flag, pre-harvest interval (PHI) in days, and restricted-entry interval (REI) in hours per FIFRA requirements.
- **Application event recording**: links field, input item, application rate (kg/ha or L/ha), equipment ID, operator, weather conditions at time of application (temperature, wind speed, humidity from integrated agronomic APIs). Required for FIFRA recordkeeping and GLOBALG.A.P. IFA v6 compliance.
- **Equipment telematics integration**: GPS-linked field equipment records engine hours, fuel consumption, field coverage, and maintenance triggers. Integrated with John Deere Operations Center, CNH AFS Connect (Case IH / New Holland), and Trimble Ag Software.
- **Yield recording**: actual yield by field, variety, and block recorded at harvest; compared against planned yield for agronomic analysis and insurance reporting.

### 2.2 Batch Traceability — Farm-to-Fork

| Traceability Layer | Legal Basis | Scope |
|---|---|---|
| One-up / one-down | Bioterrorism Act 2002 (Public Law 107-188) | Immediate supplier + immediate customer only |
| Multi-step KDE/TLC | FSMA 204 / 21 CFR Part 1 Subpart S | All CTEs across the supply chain for FTL foods |

**FSMA 204 architecture requirements:**

- **Traceability Lot Code (TLC)**: unique identifier assigned at first creation or transformation. Must be globally unique and never reassigned; GS1 SSCC or a structured internal scheme satisfying uniqueness guarantees is the implementation standard.
- **Key Data Elements (KDEs)**: specific data fields required at each Critical Tracking Event (CTE). CTEs defined by rule: harvesting, cooling, initial packing, first land-based receiving, shipping, receiving, transformation.
- **24-hour retrieval**: KDE records must be retrievable and deliverable to FDA within 24 hours of request [1]. Append-only audit log per lot, not an editable data grid.
- **2-year retention**: all traceability records must be retained for a minimum of 24 months.
- **Food Traceability List (FTL)**: soft and semi-soft cheeses, shell eggs, nut butters, fresh-cut produce, leafy greens, cucumbers, fresh herbs, melons, peppers, sprouts, tomatoes, tropical tree fruits, finfish (histamine-producing species and species susceptible to ciguatoxin contamination), crustaceans, molluscan shellfish, and ready-to-eat deli salads. See the FDA FTL for the authoritative and current enumeration [2].

**Lot lifecycle operations ERP must support:**

- Lot generation at first receipt (grower delivery or in-field harvest event).
- Split operations: one inbound lot splits into multiple child lots during grading or packing.
- Merge / blend operations: multiple parent lots combine into one child lot in a blending tank, juice line, or co-packing operation. This creates N:M lot genealogy, which many ERP systems support only partially; verify before selection.
- Transformation: raw agricultural product transforms into a processed item; new TLC required; parent TLCs must be linked.
- GS1-128 barcodes and RFID labels for physical lot identification; integration to label-printing systems at pack shed and receiving dock.
- Mock recall drill support: ability to execute a bilateral trace query (forward and backward) on a specified lot within minutes, producing a complete affected-lot list.

### 2.3 Perishable Inventory & Shelf-Life Management

- **FEFO pick sequencing**: warehouse management must sequence picks by earliest expiry date, not earliest receipt date. FEFO configuration must propagate through WMS, ERP inventory management, and any 3PL integration; misalignment causes FEFO compliance failure.
- **Days-to-expiry (DTE) tracking**: maintained per lot at each storage location. Expiry date set at receipt from supplier shelf-life data or calculated from harvest date and commodity-specific shelf-life parameters.
- **Minimum remaining shelf-life (MRSL) rules**: customer-specific and SKU-specific rules define the minimum DTE acceptable at time of shipment. ERP must prevent allocation of a lot whose remaining DTE falls below the MRSL for the target customer.
- **Automatic blocked-stock quarantine**: when a lot's DTE reaches zero, system auto-transitions lot to blocked status; requires QM disposition to move out of block.
- **Shelf-life bucket segmentation at receipt**: lots are classified on intake as saleable, near-expiry, or quarantine based on days remaining vs. MRSL thresholds. Near-expiry lots may be diverted to secondary markets or priced down.
- **Cold-chain temperature excursion integration**: if IoT sensors detect a temperature breach in a storage zone, affected lots must be automatically placed on quality hold pending inspection. Integration latency between IoT platform and ERP QM must be tested.

### 2.4 Catch-Weight Management

Catch weight applies wherever natural product weight variation makes a fixed-weight unit impractical: fresh meat, fish, poultry, whole cheeses, bulk produce, live shellfish.

| Element | Description |
|---|---|
| Dual UOM | Stocking UOM (case, box, pallet) + pricing/billing UOM (kg or lb) maintained simultaneously |
| Weighbridge capture | Actual weight recorded per lot at intake weigh station; scale integration (e.g., Mettler Toledo ICS) transmits weight to ERP lot record |
| Invoice billing | AR invoice generated on actual weight, not nominal unit count |
| Variance posting | Difference between nominal weight (cases × nominal weight per case) and actual weight is posted to a variance account |
| WMS pick | WMS allocates by stocking UOM (cases) but records actual weight at pick; invoice updated from actual pick weight |
| Label printing | Catch-weight labels printed per lot with actual weight, lot number, expiry date, and GS1-128 barcode |

Dual UOM must be configured consistently across MM (materials management), EWM/WMS, SD (sales/billing), and AP (purchasing invoices). A common failure mode is configuring catch weight in the warehouse but defaulting to nominal weight in AP or billing — causes systematic AP/AR posting errors.

### 2.5 Grower Accounting & Settlements

Grower accounting manages the financial relationship between a handler or processor and the growers supplying raw product. This is distinct from standard AP because payment is contingent on sales outcomes.

- **Grower / ranch master**: linked to field/block records; records certifications (organic certificate number, GLOBALG.A.P. certificate number and expiry), GAP audit date, contract terms.
- **Receipt grading**: at intake, quality inspector records grade code (per USDA AMS commodity-specific grade scale), pack size, defect percentages, and net weight. Grade drives price calculation.
- **Pooling models**:
  - *Lot-by-lot*: grower receives settlement based solely on sale proceeds from their specific lot.
  - *Weekly pool*: proceeds from all grower lots sold in a week are averaged and distributed proportionally.
  - *Seasonal pool*: proceeds averaged over the entire season; smooths price risk for grower but delays final payment.
- **Settlement calculation**: gross sales price minus itemized deductions (packing/processing charge, freight, cold storage, commission, marketing assessment, advance repayment) equals net amount due to grower.
- **Advance payments**: growers may receive a pre-harvest or on-delivery advance against future settlement; tracked as debit against final net settlement.
- **Account sales (liquidation) document**: the settlement statement sent to grower, showing gross sales, deductions, advances, and net remittance. Triggers AP invoice and payment.
- **Multi-payee support**: single ranch may split proceeds between landowner, farm operator, and custom harvester per contract terms; ERP must split AP posting accordingly.

### 2.6 Quality & Grading

- **USDA AMS grade scales**: commodity-specific grade standards (e.g., U.S. Fancy, U.S. No. 1, U.S. No. 2 for fresh produce; USDA Choice/Select/Prime for beef). Grade codes must be configurable per commodity in item master.
- **Inspection points**: receive inspection (grade at intake), in-process inspection (CCP monitoring on processing line), outbound inspection (pre-shipment CoA generation).
- **HACCP CCP record linkage**: each CCP monitoring event (e.g., cook temperature, chiller temperature, metal detector pass) links to the lot being processed. FSMA 21 CFR Part 117 requires verification records be maintained.
- **Non-conformance management**: non-conforming lots placed on hold; disposition workflow (accept, rework, divert to secondary use, destroy) with electronic approval and audit trail.
- **LIMS interface**: microbiological and chemical test results (e.g., pathogen PCR, pesticide residue, allergen ELISA) transmitted from laboratory information management systems (e.g., LabVantage LIMS, NEOGEN) into ERP quality records.
- **Allergen management**: finished product CoA must declare allergens; cross-contact risk from shared equipment must be tracked; changeover cleaning records linked to production order.
- **Certificate of Analysis (CoA)**: system-generated, non-editable PDF signed document combining grade, test results, and lot data for customer-facing quality documentation.

### 2.7 Commodity Pricing & Hedging

- **Mark-to-market inventory valuation**: commodity inventory revalued at current market prices for management reporting; affects both P&L and working capital visibility.
- **Futures contract register**: records open futures positions by exchange code (CME Group CBOT for corn, soybeans, wheat; NYMEX for some energy-related agri inputs), contract month, quantity, and entry price.
- **Basis tracking**: basis = cash price − futures price. Basis is the local price differential driven by transportation cost, local supply/demand, and quality premiums. ERP must maintain basis by location/origin.
- **Price-to-be-fixed (PTF) contracts**: sales contracts where quantity is fixed but price references a future date's futures price. ERP must hold open PTF exposure and resolve it when price is fixed.
- **Hedge accounting**: designation of qualifying futures positions as hedges against inventory or forecasted sales; effectiveness testing required under ASC 815 (US GAAP) or IFRS 9 (IFRS). The commodity management module must generate effectiveness documentation; inadequate documentation causes hedge accounting de-designation and P&L volatility from mark-to-market swings.
- **Price feed integration**: real-time or end-of-day price feeds from CME Group, Refinitiv Eikon (LSEG), or DTN ProphetX populate the futures pricing engine.

### 2.8 Seasonal Workforce Management

Agricultural labor is the most compliance-intensive workforce category in US operations:

- **H-2A temporary agricultural worker program** (8 U.S.C. 1101(a)(15)(H)(ii)(a); DOL regulations 20 CFR Part 655 Subpart B): employer must file DOL Form ETA-790/790A no more than 75 calendar days and no fewer than **60 calendar days** before the date workers are needed (standard filing) [3]. Emergency filings below 60 days require documented justification. ERP workforce planning must trigger the HR filing process with sufficient lead time.
- **Adverse Effect Wage Rate (AEWR)**: federally mandated minimum wage for H-2A workers, published annually by DOL by state. ERP payroll configuration must be updated when AEWR changes; underpayment carries DOL debarment risk.
- **I-9 verification and visa expiry tracking**: each H-2A worker's visa expiry date must be tracked; work authorization expires at visa date. HR module must generate alerts before expiry.
- **Crew and labor contractor management**: growers commonly use farm labor contractors (FLCs); ERP must track contractor ID, worker roster, and liability for wage and hour compliance.
- **Time-and-attendance by field/block/task**: piece-rate workers (e.g., harvest pickers) require time recorded by field and task. Piece-rate wage compliance is governed by FLSA plus state-specific rules (e.g., California IWC Wage Order No. 14 for agricultural workers; other states vary — verify applicable state law for each operation).
- **Housing and transportation**: H-2A employers must provide or arrange free housing and transportation; costs tracked per worker for regulatory reporting.
- **Worker safety records**: OSHA 300 log maintained for agricultural employers; field injury events recorded and linked to location and task.
- **Payroll integration**: HR/payroll systems such as ADP Workforce Now, Paylocity, or UKG receive field attendance and piece-rate records from ERP for pay calculation.

### 2.9 Crop Insurance Integration

- **USDA Risk Management Agency (RMA) programs**: Actual Production History (APH) policy requires historical yield records by field and crop year. Revenue Protection (RP) policy protects against both yield loss and price decline. Agricultural Risk Coverage (ARC) and Price Loss Coverage (PLC) are farm bill commodity programs administered through USDA FSA.
- **Acreage reporting**: planted acres by crop and field submitted to crop insurance agent and/or USDA Farm Service Agency (FSA). ERP field records must produce acreage reports in required format.
- **Yield data submission**: actual yield per field per crop year, supported by production records, submitted at policy settlement. ERP yield records must be audit-ready.
- **Loss claim documentation**: when yield shortfall occurs, ERP must produce documented yield records by cause (weather event, pest, disease) for insurance adjuster review.
- **Integration**: USDA RMA online portals; use "USDA-approved crop insurance agent" as the integration counterparty concept rather than specific company names, as the approved insurer list changes through acquisitions.

### 2.10 Recall & Withdrawal Management

- **Recall vs. withdrawal distinction**: FDA recall (health hazard) vs. voluntary market withdrawal (no health risk); ERP workflow must support both with different notification paths.
- **Bilateral trace execution**: from a suspect lot, system simultaneously traces forward (which customers received product from this lot?) and backward (what inputs or source lots contributed to this lot?). FSMA 204 architecture target: complete one-up/one-down trace of a suspect lot within minutes; full multi-step trace within hours.
- **Regulatory notification**: FDA Reportable Food Registry (RFR) is specifically for reports of articles of food that are reasonably likely to cause serious adverse health consequences or death — it is a distinct reporting obligation from standard FDA recall notification (which goes through FDA's recall reporting system). ERP recall workflow must distinguish these paths. USDA FSIS maintains a separate notification process for meat and poultry recalls.
- **Customer notification**: system-generated notification letters including affected lot numbers, TLCs, quantity, and disposition instructions.
- **Quantity freeze and disposition tracking**: affected inventory placed on system hold; disposition tracked per lot (destroy, rework, return to supplier) with quantity confirmed destroyed.
- **Mock recall drills**: many retail and foodservice customers require suppliers to demonstrate recall capability with periodic mock drills; ERP must support drill execution with documented results.

---

## 3. Regulatory & Compliance Requirements

### 3.1 US Federal (FDA / USDA)

| Regulation | Citation | ERP Relevance |
|---|---|---|
| FSMA Food Traceability Rule | 21 CFR Part 1, Subpart S (87 FR 70752, 21 Nov 2022); compliance date extended to **20 Jul 2028** [1] | TLC assignment, KDE capture at each CTE, 2-year retention, 24-hr retrieval |
| FSMA Preventive Controls for Human Food | 21 CFR Part 117 | HACCP food safety plan, CCP monitoring records, corrective action records, verification |
| FSMA Produce Safety Rule | 21 CFR Part 112 | Agricultural water testing, worker hygiene records, equipment sanitation log |
| FSMA Intentional Adulteration Rule | 21 CFR Part 121 | Vulnerability assessment for wide-release adulteration points; access controls on bulk production transactions |
| Bioterrorism Act 2002 | Public Law 107-188 | Baseline one-up/one-down traceability for all FDA-regulated food facilities |
| USDA FSIS HACCP | 9 CFR Part 417 | HACCP plan, CCP records for meat and poultry processing |
| USDA FSIS Sanitation SOPs | 9 CFR Part 416 | Sanitation standard operating procedures; pre-operational and operational inspection records |
| FIFRA / WPS | FIFRA (7 U.S.C. 136 et seq.); Worker Protection Standard 40 CFR Part 170 | Pesticide application records (2-year retention for restricted-use pesticides); handler/worker safety records |
| H-2A Program | 8 U.S.C. 1101(a)(15)(H)(ii)(a); DOL 20 CFR Part 655 Subpart B | Worker visa tracking, AEWR compliance, ETA-790/790A filing: standard deadline 60 days before need [3] |
| Fair Labor Standards Act | 29 U.S.C. 201 et seq.; agricultural exemptions at 29 U.S.C. 213(a)(6) | Piece-rate wage compliance; overtime exemptions for small farm operations |
| USDA National Organic Program | 7 CFR Part 205 | Organic system plan, prohibited substance records per field; 5-year record retention |

### 3.2 International Standards & Certifications

| Standard | Version / Publication | Scope |
|---|---|---|
| GLOBALG.A.P. IFA | v6.0 (General Regulations); mandatory Jan 2025 for Fruits & Vegetables (IFA v6 Smart or IFA v6 GFS); IFA v6 Smart for Combinable Crops mandatory 1 May 2026 [4] | Integrated Farm Assurance: farm inputs, practices, worker safety, traceability; Chain of Custody (CoC) module for handlers |
| Codex Alimentarius General Principles of Food Hygiene | CXC 1-1969, revised 2020 (2023 reissue) | Authoritative HACCP framework underpinning all GFSI standards; seven HACCP principles |
| ISO 22000 | ISO 22000:2018 | Food Safety Management System requirements; risk-based thinking, PRPs, HACCP system |
| FSSC 22000 | Version 6.0 (April 2023); GFSI-benchmarked; mandatory for all FSSC audits from 1 April 2024 [5] | Builds on ISO 22000:2018 + ISO/TS 22002 series PRPs; adds requirements for quality culture, environmental monitoring program |
| SQF | Edition 9 (current for audits until auditing against Edition 10 is permitted); Edition 10 (published March 2026; audits not prior to 2 Jan 2027, pending GFSI benchmarking completion) [6] | GFSI-recognized; primary standard in North American retail and foodservice supply chains |
| BRCGS Food Safety | Issue 9 (published Aug 2022; mandatory for all audits from Feb 2023) [7] | GFSI-benchmarked; dominant for UK and European retail supplier approval; branded BRCGS (formerly BRC Global Standards) |
| IFS Food | Version 8 (published April 2023; mandatory for audits from 1 Jan 2024) [8] | European retail and wholesale standard; GFSI-recognized |
| EU Organic Regulation | (EU) 2018/848 | Required for organic labeling on EU market; traceability and documentation requirements for organic supply chain |
| Rainforest Alliance / UTZ | Current certification scheme (merged programs) | Sustainability criteria for cocoa, coffee, palm oil; supply chain attestation per shipment |

### 3.3 Commodity Hedge Accounting Standards

- **ASC 815** (FASB) — Derivatives and Hedging: US GAAP framework for designation of qualifying hedge relationships, effectiveness testing, and fair-value vs. cash-flow hedge accounting treatment for commodity futures and options contracts.
- **IFRS 9** — Financial Instruments: IFRS equivalent; similar hedge designation and effectiveness testing requirements. IFRS 9 permits the "cost of hedging" approach for options, which ASC 815 does not in the same way; verify with accounting before configuring ERP hedging module.

---

## 4. Key Data Entities

Domain-specific entities beyond the core ERP data model (see `core/features-core.md` for standard item, vendor, customer, GL entities):

| Entity | Key Fields |
|---|---|
| Field / Block / Parcel | GeoID, geo_polygon (GeoJSON), area_ha, soil_class, irrigation_zone, grower_id (FK) |
| Crop Season | season_id, field_id (FK), commodity, variety, plant_date, planned_harvest_date, actual_harvest_date, status |
| Grower / Ranch Master | grower_id, name, certifications[], ggap_cert_no, ggap_cert_expiry, organic_cert_no, organic_certifier, gap_audit_date |
| Input Item | input_item_id, epa_reg_no, restricted_use_flag, phi_days, rei_hours, active_ingredient, signal_word |
| Application Event | event_id, season_id (FK), input_item_id (FK), rate_kg_ha, operator_id, equipment_id, application_dt, temp_c, wind_kph, humidity_pct |
| Harvest Lot / Grower Receipt | lot_id, TLC, grower_id (FK), field_id (FK), season_id (FK), gross_wt_kg, tare_wt_kg, net_wt_kg, grade_code, harvest_dt, receipt_dt |
| Catch-Weight Record | cwt_id, lot_id (FK), nominal_cases INT, actual_wt_kg DECIMAL(12,3), scale_id, weigh_dt |
| Perishable Stock | stock_id, lot_id (FK), location_id (FK), qty_on_hand, expiry_dt, days_to_expiry (computed), status ENUM[SALEABLE, NEAR_EXPIRY, BLOCKED, EXPIRED] |
| Quality Inspection Result | insp_id, lot_id (FK), ccp_id, inspection_type ENUM[RECEIVE, INPROCESS, OUTBOUND], measurement_value, uom, pass_fail, inspector_id, insp_dt |
| Grower Settlement | settlement_id, grower_id (FK), pool_period, gross_sales_amt, currency, deductions[], net_due, ap_invoice_ref, payment_dt |
| Recall Event | recall_id, trigger_lot_id (FK), direction ENUM[FWD, BWD, BOTH], initiated_dt, fda_notification_dt, status |

**Fenced schema sketch:**

```sql
-- Core farm hierarchy
Grower (grower_id PK, name, certifications[], ggap_cert_expiry, organic_cert_no, organic_certifier)
  └─< Field (field_id PK, grower_id FK, geo_polygon GEOMETRY, area_ha DECIMAL, irrigation_zone, soil_class)
        └─< CropSeason (season_id PK, field_id FK, commodity, variety, plant_date DATE, harvest_date DATE, status)
              └─< ApplicationEvent (
                    event_id PK, season_id FK, input_item_id FK,
                    rate_kg_ha DECIMAL, operator_id FK, equipment_id FK,
                    application_dt TIMESTAMP, temp_c DECIMAL, wind_kph DECIMAL
                  )
              └─< HarvestLot (
                    lot_id PK, season_id FK, TLC VARCHAR(50) UNIQUE NOT NULL,
                    gross_wt_kg DECIMAL, tare_wt_kg DECIMAL, grade_code VARCHAR(10),
                    harvest_dt TIMESTAMP
                  )

-- Lot lifecycle: quality, catch weight, inventory
HarvestLot (lot_id PK)
  └─< QualityInspection (
        insp_id PK, lot_id FK, ccp_id, inspection_type ENUM,
        measurement_value DECIMAL, uom, pass_fail BOOLEAN,
        inspector_id FK, insp_dt TIMESTAMP
      )
  └─< CatchWeightRecord (
        cwt_id PK, lot_id FK,
        nominal_cases INT, actual_wt_kg DECIMAL(12,3),
        scale_id VARCHAR(20), weigh_dt TIMESTAMP
      )
  └─< PerishableStock (
        stock_id PK, lot_id FK, location_id FK,
        qty_on_hand DECIMAL, expiry_dt DATE,
        days_to_expiry AS (expiry_dt - CURRENT_DATE),  -- computed
        status ENUM[SALEABLE, NEAR_EXPIRY, BLOCKED, EXPIRED]
      )

-- N:M lot genealogy for blend/transformation
LotLineage (
  parent_lot_id FK REFERENCES HarvestLot(lot_id),
  child_lot_id  FK REFERENCES HarvestLot(lot_id),
  pct_contribution DECIMAL,
  transformation_event_id FK,
  PRIMARY KEY (parent_lot_id, child_lot_id)
)

-- Grower financial settlement
GrowerSettlement (settlement_id PK, grower_id FK, pool_period VARCHAR(20),
                  gross_sales_amt DECIMAL, currency CHAR(3))
  └─< SettlementDeduction (
        ded_id PK, settlement_id FK,
        deduction_type VARCHAR(50), amount DECIMAL, gl_account VARCHAR(20)
      )
  └─< SettlementPayee (
        payee_id PK, settlement_id FK,
        payee_vendor_id FK, pct_share DECIMAL, ap_invoice_ref
      )

-- Recall management
RecallEvent (recall_id PK, trigger_lot_id FK, direction ENUM[FWD,BWD,BOTH],
             initiated_dt TIMESTAMP, fda_notification_dt TIMESTAMP, status)
  └─< AffectedLot (
        recall_id FK, lot_id FK,
        qty_frozen DECIMAL,
        disposition ENUM[DESTROY, REWORK, RETURN],
        confirmed_dt TIMESTAMP,
        PRIMARY KEY (recall_id, lot_id)
      )
```

---

## 5. Critical Integrations

| System Category | Named Products / Systems | Data Exchanged |
|---|---|---|
| Weighbridge / Scale | Mettler Toledo ICS industrial scales, Avery Weigh-Tronix | Catch-weight readings (actual kg) per lot; scale ID, timestamp |
| Field Telematics | John Deere Operations Center, CNH AFS Connect (Case IH, New Holland), Trimble Ag Software | GPS tracks, engine hours, fuel consumption, field operation records |
| Agronomic / Weather | The Climate Corporation Climate FieldView (Bayer), Trimble Ag, DTN AgWeather | GDD accumulation, spray window advisories, soil moisture, irrigation triggers |
| Commodity Price Feed | CME Group (CBOT grain/oilseed futures), Refinitiv Eikon (LSEG), DTN ProphetX | Real-time and end-of-day futures prices, cash prices, basis by location |
| GIS / Mapping | ESRI ArcGIS | Field polygon management, area calculation, spatial analysis for field records |
| Lab / LIMS | LabVantage LIMS, NEOGEN platform | Microbiological and chemical test results per lot; pass/fail, measurement value, test method |
| Cold-Chain / WMS | Swisslog, Dematic, Manhattan Associates Warehouse Management | FEFO pick sequencing, location temperature logging, lot status updates |
| IoT / Sensors | CropX soil sensors, Davis Instruments weather stations, Conservis | Soil moisture, ambient temperature, storage humidity; feeds temperature excursion triggers |
| Electronic Bills of Lading / TMS | FourKites, project44, SAP TM | Outbound shipment tracking, proof of delivery, temperature in transit |
| Regulatory — FDA | FDA Reportable Food Registry (RFR) electronic portal; FDA recall reporting system | Adverse event reports (RFR); standard recall notifications (separate channel) |
| Crop Insurance | USDA RMA online portals; USDA-approved crop insurance agents | Acreage reports, yield history, loss claim documentation |
| HR / Payroll | ADP Workforce Now, Paylocity, UKG Pro | H-2A worker records, I-9 status, visa expiry, piece-rate time-and-attendance, payroll feeds |
| EDI / Retail Customers | SPS Commerce, GS1 EDI (ANSI X12 856 ASN, 850 PO, 810 Invoice) | Advance ship notices with TLC data, purchase orders, invoices |
| Certification Bodies | GLOBALG.A.P. database, organic certifier portals | Certificate status, audit results, QR-code verified certification |

**FSMA 204 EDI gap**: Many trading partners still use ANSI X12 856 ASNs without the KDE fields (TLC, CTE, lot-specific harvest data) required by FSMA 204. This is not a negotiable gap — it requires either trading partner data augmentation agreements or an intermediary translation layer before the Jul 2028 compliance date [1].

---

## 6. KPIs & Metrics

| KPI | Definition | Formula / Unit |
|---|---|---|
| Traceability Response Time | Time from recall trigger to complete one-up/one-down lot list | Minutes from trigger to full affected-lot list |
| Recall Effectiveness Rate | Confirmed retrieved/destroyed product as % of total shipped | (Units retrieved or confirmed destroyed / Units shipped) × 100 |
| Shelf-Life Waste % | Value of expired or written-off perishable inventory as % of perishable throughput | (Expired inventory cost / Total perishable throughput cost) × 100 |
| Catch-Weight Variance % | Deviation of actual weight from nominal billed weight | (Actual kg − Nominal kg) / Nominal kg × 100 |
| Days-to-Expiry at Shipment (DTE) | Average remaining shelf-life in days at outbound shipment | Avg(expiry_date − ship_date) per lot shipped |
| Yield per Hectare | Crop output per unit land area by variety and field | Total harvest kg / Planted ha |
| Input Cost per Hectare | Total agrochemical + seed + irrigation cost per harvested hectare | Total input spend / Harvested ha |
| Settlement Cycle Time | Days from grower delivery to settlement AP payment | Calendar days: receipt_date to ap_payment_date |
| Hedge Coverage Ratio | % of forward sales volume covered by futures or options positions | (Hedged volume / Total projected production volume) × 100 |
| OTIF to Retail DC | Orders delivered on-time and in-full to retail distribution centers | (Orders delivered on-time and complete / Total orders) × 100 |
| Produce Shrink % | Product value lost to damage, spoilage, culls in pack shed or warehouse | (Shrink value / Received value) × 100 |
| H-2A Worker Utilization | Productive hours vs. contracted hours for H-2A workforce | (Productive hours / Contracted hours) × 100 |
| Cost of Goods Processed per Tonne | Total processing cost (labor, utilities, packaging) per output tonne | Total processing cost / Output tonnes |
| MRSL Compliance Rate | % of outbound shipments meeting minimum remaining shelf-life per customer rules | (Shipments meeting MRSL / Total shipments) × 100 |

---

## 7. Major ERP Vendors for this Vertical

### 7.1 SAP S/4HANA for Agribusiness

SAP S/4HANA is the enterprise standard for large-scale food and agribusiness operations. Core functional modules: FI/CO (financial accounting and controlling), MM (materials management), SD (sales and distribution), PP-PI (process manufacturing with production orders), QM (quality management), PM (plant maintenance), EWM (extended warehouse management), TM (transportation management).

**Agri-specific modules and components:**

- **SAP Agricultural Contract Management (SAP ACM)**: delivered as part of SAP S/4HANA; covers grower contracts, pooling logic, settlement calculation, advance payment processing, and account sales document generation. Available in S/4HANA on-premise releases including S/4HANA 2025 [9].
- **SAP Catch Weight Management**: dual-UOM inventory within MM and EWM; weighbridge integration points; catch-weight-specific posting logic.
- **SAP Commodity Management (SAP CM)**: futures contract register, basis tracking, PTF contracts, hedge effectiveness documentation. Verify current module name and availability in the target S/4HANA release via SAP Help Portal, as naming has varied across releases.
- **SAP Environment, Health & Safety (EHS) Management**: pesticide application records, Safety Data Sheet (SDS) management, worker exposure tracking.
- **SAP Transportation Management (TM)**: fresh-produce route optimization with temperature and FEFO constraints.

Implementation pattern: SAP S/4HANA core is commonly supplemented by Trimble Ag Software or Climate FieldView for farm-side field data, integrated via SAP Business Technology Platform (BTP) APIs. SAP does not provide a native agronomic decision engine.

Note: SAP ECC mainstream maintenance ends 2027 (extended maintenance to 2030); new agri-food projects should target S/4HANA.

### 7.2 Infor CloudSuite Food & Beverage (Infor M3)

Infor CloudSuite Food & Beverage is built on the Infor M3 process manufacturing ERP core. Target segment: mid-to-large food manufacturers including meat/fish processors, dairy, bakeries, beverage producers.

- **Infor M3 core**: batch management, formula and recipe management, co-products and by-products, process order execution.
- **CloudSuite F&B additions**: Quality Management (CoA generation, inspection plans, test result capture), potency-based ordering, catch-weight management, FEFO-native warehouse management, grower contracts and settlements for farmer payments based on received quality grades [10].
- **Infor WMS**: purpose-built warehouse management with FEFO pick sequencing natively integrated.
- **Lot genealogy**: multi-level forward and backward trace across process orders; supports N:M blend relationships.
- Verify KDE field coverage in current CloudSuite release against FSMA 204 specific requirements before finalizing design.

### 7.3 AgriERP (Folio3 / Microsoft Dynamics 365 Business Central)

AgriERP is a purpose-built vertical solution for mid-size farm operations, built on Microsoft Dynamics 365 Business Central. Named "ERP Software of the Year" by AgTech Breakthrough Awards, August 2025 [11].

**Modules**: Farm Operations Management, Crop and Field Management (GIS integration via ESRI ArcGIS), Yield Recording, Input Inventory, Equipment Maintenance, Financial Management, HR and Labor Management.

**Integrations**: John Deere Operations Center (telematics), ESRI ArcGIS (geo-referenced field records).

Best suited for: row crop farms, orchards, nut growers, smaller agribusinesses where a full SAP or Infor deployment is disproportionate to scale. Grower settlement complexity and commodity hedging depth should be evaluated against specific requirements before selection.

### 7.4 Aptean Food & Beverage ERP

Aptean Food & Beverage ERP offers tiered editions for different segments. The Enterprise Edition is built on Microsoft Dynamics 365 Finance and Operations (Finance & Supply Chain Management) [12]. Other editions run on Microsoft Dynamics 365 Business Central.

| Edition | Platform | Target Segment |
|---|---|---|
| Enterprise Edition | Microsoft Dynamics 365 Finance & Supply Chain Management | Large food processors, multi-site |
| bcFood ERP | Microsoft Dynamics NAV | Mid-market food and beverage |
| (Business Central edition) | Microsoft Dynamics 365 Business Central | Cloud-native mid-market |
| Fresh Produce ERP | Microsoft Dynamics 365 F&SCM / BC | Fresh produce handlers and distributors |
| Meat & Fish Edition | Microsoft Dynamics 365 F&SCM | Protein processors |

**Agri-specific modules**: Grower Tracking (grower/ranch/field/block master), Harvest Planning, Grower Accounting (settlement calculation, pooling, deductions, advance management, commission), catch-weight management, FEFO-native inventory, bi-directional Recall Management, Trading Board, Weighbridge integration. Module names as presented in Aptean vendor documentation; internal Dynamics 365 technical module names may differ.

### 7.5 Notable Alternatives

| Product | Vendor | Agri-Food Fit | Key Gaps |
|---|---|---|---|
| NetSuite | Oracle | Food distributors, smaller food manufacturers; SuiteApp ecosystem for some gaps | No native farm management or grower settlement; catch weight via SuiteApp |
| Dynamics 365 F&SCM (base) | Microsoft | Large food/beverage with ISV overlays (Aptean, AgriERP, others) | No native agri verticalisation without ISV |
| Plex | Rockwell Automation | Food processor shop-floor operations; strong MES and QC | Limited grower-side; weak commodity management |
| Deacom ERP | ECI Solutions | Process manufacturing, batch and catch weight; food and beverage niche | Limited farm management |

---

## 8. Implementation Cautions

1. **Biological variability vs. ERP determinism.** Standard ERP planned orders assume deterministic yield from a BOM and routing. Crop yields carry meaningful variance depending on weather and pest pressure (qualitative assessment; do not use a specific percentage without client historical data). ERP planning models must incorporate agronomic forecast ranges and buffer stock logic; standard MRP logic will generate chronic shortage or excess signals if yield variance is not modeled.

2. **N:M lot genealogy at blend/transformation.** Blending tanks (juice, wine, olive oil, tomato paste) create one child lot from multiple parent lots. Many ERP systems support 1:N genealogy (one parent splits into children) but implement N:M (multiple parents blend into a child) as a workaround or not at all. Verify N:M support with a documented test case before vendor selection; this is a FSMA 204 architectural requirement for any blending operation.

3. **Catch-weight dual UOM consistency.** Billing on actual weight with ERP defaulting to nominal UOM at any integration point creates systematic AP/AR posting errors. Dual-UOM configuration must be validated end-to-end: weighbridge → EWM/WMS → MM goods receipt → SD billing → AP invoice. Test with actual scale data from production-representative lot sizes before go-live.

4. **FEFO requires WMS physical enablement.** FEFO pick sequences generated by the system fail if physical warehouse layout mandates first-in/first-out access (e.g., drive-in racking, floor-stacked product). FEFO compliance requires random-access storage (single-deep racking or automated storage). Implement FEFO-capable WMS and physical storage design together; do not bolt FEFO logic onto a warehouse designed for FIFO.

5. **Grower settlement complexity is routinely underestimated.** Pool settlement touching hundreds of growers with differing contract terms, advance balances, multiple payees, and complex deduction schedules is the most frequently underestimated configuration effort in fresh produce ERP projects. Build and test settlement scenarios with finance, operations, and grower relations staff before UAT; do not treat settlement as a standard AP configuration.

6. **Seasonal peak load testing is non-negotiable.** Harvest-period transaction volumes can exceed average daily volumes by large multiples (validate against client operational data). ERP, WMS, EDI middleware, and HR/payroll must all be load-tested under peak assumptions. Performance failures at harvest are operationally catastrophic because they cannot be rescheduled.

7. **H-2A filing lead time must be system-enforced.** H-2A petitions must be filed a minimum of 60 calendar days before workers are needed (standard filing) [3]. If ERP workforce planning does not trigger the HR/legal filing process at the correct lead time, the farm will be short of legal labor at harvest. Build a planning workflow alert into the system, not a manual calendar reminder.

8. **FSMA 204 KDE coverage in legacy EDI.** Trading partners using ANSI X12 856 ASNs without KDE extensions will not transmit the Traceability Lot Code, CTE-specific data, or harvest event details required by FSMA 204 [1]. Before Jul 2028, each major trading partner's EDI capability must be assessed and gaps remediated either through direct EDI upgrade negotiation or an intermediary data translation layer.

9. **Commodity hedge accounting mis-designation.** Incorrect designation of futures positions as accounting hedges — or failure to maintain contemporaneous effectiveness documentation — causes de-designation, forcing mark-to-market of the futures position through P&L independent of the hedged inventory or sales. Ensure the commodity management module auto-generates hedge effectiveness test documentation; have the accounting team review ERP hedge designation configuration before go-live, not after the first period-end.

10. **Cold-chain IoT integration latency.** Temperature excursions in a cold storage zone must trigger an automatic quality hold on all affected lots within minutes. Integration between IoT sensor platform, WMS location records, and ERP QM must be tested for both latency (how quickly does the hold propagate?) and false-positive handling (sensor noise must not generate spurious production holds). Define latency and false-positive SLAs before integration design.

11. **Organic segregation must be systemic, not procedural.** Organic and conventional product physically co-mingled in a shared bin, conveyor, or packing line — even briefly — can result in USDA NOP decertification of the entire farm operation. ERP must enforce physical and systemic segregation via separate inventory locations, separate production orders, and separate lot numbering sequences for organic product. Segregation checks must be configured as system controls, not reliant on operator procedures.

12. **FSMA 204 compliance date extension does not reduce scope.** The Jul 2028 deadline was established through Congressional action [1]. The rule is final in substance; deferring architecture decisions does not reduce the eventual scope of work, and integration design decisions made now (lot numbering, EDI field mapping, TLC uniqueness enforcement) are harder to retrofit than to build correctly from the start.

---

## 9. Security & Compliance Depth

For foundational SoD controls, audit trail architecture, and role-based access patterns, see `core/security.md`. The following are agri-food-specific security and compliance requirements that extend the core:

**FSMA 204 record integrity.** KDE records must be tamper-evident and available to FDA within 24 hours of request [1]. Implementation requirement: append-only audit log per lot at the database level (insert-only table or immutable event store), not an editable data grid with a soft-delete. Standard ERP change-document logging is a minimum; a dedicated immutable event log per lot satisfies both FSMA 204 and internal audit requirements more robustly.

**Electronic records for FSMA Preventive Controls (21 CFR Part 117).** FDA does not formally apply 21 CFR Part 11 (the pharmaceutical e-record/e-signature regulation) to food records. However, electronic HACCP monitoring records and CCP logs maintained under FSMA Part 117 carry equivalent requirements for record integrity, access control, and traceability of changes. Implement e-signature controls on CCP monitoring approvals and corrective action records using the same principles as 21 CFR Part 11, even though the specific regulation does not formally apply.

**FSMA Intentional Adulteration (21 CFR Part 121).** This rule requires a written vulnerability assessment for points in the process susceptible to wide-release adulteration. ERP access controls on bulk production transactions (bulk ingredient additions, rework additions, production order releases) are a mitigating control in that vulnerability assessment. Ensure ERP role design restricts who can modify bulk formula inputs post-release.

**Pesticide application record access.** FIFRA requires 2-year retention of restricted-use pesticide application records and grants state agricultural regulatory agencies the right to inspect on demand. ERP access must allow read-only export of application records for regulatory inspectors without granting broader system access. Implement a dedicated regulatory-access role with field/application record read-only scope.

**Grower data confidentiality.** Grower contract terms, settlement amounts, and field-level yield data are commercially sensitive. Competitors, trading partners, and even internal sales staff should not have visibility into settlement calculations or individual grower yields. RBAC must restrict settlement module access to AP/accounting staff and grower relations management.

**GS1 TLC uniqueness enforcement.** FSMA 204 prohibits reassignment of a Traceability Lot Code once assigned [1]. ERP lot numbering sequences must enforce global uniqueness — use GUIDs or GS1 SSCC-structured lot codes with a check digit. Do not allow manual lot number entry without format validation; manual entry is the primary source of TLC duplication errors.

**Segregation of duties in grower settlement.** The same user must not create a grower receipt record, enter the grade determination, and approve the settlement calculation. These three functions represent both financial authorization controls and food safety controls (grade manipulation affects both payment and compliance). SoD configuration for grower settlement is a specific audit finding in food company financial audits; see `core/security.md` for the SoD matrix framework.

**Data retention schedule — dual requirement.** FSMA 204 mandates 2-year retention for traceability records [1]. USDA NOP (7 CFR Part 205) mandates 5-year retention for organic certification records. FIFRA mandates 2-year retention for restricted-use pesticide application records. ERP archive and data retention strategy must address all three retention horizons; the 5-year NOP retention drives the longest retention obligation and should be used as the baseline for agri-food record retention design.

**Export documentation integrity.** Phytosanitary certificates, certificates of origin, and import tolerance certificates are government-endorsed documents. They must be generated as system-sealed, non-editable PDF outputs from ERP with electronic signature; post-generation manual editing must be technically impossible, not merely prohibited by procedure. Allow only authorized government agency users or qualified inspectors to initiate the generation workflow.

**Supply chain fraud detection.** Commodity price manipulation (false grade declarations, weight fraud at weighbridge) has financial and regulatory consequences. Anomaly detection on catch-weight variance (lots with variance outside tolerance bounds should auto-flag for supervisor review), on grade distribution patterns (sudden shift in grade mix for a grower), and on manual journal entries in commodity inventory accounts should be part of the internal control design.

---

## See also

- `core/features-core.md` — standard ERP modules and capabilities
- `verticals/distribution-logistics.md` — cold-chain, 3PL, and temperature-controlled logistics overlap
- `verticals/manufacturing.md` — process manufacturing (PP-PI, formula/recipe, batch management) concepts
- `core/security.md` — SoD matrix, audit trail architecture, RBAC patterns
- `core/localization-tax.md` — multi-country tax and currency considerations for export operations

---

## Citations & Sources

1. FDA / Federal Register — "Requirements for Additional Traceability Records for Certain Foods: Compliance Date Extension," 90 FR [2025-14967], 7 Aug 2025; subsequently made non-enforcement binding through the Continuing Appropriations, Agriculture, Legislative Branch, Military Construction and Veterans Affairs, and Extensions Act of 2026 (enacted Nov 2025). See: https://www.federalregister.gov/documents/2025/08/07/2025-14967/requirements-for-additional-traceability-records-for-certain-foods-compliance-date-extension

2. FDA — Food Traceability List (FTL), maintained at: https://www.fda.gov/food/food-safety-modernization-act-fsma/food-traceability-list

3. U.S. Department of Labor, Employment and Training Administration — H-2A Agricultural Clearance Order Form ETA-790/790A General Instructions (updated 30 Nov 2025); DOL regulations 20 CFR Part 655 Subpart B. See: https://www.dol.gov/agencies/eta/foreign-labor/programs/h-2a

4. GLOBALG.A.P. — IFA v6 standards for combinable crops and plant propagation material (published 8 Jul 2025; IFA v6 Smart for Combinable Crops mandatory 1 May 2026). See: https://www.globalgap.org/news-and-press/ifa-v6-cc-ppm-launch/

5. FSSC 22000 — Scheme Version 6.0 (April 2023); mandatory for all FSSC 22000 audits from 1 April 2024, transition period ending 31 March 2025. See: https://www.fssc.com

6. SQF Institute — SQF Edition 10 (published March 2026); audits not prior to 2 Jan 2027 pending GFSI benchmarking completion. See: https://www.sqfi.com

7. BRCGS — Global Standard Food Safety Issue 9 (published Aug 2022; mandatory for all audits from Feb 2023). See: https://www.brcgs.com/our-standards/food-safety/

8. IFS — IFS Food Version 8 (published April 2023; mandatory for audits from 1 Jan 2024). See: https://www.ifs-certification.com

9. SAP — Agricultural Contract Management (SAP ACM) on SAP S/4HANA; SAP Help Portal: https://help.sap.com/docs/SAP_S4HANA_ON-PREMISE/29b076e23a9f4b0b9d41c5af9c6f7da0/a8aa9e3a7bb24f0c829677cecf532a56.html

10. Infor — CloudSuite Food & Beverage product documentation: https://docs.infor.com/m3cs

11. Folio3 / AgriERP — "AgriERP From Folio3 Software Named 'ERP Software of the Year' By AgTech Breakthrough," GlobeNewswire, 21 Aug 2025: https://www.globenewswire.com/news-release/2025/08/21/3137313/0/en/AgriERP-From-Folio3-Software-Named-ERP-Software-of-the-Year-By-AgTech-Breakthrough.html

12. Aptean — Food & Beverage ERP Enterprise Edition on Microsoft Dynamics 365 Finance and Operations: https://www.aptean.com/solutions/erp/products/aptean-food-and-beverage-erp-enterprise

13. FDA FSMA Final Rule — Requirements for Additional Traceability Records for Certain Foods (87 FR 70752, 21 Nov 2022): https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-requirements-additional-traceability-records-certain-foods

14. Codex Alimentarius — General Principles of Food Hygiene CXC 1-1969 (revised 2020): http://www.fao.org/fao-who-codexalimentarius

15. ISO 22000:2018 — Food Safety Management Systems: https://www.iso.org

16. USDA National Organic Program (7 CFR Part 205): https://www.ams.usda.gov/about-ams/programs-offices/national-organic-program

17. USDA RMA Crop Insurance programs: https://www.rma.usda.gov

18. CME Group Agricultural Markets (CBOT): https://www.cmegroup.com/markets/agriculture

19. FASB ASC 815 — Derivatives and Hedging: https://asc.fasb.org

20. IFRS 9 — Financial Instruments: https://www.ifrs.org/issued-standards/list-of-standards/ifrs-9-financial-instruments/

21. GS1 — SSCC and GS1-128 standards: https://www.gs1.org/standards/barcodes/sscc
