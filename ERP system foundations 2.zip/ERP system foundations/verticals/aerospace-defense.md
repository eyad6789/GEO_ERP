# ERP for Aerospace & Defense

## 1. Overview

Aerospace & Defense (A&D) imposes a denser intersection of legal, regulatory, and operational constraints on ERP than virtually any other vertical. A single defense contract program can simultaneously require DCAA-auditable project accounting, ITAR-controlled data segregation, AS9100 Rev D quality traceability, EVMS earned-value reporting, and airworthiness documentation — each with its own audit trail density, user-access model, and data retention obligation. No general-purpose ERP satisfies all of these out of the box; every A&D deployment involves either a purpose-built system (Deltek Costpoint) or substantial configuration of a broader platform (SAP S/4HANA, IFS Cloud, Infor LN).

**Sub-sectors and their ERP focal points:**

| Sub-sector | Primary ERP pressure points |
|---|---|
| Prime defense contractors | DCAA cost accounting, EVMS, CAS disclosure, ITAR segregation, progress billing |
| Tier-2/Tier-3 subcontractors | FAR flow-down compliance, CAS modified coverage, AS9100 QMS, counterfeit parts |
| MRO providers & repair stations | Airworthiness releases (8130-3/EASA Form 1), serialized traceability, rotable pools, PBH billing |
| Commercial airlines | MPD/AMM task cards, reliability analysis, heavy-check work-order costing, PBH contracts |
| Aerospace distributors/stockists | AS9120B QMS, OCM traceability, counterfeit prevention (AS5553E), lot genealogy |
| Space companies | Long-cycle project accounting, unique serialized component traceability, export control (USML Categories IV and XV) |

**Contrast with standard manufacturing ERP:** Standard manufacturing ERP is product-centric: BOM-driven, standard-cost or actual-cost, with revenue recognized on shipment or delivery. A&D ERP is predominantly project-centric: cost-type contracts accumulate actual costs to specific contract/WBS objectives; revenue recognition follows percentage-of-completion under ASC 606 over time; cost visibility must be preserved at the cost-element level (labor, material, subcontract, ODC) for government audit. Fixed-price contracts (FFP) look more like product manufacturing, but even these carry AS9100 and counterfeit-parts obligations that standard manufacturing ERP does not address.

The four architectural drivers that distinguish A&D ERP from all other verticals:

1. **ITAR/EAR data segregation** — citizenship-based access control enforced at the database record level, not the UI layer.
2. **DCAA audit readiness** — cost accounting must satisfy SF 1408's 18 criteria; timekeeping must prohibit pre-population and require daily employee certification.
3. **EVMS** — WBS/OBS/CBS integration with time-phased budgets (BCWS), earned value (BCWP), and actual cost (ACWP) tracking, feeding Contract Performance Reports (CPR) per DI-MGMT-81861. [1]
4. **AS9100 / airworthiness quality density** — every production or repair transaction must carry an unbroken traceability chain back to raw material, manufacturer, lot, and inspector.

---

## 2. Industry-Specific Modules

### Contract Lifecycle Management

A&D contracts do not map to standard sales orders. The CLIN/SLIN/ACRN structure — Contract Line Item Number, Sub-Line Item Number, Accounting Classification Reference Number — must be natively modeled, not approximated via custom fields. Each CLIN represents a separately priced deliverable; each ACRN represents a distinct funding appropriation. The ERP must track:

- **Contract type** per CLIN: Firm Fixed Price (FFP), Cost Plus Fixed Fee (CPFF), Cost Plus Award Fee (CPAF), Time & Materials (T&M), Indefinite Delivery/Indefinite Quantity (IDIQ), Basic Ordering Agreement (BPA)
- **Option periods** with automatic notifications at option exercise deadlines
- **Period of Performance (POP)** start/end per CLIN with obligation and funding ceiling tracking
- FAR/DFARS clause matrix attached to each contract (e.g., presence of FAR 52.216-7 triggers incurred cost submission obligation; presence of DFARS 252.234-7999 triggers EVMS [1])

### Government Project Accounting & Cost Pools

Indirect cost pool structure is the foundation of DCAA compliance. The ERP must support multi-tier indirect rate pools allocated in sequence:

| Pool | Typical allocation base |
|---|---|
| Fringe Benefits | Direct labor dollars or hours |
| Overhead (by facility or business unit) | Direct labor dollars (or direct labor + fringe) |
| Material Overhead (Mat OH) | Direct material dollars |
| G&A (General & Administrative) | Total Cost Input (TCI) or Value Added base |
| Facilities Capital Cost of Money (FCCM) | Net Book Value × Treasury rate; FAR 31.205-10 |

Each cost transaction must hit a cost objective (direct: specific contract/WBS/CLIN; indirect: pool). **Unallowable costs** per FAR 31.205 (advertising, entertainment, fines, penalties, lobbying, certain legal costs) must be tagged in the chart of accounts and excluded from indirect pool calculations automatically — misallocation to government contracts creates False Claims Act exposure. [2]

### EVMS Module

Earned Value Management System integration is mandatory for DoD contracts. As of February 1, 2026, DFARS Class Deviation 2026-O0011 replaced DFARS clauses 252.234-7001 and 252.234-7002 with new clauses 252.234-7998 (Notice of EVMS) and 252.234-7999 (Earned Value Management System). [1] The updated thresholds under this deviation:

- **$50M or more (cost or incentive contract):** Contractor must use an EVMS and insert DFARS clause 252.234-7999.
- **$100M or more:** Contractor must use an EVMS that has been determined acceptable by the Cognizant Federal Agency (CFA), typically DCMA. [1]

The module must implement **ANSI/EIA-748-E (published February 17, 2026)**, which reduced the prior 32 criteria to 27 guidelines (a reduction of five guidelines) across 5 categories: Organization; Planning & Budgeting; Progress Assessment & Data Collection; Analysis & Management Reports; Revisions & Data Maintenance. [3]

Required EVMS module capabilities:

- **Work Breakdown Structure (WBS)** linked to **Organizational Breakdown Structure (OBS)** defining the Control Account structure
- **Control Account Plan (CAP)** with **Performance Measurement Baseline (PMB)**: time-phased BCWS (Budgeted Cost for Work Scheduled) spread across the period of performance
- Real-time BCWP (Budgeted Cost for Work Performed) computation from earned-value measurement methods (0/100, 50/50, milestones, % complete, level of effort)
- ACWP (Actual Cost of Work Performed) from cost transactions posted to the WBS
- Automated variance analysis: SV = BCWP − BCWS; CV = BCWP − ACWP; SPI = BCWP/BCWS; CPI = BCWP/ACWP
- EAC (Estimate at Completion) and ETC (Estimate to Complete) management with formal review cadence
- CPR (Contract Performance Report, DI-MGMT-81861) Format 1–5 generation; CFSR (Contract Funds Status Report) generation
- Management Reserve (MR) and Undistributed Budget (UB) tracking; Over Target Baseline (OTB) / Over Target Schedule (OTS) reprogramming workflow

### ITAR/EAR Export Control Module

Export control is an architecture requirement, not a module add-on. The ERP must enforce:

- **USML classification** (22 CFR Parts 120–130, ITAR) [4] at the item master level: USML category I–XXI assignment with effective date and review date
- **ECCN classification** (15 CFR Parts 730–774, EAR) [5] for dual-use items; EAR99 designation for non-controlled items
- **US Person flag** on every record containing controlled technical data (drawings, BOMs, specifications); non-US-Person users are blocked at the record level regardless of UI role
- **Technology Control Plan (TCP) enforcement**: system checks TCP requirements before allowing access to controlled data or export of records
- **Deemed export tracking**: disclosure of controlled technology to foreign nationals, even on domestic soil, constitutes an export under 22 CFR 120.17 (ITAR) and 15 CFR 734.13 (EAR) [4][5]
- **Export license management**: license number, authorized quantity, expiration date, consumed quantity per shipment; automated alerts before expiration
- **Denied Party Screening (DPS)**: integration with screening services (Descartes Visual Compliance, Thomson Reuters ONESOURCE) against DDTC, BIS, OFAC, and other lists at order entry and shipping

### Serialized & Lot-Controlled Inventory

Every serialized unit in A&D must have an unbroken chain of custody from the original component manufacturer (OCM) through every transfer, repair, and installation. The ERP must capture serial number at receipt (not just at build), carry TSN/TSO/CSN/CSO counters for life-limited parts, attach the Certificate of Conformance (C of C) and FAA Form 8130-3 or EASA Form 1 as document references, track shelf-life expiration for time-controlled materials, and support quarantine status for suspect counterfeit or unserviceable units. IUID/UID per MIL-STD-130 (2D DataMatrix) must be generated and registered in the DoD IUID Registry via WAWF/EDI for all deliverable and government-furnished items.

### Configuration Management

A&D requires effectivity-controlled BOMs — the "as-designed" BOM (what engineering released), the "as-built" BOM (what was actually assembled, serial-by-serial), and the "as-maintained" BOM (current installed configuration after repairs and mods). The ERP must maintain all three:

- Engineering Change Order (ECO) lifecycle: initiation → impact analysis → disposition → approval → release → effectivity → retrofit tracking
- Deviation and waiver management: authorized departure from design (deviation) or from conforming product already built (waiver); each must link to contract CLIN and customer approval
- Configuration baseline snapshots at contract milestones for configuration audits (Functional Configuration Audit / Physical Configuration Audit)

### MRO (Maintenance, Repair & Overhaul)

MRO in A&D is functionally distinct from manufacturing. Key capabilities required:

- **Work-scope authoring** from regulatory task cards: Maintenance Planning Document (MPD), Aircraft Maintenance Manual (AMM), Component Maintenance Manual (CMM) references embedded in work orders
- **Rotable pool management**: tracking total fleet, serviceable, unserviceable, in-shop, and exchange-queue quantities per part number
- **Component time/cycle tracking**: TSN (Time Since New), TSO (Time Since Overhaul), CSN (Cycles Since New), CSO (Cycles Since Overhaul) — updated at every shop visit and installation
- **Shop order and line-maintenance work orders**: discrepancy recording, resolution, parts consumed, labor hours, non-routine task generation
- **FAA Form 8130-3 / EASA Form 1 generation**: Authorized Release Certificate produced directly from the work order with full traceability to part removed, part installed, work performed, authorizing individual, and repair station (14 CFR Part 145 station) [6]
- **Airworthiness Directive (AD) compliance tracking**: mandatory ADs linked to aircraft/engine/component records; compliance status and next-due tracking
- **Reliability analysis**: mean time between removals (MTBR), mean time between failures (MTBF), component reliability dashboards
- **Power-by-the-Hour (PBH) billing**: actual MRO cost accumulation against contracted flight-hour rates; airline customer invoicing with reconciliation reports

### DCAA-Compliant Timekeeping

The DCAA tests timekeeping as part of the SF 1408 accounting system adequacy review. The ERP timekeeping module must enforce:

- Daily charge-number entry: employees must record hours on the day worked (no advance entry)
- **No pre-population**: the system must not auto-fill prior-period charge numbers or hours; each day starts blank
- Employee **certification** (electronic signature) attesting that recorded hours are accurate
- **Supervisor review and approval workflow** before charges are distributed to contracts
- Full audit trail: who entered, when entered, any corrections with original value, correcting value, reason code, and approver
- Labor distribution from approved timesheet to contract/WBS/cost element, feeding the indirect pool allocation process

### Incurred Cost Submission (ICS) / ICE Model Support

FAR 52.216-7 requires contractors on cost-type contracts to submit incurred costs to their cognizant DCAA office within 6 months of fiscal year end. The ERP must support generation of the approximately 19 schedules of the ICE (Incurred Cost Electronically) model — including direct costs by contract, indirect cost pool reconciliation, subcontract cost summaries, and executive compensation disclosure — along with provisional versus final indirect rate reconciliation and rate variance analysis.

### Progress Billing / Milestone Billing

- **Public voucher generation**: SF-1034 / SF-1035 formatted output for government submission
- **ACRN tracking**: each billing line must reference the correct ACRN to credit the correct government appropriation
- **WAWF / IPP integration**: mandatory electronic invoicing submission for most DoD contracts; ERP must transmit invoice data to Wide Area Workflow
- **Milestone billing triggers**: system events (test completion, delivery acceptance, design review approval) that auto-generate billing requests
- **Retainage management**: contractor-held retainage released upon contract closeout or performance milestones
- **Underbilling / overbilling controls**: ceiling monitoring per CLIN and ACRN to prevent over-ceiling billing

### Counterfeit Parts Prevention

Per **AS5553E** (Revision E, November 2025, SAE International — superseding AS5553D (2022), AS5553C (2019), AS5553B (2016), AS5553A (2013)): [7]

- OCM (Original Component Manufacturer) traceability required for all electrical, electronic, and electromechanical (EEE) parts
- Independent distributor purchase triggers enhanced inspection and quarantine workflow automatically
- Suspect counterfeit quarantine with documented disposition (test, destroy, report to ERAI/GIDEP)
- AS5553E flow-down must be captured in ERP supplier records and purchase order terms, extending to all supply chain tiers
- Risk scoring per part number based on obsolescence status, supply chain depth, and historical counterfeit reports

### AS9100 QMS Integration

- **Nonconformance (NCR) module**: discrepancy capture at receiving, in-process, and final inspection; Material Review Board (MRB) disposition (use-as-is, rework, repair, scrap, return to vendor); link to production work order
- **First Article Inspection Report (FAIR)** per AS9102B: 10 FAI forms; part number, design characteristics, material, process, functional test; ERP must track FAIR completion status per part number and revision [8]
- **Supplier Corrective Action Request (SCAR)**: issued from NCR; supplier response tracking; effectiveness verification
- **Internal audit management**: audit schedule, finding tracking, corrective action closure
- **Document control**: controlled document library with revision history; distribution control; acknowledgment tracking

---

## 3. Regulatory & Compliance Requirements

### Export Control

**ITAR — 22 CFR Parts 120–130** (International Traffic in Arms Regulations): Administered by the State Department's Directorate of Defense Trade Controls (DDTC). Covers defense articles and services on the United States Munitions List (USML), Categories I–XXI. All manufacturers, exporters, and brokers of defense articles must register with DDTC. ITAR violations carry criminal penalties of up to $1M per violation and 20 years imprisonment; civil penalties up to $1.3M per violation. [4]

**EAR — 15 CFR Parts 730–774** (Export Administration Regulations): Administered by the Commerce Department's Bureau of Industry and Security (BIS). Covers dual-use items and technologies via Export Control Classification Numbers (ECCN). Items not on the USML or CCL are designated EAR99. The deemed export rule (15 CFR 734.13) treats disclosure of controlled technology to foreign nationals in the US as an export to their home country. [5]

**Data segregation in ERP:** ITAR-controlled technical data (drawings, specifications, BOMs referencing USML parts) must be segregated from non-controlled data at the database/record level. Citizenship-based access (US Person vs. foreign national) must be enforced by the application server, not just the UI. Cloud hosting must use FedRAMP High or ITAR-compliant data centers (AWS GovCloud, Azure Government); standard commercial multi-tenant hyperscaler environments are not acceptable for ITAR-controlled data without explicit DDTC guidance.

### Quality Standards

| Standard | Scope | Key additions over base ISO 9001 |
|---|---|---|
| AS9100:2016 Rev D | OEMs, prime contractors, Tier-1/2 suppliers | Product safety, counterfeit parts, human factors, risk management, config management, project management; certifying body: IAQG / OASIS database |
| AS9120:2016 Rev B | Aerospace distributors and stockists | Enhanced traceability, counterfeit prevention beyond AS9100; requires OCM or authorized distributor chain |
| AS9110C | MRO / repair stations | Adapted AS9100 for maintenance organizations; links to regulatory approvals (FAA 14 CFR Part 145, EASA Part 145) |
| AS9102B | First Article Inspection | 10-form FAI package; required for new part numbers and post-change requalification |
| AS5553E (November 2025) | Counterfeit EEE parts | Avoidance, detection, mitigation, disposition; mandatory flow-down to all supply chain tiers; supersedes AS5553D (2022) |

**Upcoming revision:** The IAQG is developing **IA9100** as the successor to AS9100 Rev D, targeting publication in late 2026 aligned with ISO 9001:2026 (expected Q4 2026). Once published, a transition window of approximately two to three years is anticipated before AS9100 Rev D certifications are no longer accepted. Treat this timeline as anticipated until SAE/IAQG publishes formally. [9]

### Government Contract Accounting

**FAR Part 31 — Cost Principles:** Defines allowable and unallowable costs for government contracts. FAR 31.205 enumerates specific unallowable categories including: advertising and public relations (31.205-1), entertainment (31.205-14), fines and penalties (31.205-15), lobbying (31.205-22), certain legal costs. Unallowable costs that are commingled in a cost pool must be identified and excluded before allocating pool costs to government contracts. [2]

**DFARS:** Defense Federal Acquisition Regulation Supplement adds cybersecurity (252.204-7012, 7019, 7020), contractor business systems (252.242-7005 / 252.242-7006 covering accounting system, estimating system, purchasing system, MMAS, EVMS, and property management system), and CAS applicability requirements.

**Cost Accounting Standards (CAS) — 48 CFR Chapter 99:** 19 standards governing consistency and disclosure of cost accounting practices. The FY2026 National Defense Authorization Act (signed December 18, 2025, Section 1806) made the following changes effective for contracts entered into after June 30, 2026: [10]

- CAS applicability threshold raised from $2.5M to $35M per contract (effectively eliminating the modified-coverage "trigger contract" for most small awards)
- Full CAS coverage threshold raised from $50M to $100M in CAS-covered awards in the same year

CAS-covered contractors must file a **CASB DS-1 Disclosure Statement** before award; any change to disclosed accounting practices requires advance notification and a cost impact analysis. Modified coverage (requiring CAS 401, 402, 405, 406) continues to apply at thresholds established in implementing FAR revisions — verify current FAR text for threshold applicability to a specific contract.

**SF 1408:** DCAA accounting system adequacy checklist; 18 criteria covering segregation of costs by contract, identification of costs by type (labor, material, subcontract, ODC), timekeeping system, system for accumulating and distributing costs, and controls over unallowable cost identification.

**DFARS 252.242-7005 / 252.242-7006 — Contractor Business Systems (CBS):** DCAA/DCMA have authority to issue Disapproval of Business System findings with payment withholds (5%–10% per deficient system, or 25% for multiple deficient systems) until deficiencies are corrected.

### Earned Value Management

**ANSI/EIA-748-E (published February 17, 2026):** The current governing standard for EVMS, maintained by NDIA and SAE International. Reduced from 32 to 27 guidelines (a reduction of five guidelines) across 5 guideline categories: Organization; Planning & Budgeting; Progress Assessment & Data Collection; Analysis & Management Reports; Revisions & Data Maintenance. [3]

As of February 1, 2026, DFARS Class Deviation 2026-O0011 updated EVMS contract clause requirements: EVMS reporting is now mandatory for cost or incentive contracts of $50M or more (clause 252.234-7999); formal EVMS compliance determination by the Cognizant Federal Agency (CFA/DCMA) is required at $100M or more. [1] DoD Instruction 5000.02 governs EVMS policy for Major Defense Acquisition Programs (MDAPs). Verify current DFARS text — this threshold area has been actively revised.

### Revenue Recognition

**ASC 606 (FASB) / IFRS 15 (IASB):** Five-step model substantially converged between US GAAP and IFRS. A&D long-term contracts typically satisfy the "over time" recognition criteria (customer simultaneously receives and consumes benefits; entity's performance creates an asset the customer controls; entity's performance has no alternative use and entity has right to payment for performance completed to date). The input method — costs incurred to date divided by total estimated costs (EAC) — is the standard approach. ERP must support: POC percentage computation per contract, cumulative catch-up adjustment posting when EAC changes, contract modification accounting (prospective or cumulative catch-up), and variable consideration constraint analysis.

### Airworthiness & Maintenance

| Regulation | Scope | ERP impact |
|---|---|---|
| FAA 14 CFR Part 145 | US Repair Station certification | Station number on 8130-3; authorized work scope; inspector authorization records |
| EASA Part 145 | EU Approved Maintenance Organisation (AMO) | EASA Form 1 generation; capability list; certifying staff authorizations |
| FAA AC 120-16 | Continuous airworthiness maintenance programs | Task card compliance tracking; interval management |
| Airworthiness Directives (ADs) | Mandatory compliance actions | AD tracking per tail number / part number; compliance status and next-due |

FAA Form 8130-3 and EASA Form 1 are Authorized Release Certificates (airworthiness tags). The ERP must generate these documents directly from the work order with full traceability; manual creation outside the ERP breaks the audit chain and creates liability. [6]

### Cybersecurity

**CMMC 2.0:** Three-level model incorporated into DFARS via Final Rule published September 10, 2025, effective November 10, 2025. [11] Level 1 (15 practices, FAR 52.204-21) requires annual self-assessment. Level 2 (110 controls per NIST SP 800-171 Rev 2) requires third-party C3PAO assessment for contracts involving Controlled Unclassified Information (CUI); Level 3 (NIST SP 800-172) requires government-led assessment. Full rollout across all covered contracts by November 2028. ERP systems processing cost data, technical specifications, and personnel security information are almost certainly within CMMC scope.

**DFARS 252.204-7012:** Safeguarding Covered Defense Information; requires 72-hour cyber incident reporting to DoD CIO and preservation of images of compromised systems; ERP must have logging sufficient to identify what CUI was accessed.

**FedRAMP Moderate:** Required baseline for cloud SaaS ERP hosting CUI; ITAR-controlled data may require FedRAMP High plus additional data center controls.

---

## 4. Key Data Entities

### Contract & Project Entities

| Entity | Key Fields |
|---|---|
| Contract | contract_id, contract_number (e.g., W81XWH-26-C-0001), contract_type (FFP/CPFF/CPAF/T&M/IDIQ), prime_customer, cas_covered (bool), itar_controlled (bool), period_of_perf_start, period_of_perf_end, ceiling_value, funded_value, far_clauses[] |
| CLIN / SLIN | clin_id, contract_id, clin_number (e.g., 0001, 0002AA), acrn (2-char, e.g., AA), slin_type (SUPPLIES/SERVICES/DATA), funded_amount, loe_flag (Level of Effort), option_period |
| WBS Element | wbs_id, contract_id, wbs_code, title, obs_code, bac (Budget at Completion), bcws, bcwp, acwp, management_reserve_flag |
| Indirect Cost Pool | pool_id, pool_name, pool_type (Fringe/OH/G&A/MatOH/FCCM), allocation_base, provisional_rate, final_rate, fiscal_year, pool_budget |

### Item / Part Entities

| Entity | Key Fields |
|---|---|
| Part | part_number, revision, item_type, itar_usml_category (I–XXI), ear_eccn, counterfeit_risk_level (LOW/MEDIUM/HIGH/CRITICAL), uom, config_managed_flag, life_limited_flag, shelf_life_days |
| Serialized Unit | serial_id, part_number, part_rev, serial_number, lot_number, tsn, tso, csn, cso, location_code, status (SERVICEABLE/UNSERVICEABLE/QUARANTINE/SCRAPPED), itar_flag, ocm_traceability_ref, uid_iuid_ref |
| Lot Record | lot_id, lot_number, part_number, receipt_date, qty, supplier_id, coc_document_ref, shelf_life_exp, ocm_authorized (bool) |
| Configuration Baseline | baseline_id, part_number, effectivity_in (serial or date), effectivity_out, bom_level, eco_ref, baseline_type (AS-DESIGNED/AS-BUILT/AS-MAINTAINED) |

### MRO Entities

| Entity | Key Fields |
|---|---|
| Work Order | wo_number, wo_type (LINE/SHOP/PROJECT), aircraft_reg, serial_number, task_card_ref (MPD/AMM), scheduled_date, discrepancy, resolution, inspector_id, release_form_ref, labour_hrs, parts_consumed[] |
| Airworthiness Release | form_8130_3_number, wo_ref, part_removed_sn, part_installed_sn, auth_individual_id, release_date, far_145_station, regulation_ref (FAR145/EASA145), remarks |
| Rotable Pool | part_number, total_units, serviceable_qty, unserviceable_qty, in_shop_qty, exchange_queue_qty, avg_tat_days |

### Schema Sketch

```sql
-- Contract
CREATE TABLE contract (
  contract_id          UUID PRIMARY KEY,
  contract_number      VARCHAR(30)  UNIQUE NOT NULL,  -- e.g. W81XWH-26-C-0001
  contract_type        VARCHAR(10)  NOT NULL,          -- FFP | CPFF | CPAF | T&M | IDIQ
  prime_customer       VARCHAR(100),
  cas_covered          BOOLEAN      DEFAULT FALSE,
  itar_controlled      BOOLEAN      DEFAULT FALSE,
  period_of_perf_start DATE,
  period_of_perf_end   DATE,
  ceiling_value        NUMERIC(18,2),
  funded_value         NUMERIC(18,2)
);

-- Contract Line Item
CREATE TABLE clin (
  clin_id         UUID PRIMARY KEY,
  contract_id     UUID REFERENCES contract,
  clin_number     VARCHAR(10),          -- e.g. 0001, 0002AA
  acrn            CHAR(2),              -- e.g. AA, AB
  description     TEXT,
  slin_type       VARCHAR(10),          -- SUPPLIES | SERVICES | DATA
  funded_amount   NUMERIC(18,2),
  option_period   SMALLINT              -- NULL = base; 1,2,3 = option periods
);

-- WBS Element (EVMS-aligned)
CREATE TABLE wbs_element (
  wbs_id          UUID PRIMARY KEY,
  contract_id     UUID REFERENCES contract,
  wbs_code        VARCHAR(30),
  title           VARCHAR(200),
  obs_code        VARCHAR(30),           -- Organizational Breakdown Structure
  bac             NUMERIC(18,2),         -- Budget at Completion
  bcws            NUMERIC(18,2),         -- Budgeted Cost for Work Scheduled (cumulative to date)
  bcwp            NUMERIC(18,2),         -- Budgeted Cost for Work Performed
  acwp            NUMERIC(18,2),         -- Actual Cost of Work Performed
  management_reserve BOOLEAN DEFAULT FALSE
);

-- Indirect Cost Pool
CREATE TABLE indirect_cost_pool (
  pool_id          UUID PRIMARY KEY,
  pool_name        VARCHAR(100) NOT NULL,
  pool_type        VARCHAR(20)  NOT NULL,  -- FRINGE | OVERHEAD | G_AND_A | MAT_OH | FCCM
  allocation_base  VARCHAR(100),           -- e.g. 'DIRECT_LABOR_DOLLARS'
  provisional_rate NUMERIC(8,4),           -- e.g. 0.4250 = 42.50%
  final_rate       NUMERIC(8,4),
  fiscal_year      SMALLINT NOT NULL
);

-- Serialized Unit
CREATE TABLE serialized_unit (
  serial_id              UUID PRIMARY KEY,
  part_number            VARCHAR(50)  NOT NULL,
  part_rev               VARCHAR(5),
  serial_number          VARCHAR(50)  NOT NULL,
  lot_number             VARCHAR(50),
  tsn                    NUMERIC(10,2),          -- Time Since New (flight hours)
  tso                    NUMERIC(10,2),          -- Time Since Overhaul (flight hours)
  csn                    INTEGER,                -- Cycles Since New
  cso                    INTEGER,                -- Cycles Since Overhaul
  location_code          VARCHAR(30),
  status                 VARCHAR(20),            -- SERVICEABLE | UNSERVICEABLE | QUARANTINE | SCRAPPED
  itar_flag              BOOLEAN DEFAULT FALSE,
  uid_iuid_ref           VARCHAR(100),           -- DoD IUID Registry DataMatrix value (MIL-STD-130)
  ocm_traceability_ref   VARCHAR(200)            -- OCM invoice / CoC document reference
);

-- Work Order (MRO)
CREATE TABLE work_order (
  wo_id            UUID PRIMARY KEY,
  wo_number        VARCHAR(30)  UNIQUE NOT NULL,
  wo_type          VARCHAR(10)  NOT NULL,   -- LINE | SHOP | PROJECT
  aircraft_reg     VARCHAR(10),
  serial_number    VARCHAR(50),             -- component serial if not aircraft-level
  task_card_ref    VARCHAR(100),            -- MPD task, AMM reference
  scheduled_date   DATE,
  discrepancy      TEXT,
  resolution       TEXT,
  inspector_id     UUID,                    -- FK to employee
  release_form_ref VARCHAR(50),             -- 8130-3 or EASA Form 1 number
  closed_date      DATE
);
```

---

## 5. Critical Integrations

| System / Product | Purpose | Notes |
|---|---|---|
| Deltek Cobra | Standalone EVMS: CPR Format 1–5, CFSR generation | Often bridges into Deltek Costpoint for actuals; widely used alongside Costpoint at prime contractors |
| SAP Portfolio & Project Management (PPM) | WBS and project planning for SAP shops | Feeds actuals into FI-CO; used when S/4HANA is the ERP backbone |
| PTC Windchill / Siemens Teamcenter / IBM DOORS | PDM/PLM: BOM, ECO, drawing revision, requirements management | Item master sync; configuration baseline source-of-truth; ECO flow to ERP effectivity records |
| iBASEt Solumina (MES) | Shop-floor execution for complex assemblies | Electronic traveler; serialized operation sign-off; feeds actuals back to ERP cost engine |
| Ramco Aviation Suite / AMOS (Swiss-AS) | MRO task card and tech-records management | Work order sync; 8130-3 exchange; used by airlines as MRO system-of-record with ERP financials behind |
| DoD Wide Area Workflow (WAWF) / IPP | Electronic invoicing (SF-1034/1035 public vouchers) for government | Mandatory for most DoD contracts; ERP must push invoice data in WAWF-compatible format |
| DoD IUID Registry (MIL-STD-130) | Unique Item Identification (UID) DataMatrix registration | 2D DataMatrix on serialized deliverables; ERP must write UID on receipt/manufacture and transmit to registry via WAWF/EDI |
| DCAA iRAPT | Labor-hour floor checks; incurred cost audit data pulls | Timekeeping records extracted during DCAA audit; ERP must support DCAA read-only audit access |
| Descartes Visual Compliance / Thomson Reuters ONESOURCE | ITAR/EAR denied-party screening, license management, USML/ECCN lookup | Integrated at order entry and shipping events; real-time list updates |
| Hexagon ETQ / Arena QMS / Veeva Vault (quality) | Nonconformance (NCR), SCAR workflow, document control | NCR triggered from ERP quality inspection; SCAR tracked outside ERP then status synced back |
| DCSA DISS (Defense Information System for Security) | Personnel clearance and facility clearance (FCL) status | HR module checks clearance level before granting access to classified work orders or ITAR records |
| JEDMICS / CDRL management systems | Contract Data Requirements List (CDRL) deliverable tracking | DI-MGMT data item submission tracking; ensures all CDRLs are submitted on schedule |

---

## 6. KPIs & Metrics

| KPI | Definition | Formula |
|---|---|---|
| Schedule Variance (SV) | Earned value vs. planned value: negative = behind schedule | SV = BCWP − BCWS |
| Cost Variance (CV) | Earned value vs. actual cost: negative = over budget | CV = BCWP − ACWP |
| Schedule Performance Index (SPI) | Efficiency of schedule utilization; <1.0 = behind | SPI = BCWP / BCWS |
| Cost Performance Index (CPI) | Efficiency of cost utilization; <1.0 = over cost | CPI = BCWP / ACWP |
| Estimate at Completion (EAC) | Forecast total contract cost | EAC = BAC / CPI (independent estimate) or ACWP + ETC (management estimate) |
| Variance at Completion (VAC) | Projected over/under-run at contract completion | VAC = BAC − EAC |
| To-Complete Performance Index (TCPI) | CPI required to complete remaining work within BAC | TCPI = (BAC − BCWP) / (BAC − ACWP) |
| Indirect Rate Variance | Provisional vs. final rate delta; drives year-end billing adjustments | (Final Rate − Provisional Rate) × Allocation Base |
| On-Time Delivery (OTD) | % of contract milestones / deliveries met on scheduled date | (Milestones met on time / Total milestones due) × 100 |
| First Article Acceptance Rate | % of FAI submissions (AS9102B) accepted without major discrepancy | (Accepted FAIs / Total FAIs submitted) × 100 |
| Counterfeit Parts Escape Rate | Confirmed counterfeit parts reaching production per period | Count of confirmed escapes per 1,000,000 parts consumed |
| MRO Turnaround Time (TAT) | Elapsed time from shop induction to airworthiness release | Release Date − Induction Date (calendar days or work days) |
| PBH Cost per Flight Hour (FH) | Actual MRO cost per contracted flight hour under PBH arrangement | Total MRO cost incurred / Total flight hours under PBH contract |
| DCAA Audit Questioned Cost Rate | Proportion of audited costs questioned by DCAA | (Questioned Costs / Total Incurred Costs Audited) × 100 |
| Funded Backlog | Remaining funded contract value not yet recognized as revenue | Funded Contract Value − Cumulative Revenue Recognized to Date |
| Revenue Recognition Percentage (POC) | Percentage-of-completion under ASC 606 input method | (Costs Incurred to Date / Total EAC) × Contract Value |
| Unallowable Cost Ratio | Proportion of total incurred costs classified unallowable (FAR 31.205) | (Unallowable Costs / Total Incurred Costs) × 100 |

---

## 7. Major ERP Vendors for this Vertical

### Deltek Costpoint

Deltek Costpoint is the dominant ERP for US defense prime contractors and subcontractors, used by over 3,500 organizations per Deltek's published marketing figures. It is purpose-built for DCAA compliance and government contract accounting from the ground up — the indirect cost pool structure, DCAA-compliant timekeeping, and incurred cost schedule generation are native, not configured.

**Modules:** Project Accounting, General Ledger, Accounts Payable/Receivable, Contracts, Timekeeping (DCAA-compliant with daily entry enforcement and supervisor workflow), Labor Distribution, Billing (Progress, Milestone, T&M, IDIQ), Indirect Cost Pools, Purchasing, Inventory Management, MRP, HR/Payroll.

**Current release family:** Costpoint 8.2 is the current innovation release (launched June 2023). Starting with Q1 2025, Deltek adopted quarterly release naming: 2025.1, 2025.2 … 2026.1, 2026.2, 2026.3, etc. Costpoint 8.1 (Long-Term Support release) moved to Sustaining Support on April 1, 2026, meaning it no longer receives regulatory updates, tax table changes, or security patches. Organizations still on 8.1 face cybersecurity (CMMC scope) and DCAA audit risk.

**Hosting:** Deltek GovCloud (FedRAMP Moderate; ITAR-compliant data center).

**Companion product:** Deltek Cobra handles standalone EVMS (CPR/CFSR generation, PMB management) and is widely deployed alongside Costpoint for contracts requiring formal EVMS.

**Weaknesses:** Not strong for MRO/airworthiness workflows; limited native PLM integration; thin internationalization for non-US programs; EVMS is functional but many prime contractors supplement with Cobra.

### SAP S/4HANA with Defense & Security Add-on

SAP S/4HANA is used by large prime contractors with mixed commercial/defense portfolios who need a single ERP instance. The Defense & Security add-on extends the core with weapon system status management, force element hierarchy, mission readiness tracking, and maintenance notification routing for defense assets. It has been deployed by defense ministries including those of Canada, Germany, Norway, and the US Army.

**Core modules relevant to A&D:** FI (Financial Accounting), CO (Controlling — internal orders, WBS cost settlement, cost center accounting), PS (Project System — WBS, networks, milestones), MM (Materials Management — serialized inventory, batch management), QM (Quality Management — inspection lots, usage decisions, quality notifications), PM (Plant Maintenance — work orders, functional locations, equipment master), SD (Sales & Distribution — contract billing).

**ITAR data segregation:** Implemented via SAP authorization objects combined with data classification; requires careful architecture for cloud deployments. SAP runs on Azure Government and AWS GovCloud for US defense customers requiring FedRAMP/ITAR-compliant hosting.

**Note on naming:** The add-on is correctly called "Defense & Security add-on for SAP S/4HANA" — older product naming sometimes referenced as "DSC" (Defense & Security for SAP ECC) is a prior-generation designation.

### IFS Cloud (IFS Aerospace & Defense)

IFS Cloud is widely recognized for aerospace MRO capabilities globally, positioned as a Leader in the IDC MarketScape: Worldwide SaaS and Cloud-Enabled Manufacturing ERP Applications 2024–2025 Vendor Assessment. [12] In 2024, IFS acquired EmpowerMX to strengthen aviation MRO functionality. It is particularly strong for commercial airlines, defense MRO providers, and complex A&D OEMs requiring native airworthiness release generation.

**Modules:** IFS MRO (task card management, work-scope authoring from MPD/AMM, rotable pool management), IFS EAM (Enterprise Asset Management), IFS Project (EVM-capable with CPR support), IFS Finance, IFS SCM (including serialized inventory and lot traceability), IFS Quality (NCR, SCAR, audit management).

**Key differentiators:** Native FAA Form 8130-3 and EASA Form 1 generation directly from work orders; MPD/AMM interface for task card import; PBH billing engine; reliability analysis dashboards; composable cloud architecture. Supports ITAR-compliant hosting environments.

### Infor CloudSuite Aerospace & Defense (Infor LN)

Infor CloudSuite A&D is built on the Infor LN discrete manufacturing ERP with overlays specifically for A&D: contract management with CLIN/SLIN flow-down, EVMS integration, AS9100 QMS module, ITAR module, serialized inventory, and supplier collaboration. It is well-positioned for international A&D manufacturers who are not primarily US-DoD government contractors (where Deltek dominates).

**Hosting:** Infor IRIS (Regulated Industries SaaS) runs on AWS GovCloud and is FedRAMP Moderate-authorized, designed for NIST SP 800-171, DFARS, ITAR, and CMMC 2.0 compliance requirements.

**Platform:** Infor OS layer provides Ming.le UX, Coleman AI analytics, Birst embedded BI, and ION middleware for integration with PLM, MRO, and government systems.

### Oracle Fusion Cloud ERP

Oracle Fusion Cloud ERP is used by larger diversified contractors with strong financials requirements and complex project portfolio management needs. Relevant modules: Oracle Project Portfolio Management (PPM), Oracle Procurement, Oracle Manufacturing Cloud, Oracle Cost Management. Hosted on Oracle GovCloud (FedRAMP High authorization) for CUI/ITAR-sensitive deployments. Oracle requires more A&D-specific configuration than IFS or Infor LN for EVMS and MRO workflows, and is less common as a standalone A&D system.

---

## 8. Implementation Cautions

**Write the CASB DS-1 Disclosure Statement before ERP go-live.** The ERP chart of accounts, cost pool structure, and allocation bases must match the disclosed accounting practices exactly. Post-go-live changes to indirect cost allocation methodology require a CAS 401/402 cost impact analysis, advance notification to the government, and negotiation of any cost impact — potentially affecting all active CAS-covered contracts. Restructuring cost pools after go-live to fix an ill-planned chart of accounts is among the most expensive ERP remediation scenarios in defense contracting.

**ITAR data segregation is an architecture decision, not a configuration option.** Citizenship-based access must be enforced at the database or application-server record level. A single misconfigured security role that allows a foreign national to read a USML-classified BOM or drawing constitutes an unauthorized export under 22 CFR 120.17, regardless of whether the person is physically in the US. Dev and test environments that hold controlled technical data must be as tightly controlled as production; refreshing production data to a non-ITAR-clean environment is a violation. Confirm data residency commitments contractually with the cloud provider before go-live.

**The PMB must be loaded before contract performance begins.** EVMS requires the Performance Measurement Baseline — WBS hierarchy, OBS assignments, control account plans, and time-phased BCWS spread across the period of performance — to be established at contract start. Loading the PMB retroactively produces mathematically invalid SV/CV data for the elapsed period and can generate DCAA/DCMA findings including potential payment withholds under DFARS 252.242-7006.

**Timekeeping is an audit flashpoint on every SF 1408 review.** DCAA auditors specifically test: (1) employee enters hours on day worked; (2) system prohibits pre-population of charge numbers; (3) supervisor approval occurs before cost distribution; (4) corrections carry a complete audit trail. Any ERP that allows back-dating without an audit trail or supervisor override without logging will produce SF 1408 findings. Train all employees on timekeeping procedures before go-live, not after. Labor cost mischarging to government contracts, even if unintentional, carries False Claims Act (31 U.S.C. §§ 3729–3733) exposure. [2]

**MRO part-traceability gaps create airworthiness liability that cannot be remediated after the fact.** If the ERP cannot produce a continuous traceability chain from OCM → authorized distributor → receiving inspection → specific serial number → work order → aircraft registration → airworthiness release (8130-3/EASA Form 1), FAA or EASA can ground the aircraft and require removal of the part. Receiving inspection must capture the serial number at the moment of receipt — not when the part enters production. Never accept a go-live scope reduction that defers serialized receiving.

**Revenue recognition accuracy depends on EAC discipline.** Percentage-of-completion under ASC 606 is only as reliable as the Estimate at Completion. If the ERP does not enforce a documented EAC review cycle (monthly for CPR-reporting contracts, quarterly minimum for others), cost overruns will not be recognized until they are severe. Cumulative catch-up adjustments under ASC 606 can be material and may require restatement. The EAC review process — with formal approval and audit trail — must be built into the system workflow before go-live.

**Counterfeit parts module flow-down cannot be limited to Tier-1.** AS5553E (November 2025) explicitly extends requirements to all supply chain tiers. [7] ERP supplier master records must capture OCM authorization status per part number; any purchase from an independent distributor not on the OCM-authorized list must automatically trigger an enhanced inspection and quarantine work order. Configuring this workflow as an optional step rather than a system-enforced gate defeats the purpose and creates AS9100 audit findings.

**Phased go-live by contract type significantly reduces cutover risk.** The combination of new chart of accounts (CAS-compliant), new billing workflows (WAWF integration), new timekeeping enforcement, and new indirect rate structure in a single cutover has caused government contractor payment freezes lasting months — especially when WAWF integration is not validated before go-live. The safest sequencing: go live on FFP contracts first (simpler billing, no ICS obligation), validate cost accumulation and billing for one quarter, then migrate cost-type contracts.

**Verify EVMS clause applicability at contract execution.** The DFARS EVMS clause landscape changed materially in early 2026: Class Deviation 2026-O0011 replaced 252.234-7001/7002 with 252.234-7998/7999 and raised the mandatory threshold to $50M. Contracts awarded before the deviation effective date may still reference the old clause numbers. ERP EVMS module configuration must be verified against the specific clause in each contract's Section H. [1]

---

## 9. Security & Compliance Depth

For base Segregation of Duties (SoD), RBAC framework, and audit-log requirements applicable to all ERP verticals, see `core/security.md`. The following requirements are specific to A&D.

**CMMC 2.0 Level 2 (NIST SP 800-171 Rev 2, 110 controls):** The ERP system boundary must be scoped for CMMC assessment. All CUI flowing through the ERP — contract cost data, technical specifications embedded in BOMs, personnel security information, ITAR-controlled part classifications — falls within CMMC scope. Third-party C3PAO assessment is required (Phase 1 effective November 10, 2025; rollout continues in phases through November 2028). [11] Organizations must document the ERP's system security plan (SSP) and plan of action and milestones (POA&M) before assessment. Hosting the ERP on FedRAMP Moderate (minimum) or FedRAMP High environments reduces the assessment burden for cloud infrastructure controls.

**DFARS 252.204-7012 cyber incident reporting:** A cyber incident affecting covered defense information must be reported to DoD CIO within 72 hours. The ERP must have logging sufficient to determine what CUI records were accessed during the incident window; correlate ERP access logs with SIEM events. The 72-hour clock starts at discovery, not confirmation.

**ITAR-controlled cloud architecture:** Physical or logical separation required for ITAR-controlled technical data. Acceptable environments as of 2026: AWS GovCloud (US), Azure Government, Oracle GovCloud, Infor IRIS on AWS GovCloud, Deltek GovCloud. Standard commercial multi-tenant SaaS environments (e.g., standard AWS us-east-1, Salesforce commercial) are not acceptable without explicit data classification and DDTC guidance. Even internal enterprise systems (SharePoint, Teams) holding ITAR-controlled drawings must be in ITAR-compliant tenants.

**Personnel security integration:** The ERP HR module must record and enforce: security clearance level (Confidential, Secret, Top Secret, TS/SCI), polygraph status, clearance expiration date, and investigation type. Access to specific contract work orders or technical data records in the ERP must check clearance level at runtime — a cleared-but-expired employee must be blocked from controlled data. Integration with DCSA DISS (Defense Information System for Security) is the standard method for clearance status sync.

**Unallowable cost controls — False Claims Act risk:** FAR 31.205 categories must be tagged in the chart of accounts with an UNALLOWABLE flag. The indirect pool calculation engine must exclude these costs before computing pool rates. The ERP must produce an unallowable cost report reconciling total expenses to allocable expenses for DCAA review. Intentional or reckless misallocation of unallowable costs to government contracts can trigger False Claims Act (31 U.S.C. §§ 3729–3733) liability with treble damages and per-claim penalties. [2]

**IUID / MIL-STD-130 registry integration:** For all deliverable items and government-furnished property (GFP), the ERP must generate a Unique Identification (UID) DataMatrix label per MIL-STD-130 and transmit the UID data to the DoD IUID Registry via WAWF/EDI at the time of manufacture or receipt. Failure to register UIDs delays acceptance and payment.

**SoD for contract billing:** The individual who approves the underlying cost transactions (cost certifier) must be different from the individual who authorizes the government invoice (billing certifier). The ERP billing module must enforce this as a system control, not a procedural policy. DCAA tests billing SoD explicitly during accounting system reviews.

**Data retention:** FAR 4.703 requires a minimum of 3 years retention of contract records after contract closeout. CAS-covered contracts and cost-type contracts may require retention periods of 6 or more years depending on contract type and audit status. The ERP archive strategy must allow DCAA read-only access to historical records without requiring full system access. Cold-archive approaches must be queryable; offline tape archives are not acceptable for active audit access.

**Segregation of ITAR vs. non-ITAR data in multi-program environments:** When a single ERP instance serves both ITAR-controlled and commercial programs, the data model must prevent any query, report, or export from inadvertently joining controlled and uncontrolled records in a result set visible to a non-US-Person user. This typically requires a data classification attribute on every entity (part, BOM row, document reference, work order) and query-level filtering based on the authenticated user's US-Person flag — enforced in the data layer, not the application layer.

---

## See Also

- `core/features-core.md`
- `core/security.md`
- `verticals/government-publicsector.md`
- `verticals/manufacturing.md`
- `verticals/professional-services.md`

---

## Citations & Sources

1. DoD / DPAP: DFARS Class Deviation 2026-O0011 (effective February 1, 2026) — replaces DFARS 252.234-7001/7002 with 252.234-7998/7999; raises mandatory EVMS threshold to $50M (reporting) and $100M (CFA compliance determination) — <https://www.acq.osd.mil/dpap/dars/classdev/>; analysis at <https://www.humphreys-assoc.com/dfars-234-201-evms-policy-class-deviation-2026-o0011/>

2. US Department of Justice / FAR: False Claims Act (31 U.S.C. §§ 3729–3733); FAR Part 31 — Cost Principles (FAR 31.205 unallowable cost categories) — <https://www.acquisition.gov/far/part-31>

3. NDIA / SAE International: ANSI/EIA-748-E, *Earned Value Management Systems* (February 2026) — 27 guidelines (reduced from 32 in prior revision); available via ANSI webstore — <https://webstore.ansi.org/standards/sae/saeeia748e2026>

4. US Department of State, DDTC: ITAR — 22 CFR Parts 120–130; USML Categories I–XXI — <https://www.pmddtc.state.gov>

5. US Department of Commerce, BIS: EAR — 15 CFR Parts 730–774; deemed export rule 15 CFR 734.13 — <https://www.bis.gov>

6. FAA: 14 CFR Part 145 (Repair Stations); FAA Form 8130-3 Airworthiness Approval Tag — <https://www.faa.gov>; EASA: Part 145 AMO regulations, EASA Form 1 — <https://www.easa.europa.eu>

7. SAE International: AS5553E, *Counterfeit Electrical, Electronic, and Electromechanical (EEE) Parts; Avoidance, Detection, Mitigation, and Disposition* (November 2025) — supersedes AS5553D (2022) — <https://www.sae.org/standards/content/as5553e/>

8. SAE International: AS9102B, *Aerospace First Article Inspection Requirement* — <https://www.sae.org/standards>; AS9100:2016 Rev D and AS9120:2016 Rev B — IAQG / OASIS database at <https://www.sae.org/standards>

9. IAQG / Smithers / Quality Magazine: IA9100 — expected successor to AS9100 Rev D, target publication Q4 2026 aligned with ISO 9001:2026; status reported by Smithers (March 2026) and Quality Magazine — treat as anticipated until SAE/IAQG publishes formally — <https://iaqg.org>

10. FY2026 NDAA Section 1806 (signed December 18, 2025): CAS applicability threshold raised to $35M; full CAS coverage threshold raised to $100M; effective for contracts entered into after June 30, 2026 — Federal Register interim FAR rule 2026-05511 (March 20, 2026) — <https://www.federalregister.gov/documents/2026/03/20/2026-05511/increase-of-monetary-thresholds-and-other-matters-related-to-cost-accounting-standards-program>

11. DoD / CMMC Accreditation Body: CMMC 2.0 Final DFARS Rule published September 10, 2025, effective November 10, 2025; full rollout through November 2028 — <https://www.cyberab.org>; NIST SP 800-171 Rev 2 (CUI Protection) — <https://csrc.nist.gov>

12. IDC: *IDC MarketScape: Worldwide SaaS and Cloud-Enabled Manufacturing ERP Applications 2024–2025 Vendor Assessment* — IFS positioned as Leader — <https://www.ifs.com/assets/analyst/ifs-named-a-leader-in-2024-idc-cloud-enabled-manufacturing-erp-vendor-assessment>

13. DCAA: ICE Model (Incurred Cost Electronically) documentation, SF 1408 accounting system adequacy checklist, iRAPT — <https://www.dcaa.mil>

14. Defense Acquisition University (DAU): EVMS, FAR/DFARS, CAS, and contractor business systems resources — <https://www.dau.edu>

15. FASB: ASC 606, *Revenue from Contracts with Customers* — <https://www.fasb.org>

16. Deltek: Costpoint product documentation and GovCloud environment — <https://www.deltek.com/en/aerospace-and-defense>; Deltek Costpoint 8.2 quarterly release notes — <https://help.deltek.com/product/costpoint/8.2/releasenotes/>

17. SAP: Defense & Security add-on for SAP S/4HANA — <https://www.sap.com/industries/defense-security.html>

18. Infor: CloudSuite Aerospace & Defense, Infor IRIS on AWS GovCloud — <https://www.infor.com>

19. DoD: MIL-STD-130 (Identification Marking of US Military Property), IUID Registry — <https://www.acq.osd.mil/dpap/pdi/uid>
