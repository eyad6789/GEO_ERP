# ERP for Financial Services

Financial services encompasses banks, insurers, asset managers, securities firms, and fintech — each sharing a common requirement for multi-book accounting, regulatory capital reporting, and sub-ledger scale far beyond what generic ERP delivers. This file documents the architecture, modules, regulations, data model, and implementation pitfalls for engineers designing ERP solutions for this vertical.

---

## 1. Overview

Financial services ERP deployments differ from every other vertical on four axes: volume, precision, regulatory multiplicity, and the mandatory coexistence of a core banking or policy administration system alongside the ERP itself.

**Volume and precision.** A retail bank with 10 million loan contracts runs nightly accrual engines across every contract; each contract generates multiple journal entries per period. A medium-sized insurer calculates IFRS 17 contractual service margin (CSM) across hundreds of thousands of insurance contract groups. FX revaluation at month-end must process every foreign-currency balance on every sub-ledger account at spot and historical rates simultaneously. At this scale, a posting engine that handles 50,000 transactions per hour is inadequate — financial services ERP must handle hundreds of millions of postings per accounting period.

**Regulatory multiplicity.** A single banking group may report to: the European Central Bank (ECB) via AnaCredit, the European Banking Authority (EBA) via COREP/FINREP in XBRL, the local national competent authority (NCA), the IRS via FATCA, 120+ tax authorities via OECD CRS [1], the Financial Action Task Force (FATF)-aligned AML regime, and prudential regulators under Basel III/IV — each demanding a different view of the same underlying transactions. Regulatory bodies span the Basel Committee on Banking Supervision (BCBS), IASB, FASB, EIOPA, FinCEN, and FATF. ERP architecture must support parallel ledgers, not a single chart of accounts.

**Dual mandate: statutory reporting AND regulatory capital reporting.** General ledger GAAP reporting (IFRS or US GAAP) coexists with regulatory capital reporting. These use different measurement bases: accounting provisions under IFRS 9 ECL versus regulatory expected loss under Basel IRB; fair value under IFRS 13 versus regulatory value for COREP. The ERP must maintain both concurrently without reconciliation gaps.

**CBS vs ERP boundary.** The core banking system (CBS — e.g., Temenos Transact, Oracle FLEXCUBE, FIS Profile) handles loan origination, deposit account transactions, and payment processing. The ERP handles general ledger, consolidation, FP&A, HR, and procurement. Architects must define a clean integration boundary: CBS is the system of record for transaction origination; ERP receives financial events from CBS via a structured interface and posts to the GL. Double-booking occurs when both systems post accruals independently — a critical and common failure mode addressed in Section 8.

See `core/architecture.md` for general multi-entity and integration architecture patterns.

---

## 2. Industry-Specific Modules

### 2.1 Multi-Book / Multi-GAAP / Parallel Ledger Accounting

Parallel ledger design is the foundational capability that separates financial services ERP from standard implementations. A banking group typically requires four or more concurrent sets of books:

- **IFRS ledger** — primary statutory reporting under IASB standards
- **US GAAP ledger** — for SEC-registered groups or US subsidiaries under FASB ASC standards
- **Local statutory ledger** — jurisdiction-specific GAAP (e.g., German HGB, French PCG, Japanese J-GAAP)
- **Regulatory ledger** — COREP/FINREP capital reporting basis, which may differ from IFRS on provisioning and deferred tax

Each ledger maintains its own chart of accounts or a mapping table that translates the unified account structure to ledger-specific codes. The **accounting hub pattern** processes raw financial events (contract origination, payment, amortisation, FX revaluation) through posting rules that fan out to all active ledgers simultaneously — a single economic event creates parallel journal entries in one atomic operation.

SAP S/4HANA implements this via the **Universal Journal** (ACDOCA table) with native parallel ledger support; each row carries a ledger identifier. Oracle Fusion Cloud Financials provides **Secondary Ledger** capability and the **Oracle Accounting Hub Cloud (OAHC)** for event-based multi-ledger posting from external source systems.

### 2.2 Sub-Ledger Accounting at Scale

Each financial contract — loan, deposit, bond, insurance policy, derivative — is a sub-ledger object. The sub-ledger holds the authoritative contract-level position; the GL holds the aggregated balance. This disaggregation is mandatory for IFRS 9 ECL staging (contract-level), IFRS 17 insurance group reporting, and AnaCredit granular credit reporting.

Key sub-ledger capabilities required:

- **Accrual engines**: effective interest rate (EIR) computation under IFRS 9 / ASC 310 (amortised cost); premium and discount amortisation using constant-yield or straight-line methods per local GAAP
- **Position management**: FIFO, LIFO, average-cost, or specific-identification per asset class for held-for-trading and available-for-sale portfolios
- **Automated reconciliation**: sub-ledger to GL, GL to regulatory reports — automated daily, with tolerance alerting; any unreconciled break must be resolved before period close; see Section 8.1

### 2.3 Expected Credit Loss (ECL) Engine — IFRS 9 / ASC 326 (CECL)

IFRS 9 Financial Instruments (IASB, effective 1 January 2018) replaced the IAS 39 incurred-loss model with a forward-looking three-stage expected credit loss model. ASC 326 (CECL — Current Expected Credit Losses, FASB; effective for large US public business entities fiscal years beginning after 15 December 2019, i.e., FY2020; smaller and non-public entities fiscal years beginning after 15 December 2022, i.e., FY2023) [2] implements a similar lifetime ECL approach for US GAAP.

Under IFRS 9:

- **Stage 1**: 12-month ECL; no significant increase in credit risk (SICR) since origination
- **Stage 2**: lifetime ECL; SICR detected but not yet in default
- **Stage 3**: lifetime ECL; objective evidence of impairment / default

**ECL formula (simplified):** `ECL = EAD × PD × LGD`, applied over 12 months (Stage 1) or remaining lifetime (Stage 2/3), discounted at the effective interest rate.

**Components:**
- **PD (Probability of Default)**: point-in-time estimate incorporating forward-looking macroeconomic scenarios (unemployment, GDP growth, property price indices); 12-month and lifetime variants
- **LGD (Loss Given Default)**: collateral haircuts, recovery rates, time-to-recovery discounting
- **EAD (Exposure at Default)**: drawn balance plus undrawn committed facilities multiplied by a credit conversion factor (CCF)

**SICR assessment** is the most judgment-intensive step: quantitative triggers (days past due, PD deterioration threshold relative to origination) plus qualitative flags (forbearance, watchlist entry). The ERP must record SICR trigger date for audit purposes.

**Vintage cohort tracking** and **forbearance/modification flags** must persist at contract level. ECL is recalculated at each reporting date; model outputs (PD/LGD/EAD) are typically produced by a specialist ECL platform (Moody's Analytics, SAS Credit Risk, Prometeia) and consumed by the ERP provisioning engine via API or file interface.

### 2.4 Regulatory Capital Calculation — Basel III/IV

Basel III (BCBS, 2010, revised 2017) established minimum capital ratios: CET1 ≥ 4.5% of RWA, Tier 1 ≥ 6%, Total Capital ≥ 8%, plus a Capital Conservation Buffer of 2.5% (making the effective CET1 floor 7%). A Countercyclical Buffer of 0–2.5% is set by national authority.

Basel IV ("final Basel III," BCBS December 2017) introduces an **output floor of 72.5%** of standardised RWA, phasing in from 2025 to 2032 under the EU's transposition (CRR3: Regulation (EU) 2024/1623; CRD6: Directive (EU) 2024/1619 [3]). CRR3 entered into force on 9 July 2024 and largely applies from 1 January 2025. FRTB (Fundamental Review of the Trading Book) market-risk own-funds requirements were further postponed by Commission Delegated Regulation (EU) 2025/1496 (published 19 September 2025 Official Journal) to **1 January 2027** [4]. UK transposition under PRA PS1/26 (final rules) is effective **1 January 2027** [5]; the previous near-final statement PS17/23 was superseded. The US Basel III Endgame was reproposed by the Federal Reserve, OCC, and FDIC on 19 March 2026; comments were due 18 June 2026, with finalization anticipated mid-to-late 2026 and implementation beginning 2027 with a 3–5-year phase-in [6] — engineers should treat US implementation timelines as subject to change.

**RWA computation approaches:**

| Risk Category | Standardised Approach | Internal Models Approach |
|---|---|---|
| Credit Risk | SA-CR | IRB-A (Advanced), IRB-F (Foundation) |
| Market Risk | SA (revised under FRTB) | IMA (Internal Model Approach, FRTB) |
| Operational Risk | BIA / TSA (pre-Basel IV); SMA (Basel IV) | — |
| CVA Risk | BA-CVA | SA-CVA |

**Key regulatory ratios computed in ERP / regulatory platform:**

| Ratio | Formula | Minimum |
|---|---|---|
| CET1 | CET1 Capital / Total RWA | 4.5% (+ buffers) |
| Leverage Ratio | Tier 1 Capital / Total Exposure Measure | 3% |
| LCR | HQLA / Net Cash Outflows (30-day stress) | 100% |
| NSFR | Available Stable Funding / Required Stable Funding | 100% |

EU LCR: Delegated Regulation (EU) 2015/61. EU NSFR: Regulation (EU) 2021/451. COREP and FINREP reports are filed in XML/XBRL to the NCA using the EBA Data Point Model (DPM) taxonomy, which is updated annually.

### 2.5 Insurance-Specific Modules — IFRS 17 / Solvency II

**IFRS 17 Insurance Contracts** (IASB, effective for annual periods beginning on or after 1 January 2023) [7] requires insurance contract groups to be measured using one of three models:

- **Building Block Approach (BBA)**: Best Estimate of Liabilities (BEL) + Risk Adjustment + Contractual Service Margin (CSM). The CSM represents unearned profit, measured at inception and amortised to P&L over the coverage period as insurance revenue is recognised.
- **Variable Fee Approach (VFA)**: for direct-participating contracts where policyholder shares in the return of underlying items.
- **Premium Allocation Approach (PAA)**: simplified approach for short-duration contracts (coverage period ≤ 1 year, or approximates BBA).

IFRS 17 requires grouping contracts into **cohorts by year of inception** and **profitability class** (onerous, non-onerous, or uncertain at inception). This granularity is incompatible with legacy actuarial reserve systems that stored aggregated reserves — full historical restatement is typically required back to the comparative period (1 January 2022 for 2023 first-year reporters).

Reinsurance held is measured separately from direct contracts, with separate CSM and a net risk adjustment.

**Solvency II** (Directive 2009/138/EC; Delegated Regulation (EU) 2015/35) is the EU prudential framework for insurers, with a three-pillar structure:

- **Pillar 1** (Quantitative): Technical Provisions (BEL + Risk Adjustment), Solvency Capital Requirement (SCR), Minimum Capital Requirement (MCR), own funds
- **Pillar 2** (Governance): ORSA (Own Risk and Solvency Assessment), internal model approval
- **Pillar 3** (Reporting): QRTs (Quantitative Reporting Templates) in XBRL per EIOPA taxonomy; SFCR (Solvency and Financial Condition Report, public); RSR (Regular Supervisory Report, to supervisor)

The **Solvency II amending Directive (EU) 2025/2** was published on 8 January 2025 and must be applied by Member States from **30 January 2027** [8]. It enhances proportionality, integrates sustainability and climate-risk requirements, strengthens group supervision, and introduces new macro-prudential tools.

US insurance: ASC 944 (Financial Services — Insurance) under FASB; FASB ASU 2018-12 (LDTI — Long Duration Targeted Improvements, as deferred by ASU 2020-11) effective for large accelerated SEC filers for annual periods beginning after 15 December 2022 (FY2023; smaller reporting companies had a one-year deferral) [9]. LDTI requires updated measurement of long-duration insurance liabilities using current discount rates and updated assumptions. NAIC statutory accounting (SSAP) and risk-based capital (RBC) ratio apply for US regulatory purposes.

**Actuarial function integration**: BEL inputs (mortality tables, lapse rates, expense assumptions) are computed by actuarial systems (Prophet/FIS, AXIS/Milliman, MoSes/Moody's Analytics, Milliman STAR) and fed into the ERP insurance module; the ERP applies the IFRS 17 measurement model and posts the resulting journal entries to the parallel ledger.

### 2.6 Treasury Management and Cash/Liquidity

- **Cash position management**: intraday and end-of-day positions per bank account, legal entity, currency; cash concentration, zero-balancing sweeps, notional pooling structures
- **FX exposure management**: spot, forward, FX options; P&L attribution by currency pair; hedge designation workflow for FX hedges under IFRS 9 / ASC 815
- **LCR / NSFR liquidity buffer management**: HQLA classification and eligibility; stress scenario run-off rates; daily LCR monitoring
- **ALCO reporting**: Net Interest Income (NII) sensitivity (rate shock scenarios); Economic Value of Equity (EVE) sensitivity; behavioural modelling for deposits
- **Intraday liquidity monitoring**: per BCBS 248 guidance — intraday peak liquidity usage, available intraday liquidity, time-critical obligations

### 2.7 Derivatives and Hedge Accounting

Trade capture includes interest rate swaps, cross-currency swaps, FX forwards/options, credit default swaps (CDS), and commodity derivatives. The ERP or integrated TMS must maintain the full trade economics at instrument level.

**Hedge accounting** under IFRS 9 uses a principles-based **economic relationship test** — no bright-line percentage; the hedge must be expected to offset changes in fair value or cash flows attributable to the hedged risk. Under ASC 815 (FASB Derivatives and Hedging), ASU 2017-12 expanded the eligible hedged risks and simplified effectiveness assessment. ASU 2022-01 (effective for public entities from fiscal years beginning after 15 December 2022) renamed the "last-of-layer" method to the **portfolio layer method** and expanded it to multiple layers within a single closed portfolio of assets [10].

**Hedge documentation** at inception must specify: risk management objective, hedging instrument, hedged item, hedged risk, and effectiveness assessment method. This documentation must reside in the ERP or be retrievable on demand for audit.

**Effectiveness testing**: prospective and retrospective. IFRS 9 requires qualitative or quantitative assessment at inception and at each reporting date. ASC 815 (as amended by ASU 2017-12) eliminated the 80–125% bright-line test for certain relationships, though formal effectiveness assessment remains required.

**Accounting entries:**
- **Fair value hedge**: mark hedging instrument and hedged item's hedged-risk component to fair value through P&L; basis adjustment on hedged item
- **Cash flow hedge**: effective portion of change in fair value → Other Comprehensive Income (OCI); recycled to P&L when the hedged item affects P&L; ineffective portion → P&L immediately

### 2.8 Fair Value Measurement — IFRS 13 / ASC 820

IFRS 13 (IASB) and ASC 820 (FASB) both establish a three-level hierarchy for fair value inputs:

| Level | Input Type | Examples |
|---|---|---|
| 1 | Quoted prices in active markets for identical assets/liabilities | Exchange-traded equities, government bonds on active market |
| 2 | Observable inputs other than Level 1 | Interest rate curves, credit spreads from broker quotes, FX rates |
| 3 | Unobservable inputs / model-based | Illiquid structured products, private equity, complex derivatives |

Day-1 P&L recognition rules apply where Level 3 instruments are transacted at prices that differ from model value. CVA (Credit Valuation Adjustment) and DVA (Debit Valuation Adjustment) adjust OTC derivative fair values for counterparty and own credit risk respectively. Level 3 positions require sensitivity disclosures. The ERP must carry a "fair value level" flag per position and support disclosure aggregation.

### 2.9 FATCA / CRS Withholding and Reporting

**FATCA** (Foreign Account Tax Compliance Act, IRC §§1471–1474, enacted 2010, withholding effective 2014) requires foreign financial institutions to identify US persons and report account information to the IRS, or apply 30% withholding on US-source income. IGA Model 1 agreements route reporting through local tax authority; IGA Model 2 agreements allow direct IRS reporting. W-8 / W-9 self-certification workflow must be embedded in customer onboarding.

**OECD Common Reporting Standard (CRS)**, approved 2014, provides for automatic exchange of financial account information among more than 120 participating jurisdictions [1] under the Multilateral Competent Authority Agreement (MCAA). Schema: CRS XML per OECD schema; FATCA XML per IRS schema v2.0.

ERP implications: customer master must carry tax classification, self-certification date, and dormant account flag. Reportable account aggregation logic must handle account holder relationships across entities within the same financial group.

### 2.10 AML / KYC Integration Layer

The ERP is not the AML/KYC system of record but must integrate tightly with it:

- **Customer risk scoring**: AML risk score from the AML platform must be readable in ERP customer master; high-risk customers may trigger enhanced due diligence (EDD) workflows for account opening or transaction approval
- **Transaction monitoring alerts**: SAR (Suspicious Activity Report) filing workflow, driven by AML platform (NICE Actimize SAM module), may require ERP-sourced transaction data as input
- **Sanctions screening**: OFAC SDN list, EU Consolidated Sanctions list, UN sanctions — screening occurs at customer onboarding and on update of sanctions lists; results stored in AML platform, status flag synced to ERP
- **Beneficial ownership registry**: integration with corporate registry or UBO (Ultimate Beneficial Owner) data; PEP (Politically Exposed Person) screening via Refinitiv World-Check, LSEG, or NICE Actimize WLF module
- **Regulatory framework**: EU AML framework is undergoing major restructure — the 2024 EU AML Package (published Official Journal 19 June 2024) establishes: AMLA (Regulation (EU) 2024/1620, new EU Anti-Money Laundering Authority headquartered in Frankfurt, operational 1 July 2025, directly supervising 40 high-risk entities from 2027); the AML Single Rulebook (Regulation (EU) 2024/1624, directly applicable from 10 July 2027); and the 6th AMLD (Directive (EU) 2024/1640, national supervisory mechanisms) [11]. The 4th AMLD (Directive 2015/849/EU), 5th AMLD (Directive 2018/843/EU), and 6th AMLD on criminal liability (Directive 2018/1673/EU, applied from December 2020) remain operative until the 2024 package is applied. US: Bank Secrecy Act (31 U.S.C. §§5311–5336); FinCEN CDD Rule (31 CFR §1010.230, effective 2018); Corporate Transparency Act (CTA, 2021) BOI reporting to FinCEN; FATF 40 Recommendations (2012, updated November 2023) [12]

### 2.11 Revenue / Cost Allocation and Profitability

- **Funds Transfer Pricing (FTP)**: internal pricing mechanism that charges/credits business units for the cost/benefit of funds they use/provide; matched-maturity FTP curve locks a rate to each contract at origination date; Treasury publishes the FTP curve; ERP enforces it consistently across all originating units
- **FTP Margin**: `Product Rate − FTP Curve Rate (matched maturity)` — the residual margin attributable to the originating business unit
- **Cost-to-serve allocation**: Activity-Based Costing (ABC) assigns shared service costs (operations, IT, compliance) to products, channels, and customer segments based on activity drivers
- **Product profitability P&L**: constructed at individual loan/deposit/policy level from: interest margin, FTP charge/credit, ECL provision, allocated operating cost, allocated capital charge (RAROC)

### 2.12 Transfer Pricing — Intragroup Financial Transactions

Financial groups transact extensively between legal entities: intragroup loans, back-to-back derivatives, guarantee fees, cash pooling, management fees. All must be priced at arm's length per OECD Transfer Pricing Guidelines.

- **OECD BEPS Action 4**: interest deduction limitation rules (fixed-ratio rule, group-ratio rule) — ERP must track net borrowing cost per entity
- **OECD BEPS Action 13**: Master File, Local File, Country-by-Country Report (CbCR) — ERP transaction data is the source for CbCR; amounts, employees, taxes, and revenues per jurisdiction must be extractable
- **OECD Pillar Two GloBE Model Rules** (OECD, December 2021): 15% minimum effective tax rate per jurisdiction; EU Directive 2022/2523 (Pillar Two Directive) required member state transposition by 31 December 2023, with the Income Inclusion Rule applying for fiscal years beginning from 31 December 2023 (i.e., calendar year 2024) [13]. ERP must compute jurisdictional ETR (effective tax rate) and Qualified Domestic Minimum Top-Up Tax (QDMTT) where applicable
- **IFRIC 23** (IASB, effective 2019): Uncertainty over Income Tax Treatments — ERP must track uncertain tax positions

### 2.13 Intercompany Eliminations at Scale

A banking group with dozens of legal entities has intragroup loans (borrowings between treasury centre and subsidiaries), intragroup deposits, fee income, dividend flows, and back-to-back derivative positions. Eliminations are required under IFRS 10 (IASB) and ASC 810 (FASB).

- **Volume challenge**: thousands of intragroup exposures; matching logic must handle partial settlements, multi-currency pairs, and timing differences where one entity books in one period and the counterpart in another
- **Currency translation adjustments (CTA)**: foreign subsidiary financials are translated at closing rate for assets/liabilities and average rate for income; translation differences go to OCI and are eliminated on consolidation
- **Non-controlling interest (NCI) tracking**: partial ownership structures require NCI attribution at every consolidation node
- **Gross vs net presentation**: intragroup derivatives may gross or net depending on applicable netting agreements (ISDA Master Agreement)

See `core/features-core.md` for general consolidation patterns.

### 2.14 FP&A and Regulatory Reporting

- **Driver-based financial models**: NII drivers (rate scenarios, volume growth, mix), fee income drivers, cost-efficiency ratio targets
- **FINREP**: financial reporting templates for IFRS-reporting banks submitted to EBA/NCA in XBRL format; covers balance sheet, P&L, asset quality, forbearance, liquidity
- **COREP**: capital adequacy reporting for all CRR-scope institutions; covers RWA, capital ratios, leverage, LCR, NSFR, large exposures
- **EBA DPM (Data Point Model)**: the taxonomy underlying COREP/FINREP; updated annually; ERP + regulatory reporting platform require coordinated taxonomy update cycles
- **AnaCredit**: ECB Regulation (EU) 2016/867 (ECB/2016/13); granular credit and credit risk data; data collection began September 2018; contract-level attributes (counterparty, instrument type, carrying amount, collateral) reported monthly to the national central bank [14]
- **US regulatory reporting**: Call Report (FFIEC 031/041/051); FR Y-9C for bank holding companies; CCAR (Comprehensive Capital Analysis and Review) / DFAST (Dodd-Frank Act Stress Tests) stress testing submissions

---

## 3. Regulatory & Compliance Requirements

### 3.1 Prudential / Capital — Banking

| Standard / Regulation | Identifier | Jurisdiction | Key Requirement |
|---|---|---|---|
| Basel III | BCBS, 2010 (revised 2017) | Global | CET1 ≥ 4.5%, T1 ≥ 6%, TC ≥ 8% of RWA; CCB 2.5%; CCyB 0–2.5% |
| Basel IV / Final Basel III | BCBS, December 2017 | Global | Output floor 72.5% of SA-RWA; SA-CCR; FRTB; phased 2025–2032 |
| CRR3 | Regulation (EU) 2024/1623 [3] | EU | Basel IV transposition; most provisions 1 January 2025; FRTB 1 January 2027 [4] |
| CRD6 | Directive (EU) 2024/1619 | EU | Supervisory powers, access to EU market for third-country firms; transpose by 10 January 2026 |
| UK Basel 3.1 | PRA PS1/26 [5] | UK | Effective 1 January 2027; transitional provisions to 1 January 2030 |
| US Basel III Endgame | Federal Reserve / OCC / FDIC reproposal 19 March 2026 [6] | US | Comment period closed 18 June 2026; finalization and phase-in timeline unconfirmed |
| LCR (EU) | Delegated Regulation (EU) 2015/61 | EU | Minimum LCR 100%; HQLA classification |
| NSFR (EU) | Regulation (EU) 2021/451 | EU | Minimum NSFR 100%; ASF/RSF calculation |
| BCBS 239 | BCBS, January 2013 | Global (G-SIBs) | Risk data aggregation and risk reporting; effective G-SIBs designated by November 2012: 1 January 2016 [15] |

### 3.2 Insurance — IFRS 17 / Solvency II / US GAAP

| Standard / Regulation | Identifier | Jurisdiction | Key Requirement |
|---|---|---|---|
| IFRS 17 Insurance Contracts | IASB, effective 1 Jan 2023 [7] | IFRS jurisdictions | BBA / VFA / PAA; CSM recognised over coverage period |
| Solvency II | Directive 2009/138/EC; Delegated Reg. (EU) 2015/35 | EU | Three-pillar structure; SCR, MCR, QRTs in XBRL |
| Solvency II Review | Directive (EU) 2025/2 [8] | EU | Applied from 30 January 2027; proportionality, sustainability, group supervision |
| ASC 944 / LDTI | FASB; ASU 2018-12 (as deferred by ASU 2020-11), effective FY2023 (large accelerated filers) [9] | US GAAP | Updated measurement of long-duration insurance liabilities; current discount rates |
| NAIC SSAP / RBC | NAIC | US (statutory) | Statutory accounting; risk-based capital ratio |

### 3.3 Financial Instruments Accounting

| Standard | Identifier | Jurisdiction | Scope |
|---|---|---|---|
| IFRS 9 Financial Instruments | IASB, effective 1 Jan 2018 | IFRS | Classification (FVTPL, FVOCI, AC); ECL; hedge accounting |
| ASC 326 (CECL) | FASB; large PBEs FY2020; others FY2023 [2] | US GAAP | Lifetime expected credit losses; replaces ASC 310-20 incurred-loss |
| ASC 815 Derivatives and Hedging | FASB; ASU 2017-12 (expanded hedging); ASU 2022-01 (portfolio layer method) [10] | US GAAP | Hedge designation, effectiveness, accounting |
| IFRS 13 / ASC 820 Fair Value | IASB / FASB | IFRS + US GAAP | Three-level hierarchy; CVA/DVA; Level 3 disclosures |

### 3.4 Financial Crime / Tax Transparency

| Regulation | Identifier | Jurisdiction | Key Requirement |
|---|---|---|---|
| FATCA | IRC §§1471–1474 (enacted 2010, withholding 2014) | US extraterritorial | 30% withholding; FFI reporting; IGA Model 1/2 |
| OECD CRS | OECD, approved 2014; MCAA activated 2017+ | 120+ jurisdictions [1] | Automatic exchange of financial account information |
| EU DAC6 | Directive 2018/822/EU (effective July 2020) | EU | Mandatory disclosure of cross-border tax arrangements |
| EU 4th AMLD | Directive 2015/849/EU | EU | Customer due diligence, beneficial ownership |
| EU 5th AMLD | Directive 2018/843/EU | EU | UBO registers, crypto-assets, prepaid cards |
| EU 6th AMLD (criminal) | Directive 2018/1673/EU (applied from December 2020) | EU | Criminal liability for money laundering; extended to legal persons |
| EU 2024 AML Package | Regulations (EU) 2024/1620, 2024/1624; Directive (EU) 2024/1640 [11] | EU | AMLA authority; Single Rulebook directly applicable from 10 July 2027 |
| US BSA / AML | 31 U.S.C. §§5311–5336 | US | SAR/CTR filing; CDD Rule 31 CFR §1010.230 |
| US CTA | Corporate Transparency Act (2021) | US | BOI reporting to FinCEN |
| FATF | 40 Recommendations (2012, updated November 2023) [12] | Global | CDD, record-keeping, correspondent banking |

### 3.5 Tax Reporting

| Standard | Identifier | Jurisdiction | Key Requirement |
|---|---|---|---|
| BEPS Action 13 / CbCR | OECD | Global | Master File, Local File, Country-by-Country Report |
| Pillar Two GloBE | OECD Model Rules (Dec 2021); EU Directive 2022/2523 (IIR applies FY beginning 31 Dec 2023) [13] | Global / EU | 15% minimum ETR per jurisdiction; QDMTT |
| IFRIC 23 | IASB, effective 2019 | IFRS | Uncertain income tax treatments |
| IRC § 871(m) | IRS | US | Withholding on dividend equivalents on equity-linked instruments |

---

## 4. Key Data Entities

### 4.1 Entity Relationship Overview

| Entity | Description | Key Fields | Primary Relationships |
|---|---|---|---|
| LegalEntity | Hierarchy node for consolidation and regulatory reporting | entity_id, parent_id, jurisdiction, functional_currency, regulatory_classification | Parent: LegalEntity (self-referential); contains: FinancialContract |
| FinancialContract | Single source of truth per loan/deposit/bond/policy | contract_id, product_code, counterparty_id, legal_entity_id, currency, notional, origination_date, maturity_date, classification, stage, EIR | Counterparty, LegalEntity, Collateral, HedgeRelationship, ECLAllowance |
| Counterparty (Party) | Individual or institution; unified customer/issuer master | party_id, party_type, kyc_status, aml_risk_score, crs_classification, fatca_status, is_pep, sanctions_hit_flag | FinancialContract (many); AMLRecord |
| Position | Current balance of a financial contract; holding type | position_id, contract_id, holding_type (HFT/AFS/HTM/AC), carrying_amount, fair_value, accrued_interest, fair_value_level | FinancialContract |
| JournalEntry | Double-entry posting with ledger identifier | entry_id, ledger_id, contract_id, posting_date, debit_account, credit_account, amount_dc, amount_lc, transaction_type | FinancialContract, LegalEntity, CostCenter |
| ECLAllowance | Contract-level ECL provision; point-in-time per reporting date | ecl_id, contract_id, reporting_date, stage, pd_12m, pd_lifetime, lgd, ead, ecl_amount, macro_scenario_id | FinancialContract |
| HedgeRelationship | Hedge designation linking instrument to hedged item | hedge_id, strategy_type, hedge_standard (IFRS9/ASC815), designation_date, effectiveness_method, status | FinancialContract (hedging instrument + hedged item) |
| RegulatoryExposure | RWA, CCF, collateral; COREP input | exposure_id, contract_id, risk_weight, rwa, ccf, collateral_value, approach (SA/IRB) | FinancialContract |
| InsuranceContractGroup | IFRS 17 cohort: BEL, CSM, Risk Adjustment | group_id, legal_entity_id, portfolio_id, cohort_year, measurement_model, csm, bel, risk_adjustment, coverage_period_end | LegalEntity; individual contracts aggregate into group |
| IntracompanyTransaction | Intragroup transaction subject to elimination | ic_id, sending_entity_id, receiving_entity_id, amount, currency, transaction_type, elimination_flag, ic_match_key | LegalEntity (sender + receiver) |

### 4.2 Schema Sketch

```sql
-- Core Financial Contract (simplified)
FinancialContract (
  contract_id             UUID          PRIMARY KEY,
  product_code            VARCHAR(20),               -- maps to product catalogue
  counterparty_id         UUID          REFERENCES Counterparty(party_id),
  legal_entity_id         UUID          REFERENCES LegalEntity(entity_id),
  currency                CHAR(3),                   -- ISO 4217
  notional                NUMERIC(20,4),
  origination_date        DATE,
  maturity_date           DATE,
  classification          VARCHAR(10),               -- AC | FVOCI | FVTPL (IFRS 9)
  stage                   SMALLINT,                  -- 1 | 2 | 3  (ECL staging)
  effective_interest_rate NUMERIC(10,8),
  collateral_id           UUID          REFERENCES Collateral(collateral_id),
  hedge_relationship_id   UUID          REFERENCES HedgeRelationship(hedge_id),
  sicr_trigger_date       DATE,                      -- audit trail for Stage 1->2 migration
  ftp_rate                NUMERIC(10,8),             -- locked at origination
  ftp_curve_version_id    UUID                       -- version of FTP curve applied
);

-- ECL Allowance (point-in-time snapshot per reporting date)
ECLAllowance (
  ecl_id              UUID          PRIMARY KEY,
  contract_id         UUID          REFERENCES FinancialContract(contract_id),
  reporting_date      DATE,
  stage               SMALLINT,
  pd_12m              NUMERIC(6,5),                  -- 12-month PD
  pd_lifetime         NUMERIC(6,5),
  lgd                 NUMERIC(6,5),
  ead                 NUMERIC(20,4),
  ecl_amount          NUMERIC(20,4),                 -- EAD × PD × LGD (simplified, pre-discount)
  macro_scenario_id   UUID,
  model_run_id        UUID                           -- links to risk engine model run for audit
);

-- IFRS 17 Insurance Contract Group
InsuranceContractGroup (
  group_id            UUID          PRIMARY KEY,
  legal_entity_id     UUID          REFERENCES LegalEntity(entity_id),
  portfolio_id        UUID,
  cohort_year         SMALLINT,                      -- year of inception
  profitability_class VARCHAR(20),                   -- ONEROUS | NON_ONEROUS | UNCERTAIN
  measurement_model   VARCHAR(5),                    -- BBA | VFA | PAA
  csm                 NUMERIC(20,4),                 -- Contractual Service Margin
  bel                 NUMERIC(20,4),                 -- Best Estimate of Liabilities
  risk_adjustment     NUMERIC(20,4),
  coverage_period_end DATE,
  currency            CHAR(3),                       -- ISO 4217
  actuarial_run_date  DATE                           -- date of last BEL/lapse input from actuarial system
);

-- Parallel Ledger Journal Entry
JournalEntry (
  entry_id            UUID          PRIMARY KEY,
  ledger_id           VARCHAR(20),                   -- IFRS | US_GAAP | LOCAL_STAT | REGULATORY
  contract_id         UUID          REFERENCES FinancialContract(contract_id),
  cost_center_id      UUID,
  legal_entity_id     UUID          REFERENCES LegalEntity(entity_id),
  posting_date        DATE,
  value_date          DATE,
  amount_dc           NUMERIC(20,4),                 -- document currency
  currency_dc         CHAR(3),
  fx_rate             NUMERIC(14,8),                 -- exchange rate applied
  amount_lc           NUMERIC(20,4),                 -- ledger functional currency
  debit_account       VARCHAR(30),
  credit_account      VARCHAR(30),
  transaction_type    VARCHAR(30),                   -- ACCRUAL | AMORTISATION | ECL_PROVISION | FV_CHANGE | FX_REVAL
  source_system       VARCHAR(30),                   -- CBS | TMS | ACTUARIAL | MANUAL_REVERSAL
  posted_by           UUID,                          -- user / system service account
  is_reversing        BOOLEAN DEFAULT FALSE
);

-- Regulatory Exposure (COREP input)
RegulatoryExposure (
  exposure_id         UUID          PRIMARY KEY,
  contract_id         UUID          REFERENCES FinancialContract(contract_id),
  reporting_date      DATE,
  asset_class         VARCHAR(30),                   -- CORPORATE | RETAIL | SOVEREIGN | INSTITUTION
  approach            VARCHAR(10),                   -- SA | IRB_F | IRB_A
  gross_exposure      NUMERIC(20,4),
  ccf                 NUMERIC(5,4),                  -- Credit Conversion Factor
  ead                 NUMERIC(20,4),                 -- = gross_exposure × ccf for off-balance items
  risk_weight         NUMERIC(6,4),
  rwa                 NUMERIC(20,4),                 -- = ead × risk_weight
  collateral_value    NUMERIC(20,4),
  collateral_type     VARCHAR(20)
);
```

---

## 5. Critical Integrations

| System Category | Vendor Examples | Data Exchanged | Protocol / Standard |
|---|---|---|---|
| Core Banking System (CBS) | Temenos Transact (formerly T24), Oracle FLEXCUBE, FIS Profile, FIS Horizon, Finastra Fusion Banking, Thought Machine Vault | Transaction events, contract lifecycle events (origination, modification, closure), accrual amounts, payment schedules | ISO 20022 MX messages; proprietary APIs; file-based (fixed-width, CSV) for legacy CBS |
| Treasury Management System (TMS) | Kyriba (Hedge Management Module, IFRS 9 / ASC 815), ION Treasury (Wall Street Systems / Openlink), FIS Quantum, GTreasury | Trade capture, cash positions, hedge designations, effectiveness test results | FpML (Financial products Markup Language); SWIFT MT/MX; REST API |
| Risk Engine / ECL Platform | Moody's Analytics (RiskCalc, IFRS 9 suite), SAS Credit Risk, Prometeia | PD/LGD/EAD model outputs, staging decisions (SICR flags), macro scenario weights | REST API; SFTP file exchange (CSV/XML) |
| Actuarial System | Prophet (FIS), AXIS (Milliman), MoSes (Moody's Analytics), Milliman STAR | BEL, mortality/lapse/expense tables, reserve projections, CSM roll-forward inputs | CSV/XML; SFTP; direct DB extract |
| AML / Financial Crime Platform | NICE Actimize (SAM, WLF modules), Quantexa Decision Intelligence, Refinitiv World-Check (LSEG), Temenos FCM | KYC status, AML risk scores, SAR flags, sanctions screening results, PEP classification | REST API; message queue (Kafka/MQ) |
| Market Data / Pricing | Bloomberg (BVAL, B-PIPE), Refinitiv Eikon / LSEG DataScope | Mark-to-market prices, yield curves, FX spot/forward rates, credit spreads, volatility surfaces | Proprietary Bloomberg API; Refinitiv Elektron API; SFTP |
| Regulatory Reporting Platform | SS&C AxiomSL (Controller View), Wolters Kluwer OneSumX, Regnology | COREP/FINREP XBRL packages, AnaCredit XML, LCR/NSFR data, DFAST/CCAR submissions | EBA DPM XBRL taxonomy; EIOPA XBRL taxonomy; REST |
| Payments / SWIFT | SWIFT network (FIN/MX), SWIFTNet | Settlement instructions, nostro account reconciliation, confirmation matching | ISO 20022 MX (pacs, camt); SWIFT MT (legacy) |
| Tax Engine | Vertex, Thomson Reuters ONESOURCE, SOVOS | FATCA/CRS withholding calculations, W-8/W-9 validation, IRC §871(m) equivalents | REST API |
| Custody / Securities Settlement | Broadridge, DTCC, Euroclear | Securities positions, corporate actions, settlement instructions | ISO 15022 (MT54x); ISO 20022 SESE namespace |
| Intercompany / Group Reporting | SAP Group Reporting, Oracle FCCS, HFM (Oracle Hyperion) | Intercompany balances, elimination rules, consolidation journals | XBRL; API; proprietary adapter |

---

## 6. KPIs & Metrics

| KPI | Definition | Formula | ERP Data Source |
|---|---|---|---|
| Net Interest Margin (NIM) | Spread between interest income and expense relative to interest-earning assets | NIM = (Interest Income − Interest Expense) / Average Interest-Earning Assets | GL interest income / expense accounts; average balance from sub-ledger |
| Return on Equity (ROE) | Net profit relative to shareholders' equity | ROE = Net Income / Average Shareholders' Equity | P&L net income; equity balance from GL |
| Return on Assets (ROA) | Profitability relative to total assets | ROA = Net Income / Average Total Assets | P&L net income; total assets from GL |
| Cost-to-Income Ratio (CIR) | Operating efficiency benchmark | CIR = Operating Expenses / (NII + Non-Interest Income) | Cost centre actual spend; revenue from GL |
| CET1 Ratio | Primary regulatory capital adequacy ratio | CET1 Ratio = CET1 Capital / Total RWA | Regulatory capital position; RWA from COREP data |
| Leverage Ratio (Basel III) | Tier 1 capital to total exposure; minimum 3% | Leverage Ratio = Tier 1 Capital / Total Exposure Measure | Capital position; exposure measure from regulatory module |
| Liquidity Coverage Ratio (LCR) | HQLA available vs. 30-day stressed net outflows; minimum 100% | LCR = HQLA / Net Cash Outflows (30-day stress) | Treasury liquidity buffer; cash flow projections |
| Net Stable Funding Ratio (NSFR) | Stable funding available vs. required; minimum 100% | NSFR = Available Stable Funding / Required Stable Funding | Balance sheet maturity profile; funding classification |
| NPL Ratio | Measure of credit quality deterioration in the loan book | NPL Ratio = NPL Gross Carrying Amount / Total Gross Loans | Contract-level staging flags from sub-ledger (Stage 3 = NPL proxy) |
| NPL Coverage Ratio | ECL provisions as proportion of NPLs | Coverage Ratio = ECL Allowance / NPL Gross Carrying Amount | ECLAllowance table; NPL balances from sub-ledger |
| Net Charge-Off Rate | Realised credit losses in period | Net Charge-Off Rate = (Gross Charge-Offs − Recoveries) / Average Loans | Write-off transactions from contract sub-ledger |
| Combined Ratio (Insurance) | Underwriting profitability; below 100% = profit | Combined Ratio = (Claims Incurred + Underwriting Expenses) / Net Premiums Earned | Insurance contract group P&L accounts |
| SCR Ratio (Solvency II) | Own funds relative to Solvency Capital Requirement | SCR Ratio = Eligible Own Funds / SCR | Solvency II module; actuarial / capital model output |
| CSM Amortisation Rate | Forward profit from insurance contracts released to revenue | Derived from InsuranceContractGroup; CSM released per coverage units provided in period | IFRS 17 insurance module; actuarial coverage unit assumptions |
| FTP Margin | Internal margin attributed to originating business unit | FTP Margin = Product Rate − FTP Curve Rate (matched maturity) | FTP rate locked at contract origination; FTP curve version |
| RAROC | Risk-Adjusted Return on Capital — profitability net of expected loss and capital charge | RAROC = (Revenue − Expected Loss − Operating Cost) / Economic Capital | ECL, FTP, cost allocation, capital attribution from ERP sub-modules |

---

## 7. Major ERP Vendors for this Vertical

### 7.1 SAP S/4HANA

**Relevant modules:**

- **FI**: GL (parallel ledger via ACDOCA Universal Journal), AR, AP, Bank Accounting
- **CO**: Cost Center Accounting (CCA), Profit Center Accounting (PCA), Internal Orders
- **FI-CA** (Contract Accounts Receivable/Payable): designed for high-volume posting at the scale of retail banking (millions of contract accounts)
- **TR** (Treasury and Risk Management): derivative trade capture, hedge accounting, liquidity management
- **FSCM** (Financial Supply Chain Management): collections, credit management, dispute management
- **Group Reporting**: legal consolidation with intercompany elimination, currency translation, NCI tracking; integrated with ACDOCA
- **S/4HANA for Insurance**: claims management, policy accounting
- **SAP Financial Services Data Platform (FSDP)**: data layer for regulatory analytics; feeds downstream regulatory reporting tools
- **SAP Bank Analyzer** (legacy): ALM, credit risk, regulatory reporting; a significant number of large banks remain on Bank Analyzer; the migration path to native S/4HANA capability is ongoing — engineers should verify current SAP roadmap documentation before planning Bank Analyzer migrations

**Strength:** Universal Journal parallel ledger architecture is purpose-built for multi-GAAP at scale; Group Reporting for consolidation is native; breadth of coverage spans GL through procurement and HR.

**Weakness:** Very high cost and implementation complexity; specialist functions (ECL engine, actuarial integration, regulatory capital) require third-party point solutions even within an S/4HANA deployment. SAP ECC mainstream maintenance ends 31 December 2027 (extended maintenance available to 31 December 2030 at additional cost) [16]; all financial services customers on ECC must plan migration to S/4HANA.

### 7.2 Oracle Fusion Cloud ERP + OFSAA

- **Oracle Fusion Cloud Financials**: GL with secondary ledger capability; Oracle Accounting Hub Cloud (OAHC) for event-based multi-ledger posting from external source systems (CBS, TMS)
- **Oracle Financial Consolidation and Close Cloud (FCCS)**: legal consolidation, close management, intercompany elimination
- **Oracle Planning and Budgeting Cloud (PBCS / EPBCS)**: driver-based FP&A, NII forecasting
- **Oracle Financial Services Analytical Applications (OFSAA)**: the regulatory-depth layer — ALM, Profitability Management (FTP), Regulatory Reporting, Basel capital computation (SA, IRB, FRTB), IFRS 9 ECL, Funds Transfer Pricing, Liquidity Risk Management
- **Oracle FLEXCUBE**: core banking system (separate product); tightly integrated with OFSAA and Fusion via REST API and ISO 20022

**Strength:** OFSAA fills the deep regulatory computation gap that generic ERP cannot; strong for capital, liquidity, and IFRS 9 provisioning calculations in a single Oracle ecosystem.

**Weakness:** OFSAA + Fusion = two distinct product stacks with separate licences, release cycles, and integration points; integration effort is significant and must be designed carefully to avoid reconciliation gaps.

### 7.3 Workday Financial Management

- **Workday Financial Management**: multi-book dimensioned accounting, multi-currency, configurable accounting rules
- **Workday Adaptive Planning for Banking**: scenario modelling for NII, balance sheet, FTP, capital forecasting

**Strength:** HR + Finance unified data model; strong for asset managers, fintech, insurance company back-office P&L reporting, and FP&A.

**Weakness:** Not a CBS replacement; lacks native ECL engine, regulatory capital computation, and actuarial integration — these require third-party integrations. Not positioned for regulatory capital-intensive banking.

### 7.4 Temenos

- **Temenos Transact** (formerly T24): core banking system — handles product processing, not a GL ERP in the traditional sense but contains embedded accounting
- **Temenos Financial Crime Mitigation (FCM)**: AML/KYC/sanctions screening embedded in the CBS
- **Temenos Regulatory Reporting**: multi-country regulatory output from transaction data
- **Temenos Infinity**: digital banking front-end / customer engagement

Typically deployed as the CBS with Oracle or SAP as the GL ERP above it.

### 7.5 FIS

- **FIS Profile**: flagship core banking system for large commercial banks
- **FIS Horizon**: community bank core banking
- **FIS Quantum (Treasury and Risk Manager)**: TMS with hedge accounting support under ASC 815 and IFRS 9; derivatives; market risk

### 7.6 Finastra

- **Fusion Banking**: retail and corporate banking modules
- **Fusion Capital Markets**: trade capture, settlements, collateral management
- **Fusion Risk**: ALM, market risk, credit risk
- **FusionFabric.cloud**: open API marketplace enabling third-party IFRS 9, Solvency II, and regulatory modules to integrate with Finastra core

### 7.7 Wolters Kluwer OneSumX

Regulatory reporting and risk management platform deployed alongside (not replacing) a GL ERP. Covers COREP, FINREP, AnaCredit, LCR/NSFR, Solvency II QRTs, and IFRS 9 disclosure. Strong in EBA taxonomy management and data lineage tracing from source GL to filed report cell.

### 7.8 SS&C AxiomSL

Regulatory reporting engine: COREP, FINREP, DFAST, FR Y-9C, CCAR, AnaCredit. The **Controller View** product provides full data lineage — tracing each filed report cell back through transformation rules to the source system data — which is essential for BCBS 239 compliance and regulatory inspection. Receives GL data from SAP, Oracle, or Temenos; produces XBRL packages for submission.

---

## 8. Implementation Cautions

### 8.1 Sub-Ledger to GL Reconciliation — Silent Drift

Accrual engines and GL balances diverge silently through rounding (particularly on large portfolios with fractional EIR calculations), timing differences between system boundaries, and unauthorised manual GL adjustments. A bank that closes a quarter with unreconciled breaks faces audit qualification. Design daily automated reconciliation jobs with defined tolerances (typically zero tolerance at account level, not just aggregate); implement alerting on first occurrence of any break; never permit period close without signed-off reconciliation.

### 8.2 ECL Model Governance vs ERP System Boundary

The risk model team owns PD/LGD/EAD models; the ERP team owns the provisioning journal entry workflow; neither fully owns SICR criteria. This ambiguity leads to staging misclassification, audit findings, and disputes between Finance and Risk over provision levels. Define a formal data interface: model output files (or API responses) are the authoritative input to the ERP ECL staging engine; all model changes go through a formal change-control process with version tagging in the model_run_id field.

### 8.3 Parallel Ledger Performance at Scale

Posting to four or more parallel ledgers simultaneously multiplies write volume by the ledger count. SAP ACDOCA at a large retail bank accumulates billions of rows within two to three years of go-live. Partitioning strategy (by posting_date or ledger_id), archiving policy (ILM — Information Lifecycle Management in S/4HANA), and read-replica design for regulatory reporting queries must be scoped and tested before go-live, not retrofitted post-production.

### 8.4 Regulatory Reporting Taxonomy Changes

The EBA updates its DPM taxonomy annually; EIOPA updates the Solvency II QRT taxonomy annually. Each update changes validation rules, cell codes, and submission schema. The ERP GL data model, the data pipeline to the regulatory reporting platform (AxiomSL, OneSumX), and the platform's own taxonomy configuration all require coordinated annual releases. A taxonomy lag of even one cycle causes filing failures and regulatory late-submission penalties. Establish a joint ERP + regulatory reporting release cycle keyed to the EBA/EIOPA publication calendar.

### 8.5 IFRS 17 Data Granularity Mismatch

IFRS 17 requires contract grouping into cohorts by inception year and profitability class. Legacy actuarial systems and GAAP reserve systems stored aggregated reserves (not contract-level data). Migration from legacy to IFRS 17 typically requires full historical restatement of the comparative period (1 January 2022 for entities with a 31 December year-end reporting in 2023). Underestimating the data extraction and cleansing effort from legacy policy administration systems is the most common project failure mode for IFRS 17 implementations.

### 8.6 FTP Methodology and System Alignment

Multiple business units routinely dispute FTP charges. The ERP must enforce the Treasury-published FTP curve version that was locked to each contract at origination — not the current curve rate. Systems that re-apply the current FTP curve to existing contracts (rather than the locked rate) cause erroneous P&L restatements and destroy the economic signalling purpose of FTP. Lock curve version at origination in the FinancialContract record; audit any changes.

### 8.7 FATCA/CRS Self-Certification Backlogs

Retail banks with millions of customers face bulk remediation projects when FATCA/CRS self-certification is retrofitted rather than embedded in onboarding. These projects routinely underestimate the effort of customer outreach, failed delivery, dormant account tracking, and XML schema validation for submission files. Design CRS/FATCA workflow as a mandatory onboarding gate — not as a retroactive compliance project.

### 8.8 Core Banking vs ERP Boundary — Double-Booking Risk

The most structurally dangerous failure mode in financial services ERP: CBS posts accruals to its internal ledger AND ERP posts accruals to the GL from the same source events, resulting in double-counted interest income/expense on the P&L and overstated balances. The remedy is architectural: CBS is the system of record for origination and transaction processing; ERP receives financial events from CBS via a single canonical interface (ISO 20022 or proprietary API); no direct manual entries to the ERP GL that bypass the interface. Document this boundary in the integration specification and enforce it via GL account access controls.

### 8.9 Multi-Currency Revaluation at Month-End

FX revaluation of foreign-currency balances generates both accounting FX P&L (for the IFRS/GAAP ledger) and regulatory FX values (which may use a different reference exchange rate). Parallel-ledger revaluation with different rates produces ledger-to-ledger differences that must be reconciled, explained, and disclosed. The revaluation engine must be configured per ledger with the correct rate source; automated reconciliation between ledgers for FX revaluation differences should be part of the month-end close checklist.

### 8.10 Intercompany Elimination for Financial Institutions

A banking group may have thousands of intragroup exposures — loans from a central treasury to subsidiaries, intragroup deposits, back-to-back derivatives, management fee invoices. Automated elimination matching must handle: multi-currency pairs (where functional currency differs between entities), timing mismatches (one entity books in Day 1, counterpart in Day 2), and gross vs net presentation (ISDA netting agreements may change the presentation of intragroup derivative exposures). Missing elimination of intragroup interest income and expense is among the most common group audit findings in financial services. Implement automated IC matching with exception reporting before the consolidation close cycle begins.

---

## 9. Security & Compliance Depth

See `core/security.md` for foundational controls: Segregation of Duties (SoD) matrices, RBAC patterns, SOX IT general controls, encryption at rest and in transit, penetration testing, and SOC 2 Type II requirements. The following are financial-services-specific additions.

### 9.1 Financial-Services-Specific Security Frameworks

| Framework / Standard | Identifier | Scope | Key Requirement |
|---|---|---|---|
| PCI DSS | v4.0.1 (PCI SSC, June 2024) | Card-issuing / acquiring functions | Network segmentation, tokenisation, annual QSA assessment, penetration testing |
| SWIFT CSP / CSCF | Customer Security Programme Control Framework v2024 | SWIFT-connected institutions | Mandatory annual self-attestation; logical access, malware, activity monitoring controls |
| DORA | Regulation (EU) 2022/2554, applicable 17 January 2025 | EU financial entities and critical ICT third parties | ICT risk management framework; major incident report within 4 hours initial notification; TLPT (Threat-Led Penetration Testing) for significant FIs; third-party ICT provider register |
| FFIEC CAT | FFIEC IT Examination Handbook; Cybersecurity Assessment Tool | US federally regulated banks | Cybersecurity maturity self-assessment; maps to NIST CSF |
| OCC Heightened Standards | 12 CFR Part 30, Appendix D | US large banks (>$50B assets) | Formal model risk management; independent risk management function; board-level risk appetite |
| FCA SYSC 13 | FCA Sourcebook | UK FCA-regulated firms | Operational risk systems and controls; IT systems reliability |
| PRA SS4/21 | Supervisory Statement SS4/21 | UK PRA-regulated firms | Operational resilience; important business services; impact tolerance |
| CBEST | Bank of England / FCA | UK systemically important FIs | Intelligence-led penetration testing framework |
| FRB SR 11-7 / OCC 2011-12 | Federal Reserve SR 11-7; OCC 2011-12 | US bank model risk management | Three lines of defence; model validation by independent MRM function; challenge process |
| PRA SS3/18 | PRA Supervisory Statement SS3/18 | UK banks | Model risk management principles; escalating requirements for G-SIBs |

### 9.2 Data Residency and Sovereignty

- **EBA Guidelines on Outsourcing** (EBA/GL/2019/02, effective 30 September 2019) [17]: cloud infrastructure must permit supervisory access and audit rights; data must remain within the regulated jurisdiction or in a jurisdiction with adequate supervisory access agreements; financial institution must maintain a documented and tested exit plan for each cloud provider
- **FINMA Circular 2023/1 "Operational risks and resilience"** (effective 1 January 2024) [18]: establishes updated cyber risk management requirements, introduces concept of "critical data" requiring enhanced protection, and governs cloud outsourcing alongside the separate FINMA Circular 2018/3 "Outsourcing"
- **MAS TRM Guidelines** (Monetary Authority of Singapore, revised 18 January 2021) [19]: technology risk management framework; cloud and system resilience; third-party risk management; notification requirements for material IT incidents

### 9.3 Model Risk Management

Models used within ERP workflows — ECL PD/LGD/EAD models, fair value models (Level 3), FTP curve construction, capital attribution models — fall under the scope of model risk management (MRM) frameworks:

- All such models must be documented, validated by an independent MRM function, and approved before production use
- Model outputs used in regulatory submissions (COREP RWA, FINREP provisions) are subject to additional supervisory scrutiny; regulators may challenge model assumptions in supervisory review and evaluation process (SREP)
- Model inventory must be maintained in ERP or a linked GRC system; version control for model changes must be enforced

### 9.4 Audit Trail and Non-Repudiation

- Every financial posting must be immutable after period close; corrections are made via reversing entries only — no modification of original records
- Complete audit trail per journal entry: who initiated, who approved, which source system, approval chain, timestamp — accessible on demand for regulatory inspection
- Retention: minimum 5–7 years for financial records; AML records minimum 5 years post-relationship end under EU 5th AMLD (Directive 2018/843/EU); some jurisdictions (e.g., Switzerland under FINMA) require 10-year retention
- BCBS 239 [15] requires comprehensive, accurate, and timely risk data aggregation with documented data lineage from source system to board risk report — this lineage must be demonstrable within the ERP data architecture

### 9.5 Segregation of Duties — Financial Services Specific

The SoD matrix in financial services must separate the following roles completely:

| Role | Must Not Be Combined With |
|---|---|
| Trade capture (origination) | Trade confirmation / settlement approval |
| ECL staging assignment | ECL provision journal posting |
| Regulatory capital model output | COREP filing and submission |
| FTP curve publication | FTP curve application to new contracts |
| Payment initiation | Payment release / authorisation |
| Account master data maintenance | GL posting |
| Hedge designation | Hedge effectiveness certification |

No single user should be able to: originate a financial contract AND approve its ECL staging AND post the provision journal. This three-step separation is mandatory under FRB SR 11-7 model risk management guidance and EBA supervisory expectations on internal control frameworks.

See `core/security.md` for SoD matrix design patterns and RBAC implementation approaches.

---

## See also

- `core/features-core.md` — general consolidation, multi-entity, and FP&A patterns
- `core/architecture.md` — multi-entity architecture, integration bus patterns, CBS↔ERP boundary design
- `core/security.md` — foundational SoD, RBAC, SOX ITGC, encryption, and audit trail patterns
- `core/localization-tax.md` — multi-currency, transfer pricing, and jurisdiction-specific tax treatment
- `verticals/construction-realestate.md` — for contrast: project-cost accounting vs financial-contract accounting at scale

---

## Citations & Sources

1. OECD Global Forum on Transparency and Exchange of Information for Tax Purposes — CRS participating jurisdictions (120+ as of 2025): https://www.oecd.org/tax/transparency/
2. FASB ASU 2016-13 (ASC 326 CECL) effective dates — large PBEs: fiscal years beginning after 15 December 2019; non-PBEs and smaller reporting companies: fiscal years beginning after 15 December 2022: https://fasb.org/standards
3. CRR3 Regulation (EU) 2024/1623, Official Journal of the EU, published 19 June 2024, entered into force 9 July 2024, largely applying from 1 January 2025: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32024R1623
4. Commission Delegated Regulation (EU) 2025/1496 of 12 June 2025, published Official Journal 19 September 2025 — postpones FRTB own-funds requirements to 1 January 2027: https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=OJ:L_202501496
5. PRA PS1/26 "Implementation of Basel 3.1: Final rules," published 20 January 2026, effective 1 January 2027: https://www.bankofengland.co.uk/prudential-regulation/publication/2026/january/implementation-of-the-basel-3-1-final-rules-policy-statement
6. US Basel III Endgame reproposal — Federal Reserve, OCC, FDIC, 19 March 2026; comment period closed 18 June 2026; implementation anticipated 2027 with 3–5 year phase-in: https://www.federalreserve.gov/supervisionreg/basel.htm
7. IASB IFRS 17 Insurance Contracts, effective for annual periods beginning on or after 1 January 2023: https://www.ifrs.org/issued-standards/list-of-standards/ifrs-17-insurance-contracts/
8. Directive (EU) 2025/2 (Solvency II amending directive), published 8 January 2025 Official Journal, to be applied from 30 January 2027: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32025L0002
9. FASB ASU 2018-12 (LDTI) as deferred by ASU 2020-11 — effective for large accelerated SEC filers: fiscal years beginning after 15 December 2022 (FY2023): https://fasb.org/standards
10. FASB ASU 2022-01 (ASC 815 portfolio layer method), effective for public entities fiscal years beginning after 15 December 2022: https://fasb.org/standards
11. EU 2024 AML Package published Official Journal 19 June 2024: AMLA Regulation (EU) 2024/1620; AML Single Rulebook Regulation (EU) 2024/1624 (applies 10 July 2027); Directive (EU) 2024/1640: https://finance.ec.europa.eu/financial-crime/anti-money-laundering-and-countering-financing-terrorism-eu-level_en
12. FATF — International Standards on Combating Money Laundering and the Financing of Terrorism and Proliferation: The FATF Recommendations (2012, updated November 2023): https://www.fatf-gafi.org/en/topics/fatf-recommendations.html
13. EU Directive 2022/2523 (Pillar Two), entered into force 23 December 2022; member state transposition by 31 December 2023; Income Inclusion Rule applies for fiscal years beginning on or after 31 December 2023: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32022L2523
14. ECB Regulation (EU) 2016/867 (ECB/2016/13) — AnaCredit; data collection commenced September 2018: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32016R0867
15. BCBS 239 "Principles for effective risk data aggregation and risk reporting," BCBS, January 2013; effective for G-SIBs designated by November 2012 from 1 January 2016: https://www.bis.org/publ/bcbs239.htm
16. SAP ECC mainstream maintenance ends 31 December 2027; extended maintenance (at additional cost) available to 31 December 2030: https://support.sap.com/en/release-upgrade-maintenance.html
17. EBA Guidelines on outsourcing arrangements (EBA/GL/2019/02), effective 30 September 2019: https://www.eba.europa.eu/sites/default/files/documents/10180/2551996/38c80601-f5d7-4855-8ba3-702423665479/EBA%20revised%20Guidelines%20on%20outsourcing%20arrangements.pdf
18. FINMA Circular 2023/1 "Operational risks and resilience — banks," effective 1 January 2024: https://www.finma.ch/en/regulation/circulars/
19. MAS Technology Risk Management Guidelines, revised 18 January 2021: https://www.mas.gov.sg/regulation/guidelines/technology-risk-management-guidelines
20. BCBS Basel III framework (consolidated, December 2017 / revised 2019): https://www.bis.org/bcbs/publ/d424.htm
21. IASB IFRS 9 Financial Instruments, effective 1 January 2018: https://www.ifrs.org/issued-standards/list-of-standards/ifrs-9-financial-instruments/
22. IASB IFRS 13 Fair Value Measurement: https://www.ifrs.org/issued-standards/list-of-standards/ifrs-13-fair-value-measurement/
23. EBA DPM taxonomy and reporting frameworks (COREP/FINREP): https://www.eba.europa.eu/risk-analysis-and-data/reporting-frameworks
24. EIOPA Solvency II regulatory framework and QRT taxonomy: https://www.eiopa.europa.eu/browse/regulation-and-policy/solvency-ii_en
25. DORA — Regulation (EU) 2022/2554, entered into force 17 January 2023, applicable 17 January 2025: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32022R2554
26. SWIFT Customer Security Programme (CSP) / CSCF: https://www.swift.com/myswift/customer-security-programme-csp
27. OECD Transfer Pricing Guidelines and BEPS Actions: https://www.oecd.org/en/topics/sub-issues/transfer-pricing.html
28. PCI DSS v4.0.1 (PCI Security Standards Council, June 2024): https://www.pcisecuritystandards.org/document_library/ (v3.2.1 retired December 31, 2024; v4.0 future-dated requirements became mandatory March 31, 2025)
