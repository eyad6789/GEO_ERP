# ERP for Healthcare & Life Sciences

## 1. Overview

Healthcare and life sciences impose constraints on ERP that no other vertical combines simultaneously: clinical safety as a non-negotiable system invariant, extreme regulatory density across multiple agencies and geographies, mandatory integration with authoritative external systems (EHR, LIMS, CDMS) that own the primary workflow, and the obligation to maintain cryptographically tamper-evident records on every data mutation touching a regulated function. An ERP misconfiguration that causes a billing error in retail results in a refund; the same class of defect in a pharma batch record can trigger an FDA recall, a Warning Letter, or a consent decree.

**Dual-mode complexity.** The vertical spans two operationally distinct modes. Hospitals and Integrated Delivery Networks (IDNs) function primarily as cost centers: they generate revenue through billable encounters billed to payers, and ERP serves revenue cycle, supply chain, facilities management, and HR. Pharmaceutical and medical device manufacturers operate as product companies: ERP runs batch manufacturing, quality management, serialization, and regulatory compliance. CROs and biotech companies add a third mode—clinical trial supply—with its own inventory logic, blinding constraints, and chain-of-custody requirements.

**EHR as the source of truth.** ERP cannot own clinical data. The EHR (Epic, Oracle Health/Cerner, Meditech) is the authoritative record for patient demographics, encounters, diagnoses, and orders. ERP receives clinical events via ADT (Admit, Discharge, Transfer) messages, charge feeds, and FHIR R4 APIs, then handles everything downstream: payer adjudication, cash posting, supply consumption, and cost accounting. The integration contract between EHR and ERP is the single highest-risk interface in hospital IT architecture.

**Sub-segments and distinct ERP profiles:**

| Sub-segment | Primary ERP Functions | Key Regulatory Driver |
|---|---|---|
| Hospital / IDN | Revenue cycle, supply chain, HRMS, facilities | HIPAA, CMS Conditions of Participation |
| Pharma manufacturer (innovator) | Batch manufacturing, QMS, serialization, regulatory | 21 CFR Part 211, DSCSA, EU GMP |
| Pharma manufacturer (generic) | Same as above plus paragraph IV ANDA tracking | 21 CFR Part 211, DSCSA |
| Medical device company | DHR/DHF management, UDI, complaint/MDR handling | 21 CFR Part 820 (QMSR, effective Feb 2, 2026), 21 CFR Part 830 |
| CRO / Biotech | Clinical trial supply, IP management, cold chain | ICH E6(R3) (final January 2025), 21 CFR Part 312 |
| Cell & Gene Therapy | Cryogenic chain, donor tracking, autologous/allogeneic batches | 21 CFR Part 1271, EU ATMP Regulation |

---

## 2. Industry-Specific Modules

### Revenue Cycle Management (Hospitals/Clinics)

**Charge capture and CDM management.** The Charge Description Master (CDM) is a hospital's internal price list mapping service codes to CPT (Current Procedural Terminology, AMA-maintained) and HCPCS Level II codes. ERP must support CDM versioning, effective-date management, and mass updates when CMS publishes annual code revisions (effective October 1 for ICD-10 updates; January 1 for CPT). Charge capture interfaces consume HL7 v2.x charge trigger events or FHIR R4 ChargeItem resources from the EHR.

**Claims generation.** Claims are transmitted as ASC X12 837 transactions: 837P (professional/physician billing), 837I (institutional/hospital facility billing), 837D (dental). ERP generates these transactions, submits via a clearinghouse (Optum/Change Healthcare, Availity, Waystar), receives real-time acknowledgments (999 functional acknowledgment, 277CA claim acknowledgment), and updates claim status. Claims must carry the rendering provider's NPI (National Provider Identifier, 10-digit HIPAA-mandated ID), primary and secondary diagnosis codes in ICD-10-CM, and procedure codes in CPT or ICD-10-PCS for inpatient.

**Electronic Remittance Advice (ERA) and auto-posting.** Payers return payment detail as ASC X12 835 transactions. ERP parses 835 loops to extract: CLP (claim-level payment), SVC (service-line adjustment), CAS segments with Group/Reason/Amount (CO = contractual obligation, PR = patient responsibility, OA = other adjustment). Auto-posting rules apply expected-vs-paid variance logic against the payer contract model; accounts outside tolerance route to denial management queues.

**DRG grouper integration.** Inpatient reimbursement under Medicare uses MS-DRG (Medicare Severity Diagnosis Related Groups), assigned by a CMS-certified grouper (3M Health Information Systems is the dominant vendor, marketing its grouper as 3M Solara). ERP must receive the MS-DRG code and relative weight from the grouper to model expected reimbursement, calculate case mix index (CMI), and perform variance analysis against actual costs.

**Denial management.** ERP tracks denial reason codes (CARC — Claim Adjustment Reason Codes; RARC — Remittance Advice Remark Codes) per claim line, manages appeal timelines (payer-specific, typically 30–180 days), logs rebilled claims, and reports denial patterns for root-cause analysis. Denial rate by payer, by CPT code, and by denial reason drives CDM and clinical documentation improvement interventions.

**Payer contract management.** ERP stores fee schedules, carve-out arrangements, capitation parameters, and value-based reimbursement modifiers per payer. Expected reimbursement is calculated at charge entry using the contract model, enabling real-time underpayment flagging when 835 payments post below contract rate.

**Collection workflow.** Bad debt management includes collection agency interface (batch file extract of overdue accounts), bad debt write-off posting (debit bad debt expense / credit AR), and charity care qualification tracking under IRS Form 990 Schedule H requirements for tax-exempt hospitals.

### Pharmaceutical & Life Sciences Manufacturing

**Batch/lot management.** Every manufactured lot requires a unique lot number, expiry date, and complete genealogy from raw material lots through intermediates to finished goods. ERP enforces FEFO (First Expired First Out) picking and blocks shipment of lots outside approved status. Batch genealogy must survive lot splits, pooling operations, and repackaging events.

**Electronic Batch Record (eBR) / Master Batch Record (MBR).** Under 21 CFR Part 211, each lot requires a batch production record documenting every step, quantity, equipment ID, operator signature, and in-process test result. ERP generates eBRs from the versioned MBR, enforces step sequencing, captures timestamps, and requires electronic signatures per 21 CFR Part 11 for each critical step. MBR versioning must be controlled: only the approved revision in effect at manufacturing start date is used; prior revisions are archived with their audit trail.

**Certificate of Analysis (CoA) generation.** CoA is generated from LIMS test results linked to the batch record. ERP merges specification limits (from the material master) with LIMS result values and generates a signed, printable CoA. Any Out-of-Specification (OOS) result blocks CoA generation and triggers an OOS investigation workflow per 21 CFR § 211.192 (Laboratory Controls).

**Deviation, OOS investigation, and CAPA.** Deviations are events where a parameter falls outside pre-defined limits or a procedure was not followed. ERP QM module creates a deviation record linked to the affected batch, captures severity (critical/major/minor), routes for investigation, and links to a CAPA (Corrective and Preventive Action) record. CAPA must track root cause, action plan, due dates, effectiveness check date, and closure approval with e-signature.

**Campaign manufacturing and cleaning validation.** Shared equipment in pharma manufacturing requires cleaning validation between campaigns of different products. ERP tracks equipment qualification status, last-cleaned date, and cleaning validation batch ID; blocks new manufacturing orders on equipment pending requalification.

### Quality Management (GxP)

- **NCR (Non-Conformance Report)** management integrated with disposition (accept/rework/reject/destroy)
- **Change control** workflow: change request → impact assessment → approval → implementation → effectiveness check
- **Training management** (21 CFR Part 211.68): GxP training records per employee, with competency verification and expiry tracking; ERP enforces training prerequisites before access to regulated functions
- **Audit trail** meeting 21 CFR Part 11: immutable, timestamped record of every create/read/update/delete on regulated data
- **Electronic signature** workflows: two-component signing (meaning statement + authentication) per 21 CFR § 11.200(a); non-biometric e-sigs require unique ID + password at minimum; ERP must validate each signing event is cryptographically bound to the record at the time of signing
- **Stability testing management**: shelf-life studies per ICH Q1A(R2); ERP tracks station pull schedule, results entry, and generates stability summary for regulatory submissions
- **Vendor qualification / Approved Supplier List (ASL)**: supplier qualification status, audit results, GDP compliance documentation; ERP blocks receipt from non-approved suppliers

### Serialization & Track-and-Trace

Serialization is mandatory in the U.S. under DSCSA (21 U.S.C. § 360eee) and in the EU under Regulation (EU) 2016/161 (EU FMD). Full enhanced drug distribution security enforcement under DSCSA began November 27, 2024 (after FDA's 1-year stabilization period announced August 2023) [1]. A small dispenser exemption—applicable to corporate entities with 25 or fewer pharmacist/technician FTEs—extends to November 27, 2026, per FDA's June 12, 2024 exemption announcement [1].

**Unit-level serialization.** Each saleable unit receives a SGTIN (Serialized Global Trade Item Number = 14-digit GTIN + serial number). Case-level aggregation uses SSCC (Serial Shipping Container Code, 18-digit GS1 identifier). Both are encoded as GS1-128 barcodes and 2D DataMatrix (EU FMD requires DataMatrix on medicine packs).

**EPCIS event logging.** GS1 EPCIS 2.0 (ratified June 2022; adopted as ISO/IEC 19987:2024) defines four event types: ObjectEvent (item state change), AggregationEvent (packing/unpacking), TransactionEvent (purchase order linkage), and TransformationEvent (kitting/dekitting, repackaging). ERP must generate these events at commissioning, shipping, receiving, and dispensing. Events are submitted to an EPCIS repository (TraceLink, rfxcel, or SAP ATTP internal repository).

**DSCSA Verification Router Service (VRS).** Before accepting saleable returns, trading partners must verify the product identifier against the manufacturer's verification system via VRS. ERP must support VRS query/response integration.

**Recall management.** ERP must support rapid lot isolation: set all inventory to quarantined status, generate distribution list (all ship-to parties who received the lot via EPCIS tracing data), issue recall notifications, and track unit recovery for recall effectiveness reporting. FDA expects root cause submission within 30 days of recall initiation.

### Clinical Trial & Drug Development Management

**Investigational Product (IP) management.** Clinical supply differs from commercial supply: kits are assembled per randomization schedule, subjects are identified by blinded subject IDs (not names), and dispensing records must link to the subject without unblinding the site. ERP or a clinical supply module manages IP kit numbering, kit assembly, storage, and destruction of unused materials.

**IRT/RTSM integration.** Interactive Response Technology (IRT) / Randomization and Trial Supply Management (RTSM) systems (Veeva Vault RTSM, Medidata RTSM) own the randomization algorithm and dispensing records. ERP receives supply consumption events and generates resupply orders. The integration must maintain subject blinding: ERP sees kit IDs and treatment group codes, never subject-level unblinded treatment assignment during a blinded trial.

**Clinical supply forecasting.** Demand is driven by enrollment rates (uncertain), dropout rates (uncertain), and protocol amendment frequency (frequent). ERP clinical supply planning uses stochastic modeling or simulation-based forecasting rather than deterministic MRP.

**Clinical trial financial management.** CRO invoices, pass-through expenses, and site payments must be tracked against protocol-defined budgets and accrued based on milestone completion events from the CTMS (Veeva Vault CTMS, Medidata Rave CTMS, Oracle Siebel CTMS).

### Cold Chain Management

| Temperature Class | Range | Typical Products | Key ERP Requirement |
|---|---|---|---|
| Refrigerated | 2–8°C | Most biologics, vaccines, insulin | Zone-controlled storage locations, FEFO picking |
| Frozen | -20 to -30°C | Some vaccines, plasma derivatives | Dry ice shipment tracking |
| Ultra-Low Temperature (ULT) | -60 to -80°C | mRNA vaccines (e.g., BNT162b2) | Validated ULT storage units, excursion alerting |
| Cryogenic | Below -150°C (liquid nitrogen) | Cell & gene therapy products | Dewars, vapor-phase nitrogen, chain-of-identity |

IoT temperature sensors (Sensitech/Carrier, Controlant, ELPRO) must integrate with ERP/QMS via REST API: sensor readings feed excursion events, which auto-create deviations in the QM module linked to the affected lot. Manual handoff from sensor dashboard to QM is an audit failure mode. Excursion disposition (use/quarantine/destroy) requires documented assessment and e-signature against the batch record.

### Medical Device-Specific

**Device History Record (DHR).** 21 CFR Part 820 (now titled Quality Management System Regulation, QMSR, effective February 2, 2026, harmonized with ISO 13485:2016) requires a DHR for each production unit or lot, documenting: date(s) manufactured, quantity released, authorization to distribute, primary ID (lot, serial, or UDI), and labels/labeling used. ERP generates and maintains DHR as part of the manufacturing order close process. [2]

**Design History File (DHF) linkage.** The DHF (design control records) is typically maintained in a PLM or QMS system (Oracle Agile PLM, Veeva Vault QualityDocs). ERP manufacturing orders reference the applicable DHF revision to confirm the device was built to the approved design. Design changes trigger change control and potentially a new 510(k) or PMA supplement.

**UDI assignment and GUDID submission.** Under 21 CFR Part 830, every medical device label must carry a UDI consisting of a Device Identifier (UDI-DI, representing the specific version/model) and a Production Identifier (UDI-PI, containing lot, serial, manufacture date, expiry). GS1, HIBCC, and ICCBBA are the three FDA-accredited issuing agencies. ERP must manage GS1 GTIN assignment for UDI-DI and submit device master data to GUDID (Global Unique Device Identification Database, FDA-managed). GUDID submissions use HL7 SPL (Structured Product Labeling) or the GUDID web API.

**Complaint handling and MDR.** 21 CFR Part 803 requires manufacturers to submit Medical Device Reports (MDRs) to FDA within 30 days (5 days for malfunction events that could cause serious injury if recurrence). ERP complaint module captures: device identity (UDI), patient information, event description, MDR reportability determination, and generates draft FDA eMDR (electronic MDR) for submission via FDA's MedWatch Plus or eSub gateway.

**Consignment inventory.** Implantable devices (orthopedics, cardiovascular) are routinely held at hospital locations on consignment. ERP must track consignment stock by hospital/location, consume items at implant (triggered by case completion event from hospital ERP or surgical scheduling system), and manage vendor replenishment of consignment stock.

---

## 3. Regulatory & Compliance Requirements

### United States

| Regulation | Citation | Scope | Key ERP Impact |
|---|---|---|---|
| HIPAA Privacy Rule | 45 CFR Part 164, Subpart E | PHI handling | Minimum necessary access; field-level security on patient data |
| HIPAA Security Rule | 45 CFR Part 164, Subpart C | ePHI | AES-256 encryption at rest; TLS 1.2+ in transit; audit logging; access controls; auto-logoff |
| HIPAA Breach Notification Rule | 45 CFR §§ 164.400–414 | Breach response | 60-day notification SLA; >500 individuals triggers media notification; annual log to HHS for <500 |
| HITECH Act (2009) | 42 U.S.C. § 17901 et seq. | Extends HIPAA to Business Associates | BA Agreement (BAA) tracking in vendor module; BA liability for breaches |
| 21 CFR Part 11 | Title 21, CFR Part 11 | Electronic records/signatures | Tamper-evident audit trails; two-component e-sig; validated systems; published 1997, still current |
| 21 CFR Part 211 | cGMP for finished pharmaceuticals | Batch records, lab controls, deviations | eBR, CoA, OOS investigation, deviation, CAPA management |
| 21 CFR Part 820 (QMSR) | Quality Management System Regulation; final rule February 2, 2024; effective February 2, 2026 | Medical device manufacturing; harmonized with ISO 13485:2016 | DHR, DHF linkage, CAPA, complaint handling; QMSR replaces legacy QSR structure |
| 21 CFR Part 830 | UDI System | Medical device labeling | GTIN/SSCC assignment; GUDID submission via HL7 SPL or API |
| 21 CFR Part 803 | Medical Device Reporting | Complaint/adverse events | Workflow to generate eMDR; 30-day/5-day reporting timelines |
| DSCSA | 21 U.S.C. § 360eee | Drug serialization & traceability | SGTIN/SSCC generation; EPCIS event logging; VRS integration; full enforcement from November 27, 2024 [1] |
| FDA CSA Guidance | September 2022 final guidance | Computer system assurance approach | Risk-based testing (not documentation-heavy CSV); non-binding but FDA-accepted; does not eliminate validation obligation |
| FDA Cybersecurity Guidance (Medical Devices) | September 2023 final guidance | Premarket submissions | SBOM required in 510(k)/PMA; cybersecurity documentation in DHF |

**HIPAA Security Rule NPRM (Proposed Rule).** On January 6, 2025, HHS published a Notice of Proposed Rulemaking in the Federal Register (Docket HHS-OCR-2023-0015) proposing mandatory MFA, encryption of all ePHI (removing the current "addressable" flexibility), network segmentation, and vulnerability scanning [3]. The public comment period closed March 7, 2025. As of June 2026, the final rule has not been published; the rule's finalization had been on HHS OCR's regulatory agenda for May 2026 but that window passed without publication. Architects should design new systems to the stricter proposed standards to avoid rework on finalization.

### European Union

| Regulation/Standard | Identifier | Scope |
|---|---|---|
| EU Falsified Medicines Directive serialization | Regulation (EU) 2016/161 (Delegated Regulation implementing Directive 2011/62/EU) | 2D DataMatrix unique identifier on medicine packs; verification at point of dispensing |
| EU MDR | Regulation (EU) 2017/745, applied May 26, 2021 | Medical device conformity assessment; UDI, EUDAMED registration |
| EU IVDR | Regulation (EU) 2017/746 | In vitro diagnostics; phased IVDR application schedule per risk class |
| EU GMP Annex 11 | EudraLex Vol. 4, Annex 11 (2011 revision, current) | Computerised systems in pharmaceutical manufacturing; a draft revision has circulated but the updated Annex 11 was not finalized as of June 2026 |
| EU GMP Annex 13 | EudraLex Vol. 4, Annex 13 | Investigational medicinal products; IP manufacturing, packaging, labeling |
| EU GDP Guideline | 2013/C 343/01 | Good Distribution Practice for medicinal products; cold chain, transport qualification |

### International and Cross-Regional Standards

| Standard | Identifier | Notes |
|---|---|---|
| ICH Q7 | ICH Q7 | GMP for Active Pharmaceutical Ingredients |
| ICH Q9 | ICH Q9 Rev 1 (2023) | Quality Risk Management; Rev 1 adds clarity on subjectivity and risk tools |
| ICH Q10 | ICH Q10 | Pharmaceutical Quality System; lifecycle-based, aligned with ISO 9001 |
| ICH E6 | ICH E6(R3), final version published January 6, 2025 [4] | Good Clinical Practice; final text updates address risk-based monitoring, decentralized/remote trials, technology-agnostic language |
| ISPE GAMP 5 | 2nd Edition, July 2022 | Shifts from document-heavy CSV to CSA/risk-based approach; supports agile development; addresses cloud and cybersecurity |
| ISO 13485 | ISO 13485:2016 | Medical devices QMS requirements; mandatory for EU MDR technical file; now incorporated by reference into FDA QMSR (21 CFR Part 820) [2] |
| ISO 14971 | ISO 14971:2019 | Risk management for medical devices; risk file linked to DHF |
| HL7 FHIR | R4 (normative, December 2018) is the dominant deployed standard; R5 (April 2023) available; R6 is in active ballot (ballot 4, May 2026) with final publication expected 2026–2027 [5] | Healthcare interoperability; ERP integration with EHR uses FHIR R4 SMART on FHIR authorization |
| HL7 v2.x | Multiple versions (v2.3–v2.8) still in production | ADT, ORM, ORU, DFT messages; legacy but dominant in hospital ADT and lab feeds |
| GS1 EPCIS | EPCIS 2.0 (ratified June 2022; ISO/IEC 19987:2024) | Event-based supply chain track-and-trace; CBV (Core Business Vocabulary) defines standard business steps and dispositions |

### Coding Standards (Revenue Cycle)

| Code System | Maintainer | Update Cycle | Use |
|---|---|---|---|
| ICD-10-CM | CDC/CMS | Annual, October 1 | Diagnosis coding (outpatient and inpatient) |
| ICD-10-PCS | CMS | Annual, October 1 | Inpatient procedure coding; directly influences MS-DRG assignment |
| CPT | AMA | Annual, January 1 | Outpatient/professional services procedures |
| HCPCS Level II | CMS | Quarterly + annual | Supplies, DME, drugs, ambulance |
| MS-DRG | CMS | Annual, October 1 | Medicare inpatient grouper; basis for hospital payment per stay |
| Revenue Codes (UB-04 / CMS-1450) | NUBC | As needed | Required on institutional claims (837I) to classify services |
| NPI | CMS (NPPES) | N/A | 10-digit unique provider identifier; required on all HIPAA claims |

---

## 4. Key Data Entities

### Entity Descriptions

**Revenue Cycle (Hospital)**
- **Patient**: MRN (Medical Record Number) as primary key; demographics; active payer assignment; guarantor linkage. Owned by EHR; ERP receives via HL7 ADT A08 (patient update) or FHIR R4 Patient resource.
- **Encounter/Visit**: ADT-driven; admit date, discharge date, care setting (inpatient/outpatient/ED), attending provider NPI, final MS-DRG code and relative weight. Source: HL7 ADT A01/A03/A08 or FHIR R4 Encounter resource.
- **Charge**: CDM code, mapped CPT/HCPCS, primary ICD-10-CM diagnosis, service date, quantity, charge amount, ordering provider NPI. Source: EHR charge trigger or manual CDM entry.
- **Claim**: 837 transaction type (P/I/D), payer, total billed, submission date, status (submitted/acknowledged/adjudicated/denied), claim control number.
- **Remittance**: 835 ERA; maps to one or more claims; contains CLP/SVC segments; payment amount; adjustment reason codes (CARC/RARC); posting status.
- **Payer Contract**: Fee schedule effective dates, reimbursement basis (% of charges, fee schedule, DRG rate, per diem), carve-outs, value-based arrangements.

**Pharma Manufacturing**
- **Product**: Product code, name, NDC number (11-digit National Drug Code), strength, dosage form, shelf life in months, storage conditions.
- **Batch/Lot**: Lot number, product code FK, MBR version, manufacturing date, expiry date, actual yield, status (in-process/released/rejected/recalled).
- **BatchIngredient**: FK to batch and material; lot number of ingredient; quantity and UOM; CoA reference.
- **Deviation**: Deviation ID, batch FK, description, severity, CAPA FK, closure date, approver e-signature record.
- **CAPA**: Root cause, action plan, due date, effectiveness check date, closure approver.

**Serialization**
- **SerializedItem**: SGTIN (GTIN + serial) as PK, batch FK, SSCC (case/pallet), current status (commissioned/shipped/dispensed/recalled/destroyed).
- **EPCISEvent**: Event type (ObjectEvent/AggregationEvent/TransactionEvent/TransformationEvent), SGTIN FK, business step (CBV vocabulary), disposition (in_progress/active/recalled), location SGLN (GS1 Location Number), event timestamp.

**Medical Device**
- **Device**: UDI-DI as PK, UDI-PI (lot/serial/expiry), device code FK, implant date, patient MRN FK, facility ID FK. Consumed after implant surgery.
- **Complaint**: Complaint ID, UDI-DI FK, received date, description, MDR reportability determination (boolean), FDA report number, status.

**Clinical Trial**
- **InvestigationalProduct**: IP kit ID, randomization number (blinded), subject ID (blinded), product code, expiry, storage conditions, dispensing record, destruction record.

### Schema Sketch

```sql
-- Revenue Cycle (Hospital ERP)
Patient (
    mrn              VARCHAR(20)  PRIMARY KEY,
    demographics     JSONB,                     -- name, DOB, address, SSN-last4
    active_payer_id  INT          REFERENCES Payer(payer_id),
    guarantor_id     INT          REFERENCES Guarantor(guarantor_id)
);

Encounter (
    encounter_id     BIGINT       PRIMARY KEY,
    mrn              VARCHAR(20)  REFERENCES Patient(mrn),
    admit_dt         TIMESTAMP,
    discharge_dt     TIMESTAMP,
    care_setting     VARCHAR(20),               -- inpatient/outpatient/ED/obs
    attending_npi    CHAR(10),
    drg_code         VARCHAR(5),
    ms_drg_weight    NUMERIC(6,4),
    financial_class  VARCHAR(20)
);

Charge (
    charge_id        BIGINT       PRIMARY KEY,
    encounter_id     BIGINT       REFERENCES Encounter(encounter_id),
    cdm_code         VARCHAR(10),
    cpt_hcpcs        VARCHAR(7),
    icd10cm_primary  VARCHAR(8),
    service_dt       DATE,
    units            NUMERIC(7,2),
    charge_amt       NUMERIC(12,2),
    ordering_npi     CHAR(10)
);

Claim (
    claim_id         BIGINT       PRIMARY KEY,
    encounter_id     BIGINT       REFERENCES Encounter(encounter_id),
    claim_type       CHAR(1),                   -- P=professional, I=institutional, D=dental
    payer_id         INT          REFERENCES Payer(payer_id),
    total_billed     NUMERIC(12,2),
    status           VARCHAR(20),               -- submitted/acknowledged/adjudicated/denied
    submission_dt    TIMESTAMP,
    claim_control_no VARCHAR(30)
);

Remittance (
    era_id           BIGINT       PRIMARY KEY,
    claim_id         BIGINT       REFERENCES Claim(claim_id),
    payment_dt       DATE,
    paid_amt         NUMERIC(12,2),
    adj_codes        JSONB        -- [{group:'CO', reason:'45', amt:120.00}, ...]
);

-- Pharma Manufacturing (Batch ERP)
Product (
    product_code     VARCHAR(20)  PRIMARY KEY,
    name             VARCHAR(200),
    ndc_number       CHAR(11),
    strength         VARCHAR(50),
    dosage_form      VARCHAR(50),
    shelf_life_months INT,
    storage_conditions VARCHAR(100)
);

BatchRecord (
    batch_id         VARCHAR(30)  PRIMARY KEY,
    product_code     VARCHAR(20)  REFERENCES Product(product_code),
    mbr_version      VARCHAR(10),
    mfg_dt           DATE,
    expiry_dt        DATE,
    yield_actual     NUMERIC(12,3),
    yield_uom        VARCHAR(10),
    status           VARCHAR(20)  -- in-process/released/rejected/recalled
);

BatchIngredient (
    batch_id         VARCHAR(30)  REFERENCES BatchRecord(batch_id),
    material_code    VARCHAR(20),
    lot_number       VARCHAR(30),
    quantity         NUMERIC(12,3),
    uom              VARCHAR(10),
    coa_ref          VARCHAR(50),
    PRIMARY KEY (batch_id, material_code, lot_number)
);

Deviation (
    dev_id           VARCHAR(20)  PRIMARY KEY,
    batch_id         VARCHAR(30)  REFERENCES BatchRecord(batch_id),
    description      TEXT,
    severity         VARCHAR(10), -- critical/major/minor
    capa_id          VARCHAR(20)  REFERENCES CAPA(capa_id),
    closed_dt        DATE,
    approver_esig    JSONB        -- {user_id, timestamp_utc, meaning_statement, auth_method}
);

CAPA (
    capa_id          VARCHAR(20)  PRIMARY KEY,
    root_cause       TEXT,
    action_plan      TEXT,
    due_dt           DATE,
    effectiveness_check_dt DATE,
    closed_dt        DATE
);

-- Serialization
SerializedItem (
    sgtin            VARCHAR(50)  PRIMARY KEY,  -- GS1 SGTIN-96 or SGTIN-198
    gtin             CHAR(14),
    serial_number    VARCHAR(20),
    batch_id         VARCHAR(30)  REFERENCES BatchRecord(batch_id),
    sscc             CHAR(18),
    current_status   VARCHAR(20)  -- commissioned/shipped/dispensed/recalled/destroyed
);

EPCISEvent (
    event_id         UUID         PRIMARY KEY,
    event_type       VARCHAR(30), -- ObjectEvent/AggregationEvent/TransactionEvent/TransformationEvent
    sgtin            VARCHAR(50)  REFERENCES SerializedItem(sgtin),
    biz_step         VARCHAR(100),-- GS1 CBV URI (e.g., urn:epcglobal:cbv:bizstep:shipping)
    disposition      VARCHAR(100),-- GS1 CBV URI (e.g., urn:epcglobal:cbv:disp:in_transit)
    location_sgln    VARCHAR(20),
    event_dt         TIMESTAMP WITH TIME ZONE
);

-- Medical Device
Device (
    udi_di           VARCHAR(30)  PRIMARY KEY,
    udi_pi           VARCHAR(50),             -- lot/serial/expiry encoded
    device_code      VARCHAR(20),
    lot_serial       VARCHAR(30),
    implant_dt       DATE,
    patient_mrn      VARCHAR(20)  REFERENCES Patient(mrn),
    facility_id      INT
);

Complaint (
    complaint_id     VARCHAR(20)  PRIMARY KEY,
    udi_di           VARCHAR(30)  REFERENCES Device(udi_di),
    received_dt      DATE,
    description      TEXT,
    mdr_reportable   BOOLEAN,
    fda_report_num   VARCHAR(20),
    status           VARCHAR(20)
);
```

---

## 5. Critical Integrations

### EHR / Clinical Systems

**Epic (EpicCare + Resolute + EpicOps).** Epic commands approximately 43.7% of the U.S. acute care EHR market by hospital count and 56.9% of licensed beds as of 2025 (KLAS Research) [6]. Epic Resolute provides hospital billing (HB) and professional billing (PB) directly; ERP receives charge data, ADT events, and financial summaries from Resolute via HL7 v2.x DFT (Detail Financial Transactions) messages or FHIR R4 APIs. Epic's SMART on FHIR R4 APIs are the modern integration path. MyChart is Epic's patient portal; EpicOps is Epic's emerging materials management layer that encroaches on traditional hospital supply chain ERP scope.

**Oracle Health (formerly Cerner, acquired by Oracle June 2022).** Millennium platform handles both clinical and RevCycle functions. Oracle Health holds approximately 21.9% of U.S. acute care EHR market share (KLAS Research, 2025 data), declining from 23% in 2024 following customer losses post-acquisition [6]. Provides FHIR R4 and R5 endpoints on OCI-hosted deployments; MillenniumObjects API for deeper integration. Oracle Health and Oracle Fusion ERP are separate product lines requiring deliberate API integration despite both being Oracle products. CommunityWorks is Oracle Health's hosted solution for smaller hospitals.

**Meditech Expanse.** Common in critical-access and community hospitals. REST/FHIR R4 APIs; supply chain module integration uses standard ADT and DFT feeds.

### Laboratory Information Systems (LIMS)

LIMS integration delivers CoA data and OOS flags to ERP QM: LabVantage (SAP-aligned), STARLIMS (Abbott), LabWare. Veeva Vault QualityDocs / Vault QMS integrates deviation and CAPA records bidirectionally with ERP. OOS results from LIMS must block lot release in ERP automatically; manual interface fails 483 inspection.

### Clinical Trial Systems

**Veeva Vault RTSM** (strengthened by Veracity Logic acquisition, early 2022): Randomization and Trial Supply Management. Generates resupply triggers consumed by ERP clinical supply module. Veeva Vault CTMS manages site, subject, and visit data; financial milestone events feed ERP accrual journals.

**Medidata (Dassault Systèmes): Medidata Rave CTMS, Medidata RTSM.** Patient-level study data flows to ERP for financial accrual modeling.

**Oracle Siebel CTMS / Oracle Clinical.** Legacy deployments at large pharma; requires point-to-point or middleware integration with SAP or Oracle ERP.

### Serialization / Track-and-Trace Platforms

**TraceLink**: Cloud-based DSCSA/EU FMD serialization network. Manages serial number generation, aggregation, EPCIS event publishing, and trading partner connectivity. Integrates with SAP S/4HANA and Oracle via standard APIs.

**SAP ATTP (Advanced Track and Trace for Pharmaceuticals)**: SAP's native serialization module; supports EPCIS 1.1 and 2.0, DSCSA, and EU FMD. Embedded within SAP S/4HANA stack; required when serialization volume or complexity exceeds what standard SAP SD supports.

**rfxcel**: Serialization platform with EPCIS repository; used by mid-market pharma.

**GS1 EPCIS Repository**: Event storage and query; typically hosted by TraceLink or a similar network operator, not directly hosted in most ERP deployments.

### Medical Coding & Claims Processing

**Optum/Change Healthcare (UnitedHealth Group)**: Dominant clearinghouse for 837/835 EDI processing, real-time claim scrubbing, and eligibility verification (X12 270/271). Change Healthcare was breached on February 21, 2024, by the ALPHV/BlackCat ransomware group, disrupting 837/835 processing for thousands of healthcare organizations for weeks and impacting an estimated 190 million individuals' data [7]. This event is the primary architectural argument for maintaining backup clearinghouse connectivity and downtime procedures.

**Availity / Waystar**: Multi-payer clearinghouses; strong payer connectivity for eligibility and claims status; recommended as backup routes.

**3M Health Information Systems (3M Solara)**: MS-DRG grouper software; computer-assisted coding (CAC) for ICD-10-CM/PCS and CPT automation.

**Nuance (Microsoft)**: Computer-assisted coding (CAC) and Clinical Documentation Improvement (CDI) integration; natural language processing against clinical notes to suggest codes before claim submission.

### Payment & Patient Financial Services

PaymentSafe, InstaMed (J.P. Morgan), CareCredit: patient payment processing and financing. Experian Health: real-time eligibility verification (X12 270/271) and propensity-to-pay scoring.

### Cold Chain / IoT

**Sensitech (Carrier), Controlant, ELPRO**: Hardware IoT temperature loggers with cloud dashboards and REST API integration. ERP/QMS integration must consume excursion webhooks or polling API results to auto-create deviations. SAP IoT / Azure IoT Hub: middleware for excursion event normalization and routing into ERP CAPA workflows.

### Regulatory Submission

**Veeva Vault RIM (Regulatory Information Management)**: de facto standard for dossier and submission management in pharma; product master in ERP must align with registration data in Vault RIM. **MasterControl**: QMS and document management, widely deployed in pharma and medical devices; integrates with ERP batch records and change control.

---

## 6. KPIs & Metrics

### Revenue Cycle KPIs (Hospitals)

| KPI | Definition | Formula / Benchmark |
|---|---|---|
| Days in Accounts Receivable (DAR) | Average time to collect outstanding charges | AR Balance ÷ (Gross Charges ÷ Days in Period); benchmark <50 days |
| Net Collection Rate (NCR) | % of collectible revenue actually collected | (Payments ÷ (Charges − Contractual Adjustments)) × 100; target >95% |
| Claim Denial Rate | % of claims denied on first submission | (Denied Claims ÷ Total Claims Submitted) × 100; target <5% |
| First-Pass Resolution Rate (FPRR) | Claims paid without resubmission or appeal | (Claims Paid First Pass ÷ Total Claims) × 100; target >90% |
| Cost to Collect | Administrative cost per dollar collected | Total RCM Cost ÷ Net Revenue Collected; benchmark 3–7% |
| Discharged Not Final Billed (DNFB) | Encounters complete but unbilled | Sum of charges on unbilled encounters; target <3 days equivalent |
| Case Mix Index (CMI) | Weighted average MS-DRG weight; proxy for patient acuity | Sum of MS-DRG weights ÷ Total discharges; higher CMI = higher expected reimbursement |
| Bad Debt Rate | Charges written off as uncollectable as % of net revenue | Write-offs ÷ Net Patient Revenue × 100 |

### Clinical Supply Chain KPIs (Pharma / Medtech)

| KPI | Definition | Formula |
|---|---|---|
| Batch Right-First-Time Rate | % of batches released without deviation, OOS, or reprocessing | (Released batches − rejected/reworked) ÷ Total batches × 100 |
| CAPA Cycle Time | Days from deviation detection to CAPA closure | CAPA close date − deviation open date |
| Serialization Compliance Rate | % of serialized units with valid SGTIN + EPCIS events | Valid serialized units ÷ Total units shipped × 100; must be 100% under DSCSA |
| Temperature Excursion Rate | % of cold chain shipments with documented temperature excursion | Excursion events ÷ Total cold chain shipments × 100 |
| Inventory Obsolescence Rate | % of inventory expiring before use | (Expired + disposed lot value) ÷ Total lot value × 100 |
| OOS Investigation Rate | Out-of-specification results as % of total analytical tests | OOS results ÷ Total analytical tests × 100 |
| Recall Effectiveness Rate | % of recalled units recovered from distribution | Units recovered ÷ Units distributed × 100 |
| Lot Release Cycle Time | Days from manufacturing complete to QA release decision | Release date − manufacturing completion date |

### Quality & Compliance KPIs

- **CAPA On-Time Completion Rate**: % of CAPAs closed by committed due date; FDA expects 100% for critical CAPAs
- **Training Compliance Rate**: % of GxP-required training completed on time per employee; target 100% for regulated roles
- **Audit Finding Closure Rate**: % of audit observations closed by agreed date; tracked by critical/major/minor severity
- **Change Control Cycle Time**: Days from change request initiation to effectiveness confirmation
- **Validated System Uptime**: RTO/RPO compliance for GxP-regulated ERP environments; downtime triggers mandatory DTP (Downtime Procedure) activation

---

## 7. Major ERP Vendors for this Vertical

### SAP S/4HANA

Dominant in large pharma, global medtech, and large hospital systems internationally. SAP ECC mainstream maintenance ends December 31, 2027 (for EHP 6–8); extended maintenance available through December 31, 2030 at additional cost. Core modules: **QM** (Quality Management — inspection lots, usage decisions, CoA, QM in procurement/production), **MM** (Materials Management with batch/lot management, FEFO, vendor evaluation), **PP** (Production Planning with process orders and batch genealogy), **EWM** (Extended Warehouse Management for controlled substance storage), **SD** (Sales & Distribution with serialization and DSCSA-mandated ship notice), **FI/CO** (batch actual costing, standard cost accounting for pharma).

**SAP ATTP** (Advanced Track and Trace for Pharmaceuticals): purpose-built serialization module within S/4HANA ecosystem; supports EPCIS 1.1 and 2.0; native DSCSA and EU FMD compliance; required for manufacturers above minimal serialization volume. **SAP EHS** (Environment, Health & Safety): MSDS management, incident reporting, industrial hygiene.

**Validation overhead**: Implementing SAP S/4HANA in a GxP environment requires full IQ/OQ/PQ (Installation/Operational/Performance Qualification) documentation; timelines 18–36 months for large pharma; every subsequent upgrade is a re-validation event. The shift to CSA (FDA September 2022 guidance) reduces testing documentation burden but not the underlying validation obligation.

### Oracle Fusion Cloud ERP

Strong in large hospital systems (Oracle Fusion Financials for hospital finance) and pharma (Oracle SCM Cloud for supply chain). **Oracle Health Cloud ERP** represents the integrated product strategy between Oracle Fusion and Oracle Health (Cerner) on OCI, but the two remain architecturally distinct product lines as of June 2026. **Oracle Agile PLM for Medical Devices**: DHF management, change control, UDI assignment, complaint handling—the PLM layer that feeds DHR data into Oracle ERP manufacturing modules.

### Infor (CloudSuite Healthcare, CloudSuite Pharma)

**Infor CloudSuite Healthcare**: purpose-built for IDNs and hospitals; supply chain (OR supply, PAR management, implant tracking), finance, and HR. Known for clinical supply chain strength vs. generic ERP. **Infor CloudSuite Pharma** (built on Infor M3 and LN): batch management, serialization, CoA generation, pharma-specific MES interfaces. **Infor GT Nexus**: multi-party supply chain visibility network integrated with CloudSuite for API and import/export visibility.

### Microsoft Dynamics 365 Finance & Supply Chain Management

Growing adoption in mid-market medtech and specialty pharma. Lot/batch control, WMS, and serialization via ISV add-ons (Arbour Group, Atum for 21 CFR Part 11 compliance on D365). Native Azure IoT Hub integration for cold chain excursion feeds into D365 supply chain. Strength: Microsoft 365 / Teams / Azure native integration reduces tooling sprawl for smaller organizations.

### Veeva Vault (Ecosystem—Not a Full ERP)

Veeva Vault is not a financial or manufacturing ERP, but it is a mandatory integration partner for pharma and biotech. **Vault QMS**: deviation, CAPA, change control, training. **Vault RIM**: regulatory submissions, product registration. **Vault CTMS**: site, subject, visit management. **Vault RTSM**: randomization, IP dispensing (Veracity Logic capabilities integrated, early 2022 acquisition). **Vault eTMF**: trial master file. Financial ERP (SAP/Oracle) must integrate with Veeva for the complete picture; Veeva does not handle financials, batch manufacturing, or serialization.

### Epic (EpicCare + Resolute + EpicOps)

Epic is not an ERP, but **Resolute** (hospital billing and professional billing) provides deep patient accounting, claims generation, and payer contract management that overlaps with traditional ERP revenue cycle scope. **EpicOps** is Epic's emerging materials management and operational layer. Most large IDNs run Epic for clinical and revenue cycle workflows and interface to SAP/Oracle/Workday for enterprise financials, HR analytics, and group purchasing. The boundary between Epic and ERP is a primary architectural decision for hospital implementation teams.

### Oracle Health (Cerner Millennium)

Millennium platform for clinical and RevCycle functions; approximately 21.9% acute care U.S. EHR market share as of 2025, down from 23% in 2024 (KLAS Research) [6]. Finance teams at Oracle Health-using hospitals frequently run Oracle Fusion ERP or Workday for enterprise finance, requiring a separate integration layer between Oracle Health RevCycle and the enterprise ERP.

### Niche / Mid-Market

- **Epicor Kinetic**: used by some ISO 13485-regulated medical device manufacturers; ISV packs for device manufacturing
- **Acumatica**: small medtech; ISV validation packs available; lacks native GxP features
- **NetSuite**: biotech startups and small pharma; requires ISV extensions (Unifii, third-party Part 11 modules) for GxP functions; native NetSuite lacks eBR, validated audit trail, and serialization depth

---

## 8. Implementation Cautions

### Validation Scope Underestimation

Every configuration change in a GxP-regulated ERP—whether a workflow parameter, a new user role, or a report modification—triggers change control and potentially re-validation under 21 CFR Part 11 and GAMP 5 2nd Edition (July 2022). FDA's CSA guidance (September 2022) is frequently misread as eliminating validation requirements; it does not. CSA shifts emphasis from generating test scripts and paper records toward documented risk assessment and critical thinking about what requires testing. The validation obligation remains; the documentation approach changes.

ERP upgrade cycles in pharma routinely take 12–24 months due to re-validation scope. Upgrade strategy must account for this: avoid big-bang upgrades; use a staged upgrade approach with parallel validated environments; map every custom configuration and ISV extension to a re-validation test scope before upgrade project start.

### 21 CFR Part 11 Electronic Signature Pitfalls

Non-biometric electronic signatures require two distinct components: a unique user ID and a password/PIN, applied consecutively for multi-signing workflows (21 CFR § 11.200(a)). Shared logins are a primary 483 observation trigger; ERP must enforce unique user IDs and prohibit session sharing at the module level. The e-signature record must include: printed name, date/time (UTC from a validated NTP-synchronized source), meaning (e.g., "Reviewed and approved"), and the unique ID used. Each signature must be cryptographically bound to the record at the moment of signing; a signature that can be detached and reattached to a different record fails Part 11.

### PHI in ERP (HIPAA)

Any ERP module storing or processing PHI (patient billing data, guarantor records, claims data, remittance data with patient identifiers) is subject to HIPAA Security Rule (45 CFR Part 164, Subpart C). SaaS ERP vendors must execute a Business Associate Agreement (BAA) before receiving PHI. Cloud ERP must meet technical safeguards: AES-256 encryption at rest, TLS 1.2+ in transit, audit logging, role-based access controls, and automatic session logoff. The proposed HIPAA Security NPRM (January 6, 2025) [3] would strengthen these requirements if finalized; design new systems to exceed current minimums to avoid rework.

### DSCSA Serialization Integration Complexity

ERP must generate GTINs at product setup, assign serial numbers at commissioning, aggregate to SSCC at case packing, and log EPCIS events at each transfer of ownership. Errors in SGTIN format, EPCIS event timing, or SSCC aggregation break the legal chain of custody under DSCSA. Most ERP systems cannot natively generate EPCIS 2.0 events; SAP ATTP or TraceLink middleware is required. The DSCSA small dispenser exemption (November 27, 2026 deadline) applies only to dispensers with 25 or fewer pharmacist/technician FTEs [1]—it does not relieve manufacturers and wholesale distributors of their obligations.

### Medical Device QMSR Transition (February 2, 2026)

FDA's QMSR final rule (published February 2, 2024; effective February 2, 2026) replaces the legacy Quality System Regulation (QSR) structure with a framework that incorporates ISO 13485:2016 by reference [2]. ERP device manufacturing configurations built against legacy QSR section citations (e.g., § 820.100 for CAPA, § 820.198 for complaint handling) must be reviewed and updated to QMSR / ISO 13485 section mappings. Firms that already held ISO 13485 certification face reduced but not zero gap work; FDA has added QMSR-specific requirements (MDR, GUDID) that ISO 13485 does not address.

### EHR-ERP Integration Data Contract

**Charge lag**: EHR charges may flow to ERP billing hours or days after the clinical service; daily claim run cutoffs must account for charge lag. Missing charges result in unbilled encounters (DNFB).

**ADT message idempotency**: HL7 ADT messages are frequently retransmitted. ERP ADT ingestion must be idempotent: receiving the same A01 twice must not create two encounters. Use the visit number (PV1-19) as the natural key for idempotency control.

**FHIR version incompatibility**: Epic FHIR APIs are primarily R4; Oracle Health supports R4 and R5; design ERP FHIR adapters to be version-agnostic where possible. FHIR R6 is in active ballot (ballot 4, May 2026) with final publication expected 2026–2027 [5]; avoid hard-coding R4 namespace URIs in integration layer.

**Duplicate patient risk**: Master Patient Index (MPI) matching is complex; ERP must handle overlay and duplicate patient merges (ADT A40) without corrupting charge and claim history.

### Cold Chain and CAPA Integration

Temperature excursion events from IoT sensors must automatically create deviation records in ERP QM linked to the affected lot. Manual handoff—a technician reading a sensor dashboard and manually entering a deviation—introduces lag and is an audit failure mode. The integration contract: sensor platform webhooks → ERP API → create Deviation record with lot FK, excursion parameters (min/max temp, duration), and status = open. The ERP then routes for review and disposition with required e-signature.

### Recall Management

ERP recall capability is a regulatory obligation, not a reporting add-on. When a recall is initiated, ERP must: (1) set all inventory of the affected lot/sub-lots to quarantined status across all warehouse locations and consignment stock; (2) generate a complete distribution list from EPCIS event history; (3) produce customer notification letters; (4) track returned units against distributed quantity for effectiveness calculation. Integration with DSCSA track-and-trace data is essential for distribution list completeness. FDA expects root-cause submission within 30 days.

### Hospital Go-Live Timing

Hospital ERP revenue cycle go-lives should avoid: December 31 fiscal year-end (Medicare cost report submission deadline for many U.S. hospitals), payer contract renewal effective dates (January 1 and July 1 are common), and open enrollment periods. ICD-10 annual code updates (October 1) require CDM maintenance windows in advance of go-live; launching after September without pre-loading new ICD-10-CM/PCS codes causes claim rejections.

### Change Healthcare Clearinghouse Concentration Risk

The February 21, 2024 cyberattack on Change Healthcare (ALPHV/BlackCat ransomware, disclosed by UnitedHealth Group) disrupted 837/835 processing for thousands of healthcare organizations for weeks and compromised data on an estimated 190 million individuals [7]. ERP revenue cycle architecture must maintain backup clearinghouse connectivity (Availity, Waystar) and documented downtime procedures for manual claim submission when primary clearinghouse is unavailable. Single-clearinghouse dependency is an unacceptable architectural risk.

---

## 9. Security & Compliance Depth

(Cross-reference: `core/security.md` for SoD, role-based access, audit logging fundamentals)

### ePHI-Specific Security Controls

**Encryption**: AES-256 at rest; TLS 1.2 minimum (TLS 1.3 preferred) in transit for all ePHI. Key management under a HIPAA-compliant HSM; key rotation schedule documented in the System Security Plan.

**Minimum Necessary standard** (45 CFR § 164.502(b)): RCM module roles must be scoped so billing staff see only the patient fields necessary for billing (name, DOB, address, payer, charges)—not clinical notes, diagnoses beyond ICD-10 billing codes, or treatment detail. Implement field-level security at the ERP module level, not just screen-level.

**Automatic logoff**: HIPAA requires configurable session timeout for any workstation or application accessing ePHI (45 CFR § 164.312(a)(2)(iii)). Typical configuration: 15-minute inactivity timeout with re-authentication.

**Audit logging**: Every access to a PHI record must be logged: user ID, timestamp, record accessed, action (read/write/delete). Logs must be retained for 6 years per HIPAA (45 CFR § 164.530(j)). Audit logs must be stored separately from application data, with write-only access for the application and read access restricted to security/compliance roles.

**Proposed HIPAA Security Rule NPRM (not yet finalized as of June 2026)**: The January 6, 2025 Federal Register proposed rule (Docket HHS-OCR-2023-0015) [3] would require: mandatory MFA for all ePHI system access, network segmentation between clinical and administrative systems, encryption of all ePHI (removing "addressable" status for encryption), and vulnerability scanning on a defined schedule. Design new systems to these stricter standards in anticipation of finalization, even before the final rule is published.

### 21 CFR Part 11 Audit Trail Requirements

The audit trail must be tamper-evident (cryptographically protected or stored in a system inaccessible to production users), capturing: user ID, timestamp in UTC from a validated NTP-synchronized source, field changed, value before change, value after change, and reason for change where required by SOP. The trail must be retained for as long as the underlying record is required—for pharma records under 21 CFR Part 211, this is at least 1 year beyond the product expiry date of the last lot produced from that record. Audit trail records cannot be deleted or altered by production users; archiving requires system-level access with its own audit trail.

Computer-generated timestamps must use a validated, synchronized time source. If NTP synchronization is lost, the system must either reject the timestamp or flag it as potentially invalid. Time zone ambiguity in audit trails is a recurring FDA 483 observation: store all timestamps in UTC, display in local time with explicit offset.

### Segregation of Duties (SoD) in Regulated Environments

In pharma ERP: the operator who creates a batch record cannot be the same person who approves lot release (reviewer independence requirement under 21 CFR § 211.192). ERP role matrices must enforce this separation, and the role matrix itself must be a controlled document in the QMS validated under GAMP 5.

In revenue cycle ERP: the person who enters or modifies charges cannot post payments; the person who processes refunds cannot approve write-offs. SoD in hospital finance prevents fraudulent payment schemes (fictitious vendors, unauthorized adjustments). SoD violation reports should run nightly and route to compliance.

SoD violations in GxP environments constitute FDA 483 observations and, if systemic, can escalate to Warning Letters.

### Data Integrity: ALCOA+

FDA and EMA expect all GxP-regulated ERP data to satisfy the ALCOA+ framework:

| Attribute | Meaning | ERP Enforcement |
|---|---|---|
| Attributable | Each data entry linked to specific person | Unique user login; no shared accounts |
| Legible | Records permanently readable | No overwriting; retain original; display history |
| Contemporaneous | Recorded at time of activity | System timestamp at entry; no backdating |
| Original | First capture; not transcribed | Direct system entry from instrument or operator |
| Accurate | Correct; true; complete | Validation rules; range checks; unit verification |
| Complete | No missing data; full record | Mandatory field enforcement; step completion gates |
| Consistent | Consistent dates/times across records | NTP synchronization; single time zone (UTC storage) |
| Enduring | Permanent; not erasable | Immutable audit trail; no delete permissions for production |
| Available | Accessible during inspection | Disaster recovery; 99.9%+ uptime SLA for regulated modules |

Cloud ERP vendors operating in GxP context must provide: Data Processing Agreements (DPAs), immutable backup architecture, and documented disaster recovery procedures that are themselves validated.

### Cybersecurity for Medical Devices (FDA Section 524B)

FDA's September 2023 final guidance (Cybersecurity in Medical Devices: Quality System Considerations and Premarket Submission Content) requires that 510(k) and PMA submissions include: a cybersecurity risk assessment, a Software Bill of Materials (SBOM), and a documented plan for post-market security patching [8]. ERP systems that manage medical device manufacturing records—DHR, DHF, complaint records, CAPA linked to field safety corrective actions—must maintain logs of security patch application dates and patch validation outcomes. The SBOM for the ERP software stack may need to be provided to the device manufacturer's regulatory team for inclusion in submissions.

On January 14, 2026, FDA and EMA jointly released Guiding Principles of Good AI Practice in Drug Development [9], signaling regulatory expectations for AI/ML tools used in GxP-regulated systems. ERP implementations incorporating AI-assisted deviation detection, AI-assisted coding (CAC), or AI-assisted demand forecasting in GxP contexts should anticipate regulatory scrutiny; the principles emphasize human oversight, documented validation of AI outputs, and lifecycle risk management.

### Business Continuity in Clinical Settings

Hospital revenue cycle ERP downtime directly impacts: billing (charges cannot be generated), supply ordering (OR supplies cannot be requested via ERP), and in some configurations, medication dispensing cabinet interfaces. Tier-1 RCM systems must target RTO (Recovery Time Objective) under 4 hours; RPO (Recovery Point Objective) under 15 minutes for transaction data. Cross-reference: `core/architecture.md` for HA/DR patterns.

GxP-regulated ERP systems require documented Downtime Procedures (DTPs): pre-approved manual procedures for batch record entry, deviation reporting, and lot release that take effect when the system is unavailable. DTPs themselves must be validated and trained to; paper forms used during downtime must be entered into the ERP retrospectively with a clear audit trail indicating the original paper record.

---

## See also

- `core/security.md` — SoD role matrix design, audit logging architecture, access control fundamentals
- `verticals/manufacturing.md` — batch process manufacturing, MES integration, production planning
- `verticals/distribution-logistics.md` — cold chain logistics, 3PL integration, serialization in distribution
- `verticals/aerospace-defense.md` — regulated manufacturing parallels: configuration management, traceability, government audit requirements
- `core/localization-tax.md` — multi-country ERP configuration for EU/US regulatory dual compliance

---

## Citations & Sources

1. FDA, "DSCSA Compliance Policies – Establish a 1-Year Stabilization Period for Implementing Electronic, Interoperable Systems" and June 12, 2024 exemption announcement for small dispensers (≤25 pharmacist/technician FTEs), exemption valid November 27, 2024–November 27, 2026: https://www.fda.gov/drugs/drug-safety-and-availability/dscsa-compliance-policies-establish-1-year-stabilization-period-implementing-electronic-systems

2. FDA, "Quality Management System Regulation (QMSR)" — final rule amending 21 CFR Part 820, published February 2, 2024, effective February 2, 2026, incorporating ISO 13485:2016 by reference: https://www.fda.gov/medical-devices/postmarket-requirements-devices/quality-management-system-regulation-qmsr

3. HHS Office for Civil Rights, "HIPAA Security Rule to Strengthen the Cybersecurity of Electronic Protected Health Information" (NPRM), Federal Register January 6, 2025, Docket HHS-OCR-2023-0015; not finalized as of June 2026: https://www.federalregister.gov/documents/2025/01/06/2024-30983/hipaa-security-rule-to-strengthen-the-cybersecurity-of-electronic-protected-health-information

4. ICH, "E6(R3) Guideline for Good Clinical Practice — Step 5 Final Version," January 6, 2025 (draft endorsed May 2023; final version adopted December 2024 / published January 2025): https://www.ich.org/page/efficacy-guidelines

5. HL7 International, FHIR R6 development status — ballot 4 (v6.0.0-ballot4) published May 2026; next normative ballot planned July 2026; final publication expected 2026–2027: https://build.fhir.org/versions.html

6. KLAS Research, "Acute Care EMR Market Share" reports (2024–2025 data): Epic 43.7% hospital count / 56.9% beds; Oracle Health 21.9% (declining from 23% in 2024). https://klasresearch.com (subscription required; also reported by Healthcare Dive and Fierce Healthcare)

7. UnitedHealth Group, SEC Form 8-K filed February 21, 2024 (initial disclosure of Change Healthcare cyberattack by ALPHV/BlackCat); subsequent disclosures confirmed approximately 190 million individuals affected: https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0000731766&type=8-K

8. FDA, "Cybersecurity in Medical Devices: Quality System Considerations and Premarket Submission Content" — final guidance, September 2023: https://www.fda.gov/regulatory-information/search-fda-guidance-documents/cybersecurity-medical-devices-quality-system-considerations-and-premarket-submission-content

9. FDA and EMA, "Guiding Principles of Good AI Practice in Drug Development," jointly released January 14, 2026: https://www.ema.europa.eu/en/news/ema-fda-set-common-principles-ai-medicine-development-0

10. FDA, "21 CFR Part 11 — Electronic Records; Electronic Signatures": https://www.ecfr.gov/current/title-21/chapter-I/subchapter-A/part-11

11. FDA, "Computer Software Assurance for Production and Quality System Software" — final guidance, September 2022: https://www.fda.gov/regulatory-information/search-fda-guidance-documents/computer-software-assurance-production-and-quality-system-software

12. HHS, HIPAA Security Rule (45 CFR Part 164, Subpart C) and Breach Notification Rule (45 CFR §§ 164.400–414): https://www.hhs.gov/hipaa/for-professionals/security/index.html

13. HL7 International, FHIR R4 Normative specification (December 2018): https://hl7.org/fhir/R4/

14. GS1, EPCIS 2.0 standard (ratified June 2022; ISO/IEC 19987:2024): https://www.gs1.org/standards/epcis

15. ISPE, "GAMP 5: A Risk-Based Approach to Compliant GxP Computerized Systems," 2nd Edition, July 2022: https://ispe.org/publications/guidance-documents/gamp-5-guide-2nd-edition

16. ICH Q9(R1) Quality Risk Management (2023 revision): https://www.ich.org/page/quality-guidelines

17. ICH Q10 Pharmaceutical Quality System guideline: https://www.ich.org/page/quality-guidelines

18. EudraLex Vol. 4, Annex 11 (Computerised Systems, 2011 revision) and Annex 13 (Investigational Medicinal Products): https://health.ec.europa.eu/medicinal-products/eudralex/eudralex-volume-4_en

19. FDA, 21 CFR Part 830 (UDI System): https://www.ecfr.gov/current/title-21/chapter-I/subchapter-H/part-830

20. CMS, ICD-10-CM/PCS annual code updates: https://www.cms.gov/medicare/coding-billing/icd-10-codes

21. ASC X12, EDI transaction sets (837P, 837I, 837D, 835, 270, 271, 999, 277CA): https://x12.org/products/transaction-sets

22. GS1, UDI for Medical Devices (GTIN/SSCC assignment guidance): https://www.gs1.org/industries/healthcare/udi
