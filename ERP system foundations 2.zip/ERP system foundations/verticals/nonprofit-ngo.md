# ERP for Nonprofits & NGOs

## 1. Overview

Nonprofits, NGOs, foundations, charities, and religious organizations share a defining structural characteristic that invalidates most commercial ERP defaults: accountability runs to donors, grantors, boards, and beneficiaries — not shareholders — and every dollar carries a legal or moral obligation about how it may be spent. This single fact cascades into a distinct accounting model, a distinct regulatory stack, and a distinct set of ERP modules that commercial-sector systems do not support without substantial vertical configuration or purpose-built alternatives.

**What makes this vertical architecturally different:**

- **Fund accounting replaces profit-center accounting.** Every dollar is tracked by source restriction and purpose. A fund is a self-balancing set of accounts; the organization may operate dozens or hundreds of concurrently active funds that must each independently balance. A general ledger without fund-level balance sheets is structurally inadequate.
- **Two-dimensional financial reporting is mandatory.** The Statement of Functional Expenses (required under FASB ASC 958-720-45 for voluntary health and welfare organizations, and required disclosure for all nonprofits under FASB ASU 2016-14 [1]) presents expenses simultaneously by natural classification (salaries, rent, supplies) and by functional category (Program Services, Management & General, Fundraising). Commercial P&L reporting along a single cost-center dimension does not satisfy this requirement.
- **Revenue recognition is fundamentally different.** Under FASB ASU 2018-08 [2], contributions (non-exchange transactions) and exchange transactions follow different recognition models. Conditional grants — including virtually all cost-reimbursement government awards — are recognized as revenue only as qualifying costs are incurred, not when the grant is signed. ERP revenue recognition engines built for ASC 606 exchange transactions must be reconfigured or supplemented.
- **Multiple concurrent restricted funding streams** — each with distinct allowable-cost rules, budget line constraints, reporting deadlines, and indirect cost rate terms — must be tracked in parallel. A single federal grant may have 30+ budget lines, each with allowable/unallowable designations under 2 CFR Part 200 [3].
- **IRS tax-exempt status** creates compliance obligations (Form 990 and its Schedules A, B, D, F, I, L, R; Form 990-T for UBIT) that commercial ERPs do not support natively. Chart of accounts and cost allocation must be designed with Form 990 Part IX functional expense matrix in mind from day one.
- **International NGOs** face layered multi-donor compliance: USAID 2 CFR Part 700 / ADS 303, EU/ECHO FAFA terms, FCDO Programme Operating Framework (PrOF), UN agency financial regulations — each with different budget flexibility rules, procurement thresholds, and audit requirements.
- **The "overhead" ratio is politically salient.** Charity Navigator, GuideStar/Candid, and watchdog groups scrutinize the program expense ratio. ERP cost allocation configuration directly determines reported ratios; misconfigured allocation methods produce defensible-looking but inaccurate functional splits that create reputational and audit risk.
- **Chart of accounts requires at minimum four dimensions:** Fund, Program/Project, Natural Expense Classification, Functional Category. Adding Grant/Contract and Department brings the minimum to six dimensions. Collapsing these into a monolithic account number is the most common implementation failure in this vertical.
- **In-kind resources and volunteers** are pervasive but have strict recognition rules under ASC 958-605. General volunteer hours are not recognized in financial statements; only services requiring specialized skills the organization would otherwise purchase meet the recognition threshold. ERP must support both recognized and non-recognized tracking.

## 2. Industry-Specific Modules

### 2.1 Fund Accounting Engine

The fund accounting engine is the definitional core of a nonprofit ERP. Standard GL modules treat the organization as a single balancing entity; fund accounting enforces independent balance-sheet integrity for each fund simultaneously.

- **Net asset class segregation** per FASB ASU 2016-14 (effective for fiscal years beginning after December 15, 2017 [1]): two classes — "with donor restrictions" and "without donor restrictions" — replacing the prior three-class model of unrestricted, temporarily restricted, and permanently restricted. ERP chart of accounts and financial statement templates must reflect the current two-class model; organizations that have not yet completed this migration are reporting on a superseded framework.
- **Sub-fund tracking within net asset classes:** board-designated funds, endowment principal, term endowments, quasi-endowments, program-restricted operating funds. Each sub-type carries different governance rules and reporting requirements.
- **Endowment management:** Underwater endowments (market value < historic gift value) must be classified **entirely** within "with donor restrictions" — ASU 2016-14 eliminated the prior treatment that split underwater endowment balances between classes. The `is_underwater` flag on the Fund entity triggers this reclassification automatically.
- **Encumbrance accounting:** Purchase orders and commitments reduce available fund balances before cash disbursement. This is essential for grant budget control; without encumbrance, a fund can appear to have budget available while committed expenditures already exceed authorized limits.
- **Restricted fund release:** Automatic journal entries on satisfaction of purpose or time restrictions. Reclassifies net assets from "with donor restrictions" to "without donor restrictions." Must enforce approval workflow (see §9.1 for SoD requirements) before posting.
- **Interfund loans and transfers** with full audit trail, with distinction between permanent transfers (equity reclassification) and temporary interfund loans (liability/receivable pair).
- **Multi-fund trial balance and fund-level balance sheets:** each fund produces its own balance sheet independently.

### 2.2 Grant Lifecycle Management

Grant management covers the full lifecycle from opportunity identification through closeout and fund return, and must integrate tightly with the fund accounting engine and AP module.

- **Pre-award pipeline:** RFP tracking, proposal status, probability-weighted revenue pipeline for cash flow forecasting.
- **Budget setup on award:** cost category budget lines tied to grant; each line tagged with allowable/unallowable flag per the applicable compliance framework (2 CFR Part 200 for federal [3], ECHO FAFA for EU, FCDO PrOF for UK awards). Allowable cost rules differ materially by grantor.
- **Cost reimbursement vs. fixed-price modes:** cost-reimbursement grants recognize revenue as costs are incurred (ASU 2018-08 barrier = qualifying cost incurrence [2]); fixed-price grants recognize revenue on performance milestone completion.
- **Indirect cost rate management:**
  - NICRA (Negotiated Indirect Cost Rate Agreement): rate negotiated with cognizant federal agency (typically DHHS Division of Cost Allocation or DOD DCAA). Once an organization negotiates a NICRA, it **cannot revert** to the de minimis rate.
  - De minimis rate: 15% of MTDC per the 2024 revision to 2 CFR Part 200 [3] (raised from 10%); available only to organizations that have never had a negotiated rate.
- **MTDC (Modified Total Direct Costs) calculation engine:** excludes equipment items costing $10,000 or more (2024 threshold [3], raised from $5,000 for awards predating October 1, 2024), the portion of subawards exceeding the first $50,000 per subaward (raised from $25,000 in 2024 revision [3]), patient care costs, and other designated exclusions. Miscalculating the MTDC base is the primary cause of indirect cost overrecovery audit findings.
- **Budget-to-actual variance tracking** with configurable overspend alerts by budget line. Alert thresholds (e.g., 90% budget consumed) trigger workflow notifications to grant manager and finance.
- **Grant invoicing/drawdown:** milestone billing for fixed-price; cost-reimbursement billing with supporting cost detail. Federal grantees typically draw down via ASAP (Automated Standard Application for Payments) or HHS Payment Management System (PMS); ERP must reconcile drawdown transactions.
- **Carryforward management:** tracks unspent balances at period end, grantor approval status, and adjusted budget after carryforward authorization.
- **Closeout workflow:** final financial report generation, SEFA (Schedule of Expenditures of Federal Awards) update, fund return calculation for unspent cost-reimbursement balances.

### 2.3 Donor Management & CRM Integration

While CRM functionality typically resides in a dedicated fundraising platform (see §5.1), the ERP must maintain the financial side of donor relationships: gift records linked to funds, pledge schedules, and IRS compliance documentation.

- **Constituent/donor master:** individual, corporate, foundation, government — with tax ID, relationship manager, and contact preferences. Shared master with CRM via bidirectional sync.
- **Gift entry types:** cash, check, ACH, credit card, wire, planned giving/bequest pledge, stock gifts, real estate.
- **Pledge management:** pledge schedules, automatic payment reminders, write-off workflows for uncollectible pledges.
- **Soft credit and hard credit tracking:** spousal/household gift credit, donor-advised fund source tracking.
- **Donor-restricted gift routing:** gift designation code maps directly to a Fund record; ERP enforces that funds are spent consistent with donor restriction language.
- **Acknowledgment generation:** IRS §170(f)(8) requires a written acknowledgment for gifts exceeding $250; acknowledgment must state whether any goods or services were provided in exchange (quid pro quo). ERP must track acknowledgment generation date and content for audit purposes.
- **Tribute/memorial gift tracking** for stewardship reports to honoree families.

### 2.4 Program & Functional Expense Accounting

- **Statement of Functional Expenses:** mandatory under FASB ASC 958-720-45 for voluntary health and welfare organizations; required disclosure for all nonprofits under ASU 2016-14 [1]. The statement is a matrix: rows are natural expense classes (salaries and wages, employee benefits, occupancy, travel, depreciation, etc.), columns are functional categories (Program Services — often broken into individual programs — Management & General, Fundraising).
- **Functional categories (three required):**
  - Program Services: activities that fulfill the organization's exempt purpose.
  - Management & General (M&G): administrative functions not identifiable with a specific program or fundraising activity.
  - Fundraising: costs of soliciting contributions.
- **Allocation engine:** shared costs (occupancy, IT, certain salaries) must be allocated across functional categories using a documented, consistently applied method. Acceptable methods include time studies (for personnel), square footage (for occupancy), headcount or FTE ratios, and revenue ratios. The method selected must be defensible to auditors and documented with support (e.g., time study logs, space utilization records).
- **Multi-program tracking:** each Program has its own budget, outcome metrics, and expense tracking separate from other programs, enabling program-level sustainability analysis for board reporting.

### 2.5 In-Kind / Gift-in-Kind Management

- **Contributed nonfinancial assets** are recognized per FASB ASC 958-605 and FASB ASU 2020-07 [4] (effective for annual periods beginning after June 15, 2021, with retrospective application).
- **Fair value measurement at donation date** per FASB ASC 820; for unusual assets (donated real estate, art, collections), independent appraisal is required.
- **Contributed services recognition criteria** (ASC 958-605-55): services must (a) require specialized skills AND (b) be provided by an individual possessing those skills AND (c) create or enhance nonfinancial assets OR would otherwise be purchased by the organization. General volunteer hours sorting food boxes do not qualify; pro bono legal counsel or donated architectural services typically do.
- **Offsetting expense recording:** recognized in-kind gifts are recorded as both revenue (contribution) and expense (in the appropriate natural and functional category simultaneously).
- **Goods/food/inventory in-kind:** quantity received, fair value at receipt date, disbursement to beneficiaries tracked separately for donor stewardship and audit trail.
- **ASU 2020-07 disclosures [4]:** must disaggregate contributed nonfinancial assets by category (presented on a separate line on the statement of activities), disclose whether assets were monetized or used in programs, disclose donor restrictions, and describe the organization's policy for monetizing versus using in-kind gifts.

### 2.6 Volunteer Management

- Volunteer hour logging by program and activity, supporting grant narrative reporting and Form 990 disclosures.
- Skills inventory and background check status tracking (required for volunteers in direct contact with vulnerable populations).
- **Non-recognition rule for financial reporting:** general volunteer hours are tracked operationally but not recorded in the financial statements. Only contributed services meeting the specialized-skills criteria (§2.5) generate GL entries. ERP must prevent non-qualifying hours from being journalized while still retaining them for operational reporting.
- Volunteer hour valuation for disclosure purposes: Independent Sector publishes an annual rate — $33.49/hour for 2024, $34.79/hour for 2025, and $36.14/hour for the 2026 release [5]. Confirm the applicable year's rate at independentsector.org before citing; the rate is updated annually based on Bureau of Labor Statistics data.

### 2.7 Revenue Recognition for Nonprofits

- **Conditional vs. unconditional contributions** per FASB ASU 2018-08 [2]: a contribution is conditional if it contains both (1) a barrier that must be overcome and (2) a right of return of assets transferred or right of release from obligation. Government cost-reimbursement grants almost universally meet both criteria; the barrier is incurring qualifying costs.
- **Revenue recognition timing for conditional grants:** recognize as revenue only as the barrier is overcome (i.e., as qualifying expenditures are incurred). Recording full grant award as revenue on execution of grant agreement is a material error common in organizations misconfiguring their ERP.
- **Exchange vs. non-exchange classification:** if a grantor or donor receives direct, commensurate value in return for the transfer, the transaction is an exchange (follow ASC 606); if the resource provider receives no direct value, it is a contribution (follow ASC 958-605). Government contracts for services (e.g., Medicaid reimbursements, per-capita service contracts) are typically exchange transactions.
- **ASU 2018-08 effective dates [2]:** for resource recipients that are public business entities or conduit bond obligors for traded securities — annual periods beginning after June 15, 2018, including interim periods; for all other nonprofit resource recipients — annual periods beginning after December 15, 2018, and interim periods within annual periods beginning after December 15, 2019. Organizations that have not yet adopted ASU 2018-08 are operating on superseded guidance.

## 3. Regulatory & Compliance Requirements

### 3.1 US GAAP / FASB Standards

| Standard | Description | ERP Impact |
|---|---|---|
| FASB ASC 958 | Not-for-Profit Entities — primary US GAAP framework | Entire accounting model; COA design, fund tracking, financial statements |
| FASB ASU 2016-14 (Aug 2016) | Presentation of Financial Statements of Not-for-Profit Entities; effective FY beginning after Dec 15, 2017 [1] | Two net asset classes, liquidity disclosure, functional expense disclosure, investment return presentation |
| FASB ASU 2018-08 (Jun 2018) | Clarifying Scope and Accounting Guidance for Contributions Received and Contributions Made [2] | Conditional grant recognition; cost-reimbursement timing |
| FASB ASU 2020-07 (Sep 2020) | Presentation and Disclosures by Not-for-Profit Entities for Contributed Nonfinancial Assets [4] | Enhanced in-kind gift disclosures; effective annual periods beginning after Jun 15, 2021 |
| FASB ASC 958-205 | Not-for-Profit Presentation — going concern disclosures | Liquidity and going concern note generation |
| FASB ASC 958-320 | Investments in Debt Securities for not-for-profits | Endowment investment classification and reporting |
| FASB ASC 958-605 | Revenue Recognition — contributions and grants | Non-exchange transaction revenue; conditional grant barriers |
| FASB ASC 958-720 | Other Expenses — functional expense allocation | Statement of Functional Expenses; allocation methodology |
| FASB ASC 820 | Fair Value Measurement | In-kind gift valuation; endowment investment marking |

### 3.2 IRS Compliance (US)

| Form / Rule | Threshold / Trigger | ERP Data Requirements |
|---|---|---|
| Form 990 | Annual filing; gross receipts ≥ $200,000 OR total assets ≥ $500,000; due 15th day of 5th month after FY end | Full functional expense matrix (Part IX), Schedule of Revenue (Part VIII), key employee compensation |
| Form 990-EZ | Gross receipts < $200,000 AND total assets < $500,000 | Simplified but still requires functional expense data |
| Form 990-N (e-Postcard) | Gross receipts ≤ $50,000 | Basic identifying information only |
| Schedule A | Public support test — 509(a)(1) or 509(a)(2) status | Five-year public support history by source category |
| Schedule B | Contributors giving > $5,000 or > 2% of contributions | Donor gift amounts with names (not publicly disclosed; ERP must support redacted public copy) |
| Schedule D | Supplemental financial statements — endowments, investments, escrow | Endowment rollforward, investment schedule |
| Schedule F (Rev. Dec 2024) | Foreign expenditures > $10,000 aggregate OR foreign investments ≥ $100,000 [6] | Expenditures by region and activity type outside US |
| Schedule I | Grants and assistance to domestic individuals/organizations | Grantee list with amounts and purposes |
| Schedule L | Transactions with interested persons | Conflict-of-interest transaction flagging |
| Schedule R | Related organizations and unrelated partnerships | Intercompany transaction data |
| Form 990-T | Unrelated Business Income (UBI) | Identification and segregation of UBI-generating activities |
| IRC §501(c)(3) | Annual compliance testing for tax-exempt status | Private benefit, private inurement, lobbying limits |
| IRC §170(f)(8) | Written acknowledgment for gifts > $250 | Acknowledgment letter generation with quid pro quo disclosure |

### 3.3 US Federal Grant Compliance

**2 CFR Part 200 (Uniform Guidance)** — Uniform Administrative Requirements, Cost Principles, and Audit Requirements for Federal Awards. Originally effective December 26, 2014 (superseding OMB Circular A-133 and other OMB circulars); substantially revised in 2024 [3], effective government-wide October 1, 2024.

**2024 Revision Key Changes (effective Oct 1, 2024) [3]:**

| Parameter | Pre-2024 Value | Post-2024 Value (effective Oct 1, 2024) |
|---|---|---|
| Single Audit expenditure threshold | $750,000 | $1,000,000 |
| De minimis indirect cost rate | 10% of MTDC | 15% of MTDC |
| Equipment capitalization threshold | $5,000 | $10,000 |
| Subaward MTDC exclusion (per subaward) | First $25,000 | First $50,000 |

Additional compliance points:
- **USAID ADS 303:** Assistance Instruments — governs USAID grants and cooperative agreements to NGOs. USAID also implements **2 CFR Part 700** (USAID-specific additions to Uniform Guidance). USAID issued an Acquisition & Assistance Policy Directive on August 7, 2024, implementing the 2024 Uniform Guidance revisions for U.S. NGOs [7].
- **SEFA:** Schedule of Expenditures of Federal Awards must include ALL federal award expenditures, including pass-through awards, tagged by Assistance Listings number (formerly CFDA number) and Federal Award Identification Number (FAIN). Omissions cause Single Audit findings.
- **2 CFR 200.334:** Federal award records must be retained for 3 years from submission of the final financial report. Retention periods extend if audit findings are pending. ERP document management must enforce these retention rules by grant.

### 3.4 International Grant Compliance

| Framework | Jurisdiction | Key ERP Requirements |
|---|---|---|
| ECHO FAFA (Financial and Administrative Framework Agreement) | EU/European Commission humanitarian grants | Separate budget tracking per ECHO grant; procurement threshold documentation (verify exact threshold against specific grant agreement and applicable FAFA annex — thresholds vary by agreement and are subject to revision); narrative and financial reporting templates |
| FCDO Programme Operating Framework (PrOF) | UK Foreign, Commonwealth & Development Office (DFID merged into FCDO September 2, 2020; PrOF effective April 1, 2021 [8]) | Value for Money (VfM) reporting; financial management standards for implementing partners; specific audit and procurement requirements |
| USAID ADS 303 / 2 CFR Part 700 | United States | Layered on 2 CFR Part 200; standard provisions for U.S. and non-U.S. NGOs differ; 2024 revisions effective October 1, 2024 [7] |
| UN Agencies (UNHCR, UNICEF, WFP) | Multilateral | Agency-specific grant terms; direct implementation vs. implementing partner distinctions; harmonized reporting where applicable |

### 3.5 GASB (Governmental Component Units)

GASB Statement No. 34 (Basic Financial Statements for State and Local Governments) applies only if a nonprofit is organized as a component unit of a governmental entity. Most US nonprofits follow FASB ASC 958, not GASB. Engineers designing for organizations that straddle both frameworks (e.g., community foundations with government affiliations) must handle dual-reporting requirements. See `verticals/government-publicsector.md` for GASB fund accounting details.

### 3.6 Anti-Money-Laundering / Counter-Terrorism Financing

- **OFAC SDN List screening:** all donors, grantees, subgrantees, and significant vendors must be screened against the OFAC Specially Designated Nationals list (US nonprofits), EU Consolidated List, and UN Consolidated List.
- **FATF Recommendation 8 [9]:** designates the nonprofit sector as a recognized higher-risk category for terrorist financing misuse, particularly for organizations operating in or transferring funds to conflict-affected regions. Enhanced due diligence and periodic rescreening are expected.
- **Bank Secrecy Act:** obligations triggered at applicable thresholds for cash transactions.
- ERP must provide screening workflow or integrate with dedicated screening services (Dow Jones Risk & Compliance, Refinitiv World-Check, or similar) — see §9.2.

## 4. Key Data Entities

### 4.1 Entity Overview

| Entity | Key Fields | Notes |
|---|---|---|
| Fund | fund_id, name, restriction_type, sub_type, grantor_id, purpose_description, expiry_date, is_underwater | Self-balancing; is_underwater drives endowment reclassification under ASU 2016-14 |
| NetAssetClass | class {with_donor_restrictions, without_donor_restrictions}, sub_classification | Two-class model per ASU 2016-14; additional disaggregation in notes |
| Grant | grant_id, grantor_id, fund_id, award_number, award_amount, currency, start_date, end_date, indirect_cost_type, nicra_rate, mtdc_base_amount, status, compliance_framework | compliance_framework drives allowable-cost rules and reporting template |
| GrantBudgetLine | line_id, grant_id, cost_category, approved_amount, encumbered, actual_spent, allowable, mtdc_included | MTDC inclusion flag drives indirect cost base calculation |
| Donor/Constituent | constituent_id, type, name, address, tax_id, relationship_manager, ofac_screen_date, ofac_screen_result | OFAC screening status must be recorded and refreshed periodically |
| Gift | gift_id, constituent_id, date, amount, gift_type, fund_designation, restriction_note, acknowledgment_sent_date, irs_substantiation_threshold_met | Acknowledgment tracking required for IRC §170(f)(8) compliance |
| InKindGift | gift_id, asset_type, description, fair_value, measurement_basis, contributed_service_flag, specialized_skill_type, offsetting_expense_category | ASU 2020-07 requires category-level disaggregated disclosure |
| Program | program_id, name, theory_of_change, budget, start_date, end_date, outcome_metrics[] | Outcome metrics enable units-of-service reporting for grant narratives |
| FunctionalExpenseAllocation | allocation_id, period_start, period_end, natural_class_id, method, program_pct, mgmt_general_pct, fundraising_pct, support_doc_url | Support documentation URL is audit-critical; must be retained per 2 CFR 200.334 |
| Volunteer | volunteer_id, name, skills[], background_check_status, background_check_expiry, hours_logged_by_program[] | Hours are operational-only unless specialized skills criterion met |
| RestrictionRelease | release_id, fund_id, amount, release_type {purpose_satisfied, time_elapsed}, authorization_ref, journal_entry_id | Requires approval workflow before GL posting; see §9.1 |

### 4.2 Schema Sketch

```sql
-- Fund: self-balancing ledger unit
Fund (
  fund_id            UUID PRIMARY KEY,
  name               VARCHAR(200) NOT NULL,
  restriction_type   ENUM('with_donor_restrictions','without_donor_restrictions') NOT NULL,
  sub_type           ENUM('operating','board_designated','endowment_principal',
                          'term_endowment','quasi_endowment','program_restricted') NOT NULL,
  grantor_id         UUID REFERENCES Constituent(constituent_id),
  purpose_code       VARCHAR(50),
  expiry_date        DATE,
  is_underwater      BOOLEAN DEFAULT FALSE,  -- endowment MV < historic gift value; triggers ASU 2016-14 reclassification
  created_at         TIMESTAMPTZ NOT NULL
);

-- Grant: award-level tracking
Grant (
  grant_id             UUID PRIMARY KEY,
  fund_id              UUID NOT NULL REFERENCES Fund(fund_id),
  grantor_id           UUID NOT NULL REFERENCES Constituent(constituent_id),
  award_number         VARCHAR(100) UNIQUE NOT NULL,  -- FAIN for federal awards
  award_amount         DECIMAL(18,2) NOT NULL,
  currency             CHAR(3) NOT NULL DEFAULT 'USD',
  start_date           DATE NOT NULL,
  end_date             DATE NOT NULL,
  indirect_cost_type   ENUM('NICRA','de_minimis','cost_share','none') NOT NULL,
  nicra_rate           DECIMAL(5,4),                  -- e.g. 0.2750 for 27.50%
  mtdc_base_amount     DECIMAL(18,2),                 -- computed field; sum of MTDC-eligible direct costs
  status               ENUM('pipeline','awarded','active','closeout','closed') NOT NULL,
  compliance_framework ENUM('2CFR200','2CFR700_USAID','ECHO','FCDO','UN','bilateral','private') NOT NULL,
  assistance_listings_number VARCHAR(20)               -- formerly CFDA; required for SEFA
);

-- Grant budget line: cost category control
GrantBudgetLine (
  line_id            UUID PRIMARY KEY,
  grant_id           UUID NOT NULL REFERENCES Grant(grant_id),
  cost_category      VARCHAR(100) NOT NULL,  -- Personnel, Fringe, Travel, Equipment, Subawards, Indirect
  approved_amount    DECIMAL(18,2) NOT NULL,
  encumbered         DECIMAL(18,2) NOT NULL DEFAULT 0,
  actual_spent       DECIMAL(18,2) NOT NULL DEFAULT 0,
  balance_available  DECIMAL(18,2) GENERATED ALWAYS AS (approved_amount - encumbered - actual_spent) STORED,
  allowable          BOOLEAN NOT NULL DEFAULT TRUE,
  mtdc_included      BOOLEAN NOT NULL DEFAULT TRUE  -- FALSE for equipment >$10k, subawards beyond $50k, etc.
);

-- Functional expense allocation: period-level method documentation
FunctionalExpenseAllocation (
  allocation_id      UUID PRIMARY KEY,
  period_start       DATE NOT NULL,
  period_end         DATE NOT NULL,
  natural_class_id   UUID NOT NULL REFERENCES ChartOfAccounts(account_id),
  method             ENUM('time_study','headcount','sqft','direct','revenue_ratio','fte_ratio') NOT NULL,
  program_pct        DECIMAL(5,4) NOT NULL,  -- e.g. 0.7500 = 75%
  mgmt_general_pct   DECIMAL(5,4) NOT NULL,
  fundraising_pct    DECIMAL(5,4) NOT NULL,
  CHECK (program_pct + mgmt_general_pct + fundraising_pct = 1.0000),
  support_doc_url    TEXT,
  approved_by        UUID REFERENCES Users(user_id),
  approved_at        TIMESTAMPTZ
);

-- Restriction release: controls net asset reclassification
RestrictionRelease (
  release_id         UUID PRIMARY KEY,
  fund_id            UUID NOT NULL REFERENCES Fund(fund_id),
  amount             DECIMAL(18,2) NOT NULL,
  release_type       ENUM('purpose_satisfied','time_elapsed') NOT NULL,
  release_date       DATE NOT NULL,
  authorization_ref  TEXT NOT NULL,  -- board minute reference or program officer approval
  journal_entry_id   UUID REFERENCES JournalEntry(entry_id),
  initiated_by       UUID REFERENCES Users(user_id),
  authorized_by      UUID REFERENCES Users(user_id),  -- SoD: must differ from initiated_by
  authorized_at      TIMESTAMPTZ
);
```

## 5. Critical Integrations

### 5.1 Donor CRM / Fundraising Platform

| Product | Target Segment | Integration Pattern |
|---|---|---|
| Blackbaud Raiser's Edge NXT | Mid-to-large nonprofits, arts, healthcare foundations | Native bidirectional with Financial Edge NXT; tightest integration available in market |
| Salesforce NPSP / Salesforce for Nonprofits | Large nonprofits, tech-forward organizations | REST API / middleware sync; gift records flow CRM → ERP for GL coding; constituent data bidirectional |
| Bloomerang | Mid-market | API integration; gift and constituent sync |
| DonorPerfect | Smaller organizations | CSV/API import to ERP |

Integration design principle: gift records flow one-directionally CRM → ERP for GL posting; GL journal entries never originate in the CRM. Constituent updates flow bidirectionally. Timing reconciliation between CRM receipt date and ERP bank settlement date must be handled explicitly (see §8.7).

### 5.2 Grant Management / Program Management Platforms

- **Fluxx:** grantmaker portal used by foundations to manage grant awards, LOIs, and reporting; implementing NGOs receive grants via Fluxx and must pull budget data into ERP via API.
- **Submittable:** grant application intake for community foundations; inbound grant notifications.
- **AmpliFund:** dedicated grant tracking platform; may duplicate ERP grant module functionality in smaller organizations — dual-system risk must be evaluated.

### 5.3 Payroll & Human Resources

- **ADP Workforce Now, Paychex, Paylocity:** payroll systems must push labor cost detail by employee, pay period, and cost center/program to the ERP. This is critical for NICRA allocation and 2 CFR Part 200 effort reporting requirements (personnel activity reports).
- Time and labor tracking systems must capture hours by program/grant; absence of granular time data is the primary cause of indirect cost allocation disputes during federal audits.

### 5.4 Federal Payment Systems

- **ASAP (Automated Standard Application for Payments):** US Treasury system used by most federal grantees to draw down awarded funds. ERP must reconcile ASAP drawdown transactions against grant cash receipts.
- **HHS Payment Management System (PMS):** DHHS-specific payment system for grants from NIH, CDC, HRSA, and other HHS operating divisions. Separate reconciliation workflow from ASAP.
- ACH batch processing for donor refunds and vendor payments.
- Positive Pay for check fraud prevention (see `core/security.md`).

### 5.5 Planned Giving & Endowment Administration

- **PG Calc, Crescendo:** planned gift administration; actuarial calculations for charitable gift annuities, charitable remainder trusts, and bequest expectancy valuations.
- **Custodian/investment manager data feeds (Schwab, Fidelity, TIAA, others):** market value, realized/unrealized gains, income, and expense feeds for endowment pool reporting. Required for endowment underwater determination and FASB ASC 958-320 investment reporting.

### 5.6 Tax, Audit & Compliance

- Form 990 preparation software (e.g., Drake Tax for tax-exempts; verify current feature set against specific organizational complexity before selecting).
- Single audit export: SEFA (Schedule of Expenditures of Federal Awards) generation from ERP; must include all federal expenditures tagged by Assistance Listings number (formerly CFDA number) and FAIN.

### 5.7 Field Operations (International NGOs)

| Tool | Purpose |
|---|---|
| KoBoToolbox / ODK (Open Data Kit) | Beneficiary data collection in low-connectivity field environments; forms sync to server when connectivity restored |
| RedRose | Multi-purpose cash and voucher assistance (CVA) tracking; beneficiary registration and distribution management for humanitarian programs |
| ActivityInfo | Program monitoring and reporting for UNHCR, ECHO implementing partners; indicator data aggregation |

## 6. KPIs & Metrics

| KPI | Definition | Formula | Benchmark / Notes |
|---|---|---|---|
| Program Expense Ratio | % of total expenses directed to mission programs | Program Expenses / Total Expenses × 100 | ≥70% earns full points on Charity Navigator's 2023 methodology [10]; ≥75% is strong |
| M&G Expense Ratio | Administrative overhead as % of total expenses | M&G Expenses / Total Expenses × 100 | <15% is a common watchdog guideline |
| Fundraising Efficiency Ratio | Cost to raise one dollar | Fundraising Expenses / Total Contributions Raised | <$0.25 per dollar raised is considered strong |
| Donor Retention Rate | % of prior-period donors who give again in current period | Donors giving in current period who also gave in prior period / Total donors in prior period × 100 | Sector average is in the low-to-mid 40% range; >45% is strong |
| Donor Acquisition Cost | Cost per new donor acquired | Fundraising Expenses attributed to acquisition campaigns / New donors acquired | Must be compared to projected donor lifetime value to determine ROI |
| Grant Utilization Rate | % of approved grant budget expended within period | Actual Grant Expenditure / Approved Grant Budget × 100 | Underspend triggers carryforward or return obligations; overspend triggers allowability review |
| Days Cash on Hand | Liquidity reserve for operating continuity | (Unrestricted Cash + Short-term Liquid Investments) / (Total Operating Expenses / 365) | ≥90 days is considered healthy |
| Net Asset Ratio | Financial cushion relative to annual operations | Net Assets Without Donor Restrictions / Total Annual Operating Expenses | ≥0.25 (3+ months of expenses covered) |
| Indirect Cost Recovery Rate | Actual recovery vs. budget model | Indirect Costs Recovered / (MTDC × NICRA Rate) × 100 | <100% signals underrecovery; must investigate MTDC base accuracy |
| Units of Service per Program Dollar | Mission output efficiency | Units of Service Delivered / Program Expense | Organization-specific; track trend; use in grant impact reports |
| Volunteer Hour Value | Economic value of donated time for disclosure | Volunteer Hours × Independent Sector annual rate [5] | Non-financial metric; disclosed in annual report and grant narratives; not recognized in financial statements under ASC 958-605 |
| SEFA Coverage Ratio | Completeness of federal expenditure tracking | Federal Award Expenditures Included in SEFA / Total Federal Award Expenditures × 100 | Must be 100%; any gap is a Single Audit finding |

## 7. Major ERP Vendors for this Vertical

### 7.1 Sage Intacct

The dominant mid-market cloud choice; the AICPA-designated Preferred Provider of Financial Applications (designation held since 2009 [11]). Purpose-built fund accounting engine with dimension-based tagging (Fund, Grant, Program, Department) avoids COA explosion.

**Nonprofit-specific modules:**
- Nonprofit Fund Accounting (core module, included in nonprofit SKU)
- Grants Tracking and Billing (separate add-on SKU; obtain current pricing directly from Sage — module pricing changes frequently)
- Allocations Engine (for functional expense allocation with documented methods)
- Project Accounting (project-level budget vs. actual)
- Revenue Recognition (ASU 2018-08 conditional grant support)
- Multi-Entity Consolidation (for federated nonprofit structures)

ASC 958 / FASB ASU 2016-14 net asset reporting is available out-of-the-box. SEFA report generation supported. Strongest fit for mid-market US nonprofits with complex grant portfolios.

### 7.2 Blackbaud Financial Edge NXT

The dominant solution for mid-to-large nonprofits, particularly arts organizations, healthcare foundations, and higher-education-adjacent entities. Native fund accounting with encumbrance accounting is a core differentiator.

**Nonprofit-specific capabilities:**
- Native fund accounting with independent fund-level balance sheets
- Encumbrance accounting (commitments reduce available balances before disbursement)
- Grant management with budget-to-actual tracking
- Sub-fund (project/grant) tracking with flexible account segment structure
- Built-in nonprofit financial report templates including Statement of Functional Expenses
- Direct bidirectional integration with Blackbaud Raiser's Edge NXT (donor CRM) — the tightest CRM-to-ERP integration available in the nonprofit market

### 7.3 NetSuite SuiteSuccess for Nonprofits (Oracle NetSuite)

Suitable for mid-to-large nonprofits, particularly those requiring multi-entity, multi-currency, or multi-subsidiary structures supporting international NGO operations. Oracle Social Impact Program provides eligible 501(c)(3) organizations with discounted or donated access to core modules — verify current program terms and eligibility directly with Oracle, as terms adjust periodically.

**Nonprofit-specific configuration:**
- Uses "Class" dimension for fund accounting (not a native fund accounting engine — requires deliberate configuration and discipline; less structurally enforced than Blackbaud or Sage Intacct)
- Grant management via Project module
- SuiteSuccess for Nonprofits: pre-configured COA, dashboards, KPI reports
- Multi-currency and multi-subsidiary for international NGO structures
- Weaker native encumbrance accounting relative to Blackbaud and Sage Intacct

### 7.4 SylogistMission / Serenic Navigator (Microsoft Dynamics 365 Business Central)

Built on Microsoft Dynamics 365 Business Central (formerly Dynamics NAV); Serenic Software was acquired by Sylogist Ltd. in 2014; the product now markets as SylogistMission. Available on Microsoft Cloud (released 2021 [12]). Appeals to Microsoft-centric organizations and international NGOs operating within the Microsoft ecosystem.

**Modules:**
- Fund & Encumbrance Accounting
- Grant Management
- Fundraising Management
- Ministry Budgeting & Program Management
- Payroll
- Web Portals for budget owners
- Power BI integration via Microsoft 365 ecosystem

**Target segment:** nonprofits, international NGOs, K-12 school districts, religious organizations.

### 7.5 Aplos (Small Nonprofit Segment)

Cloud-based platform purpose-built for small nonprofits and churches. Fund accounting, donor management, giving tracking, and basic grant tracking. Handles Form 990 preparation basics — verify current feature set against organizational complexity requirements before selecting. Not suitable for organizations with complex multi-donor grant portfolios, NICRA compliance needs, or international operations.

### 7.6 Other Products

| Product | Notes |
|---|---|
| MIP Fund Accounting (Community Brands) | Long-standing mid-market fund accounting; on-premise and cloud versions; verify current branding and ownership status under Community Brands |
| Acumatica | General ERP with nonprofit customer deployments; not purpose-built; COA and allocation configuration required |

## 8. Implementation Cautions

### 8.1 Chart of Accounts Design (Most Common Fatal Flaw)

Conflating fund, program, grant, and functional category into a single monolithic COA segment is the most frequent and damaging implementation error. The result: thousands of account codes, impossible fund-level balance sheets, and a COA that must be rebuilt on the next audit.

**Correct pattern:** multi-dimensional segment structure with independent dimensions for:
1. Natural Expense/Revenue Classification (what was spent on)
2. Functional Category (program, M&G, fundraising)
3. Fund (source restriction)
4. Program/Project
5. Grant/Contract
6. Department

Each dimension must balance independently at the Fund level. Segment balancing rules incorrectly configured cause fund-level balance sheets to produce incorrect results that appear valid on the surface.

### 8.2 Net Asset Class Migration (ASU 2016-14)

Organizations still reporting on the pre-FY2018 three-class model (unrestricted / temporarily restricted / permanently restricted) must execute a reclassification: "temporarily restricted" and "permanently restricted" both map to "with donor restrictions" with disaggregated disclosures in the notes. The ERP financial statement template must be reconfigured to output the two-class presentation and the required liquidity and expense disclosures. Underwater endowments must be fully classified within "with donor restrictions" — not split between the two classes.

### 8.3 Conditional Grant Revenue Recognition (ASU 2018-08)

Cost-reimbursement grants from government agencies are generally conditional (barrier = incurring qualifying costs); revenue is recognized as costs are incurred, not when the grant agreement is signed [2]. Many organizations configured their ERP to recognize the full grant award as revenue on execution of the grant agreement. This produces overstated revenue and net assets and is a material GAAP error. Correct configuration: deferred revenue account on award; revenue recognition entry triggered by cost-reimbursement billing run.

### 8.4 MTDC Calculation Errors

The MTDC base must exclude per 2 CFR Part 200 (2024 revision) [3]:
- Equipment costing $10,000 or more (post-2024 threshold; $5,000 for grants awarded before October 1, 2024)
- The portion of subaward costs beyond the first $50,000 per subaward (post-2024; $25,000 for prior awards)
- Patient care costs
- Tuition remission

Including excluded items in the MTDC base causes overrecovery of indirect costs, triggering audit findings and required refunds to grantors. De minimis rate (now 15%) is available only to organizations that have never held a negotiated rate; once a NICRA is signed, the organization must maintain a negotiated rate thereafter.

### 8.5 Single Audit Preparation (2 CFR 200 Subpart F)

SEFA must include 100% of federal award expenditures including pass-through awards received from state and local agencies. Every federal transaction must be tagged at posting time with the Assistance Listings number (formerly CFDA number) and FAIN. The 2024 revision raised the Single Audit threshold to $1,000,000 (from $750,000) for fiscal years beginning on or after October 1, 2024 [3]; organizations near this threshold need accurate real-time tracking to avoid unexpected audit obligations. ERP must generate draft SEFA from tagged transaction data, not from manual assembly.

### 8.6 Multi-Donor International Compliance

ECHO, FCDO, and USAID each impose different budget flexibility rules (e.g., threshold for budget modifications requiring prior approval), no-cost extension procedures, procurement thresholds, and audit requirements. The ERP must support donor-specific rules configured per grant rather than a single global rule set. Currency risk on grants denominated in EUR or GBP with USD functional currency requires multi-currency with exchange gain/loss tracking at the grant level. Field cash advance management — petty cash floats in low-connectivity field offices — requires offline-capable reconciliation workflows with subsequent upload.

### 8.7 CRM-to-ERP Gift Reconciliation

Timing differences between gift receipt in the CRM (often recorded same-day as donation) and bank settlement (ACH settlement is T+1 to T+2; credit card settlement adds merchant processing delay) create reconciliation breaks if not explicitly handled. Pledge write-offs and donor refunds must be reflected in both CRM and ERP simultaneously; mismatches between systems create audit exposure. In-kind gift valuation for assets other than standard goods (donated art, real estate, vehicles) requires independent appraisal at fair value per ASC 820; subjective internal valuations are not sufficient.

### 8.8 Volunteer Data and Non-Financial Shadow Systems

Volunteer hours that do not meet the specialized-skills recognition threshold (§2.5) are not recorded in the GL, but they are required for grant narrative reports, board reports, and disclosure. Implementations that skip the volunteer module because "it doesn't affect the financials" cause organizations to maintain shadow spreadsheets. These shadow systems diverge from operational reality over time and produce inconsistent grant reports. The volunteer module must be implemented even though it feeds operational reporting rather than the GL.

### 8.9 Restricted Fund Release Workflow

Time-based restrictions (funds restricted for a specific future period) can be auto-released by date; purpose-based restrictions (funds restricted to a specific use) require evidence that the purpose has been accomplished before release. ERP must enforce a two-step workflow: (1) program officer initiates release with documentation reference; (2) finance officer authorizes; (3) controller posts GL entry. Premature release of donor-restricted net assets is a fiduciary breach and can trigger donor lawsuits or IRS compliance review. Auto-release by date without purpose verification — or skipping the approval workflow for small release amounts — are the common failure modes.

## 9. Security & Compliance Depth

### 9.1 Segregation of Duties (SoD)

Nonprofit organizations are disproportionately susceptible to internal fraud due to small finance teams, high trust cultures, and limited oversight infrastructure. ERP role design must enforce:

| Process | Role 1 | Role 2 (must be different person) | Role 3 (if applicable) |
|---|---|---|---|
| Gift processing | Gift entry | Gift deposit / bank reconciliation | Acknowledgment letter generation |
| Grant drawdown | Drawdown request preparation | Drawdown authorization | Bank reconciliation |
| Vendor payment | Invoice entry / PO matching | Payment authorization | Check signing / ACH release |
| Restricted fund release | Program officer (initiates with documentation) | Finance officer (authorizes) | Controller (posts GL entry) |
| New vendor/payee setup | Vendor master entry | Vendor approval | First payment authorization |

The gift-entry/deposit separation is critical: a finance employee who can both enter a gift in the ERP and make the bank deposit can cover embezzled cash by entering a fictitious gift. For additional SoD framework detail, see `core/security.md`.

### 9.2 OFAC / Sanctions Screening

- All donors, grantees, subgrantees, and vendors must be screened against OFAC SDN List (US), EU Consolidated List, and UN Consolidated List at onboarding and on a periodic refresh schedule.
- International NGOs operating in conflict-affected regions (Afghanistan, Syria, Sudan, etc.) face elevated Counter-Terrorism Financing (CTF) risk; FATF Recommendation 8 [9] requires enhanced due diligence for this class of organization.
- Screening must be integrated into the constituent onboarding workflow — not a manual periodic batch — to prevent inadvertent transactions before screening is complete.
- Dedicated screening services (Dow Jones Risk & Compliance, Refinitiv World-Check, LexisNexis) provide real-time API screening integrated into ERP vendor/donor onboarding.
- Screening results, dates, and screener identity must be recorded immutably for each constituent record.

### 9.3 Donor Data Privacy

- Donor PII (name, address, giving history, demographic data) is sensitive. GDPR (EU/UK) applies to EU-based donors or organizations with EU-based chapters; GDPR Article 9 applies if health or religious affiliation data is collected.
- CCPA/CPRA compliance for California-based donors.
- **IRS Schedule B confidentiality:** donor names and contribution amounts on Schedule B are not publicly disclosed; the public copy of Form 990 must omit Schedule B donor identification. ERP reporting must support generation of the complete internal version and the redacted public disclosure version as separate outputs — not the same report with manual redaction.
- Data minimization: CRM-to-ERP integration should transmit only the fields required for GL coding; full constituent demographic profiles should not replicate into the financial ERP.

### 9.4 Document Retention by Compliance Framework

| Framework | Retention Period | Starting Point |
|---|---|---|
| 2 CFR 200.334 (Federal grants) | 3 years | Submission of final financial report for the award |
| ECHO / EU grants | Typically 7 years | Grant end date (verify in specific grant agreement) |
| FCDO grants | Typically 7 years | Grant end date per PrOF requirements |
| IRS (Form 990 supporting records) | Minimum 3 years | Filing date; longer if material items in dispute |

ERP document management must tag each attached document with the applicable compliance framework and enforce retention lock — preventing deletion before the retention period expires. Extension of retention applies automatically when audit findings are pending.

### 9.5 Audit Trail Requirements

- **Journal entry modification log:** immutable after period close. Post-close adjustments require a new entry with reference to the original — entries cannot be edited or deleted. See `core/security.md` for implementation pattern.
- **Grant drawdown history:** every federal payment system transaction (ASAP, HHS PMS) must be recorded, timestamped, and reconcilable to the GL cash receipt. Drawdown amounts must not exceed unreimbursed allowable costs.
- **Gift acknowledgment audit trail:** IRS requires written acknowledgment for every gift exceeding $250 per IRC §170(f)(8); ERP must record: acknowledgment date, method of delivery, amount, quid pro quo disclosure, and the user who generated/sent the acknowledgment.
- **Allocation basis documentation:** for each period's functional expense allocation, the support documentation (time study worksheets, space utilization records) must be retained with a reference in the allocation record's `support_doc_url` field.

### 9.6 Internal Controls Framework

- **Board-level financial oversight:** board treasurer and audit committee members require read-only ERP dashboard access showing fund-level balances, grant budget-to-actual, and liquidity metrics. Access must be read-only with no ability to initiate transactions.
- **Investment policy compliance:** endowment investments must be tracked against the organization's Investment Policy Statement (IPS) constraints (asset class limits, prohibited investments, spending policy). ERP investment module or custodian feed integration must flag IPS violations.
- **Budget authority controls:** the encumbrance system must prevent creation of commitments that exceed authorized budget before the PO is issued. Budget overrides require explicit secondary approval and audit log entry.
- **Conflict of interest:** Schedule L transactions (loans to officers/directors, business transactions with interested persons) must be flagged by the ERP when a vendor or counterparty is linked to an employee or board member in the constituent master.

## See Also

- `core/features-core.md` — general ledger, AP/AR, encumbrance, and reporting foundations applicable to this vertical
- `core/security.md` — SoD framework, audit trail implementation, access control patterns referenced in §9.1 and §9.5
- `verticals/government-publicsector.md` — GASB fund accounting, governmental grant compliance, SEFA overlaps
- `verticals/education.md` — higher education nonprofit entities, endowment management, and Title IV compliance parallels
- `core/localization-tax.md` — multi-currency for international NGOs, VAT recovery on grants, GDPR data residency

## Citations & Sources

1. FASB ASU 2016-14, "Not-for-Profit Entities (Topic 958): Presentation of Financial Statements of Not-for-Profit Entities" (August 2016). Effective for fiscal years beginning after December 15, 2017. https://fasb.org
2. FASB ASU 2018-08, "Not-for-Profit Entities (Topic 958): Clarifying the Scope and Accounting Guidance for Contributions Received and Contributions Made" (June 2018). https://fasb.org
3. eCFR, 2 CFR Part 200 — Uniform Administrative Requirements, Cost Principles, and Audit Requirements for Federal Awards (2024 revision, effective October 1, 2024). https://www.ecfr.gov/current/title-2/subtitle-A/chapter-II/part-200
4. FASB ASU 2020-07, "Not-for-Profit Entities (Topic 958): Presentation and Disclosures by Not-for-Profit Entities for Contributed Nonfinancial Assets" (September 2020). Effective for annual periods beginning after June 15, 2021. https://fasb.org
5. Independent Sector — Value of Volunteer Time (updated annually; $33.49/hr for 2024, $34.79/hr for 2025, $36.14/hr per 2026 release). https://independentsector.org/research/value-of-volunteer-time/
6. IRS, Instructions for Schedule F (Form 990) (Rev. December 2024) — foreign expenditure and investment thresholds. https://www.irs.gov/instructions/i990sf
7. USAID, Federal Register notice — "USAID Assistance Regulation: Plain Language and Conforming Revisions" (August 2, 2024, implementing 2024 Uniform Guidance revisions). https://www.federalregister.gov/documents/2024/08/02/2024-16945/usaid-assistance-regulation-plain-language-and-conforming-revisions; USAID ADS 303 (Assistance Instruments): https://www.usaid.gov/ads/policy/300/303
8. Independent Commission for Aid Impact (ICAI), "The FCDO's Programme Operating Framework" review. DFID merged into FCDO September 2, 2020; PrOF effective April 1, 2021. https://icai.independent.gov.uk/review/the-fcdos-programme-operating-framework
9. Financial Action Task Force (FATF), Recommendation 8 (Non-Profit Organizations) and Interpretive Note. https://www.fatf-gafi.org/en/topics/fatf-recommendations.html
10. Charity Navigator, Methodology Update (2023) — program expense ratio threshold of ≥70% for maximum points. https://www.charitynavigator.org/about-us/our-methodology/
11. Sage Intacct — AICPA Preferred Provider of Financial Applications (since 2009). https://www.sageintacct.com/aicpa-preferred-financial-management-solution
12. Sylogist Ltd. / Serenic Software, "Serenic Navigator on Microsoft Cloud" announcement (May 2021). https://www.sylogist.com/blog/serenic-release-microsoft-cloud/
