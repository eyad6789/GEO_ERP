---
id: MANIFEST
stage: ORIENT
audience: orchestrator
read_when: once, right after 00-START-HERE
produces: routing decisions (what to read/dispatch when)
---

# manifest.md — File Catalog & Routing Table

The orchestrator reads this once to know what exists and when to load it. **Read a doc only at its `read_when` moment.** Hand a subagent the single file it needs, not the whole library.

Size discipline: playbook files target ≤300 lines; anchors ≤ their noted caps; library files and the glossary are **grep/section targets, never full reads**.

## Spine (read in this order at session start)

| id | path | audience | read_when |
|---|---|---|---|
| CLAUDE | `CLAUDE.md` | all (auto-loaded) | every turn (automatic) |
| START-HERE | `00-START-HERE.md` | orchestrator | once per session |
| MANIFEST | `manifest.md` | orchestrator | once, after START-HERE |
| KNOWLEDGE-MAP | `knowledge-map.md` | orchestrator + subagents | whenever a library fact is needed |

## Playbook (doctrine — load the current phase's file only)

| id | path | stage | read_when | produces |
|---|---|---|---|---|
| P01 | `playbook/01-freshness-check.md` | ORIENT | session start, before any decision locks | `project-config/freshness-report.md`, gate G0 |
| P02 | `playbook/02-discovery-interview.md` | ELICIT | after G0 | `project-config/interview-transcript.md` |
| P03 | `playbook/03-decision-file-spec.md` | DECIDE | after interview, to build the HTML decision file | `project-config/decisions.html` |
| P04 | `playbook/04-tech-stack.md` | DECIDE | tech-stack decision chunk | stack keys in `locked-decisions.json` |
| P05 | `playbook/05-architecture-deployment.md` | DECIDE | architecture/tenancy/deploy chunk | deploy+tenancy keys |
| P06 | `playbook/06-security-foundations.md` | DECIDE + BUILD | security baseline chunk; and before any auth/data code | security keys; routes to scenarios |
| P07 | `playbook/07-features-selection.md` | DECIDE | module-selection chunk | module list + per-vertical routing |
| P08 | `playbook/08-design-system.md` | DECIDE + BUILD | design chunk; and before any UI | design tokens + UX rules |
| P09 | `playbook/09-build-loop.md` | BUILD | for every module | built + verified module |
| P10 | `playbook/10-quality-gates.md` | HARDEN | per phase (DoD) and the final hardening pass | pass/fail evidence |
| P11 | `playbook/11-deployment-production.md` | SHIP | at deployment | running production system, gate G2 |
| P12 | `playbook/12-ui-ux-visual-verification.md` | BUILD | before/while building any UI module | UI toolchain + the enforced visual-verification loop + `ui_verify` gate |

## Advanced doctrine (optional depth — each has an ADOPT-WHEN trigger; load only when the interview surfaces the need)

| id | path | adopt when |
|---|---|---|
| A1 | `playbook/advanced/A1-temporal-ledger.md` | the ledger needs restatement / as-of reporting / audit reconstruction (almost always) — bitemporal + event-sourced core |
| A2 | `playbook/advanced/A2-formal-correctness.md` | any build with a ledger/tax/pricing — decimal rigor, DMN decision tables, golden-reference oracle |
| A3 | `playbook/advanced/A3-mdm-integration-migration.md` | replacing/integrating legacy or >1 data source — MDM, integration contracts, continuous reconciled migration |
| A4 | `playbook/advanced/A4-clean-core-extensibility.md` | client/industry-specific logic or multi-tenant SaaS — the extension boundary |
| A5 | `playbook/advanced/A5-semantic-layer.md` | cross-module reporting / KPIs — the one-number governed metrics layer |
| A6 | `playbook/advanced/A6-ai-native-operation.md` | the owner wants AI features — propose-not-dispose doctrine |
| A7 | `playbook/advanced/A7-advanced-authz-crypto.md` | complex approval hierarchies (ReBAC), regulated audit (crypto anchoring), or large green-field (spec-gen) |
| A8 | `playbook/advanced/A8-process-benefit.md` | any real deployment — process-first + benefit realization gate |

## Security library (load the relevant few, on demand)

| id | path | read_when |
|---|---|---|
| SEC-INDEX | `playbook/06-security-foundations.md` | the security index + principles |
| SEC-SCN | `playbook/security/scenarios/NN-<slug>.md` | building a module whose surface matches the scenario's tags (auth, tenancy, upload, API, AI-copilot, payments, reporting…) |
| SEC-CHK | `playbook/security/checklists/<phase>.md` | the security DoD for that phase |

## Executable orchestration

| id | path | read_when |
|---|---|---|
| WF-VERIFY | `workflows/verify-claims.js` | P01 freshness sweep |
| WF-BUILD | `workflows/build-module.js` | P09 per-module loop (builder→{QA ∥ security ∥ design-qa for UI}→bounce≤3→verify, max fan-out) |
| WF-REVIEW | `workflows/adversarial-review.js` | P10 hardening / doc review |
| AGENTS | `.claude/agents/*.md` | role definitions (researcher, builder, qa-reviewer, security-reviewer, design-qa-reviewer, verifier) |

## Templates (copied into the target project, not read as doctrine)

`playbook/templates/`:
- `verify-phase.sh` — the command-based Definition-of-Done runner (fail-closed) → `scripts/verify-phase.sh`
- `verify-commands.map.json` — concrete `verify.*` command strings by stack; copy the matching block at G1
- `guard-writes.sh` — PreToolUse hook body that blocks protected/out-of-repo writes → `scripts/`
- `decision-file.html` — Anthropic-design HTML decision file (rendered per project → `project-config/decisions.html`)
- `project-config.template.json` — **seeds `project-config/locked-decisions.json`** (pre-lock, all PROPOSED placeholders)
- `locked-decisions.schema.json` — validates the locked decisions
- `state.template.json` → `progress/state.json`; `phase-log.template.md` → `progress/phase-log.md`; `gate.template.md` → gate files
- `settings-hooks.json` — Claude Code hooks (`.claude/settings.json`) enforcing the anti-failure rules

## Provenance (why a rule exists)

`research/` holds the 2026-07 web-grounded reports the playbook distilled. A playbook file's `depends_on: R3-tech-stacks` (etc.) resolves to `research/R3-tech-stacks.md`; `verification-results.md` is the flagged-claims register used by P01. See `research/README.md`. **Fallback:** if a cited research doc is absent, the playbook file's own inline summary is authoritative — log the gap, never stall.

## Knowledge library (GREP / single-section reads ONLY — never full reads)

Route via `knowledge-map.md`. Files: `core/architecture.md`, `core/features-core.md`, `core/security.md`, `core/implementation.md`, `core/localization-tax.md`, `core/cautions.md`; `verticals/*.md` (15 industries); `glossary/*` (split index + parts). `README.md` is the human-facing index.

---
**NEXT:** `knowledge-map.md` (how to pull a fact), then `playbook/01-freshness-check.md` (how to start).
