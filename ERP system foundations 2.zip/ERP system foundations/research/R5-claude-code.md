# R5 — Claude Code: Current Capabilities & Best Practices for Long, Large Autonomous Builds (as of 2026-07)

**Purpose**: ground truth for an ERP-build-OS playbook that orchestrates Claude Code (CLI/SDK) across long, multi-session, multi-agent builds. All claims below are grounded in `code.claude.com/docs` fetched 2026-07-06 unless flagged. Where a claim is community-derived rather than official, it is labeled.

---

## 1. What Claude Code Is

Claude Code is Anthropic's terminal-native **agentic harness**: it wraps a Claude model with tools (file read/write, shell exec, search, web, code-intel), context management, and an execution environment, turning the model into an agent that can read a repo, plan, edit, run commands, and verify its own work in a loop — "gather context → take action → verify results" — repeating until the task is done or interrupted. It runs identically across terminal, VS Code/JetBrains extensions, the Desktop app, claude.ai/code (cloud VMs), Slack, and CI (GitHub Actions); only the execution environment (local machine vs. Anthropic-managed VM) and interface differ. **Confidence: high** (official "How Claude Code works" doc).

For an ERP build-OS, treat Claude Code as the **execution substrate**, and treat CLAUDE.md + skills + subagents + hooks + workflows as the **configuration surface** the playbook must hard-code.

---

## 2. CLAUDE.md: conventions and auto-loading

- Loaded automatically **every session**, at the start, before the first prompt.
- Locations, in load order/scope: `~/.claude/CLAUDE.md` (all sessions), `./CLAUDE.md` (project root, git-committed, team-shared), `./CLAUDE.local.md` (personal, gitignore it), parent directories (monorepo roots auto-pull in), and child directories (pulled in **on demand** when Claude reads a file there — not loaded up front). Supports `@path/to/file` imports for composing multiple docs.
- `/init` auto-generates a starter CLAUDE.md by inspecting build systems/test frameworks/patterns.
- **Hard rule from Anthropic's own guidance**: keep it short. For every line ask "would removing this cause Claude to make mistakes?" — if not, cut it. *"Bloated CLAUDE.md files cause Claude to ignore your actual instructions."* This is the single most emphasized failure mode in the official best-practices doc.
- Include: non-obvious bash commands, code style deltas from language defaults, test-runner instructions, repo etiquette (branch naming, PR conventions), architecture decisions, env-var quirks, common gotchas.
- Exclude: anything inferable from reading the code, standard language conventions, detailed API docs (link instead), frequently-changing info, file-by-file descriptions, "write clean code"-style platitudes.
- Emphasis markers ("IMPORTANT", "YOU MUST") measurably improve adherence — but only sparingly; overuse dilutes signal.
- Domain knowledge that's only *sometimes* relevant belongs in a **Skill**, not CLAUDE.md, specifically to avoid bloating every conversation.
- CLAUDE.md can also carry a "Compact Instructions" section that steers what survives auto-compaction (e.g., "always preserve the full list of modified files and test commands").

**Confidence: high.**

---

## 3. Subagents (`.claude/agents/`)

- Markdown files with YAML frontmatter (`name`, `description`, `tools`, `model`, optionally `effort`) + a system-prompt body. Project-level (`.claude/agents/`, team-shared) or user-level (`~/.claude/agents/`, cross-project).
- Created interactively via `/agents`, or by asking Claude directly ("write a subagent that...").
- Run in their **own context window**; only a final summary returns to the parent/caller — this is the mechanism, not an incidental detail, and it's why subagents are the primary lever for context-window hygiene on long builds.
- Invoke explicitly ("use a subagent to investigate X" / "use a subagent to review this diff") — Claude also spawns them autonomously when it judges a task benefits from isolation.
- **Model per subagent** is settable in frontmatter (`model: opus|sonnet|haiku|inherit`), or globally overridden with `CLAUDE_CODE_SUBAGENT_MODEL` (which overrides both the per-invocation `model` param and frontmatter — useful for pinning "all subagents run on Sonnet" org-wide).
- Real cost: each subagent spawn carries meaningful fixed token overhead before doing real work, and multi-agent sessions are reported (community figures, **unverified as of 2026-07**) to run 3–4x the token cost of single-threaded sessions. Reach for subagents when you need genuine context isolation or parallelism — not by default for everything.
- Canonical pattern for long builds: a **verification subagent** — a fresh-context reviewer that only sees the diff + the criteria, not the reasoning that produced the change, and is told to report gaps affecting correctness/requirements only (not style preferences, to avoid over-engineering churn). The bundled `/code-review` skill wraps exactly this pattern.

**Confidence: high** (official sub-agents doc + best-practices doc agree).

---

## 4. Skills

- A Skill = a directory with `SKILL.md` (YAML frontmatter: `name`, `description`, optional `disable-model-invocation`, `model`, `effort`) plus optional scripts/templates/reference docs.
- Discovered from `.claude/skills/` (project) and `~/.claude/skills/` (user). Claude sees only the frontmatter `description` at session start (cheap); the **full body loads only when invoked** — either automatically (Claude judges relevance from the description) or explicitly via `/skill-name`.
- Two shapes: (a) **domain-knowledge skills** — conventions Claude applies when relevant; (b) **workflow skills** — repeatable procedures with side effects, invoked directly, typically with `disable-model-invocation: true` so they never fire accidentally.
- Skills follow the **Agent Skills open standard** Anthropic published (community reporting: December 2025, **unverified exact date as of 2026-07**), with cross-tool adoption reported across ~40 tools including OpenAI Codex CLI, Gemini CLI, GitHub Copilot (**unverified as of 2026-07** — treat as directional, not exact).
- Skills are the correct place for anything that would otherwise bloat CLAUDE.md but isn't needed on every turn — this is Anthropic's own stated design rationale, not a community workaround.

**Confidence: high** for the mechanics; **medium** for the cross-tool-standard specifics.

---

## 5. Hooks: deterministic rule enforcement

Hooks are the **only** mechanism that guarantees a rule fires with zero exceptions — CLAUDE.md instructions are advisory (the model can forget/deprioritize them under context pressure); hooks are shell commands, HTTP calls, MCP tool calls, or prompt/agent evaluations that run outside Claude's context and that Claude cannot override.

**Lifecycle events** (cadence): once per session (`SessionStart`, `SessionEnd`); once per turn (`UserPromptSubmit`, `Stop`, `StopFailure`); every tool call (`PreToolUse`, `PostToolUse`, `PostToolUseFailure`, `PostToolBatch`); plus `SubagentStart/Stop`, `TeammateIdle`, `TaskCreated`, `TaskCompleted` (agent-team specific), `PermissionRequest`, `ConfigChange`, `FileChanged`, `CwdChanged`, `Notification`, `Elicitation`.

**Config** in `.claude/settings.json` (or user/local/plugin variants):
```json
{
  "hooks": {
    "PreToolUse": [
      { "matcher": "Bash", "hooks": [
        { "type": "command", "command": "${CLAUDE_PROJECT_DIR}/.claude/hooks/block-rm.sh", "timeout": 30 }
      ]}
    ]
  }
}
```
- Handler types: `command` (shell), `http` (POST to an endpoint), `mcp_tool` (call a connected MCP tool), `prompt` (LLM yes/no eval), `agent` (spawns a verifying subagent before returning a decision).
- `matcher` filters by tool name (exact/list/regex, e.g. `Edit|Write`, `mcp__memory__.*`).
- **Exit code 2 = blocking**: stderr is passed back to Claude as the reason, action is denied. Exit 0 with JSON lets you set fine-grained `permissionDecision: allow|deny|ask|defer`, rewrite tool input (`updatedInput`), or inject `additionalContext`.
- Path placeholders: `${CLAUDE_PROJECT_DIR}`, `${CLAUDE_PLUGIN_ROOT}`, `${CLAUDE_PLUGIN_DATA}`.
- **The Stop hook is the key gate for autonomous long builds**: a Stop hook can run your test/build/lint check as a script and block the turn from ending until it passes — this is how you convert "looks done" into a deterministic pass/fail gate for unattended runs. Anthropic's own guidance flags one important safety valve: **Claude Code overrides the Stop hook and ends the turn after 8 consecutive blocks**, so a broken check can't infinite-loop a session forever.
- `/hooks` browses all configured hooks (source: user/project/plugin/built-in). `"disableAllHooks": true` kills all hooks (respecting the managed-settings hierarchy).
- Claude can write hooks for you on request ("write a hook that runs eslint after every file edit").

**Concrete enforcement patterns for an ERP build-OS:**
| Rule to enforce | Hook |
|---|---|
| Never write outside repo / migrations folder | `PreToolUse` on `Edit\|Write`, deny by path pattern |
| Lint/format after every edit | `PostToolUse` on `Edit\|Write` |
| Tests must pass before a turn "finishes" | `Stop` hook running the test/build command, block on failure |
| Redact secrets from every shell call | `PreToolUse` on `Bash` |
| Log every subagent/teammate completion for audit trail | `SubagentStop` / `TaskCompleted` |
| Gate destructive commands (`rm -rf`, `terraform apply`) | `PreToolUse` matcher on `Bash`, deny + reason |

**Confidence: high.**

---

## 6. MCP servers

- MCP (Model Context Protocol) is the open standard for connecting Claude Code to external tools/data — issue trackers, DBs, Figma, Sentry, Slack, etc. Add with `claude mcp add`.
- Scopes: local (just you, this machine), project (`.mcp.json`, shared with team via git), user (all your projects).
- Tool naming: `mcp__<server-name>__<tool-name>`. Permission rules on MCP tools use this literal pattern — **`mcp__server(pattern)` parenthesized-argument syntax is invalid** for MCP rules (only plain tool-name/regex matching works).
- Context cost control: MCP tool *definitions* are deferred by default and loaded on demand via **tool search**, so only tool names (not full schemas) consume context until a specific tool is actually called. `/mcp` shows per-server token cost — check this before wiring up many servers on a long build.
- MCP servers can also act as **channels**, pushing external events (Telegram, Discord, webhooks) into a running session so Claude reacts while you're away — relevant if the ERP build-OS wants event-driven agents (e.g., react to a CI failure webhook).
- Best practice for large builds: prefer CLI tools (`gh`, `aws`, `gcloud`) over MCP where a mature CLI exists — Anthropic's own guidance calls CLI tools *"the most context-efficient way to interact with external services"*; reach for MCP for things with no good CLI (Figma, Notion, a proprietary DB).

**Confidence: high** for mechanics; MCP tool-search/context-deferral behavior confirmed via the official "How Claude Code works" page.

---

## 7. Plan Mode

- Toggle: `Shift+Tab` (cycles Default → Auto-accept edits → Plan mode → Auto mode), or start directly with `claude --permission-mode plan`.
- In plan mode Claude reads/explores/answers but **does not edit source files**; other permission prompts still apply as in default mode.
- Official 4-phase workflow: **Explore** (read-only, ask questions) → **Plan** (ask for a detailed implementation plan; `Ctrl+G` opens the plan in your editor for direct hand-editing) → **Implement** (exit plan mode, code against the plan, run tests) → **Commit**.
- Explicit guidance on *when to skip it*: "if you could describe the diff in one sentence, skip the plan" — planning is overhead that pays off for multi-file changes, unfamiliar code, or genuine uncertainty about approach, not for typo fixes.
- `opusplan` model alias (see §12) operationalizes "plan with the strong model, execute with the cheap one" as a single setting rather than a manual toggle.
- Headless plan mode exists for CI: `claude --print --permission-mode plan "your task"`.

**Confidence: high.**

---

## 8. settings.json & permissions

- Precedence (highest wins): **Managed** (org-deployed, cannot be overridden) → CLI flags → **Local** (`.claude/settings.local.json`, gitignored, personal) → **Project** (`.claude/settings.json`, git-committed, team) → **User** (`~/.claude/settings.json`). Array-type settings (like permission rules) generally **merge/union** across scopes rather than override, except when the highest-precedence managed source defines a list, which then replaces rather than merges (behavior confirmed as of Claude Code v2.1.175+). **Confidence: high** on precedence order; **medium** on exact merge semantics for every key — verify per-key before hard-coding into automation.
- Permission rules take the form `Tool(pattern)`, e.g. `Bash(npm run lint)`, `Bash(npm run test *)`, `Read(~/.zshrc)`, `Write(./dist/**)`. Three buckets: `allow`, `deny`, `ask`. **Deny wins** over allow when both match.
- Three ways to reduce prompt fatigue, in increasing order of automation trust: (1) **allowlist** specific known-safe commands (`npm run lint`, `git commit`) via `/permissions`; (2) **Auto mode** — a separate classifier model reviews each action and blocks only what looks risky (scope escalation, unknown infra, hostile-content-driven actions), currently a **research preview**; (3) **Sandboxing** (`/sandbox`) — OS-level isolation restricting filesystem/network access so Claude can act more freely inside a hard boundary.
- For unattended `claude -p` runs, auto mode has no human to fall back to, so it **aborts if the classifier repeatedly blocks actions** rather than hanging.
- MCP servers, hooks, and per-project trust are also scoped through this same settings hierarchy; a project's committed `allow` rules require a one-time workspace-trust confirmation, while `.local.json` allow rules (personal) bypass that dialog.

**Confidence: high** on the core mechanism; **medium** on exhaustive field names beyond `permissions`/`hooks`/`model`/`env` — the settings schema is large and evolves between versions, so the playbook should treat `permissions.{allow,deny,ask}`, `hooks`, `model`, and `env` as the stable, load-bearing keys, and verify anything more exotic (e.g., auto-mode classifier config, sandbox credential scoping) against the live docs before depending on it.

---

## 9. Headless & background patterns

- `claude -p "prompt"` (a.k.a. `--print`) runs non-interactively: no session UI, prints result, exits. This is the integration point for CI, pre-commit hooks, and any scripted pipeline.
- Output formats: plain text, `--output-format json` (structured, parseable), `--output-format stream-json --verbose` (real-time streaming, good for progress UIs).
- Tool scoping for unattended runs: `--allowedTools "Edit,Bash(git commit *)"` restricts what an unattended agent can touch — treat this as **mandatory** for any headless/CI invocation in an ERP build-OS, not optional.
- **Fan-out pattern** for large mechanical migrations: generate a file list, then loop `claude -p` per file with scoped tools:
  ```bash
  for file in $(cat files.txt); do
    claude -p "Migrate $file from React to Vue. Return OK or FAIL." \
      --allowedTools "Edit,Bash(git commit *)"
  done
  ```
  Anthropic's own guidance: test on 2–3 files first, refine the prompt against observed failures, *then* run at scale.
- Background shell processes started during a `claude -p` run (e.g., a dev server) are killed ~5 seconds after Claude returns its final result and stdin closes — **but background subagents/workflows are exempt** from that grace window because their output is part of the final result; `claude -p` waits for them, capped at **10 minutes by default since v2.1.182** so a stuck background agent can't hold the process open indefinitely. **Confidence: medium-high** (specific version/timing sourced from community docs, not directly fetched from the primary page — treat exact numbers as **unverified as of 2026-07**, re-check before hard-coding a timeout into the playbook).
- `claude --continue` / `claude --resume` reopen a saved session (same session ID, history appended); `--fork-session` / `/branch` copy history into a new session ID. Sessions are stored as plaintext JSONL under `~/.claude/projects/`, tied to the working directory — this is the mechanism that makes multi-day/multi-sitting builds practical without re-explaining context each time. Name sessions with `/rename` so a long ERP build can be resumed by name across days.
- Auto mode headless: `claude --permission-mode auto -p "fix all lint errors"`.

**Confidence: high** for the core `-p`/headless mechanics (official docs); **medium** for the background-task timing specifics flagged above.

---

## 10. Multi-agent orchestration: three distinct primitives, not one

As of 2026, Claude Code has **three separate orchestration mechanisms** with genuinely different architectures — the playbook should not conflate them:

| | Subagents | Agent Teams | Dynamic Workflows |
|---|---|---|---|
| What it is | A worker Claude spawns | A lead session + peer sessions | A JS script the runtime executes |
| Who decides what runs next | Claude, turn by turn | The lead agent, turn by turn | The script |
| Where results live | Claude's context window | A shared task list | Script variables |
| Communication | Report to caller only, never to each other | Teammates message each other directly via a mailbox | N/A — orchestrated in code |
| Scale | A few delegated tasks per turn | A handful (3–5 recommended) of long-running peers | Up to **16 concurrent agents**, **1,000 agents total per run** |
| Interruption | Restarts the turn | Teammates keep running | Resumable in the same session |
| Status | Stable | **Experimental, disabled by default** (`CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS`) | Stable, v2.1.154+, all paid plans |

**Agent Teams**: one session is the "lead," teammates are full independent Claude Code instances with their own context window, coordinating via a shared task list (pending/in-progress/completed, with dependency blocking and file-locking on claim) and direct agent-to-agent messaging. Best for genuinely independent parallel work that benefits from **debate** — e.g., 5 teammates each investigating a different root-cause hypothesis for a bug and actively trying to disprove each other (explicitly designed to counter anchoring bias from sequential single-agent investigation), or 3 reviewers each auditing a PR through a different lens (security/performance/test-coverage). Start with **3–5 teammates**, **5–6 tasks per teammate**. Teammates do *not* inherit the lead's conversation history (only CLAUDE.md/MCP/skills), so the spawn prompt must be self-contained. Known limitations: no session-resumption for in-process teammates, no nested teams, one team per session, permissions fixed at spawn (inherit the lead's mode), task-completion status can lag. Hooks (`TeammateIdle`, `TaskCreated`, `TaskCompleted`) let you enforce quality gates on team behavior.

**Dynamic Workflows** (`/workflows`, keyword `ultracode` in a prompt, or `/effort ultracode` to make it the session default): Claude *writes a script* (plain JS with top-level `await`, using `agent()` and `pipeline()` primitives) that orchestrates subagents deterministically in the background while the interactive session stays free. This is the mechanism built for genuine **scale** — "dozens to hundreds of agents per run" — codebase-wide audits, 500-file migrations, adversarial cross-checking of research claims. The bundled `/deep-research` command is a workflow. Scripts are saved to `.claude/workflows/` (project, shared) or `~/.claude/workflows/` (personal) and become reusable `/`-commands with an `args` parameter for repeat runs. Constraints: no mid-run user input (only permission prompts pause it), no direct filesystem/shell access from the *script itself* (only the agents it spawns touch the filesystem), and the caps above. Workflow-spawned subagents always run in `acceptEdits` mode and inherit the session's tool allowlist regardless of the launching session's permission mode — so pre-populate the allowlist before a big run or expect mid-run prompts.

**Recommendation for an ERP build-OS**: default to **subagents** for the 80% case (research, verification, isolated focused tasks). Reach for **dynamic workflows** when a build phase decomposes into a large, mostly-independent batch (e.g., "generate CRUD scaffolding for 40 entities," "audit every module for a missing tenant-isolation check") — codify it as a saved workflow so it's re-runnable and auditable as a script, not a conversation. Reach for **agent teams** only for genuinely adversarial/exploratory sub-problems (architecture bake-offs, root-cause debates) — and keep it opt-in (it's experimental and disabled by default) rather than a hard-coded default, given its documented limitations around resumption and shutdown reliability.

**Confidence: high** for architecture/mechanics (official docs, freshly fetched); **medium** on whether "Agent Teams" will graduate out of experimental status on any particular timeline — re-check before depending on it in a shipped playbook.

---

## 11. Context-window management: compaction & the rewind heuristic

- Official mechanism (confirmed): as context fills, Claude Code **clears older tool outputs first, then summarizes the conversation if needed**. Your requests and key code snippets are preserved; detailed early instructions may be lost — which is precisely why persistent rules belong in CLAUDE.md, not conversation history.
- **Manual controls**: `/clear` (nuke context, e.g. between unrelated tasks — the official guidance is to use this *frequently*, not sparingly); `/compact <instructions>` (targeted compaction, e.g. `/compact focus on the API changes`); `Esc+Esc` or `/rewind` (open a checkpoint menu to restore conversation and/or code state, or choose "Summarize from here" / "Summarize up to here" for partial compaction). Every prompt creates a checkpoint automatically (file snapshots before every edit); checkpoints persist across sessions but are **not a git substitute** — they only track Claude's own changes.
- CLAUDE.md can carry a "Compact Instructions" section telling the compactor what to preserve (e.g., modified-file list, test commands) — treat this as a required field in any ERP build-OS's CLAUDE.md template.
- **The "70–75% rule"**: community best practice (**not found as an official Anthropic number as of 2026-07 — mark as community heuristic, unverified**) is to run `/compact` manually once usage hits ~70–75%, rather than waiting for auto-compact, because compacting mid-task (auto-compact commonly triggers in the ~75–92% band per community reporting) risks losing thread on a critical step. Official guidance is directionally consistent but doesn't commit to a hard percentage — it just says compaction happens "automatically when you approach context limits" and recommends proactive `/clear`/`/compact` discipline plus `/context` to watch usage. For Sonnet 5 specifically, the **official, exact, sourced number** is: auto-compact fires at **~967K tokens by default** on its native 1M window (configurable via `CLAUDE_CODE_AUTO_COMPACT_WINDOW`) — i.e., roughly the same ~95%-of-window ballpark the community heuristic is triangulating toward, just for a different window size.
- **Failure-correction heuristic (official)**: if you've corrected Claude more than twice on the same issue in one session, `/clear` and restart with a better initial prompt that incorporates what you learned — a clean session with a sharper prompt "almost always" beats a long session with accumulated failed corrections.
- **Subagents as context firewall**: since context is the fundamental constraint, delegating exploration/research to subagents (which return only a summary) is explicitly called out as "one of the most powerful tools available" for keeping the main/orchestrator session's context clean during a long build.
- `/context` shows a live breakdown of what's consuming the window; `/mcp` shows per-MCP-server token cost — both should be checked periodically during a long autonomous run rather than only reactively.

**Recommendation for the playbook**: hard-code a **75%-usage checkpoint discipline** as the default operating rule for long orchestrated builds (check `/context` at natural phase boundaries; proactively `/compact` with explicit preserve-instructions rather than trusting auto-compact mid-phase), explicitly flagging it as a *conservative community-derived heuristic layered on top of* the confirmed official behavior (clear-then-summarize, ~95%-ish auto-trigger band), not an official Anthropic-published percentage.

**Confidence: high** on mechanism; **medium** on the specific 70–75% number as a hard threshold.

---

## 12. Model selection: orchestrator vs. subagent, and effort levels

- **Aliases** (`sonnet`, `opus`, `haiku`, and — per the live docs fetched 2026-07-06 — a newer top-tier alias `fable`/`best`) resolve to the current recommended version per provider and **update over time**; pin an exact model string (e.g. `claude-opus-4-8`) only when you need version stability (e.g., regression-sensitive CI). **Note**: the docs fetched during this research describe model names beyond the historical Opus/Sonnet/Haiku triad (a "Claude Fable 5" / "Claude Mythos 5" family positioned as the most-capable tier for long autonomous sessions). This is a substantive naming change from what's commonly known — **flag explicitly as unverified/needs-reconfirmation as of 2026-07**: treat the *pattern* (a "hardest/longest-task" tier above Opus) as directionally plausible but re-verify the exact product name against a second source (release notes, `/model` picker output) before hard-coding it into a playbook, since this diverges sharply from prior public naming.
- **`opusplan` alias**: automated hybrid — uses Opus during plan mode (reasoning/architecture), auto-switches to Sonnet for execution (code generation). This is Anthropic's own packaged version of "Opus orchestrator, Sonnet executor," available as a single `/model opusplan` setting rather than a manual per-phase switch.
- **`CLAUDE_CODE_SUBAGENT_MODEL`** env var forces a model for *all* subagents and agent-team teammates, overriding per-subagent frontmatter — the cleanest way for a build-OS to enforce "all subagents run on Sonnet unless explicitly overridden."
- **Effort levels** (`low`, `medium`, `high`, `xhigh`, `max`, plus the workflow-triggering `ultracode`): adaptive-reasoning control, not a separate model. Default is `high` on current-generation models. Official guidance: **`max` is explicitly not a "set it and forget it" default** — it "can improve performance on demanding tasks but may show diminishing returns and is prone to overthinking… test before adopting broadly." Similarly, community sourcing (not the primary doc) reports higher effort levels can make Claude "overthink routine work — slower, more hedged, more verbose output." **Recommendation**: default orchestrator sessions to `high` (the model default), reserve `max`/`xhigh` for specific hard phases (architecture decisions, root-cause debugging), and set it per-task rather than pinning `max` for an entire long build.
- **`ultracode`** (`/effort ultracode`) combines `xhigh` reasoning with automatic dynamic-workflow orchestration for every substantive task in the session — powerful but burns meaningfully more tokens/time per the docs' own framing; treat as an opt-in mode for specific heavy build phases, not a session default.
- Per-subagent and per-skill `model`/`effort` frontmatter fields let you tune cost/quality per role (e.g., a Haiku-powered file-lister/explorer + a Sonnet-powered reviewer, reserving Opus for the orchestrator's own reasoning) — community sourcing suggests this Haiku-explorer + Sonnet-reviewer pairing covers "80% of subagent use cases" (**unverified as of 2026-07**, but architecturally consistent with the documented cost/latency tradeoffs).

**Recommended default for an ERP build-OS orchestrator** (synthesizing the above, opinionated):
- **Orchestrator/main session**: top-tier reasoning model (`opus` alias, or `opusplan` if you want automatic plan/execute model-switching built in) at `high` effort by default, escalate to `max`/`xhigh` only for architecture/root-cause phases.
- **Subagents**: `sonnet` by default (set via `CLAUDE_CODE_SUBAGENT_MODEL=sonnet` or per-agent frontmatter) for code-generation/execution work; drop to `haiku` for pure exploration/listing subagents where reasoning depth doesn't matter.
- **Verification/review subagents**: keep on a capable model (Sonnet minimum, Opus for security-sensitive reviews) since these are your correctness backstop — the official example security-reviewer subagent is defined with `model: opus`.

**Confidence: high** on the mechanics (aliases, opusplan, effort levels, `CLAUDE_CODE_SUBAGENT_MODEL`) — directly from the fetched model-config doc; **medium-low** specifically on the exact current top-tier model *name* ("Fable 5") — flag for reconfirmation; **medium** on the "80% of use cases" Haiku+Sonnet split (community claim).

---

## 13. Concrete defaults to hard-code into the orchestrator playbook

1. **CLAUDE.md**: keep under ~100 lines; include a "Compact Instructions" section; check it into git; treat every line as a liability, not an asset, until proven necessary.
2. **Plan mode by default for any multi-file or unfamiliar-code task**; skip it for single-sentence-describable diffs.
3. **Stop hook running the test/build suite** as the default unattended-completion gate for any build phase run headless or via workflow; remember the 8-consecutive-block override ceiling and design checks that converge.
4. **PreToolUse hooks** blocking writes outside the repo root and blocking destructive shell patterns (`rm -rf`, `terraform apply`, prod-credential writes) — non-negotiable for any phase run with `--dangerously-skip-permissions` or auto mode.
5. **Subagents as default delegation unit**; escalate to a saved **Dynamic Workflow** for any phase that's inherently a large batch (many files/modules/entities) and worth being re-runnable as code; reserve **Agent Teams** for explicitly adversarial/exploratory sub-problems, and keep them opt-in given experimental status.
6. **`--allowedTools` scoping mandatory** on every headless (`claude -p`) invocation — never run unattended with unrestricted tool access.
7. **Model split**: Opus/top-tier alias for the orchestrator, Sonnet for subagents (enforce via `CLAUDE_CODE_SUBAGENT_MODEL`), Haiku for pure-exploration subagents. Default effort `high`; escalate deliberately, don't default to `max`.
8. **Context discipline**: `/clear` between unrelated build phases; `/compact` proactively at ~70–75% usage (community heuristic) rather than only trusting auto-compact; `/clear`-and-restart after 2 failed corrections on the same issue (official heuristic); check `/context` at phase boundaries.
9. **Adversarial review as a standing step**: after any autonomous phase finishes, run a fresh-context subagent (or workflow) reviewing the diff against the phase's stated plan/requirements, reporting only correctness/requirement gaps.
10. **Session naming/resumption**: `/rename` every long-build session so multi-day work resumes by name (`claude --resume`), since sessions are directory-scoped and independent by default.

---

## Sources

- [Best practices for Claude Code](https://code.claude.com/docs/en/best-practices) — Anthropic, fetched 2026-07-06
- [Hooks reference](https://code.claude.com/docs/en/hooks) — Anthropic, fetched 2026-07-06
- [Create custom subagents](https://code.claude.com/docs/en/sub-agents) — Anthropic
- [How Claude Code works](https://code.claude.com/docs/en/how-claude-code-works) — Anthropic, fetched 2026-07-06
- [Model configuration](https://code.claude.com/docs/en/model-config) — Anthropic, fetched 2026-07-06
- [Orchestrate subagents at scale with dynamic workflows](https://code.claude.com/docs/en/workflows) — Anthropic, fetched 2026-07-06
- [Orchestrate teams of Claude Code sessions (agent teams)](https://code.claude.com/docs/en/agent-teams) — Anthropic, fetched 2026-07-06
- [Connect Claude Code to tools via MCP](https://code.claude.com/docs/en/mcp) — Anthropic, fetched 2026-07-06
- [Claude Code settings](https://code.claude.com/docs/en/settings) — Anthropic (fetched via summarized proxy; verify exact field names before hard-coding)
- [Run Claude Code programmatically (headless mode)](https://code.claude.com/docs/en/headless) — Anthropic
- [Claude Code permission modes](https://code.claude.com/docs/en/permission-modes) — Anthropic
- Community/secondary (used only for flagged, explicitly-marked "unverified" claims: 70–75% compaction heuristic, background-task 5s/10min timing, "80% of subagent use cases" Haiku+Sonnet split): various 2026 blog posts (Totalum, ofox.ai, okhlopkov.com, claude-code-examples.vercel.app, TurboAI) surfaced via web search 2026-07-06 — none used as sole support for a load-bearing claim without an official-doc cross-check.

**Overall confidence**: High on architecture, mechanics, and official configuration surface (CLAUDE.md, subagents, skills, hooks, MCP, plan mode, headless mode, workflows, agent teams, model/effort config) — all directly fetched from `code.claude.com/docs` on 2026-07-06. Medium/flagged on: exact current top-tier model naming ("Fable 5"), precise auto-compact percentage thresholds outside the one confirmed Sonnet-5-specific number (~967K/1M tokens), and several specific numeric community heuristics (75% rule, background-task timeouts, Haiku/Sonnet split ratio) — each explicitly marked inline above.
