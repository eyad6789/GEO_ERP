# AR5 — The One-Number Problem: A Governed Semantic/Metrics Layer for ERP

**Scope**: why "two reports disagree," the headless-BI/semantic-layer pattern, 2026 tool landscape, applying it *inside* an ERP (not bolted onto a warehouse), metric lineage/certification, and the interplay with an event-sourced, bitemporal ledger. Ends with a proposed default stack.

---

## 1. Why two reports disagree: the anatomy of definition drift

"Revenue is down 8%" from Finance and "Revenue is up 3%" from Sales in the same board deck is almost never a data-quality bug — the rows are usually correct. It's a **definition drift** bug: the same English word is bound to two different computations. In practice drift enters at five points, each of which recurs identically inside an ERP:

1. **Grain and join-path drift.** "Revenue" via the order-line fact joined to a return-adjusted shipment fact differs from "revenue" via the invoice header. Two BI tools, two dbt models, two spreadsheets — three join paths, three numbers.
2. **Filter/scope drift.** "Active customer" for Sales means "placed an order in 90 days"; for Support it means "has a live contract." "Headcount" for HR includes contractors; for Finance's cost model it doesn't.
3. **Temporal-cut drift** (the ERP-specific one). "AR balance as of June 30" can mean *the balance the ledger shows today for transactions dated ≤ June 30* (valid-time cut) or *the balance we actually reported in the June 30 close, before later corrections* (system-time cut). These are legitimately different numbers, and most tools can only compute one of them.
4. **Aggregation-function drift.** DSO computed as `(ending AR / total sales) × days` vs. `(average AR / credit sales) × days` — both are "DSO," and can differ by double digits of days for a seasonal business.
5. **Recency/currency drift.** A cached extract in a spreadsheet vs. a live query against the operational ledger; nobody labels the extract with its as-of timestamp.

The fix for (1),(2),(4),(5) is a **semantic layer**: define the metric once, in code, and force every consumption surface to call that definition rather than re-deriving it. The fix for (3) requires the semantic layer to be *temporal-cut aware* — it must accept and propagate `valid_time` and `system_time` (or `record_time`) parameters, not just a single `as_of` date. This is the part general-purpose BI semantic layers get wrong by default and that an ERP build must add deliberately (§5).

## 2. The headless-BI / semantic-layer pattern

"Headless BI" = a metrics/semantic layer with no attached visualization UI: metrics, dimensions, joins and access rules are modeled once in a git-versioned repo and exposed over multiple protocols (SQL, REST, GraphQL, and increasingly MCP for AI agents) to any downstream consumer — a BI tool, a spreadsheet plugin, a chatbot, or an AI agent (Cube.dev, ["Best Semantic Layer for AI and BI (2026)"](https://cube.dev/articles/best-semantic-layer-for-ai-and-bi-2026)). The core claim, and the reason this pattern is the right default for an ERP: **the metric logic must live below the visualization layer and above the raw tables**, as a versioned artifact with owners, tests, and certification — not embedded in a Tableau workbook's calculated field, a Python notebook, or an LLM's system prompt.

Architecturally:

```
 raw operational tables / event log (ledger)
        │
 semantic models  (entities, dimensions, measures)   <- dbt MetricFlow "semantic_models"
        │
 governed metrics (simple / ratio / derived / cumulative)  <- MetricFlow "metrics", Cube "views"
        │
 query surfaces: SQL API · REST · GraphQL · MCP (agents) · JDBC/ODBC (BI tools)
        │
 consumers: BI dashboards · finance close workbook · AI copilot · embedded app widget
```

Every consumer asks the semantic layer for `revenue`, `gross_margin`, `headcount`, `dso` by **name**, with dimensional slices and a time grain — never by re-deriving SQL. This is the single mechanical guarantee that produces "the one number."

## 3. 2026 tool landscape

| Tool | Model | 2025–2026 status | Fit for ERP use |
|---|---|---|---|
| **dbt Semantic Layer / MetricFlow** | Metrics-as-code YAML compiled to SQL; JDBC/GraphQL/Python APIs; "Exports" materialize metrics on a schedule | GA on dbt Cloud (Starter tier+); MetricFlow open-sourced under dbt Labs, actively maintained ([dbt Developer Hub](https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl); [MetricFlow GitHub](https://github.com/dbt-labs/metricflow)) | Best where the ERP's reporting mart is already dbt-modeled; ties metric certification to existing dbt tests/docs |
| **Cube (Cube Core)** | Data model in YAML/JS/Python; semantic layer exposed via SQL, REST, GraphQL, and **MCP** for agent access; open-source core + commercial Cube Cloud | Actively positioned in 2026 explicitly as "the agentic analytics platform built on a semantic layer," with first-class MCP so agents "discover governed metrics and request them by name" ([Cube.dev](https://cube.dev/); [Cube "Semantic Layer for AI Agents (2026)"](https://cube.dev/articles/semantic-layer-for-ai-agents-2026)) | Best default for an ERP because it is warehouse-agnostic (works directly against Postgres/MySQL/operational stores, not just a warehouse) and ships pre-aggregation/caching for operational-latency dashboards |
| **AtScale** | Virtual cubes over the warehouse, OLAP-style | Established enterprise player, less AI/agent-native messaging than Cube in 2026 | Viable alternative if org already has AtScale/OLAP investment |
| **Looker / LookML** | Metrics defined in LookML, tightly coupled to Looker's own BI front end | Mature but vendor-coupled — LookML metrics aren't as easily consumed headlessly by non-Looker/non-Google surfaces | Weak fit if the goal is a *headless* layer independent of the BI front end |
| **Databricks Unity Catalog Metric Views** | Metrics as catalog objects (SQL-defined, YAML-managed via Git) | Growing 2025–2026 feature; still requires custom CI/CD to deploy metric definitions as objects (per community write-ups on semantic-layer drift) | Fits if the ERP's analytical estate is Databricks-native |
| **Snowflake Semantic Views / Cortex Analyst** | Native semantic model object in Snowflake, consumed by Cortex Analyst (NL-to-SQL) and BI tools | Snowflake is a founding driver of OSI (below); native semantic views ship in 2025–2026 Snowflake releases | Fits if warehouse is Snowflake and NL/agent query is a first-class requirement |
| **Malloy (Google)**, **Honeydew**, **Omni** | Modeling-language / semantic-layer entrants | Present in the OSI working group as of 2025–2026; smaller install base | Watch-list, not yet a safe long-term default |

### The interoperability development: Open Semantic Interchange (OSI)

On **2025-09-23**, Snowflake, Salesforce, dbt Labs, BlackRock, RelationalAI and others announced the **Open Semantic Interchange** initiative — a vendor-neutral, Apache-2-licensed specification for representing "data sets, metrics, dimensions, relationships and contexts" so semantic models can move between vendors instead of being re-authored per tool ([Snowflake press release](https://www.snowflake.com/en/news/press-releases/snowflake-salesforce-dbt-labs-and-more-revolutionize-data-readiness-for-ai-with-open-semantic-interchange-initiative/); [Salesforce, "Ending Semantic Drift"](https://www.salesforce.com/blog/ending-semantic-drift-unified-business-logic-foundation/)). The coalition explicitly named the problem this report is about: "two definitions exist for one metric with no guarantee they agree." By **2026-01-27** the first version of the OSI specification was finalized and published, with the coalition expanding past 30 organizations (Databricks, Qlik, Collate joined) and a stated path toward "a neutral, foundation-led governance model" ([Snowflake, "OSI Specification Finalized"](https://www.snowflake.com/en/blog/open-semantic-interchanges-specs-finalized/)). As of 2026-07, concrete vendor *conformance* (which tools actually import/export OSI-format models today, vs. merely endorsing the spec) is **unverifiable as of 2026-07** — treat OSI as a portability target to design toward, not yet a drop-in interchange you can depend on in production.

**Opinionated take**: don't wait for OSI to mature before shipping a semantic layer — build on dbt MetricFlow and/or Cube now, but keep metric definitions in plain, diffable YAML/code (not a vendor's proprietary binary project format) so a future OSI export is a translation exercise, not a rewrite.

## 4. Applying this inside an ERP, not just a warehouse

A generic semantic layer tutorial assumes: raw events → warehouse tables → dbt marts → semantic layer → BI. An ERP breaks that assumption in three ways, and the playbook must say so explicitly:

**(a) The "raw tables" are transactional, mutable, and operational-latency-sensitive.** GL entries, AR invoices, PO lines are being read/written by the ERP's own OLTP workload at the same time analytics wants to query them. The semantic layer therefore cannot only be a batch dbt-on-warehouse pattern computed nightly — for operational metrics (open AR aging, today's DSO, current headcount) it needs either (i) a semantic layer that can query the operational store directly with pre-aggregation/caching (Cube's model), or (ii) a low-latency CDC/streaming path (e.g., Debezium → append-only event log → materialized semantic views) so "today's number" isn't 24 hours stale.

**(b) Metrics must be defined per bounded context, then composed.** Don't build one monolithic `metrics.yml`. Each ERP module (GL, AR/AP, Inventory, HR/Payroll, Order-to-Cash) owns its semantic model and its own certified metrics (module owner = data steward), and cross-module metrics (e.g., "revenue per employee" = Revenue ÷ Headcount) are **derived metrics** that reference the two upstream certified metrics rather than re-deriving from raw tables. This mirrors DDD bounded-context ownership and keeps the metric graph aligned with who can actually attest to correctness.

```yaml
# semantic_models/ar.yml  (MetricFlow-style sketch)
semantic_models:
  - name: ar_invoice
    model: ref('fct_ar_invoice')
    defaults:
      agg_time_dimension: invoice_date
    entities:
      - name: customer
        type: foreign
      - name: invoice
        type: primary
    dimensions:
      - name: invoice_date
        type: time
        type_params: {time_granularity: day}
      - name: business_unit
        type: categorical
    measures:
      - name: invoice_amount
        agg: sum
        expr: amount_local_ccy
      - name: ar_open_balance
        agg: sum
        expr: open_balance   # reads bitemporal view at valid_time = query as_of
        agg_time_dimension: invoice_date

metrics:
  - name: revenue
    label: "Revenue"
    type: simple
    type_params: {measure: invoice_amount}
    meta: {certified: true, owner: finance_data_team, certified_on: "2026-05-12"}

  - name: dso
    label: "Days Sales Outstanding"
    type: derived
    type_params:
      expr: (ar_open_balance / credit_sales_90d) * 90
      metrics: [ar_open_balance, credit_sales_90d]
    meta:
      certified: true
      owner: finance_data_team
      definition_note: >
        Ending-balance method over trailing-90-day credit sales.
        NOT average-AR method — see ADR-014 for why this was chosen.
```

The `definition_note` is not decoration — DSO has at least two industry-standard formulas (ending-balance vs. average-AR); the semantic layer's *job* is to end the argument by publishing which one is canonical, with the rationale, so nobody quietly recomputes the other in a spreadsheet.

**(c) Access control must be metric-aware, not just table-aware.** ERP data has row-level sensitivity (payroll, individual compensation, customer-level margin) that table-grants don't express well. Cube and dbt Semantic Layer both support attaching row/column-level policies to the semantic model rather than the physical table, which is required in an ERP context (e.g., a regional controller can query `headcount` and `revenue` sliced by their region but not see individual comp).

## 5. Metric lineage and certification

A metric is not "governed" until it has: an **owner**, a **certification state**, **tests**, and **lineage** (what it's built from, and what's built from it).

Minimal certification lifecycle (default to adopt):

```
draft → proposed → reviewed (data steward) → certified → deprecated
```

- **`draft`**: any engineer/analyst can define a metric candidate in a PR.
- **`proposed`**: attached to an ADR-style note explaining formula choice (as in the DSO example above) and passed through CI: unit tests on the SQL, a reconciliation test against the previous "legacy" number for N historical periods, and a dimensional-consistency check (does slicing by region sum to the whole?).
- **`certified`**: merged by the metric's data-steward owner (Finance owns revenue/margin/DSO; People/HR owns headcount; each module owner owns their metrics) with a `certified: true` flag and `certified_on` date in the metric's metadata block, surfaced in every downstream BI tool so a viewer can see "certified by Finance on 2026-05-12" next to the number.
- **`deprecated`**: old metric kept queryable (with a warning banner) for a grace period, pointing at its replacement, so historical dashboards don't silently break.

**Lineage** should be tracked as a directed graph: raw table → semantic model → base measure → metric → derived metric → dashboard/report, and this graph must be diffable in CI (a PR that changes a base measure should flag every certified metric and dashboard downstream of it for re-review). In practice: dbt's built-in DAG + `dbt docs`/catalog metadata covers metric-to-model lineage; pair it with **OpenLineage**-emitting jobs (ingest/CDC pipelines feeding the semantic layer) and a catalog (DataHub, Atlan, Select Star — all OSI working-group members) for end-to-end lineage from ERP transaction table to board-deck number. Certification badges from the metric layer should be mirrored into the catalog so search/discovery surfaces "certified" status, not just the semantic layer's own UI.

## 6. Interplay with the event-sourced ledger and bitemporal as-of queries

This is the part that's specific to an ERP and mostly absent from generic BI semantic-layer literature, and it's where the playbook must be prescriptive.

If the ERP's ledger is **event-sourced** (append-only journal of posted transactions, corrections themselves are new events, never in-place UPDATEs) and **bitemporal** (each fact carries both a **valid-time** — the business/effective date, e.g., invoice date, GL posting period — and a **system/transaction-time** — when the system learned/recorded the fact), then every metric that reads from the ledger has an implicit third parameter beyond its filters and grain: **which time axis, and which cut of it, is this number as-of?**

Two distinct, both-legitimate questions an ERP must be able to answer without ambiguity:

1. *"What is AR as of June 30, using everything we know **today**?"* → valid-time cut at `2026-06-30`, system-time cut at `now()`. This is the "corrected"/best-current-knowledge view — useful for operational monitoring.
2. *"What did we **report** as AR at the June 30 close?"* → valid-time cut at `2026-06-30`, system-time cut at `close_timestamp('2026-06-30')`. This is the immutable, as-reported view — required for audit, SOX walkthroughs, and explaining "why did the number I saw in July differ from the close deck."

A metric definition that doesn't force the caller to pick one of these (or defaults silently to "now") is the single most common source of "the number changed since last week" complaints in ERP finance teams — not because the system is wrong, but because a correction posted with an earlier valid-time landed in the ledger after the original report was cut.

**Design consequence for the semantic layer:**

- Every time-sensitive semantic model/measure built on the ledger must expose **two temporal parameters**, not one: `as_of_valid_time` (business date) and `as_of_system_time` (knowledge/system date), defaulting `as_of_system_time = now()` only when the caller doesn't ask for a specific reporting snapshot.
- The underlying store should implement this with SQL:2011-style bitemporal constructs — `PERIOD FOR APPLICATION_TIME` / `PERIOD FOR SYSTEM_TIME` (as in SQL Server, or the Postgres `periods` extension, since native Postgres 18 only ships application-time support, not system-versioning — [PostgreSQL wiki, SQL2011Temporal](https://wiki.postgresql.org/wiki/SQL2011Temporal); [Illuminated Computing survey of SQL:2011 temporal features](https://illuminatedcomputing.com/posts/2019/08/sql2011-survey/)) — or a purpose-built bitemporal engine (e.g., XTDB) that natively supports `valid-time`/`system-time` queries ([XTDB, "Bitemporality"](https://v1-docs.xtdb.com/concepts/bitemporality/)).
- A metric SQL body reads from a bitemporal view, not the raw event log directly:

```sql
-- bitemporal AR-balance view (Postgres + periods-extension style sketch)
CREATE VIEW v_ar_balance_asof AS
SELECT customer_id, business_unit,
       sum(amount) AS ar_open_balance
FROM   ar_ledger
FOR PORTION OF valid_time  FROM :as_of_valid  TO :as_of_valid
FOR SYSTEM_TIME AS OF        :as_of_system
GROUP BY customer_id, business_unit;
```

  and the semantic-layer metric (`ar_open_balance`) is parameterized to pass both cuts through, so `dso(as_of_valid_time = '2026-06-30', as_of_system_time = close_ts)` and `dso(as_of_valid_time = '2026-06-30', as_of_system_time = now())` are both first-class, nameable, certified queries — not two people's separate spreadsheet reconstructions.
- **Certification must include the temporal-semantics decision** (see the `definition_note` field in §4) — i.e., "this metric defaults to as-reported (system-time frozen at period close) unless overridden" is itself a governed, documented, owned decision, exactly like the DSO formula choice.

This is the concrete bridge between AR2 (event-sourced/bitemporal ledger) and AR5 (semantic layer): the semantic layer is the place where the ledger's two-time-axis complexity gets turned into a small number of named, certified, parameterized metrics — so consuming agents/humans never have to reconstruct a bitemporal SQL query by hand, they just call `dso(as_of='close:2026-06-30')`.

## 7. Proposed default

For an ERP build operating system, adopt as the default, in priority order:

1. **Semantic layer engine: Cube (Cube Core, open-source)** as the primary headless query surface — because it can sit directly over the operational/OLTP store as well as a warehouse, supports pre-aggregation for operational-latency metrics, and ships MCP + SQL/REST/GraphQL out of the box for both human BI tools and AI agents ([Cube.dev](https://cube.dev/)). Where the org is already deeply dbt-centric for the analytical mart, run **dbt Semantic Layer/MetricFlow** as the metrics-as-code authoring layer feeding into Cube (or standing alone) — the two are not mutually exclusive; MetricFlow can be the "compiler," Cube the "server."
2. **Definitions as version-controlled YAML/code, one file set per bounded context** (GL, AR/AP, Inventory, HR, O2C), reviewed via pull request, with a mandatory `owner`, `certified` flag, `certified_on` date, and free-text `definition_note` capturing any formula-choice ambiguity (DSO method, revenue recognition cut, headcount inclusion rules).
3. **Certification workflow**: draft → proposed (CI: unit test + historical reconciliation + dimensional-consistency check) → certified (steward sign-off) → deprecated (grace period + redirect), mirrored into a catalog (DataHub/Atlan/Select Star) so certification is visible at discovery time, not just at query time.
4. **Bitemporal-aware metric parameters** for every ledger-derived metric: mandatory `as_of_valid_time` + `as_of_system_time`, with metric definitions stating their default (usually "as-reported, frozen at last period close" for financial metrics; "current knowledge" for operational ones), backed by a bitemporal store (native bitemporal engine, or Postgres + the `periods` SQL:2011 extension, or SQL Server system-versioned + application-time tables).
5. **Track OSI, don't bet on it yet.** Author metric YAML in a form that's a mechanical transform away from the OSI spec (avoid vendor-proprietary-only constructs), so that when OSI conformance is real across ≥2 of your chosen vendors, migration is cheap. Re-verify OSI vendor conformance before committing to it as a hard dependency — as of 2026-07 this is spec-published, not conformance-proven, across the tools in your stack (unverifiable as of 2026-07).

---

## Sources

- Cube.dev — ["Best Semantic Layer for AI and BI (2026)"](https://cube.dev/articles/best-semantic-layer-for-ai-and-bi-2026)
- Cube.dev — ["Semantic Layer for AI Agents (2026)"](https://cube.dev/articles/semantic-layer-for-ai-agents-2026)
- Cube.dev — [homepage, "the agentic analytics platform built on a semantic layer"](https://cube.dev/)
- Cube-js/cube — [GitHub repository](https://github.com/cube-js/cube)
- dbt Labs — [dbt Semantic Layer docs](https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl)
- dbt Labs — [About MetricFlow](https://docs.getdbt.com/docs/build/about-metricflow)
- dbt-labs/metricflow — [GitHub repository](https://github.com/dbt-labs/metricflow)
- dbt Labs — [Build your metrics](https://docs.getdbt.com/docs/build/build-metrics-intro)
- dbt Labs — [Creating metrics](https://docs.getdbt.com/docs/build/metrics-overview)
- dbt Labs best practices — ["How we build our metrics" series](https://docs.getdbt.com/best-practices/how-we-build-our-metrics/semantic-layer-4-build-metrics)
- Snowflake — [press release: Open Semantic Interchange Initiative launch, 2025-09-23](https://www.snowflake.com/en/news/press-releases/snowflake-salesforce-dbt-labs-and-more-revolutionize-data-readiness-for-ai-with-open-semantic-interchange-initiative/)
- Snowflake — [OSI specification finalized, 2026-01-27](https://www.snowflake.com/en/blog/open-semantic-interchanges-specs-finalized/)
- Snowflake — [OSI expands partner ecosystem](https://www.snowflake.com/en/blog/osi-initiative-expands-partners/)
- Salesforce — ["Ending Semantic Drift: Unified Business Logic Foundation"](https://www.salesforce.com/blog/ending-semantic-drift-unified-business-logic-foundation/)
- CIO Dive — ["Snowflake leads push to standardize metadata for AI"](https://www.ciodive.com/news/snowflake-standardize-metadata-ai/760948/)
- XTDB — ["Bitemporality" concepts doc](https://v1-docs.xtdb.com/concepts/bitemporality/)
- XTDB — ["Building a Bitemporal Index (part 2): Bitemporal Resolution"](https://xtdb.com/blog/building-a-bitemp-index-2-resolution)
- Martin Fowler — ["Bitemporal History"](https://martinfowler.com/articles/bitemporal-history.html)
- PostgreSQL Wiki — [SQL2011Temporal](https://wiki.postgresql.org/wiki/SQL2011Temporal)
- PostgreSQL Wiki — [Temporal Extensions](https://wiki.postgresql.org/wiki/Temporal_Extensions)
- Illuminated Computing — ["Survey of SQL:2011 Temporal Features"](https://illuminatedcomputing.com/posts/2019/08/sql2011-survey/)
- Microsoft Learn — [Temporal Tables (SQL Server)](https://learn.microsoft.com/en-us/sql/relational-databases/tables/temporal-tables?view=sql-server-ver17)
- Jamie Lord — ["Understanding Bitemporal Primary Keys" (2025-01-28)](https://lord.technology/2025/01/28/understanding-temporal-primary-keys.html)
- Wikipedia — [SQL:2011](https://en.wikipedia.org/wiki/SQL:2011)

*Notes on verification*: Tool-capability claims (Cube's MCP support, dbt Semantic Layer tier availability, OSI dates/membership) are sourced to 2025-2026 vendor/press pages above. The degree of actual cross-vendor OSI *conformance* (as opposed to spec publication and coalition membership) is **unverifiable as of 2026-07** and should be re-checked before being treated as a production dependency. Postgres native bitemporal (system-versioning) support is confirmed absent as of Postgres 18 per the PostgreSQL wiki; the `periods` extension and SQL Server's native system-versioned tables are the verified alternatives.
