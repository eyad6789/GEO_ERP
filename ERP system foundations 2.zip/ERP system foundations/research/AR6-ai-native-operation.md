# AR6 — AI-Native ERP Operation, Done Safely

*Track: AR6-ai-native-operation · Compiled 2026-07-07 · For: ERP Build Operating System playbook*
*Scope: product-capability doctrine for AI features that operate ON a live ERP (not AI that builds it — see R6). Defensive + safe by construction.*

---

## 0. The one doctrine that governs everything below

> **AI PROPOSES. Deterministic engines DISPOSE. Humans authorise anything that moves money. The financial record's determinism and reproducibility are sacred and are never delegated to a probabilistic model.**

An LLM is a non-deterministic, prompt-injectable, occasionally-confabulating text engine. A general ledger is a system of legal record that must reproduce the same balances byte-for-byte on re-run, survive a 7-year SOX audit, and never post an entry no human can attribute. These two things are **architecturally incompatible unless you insert a deterministic gate between them.** Every AI feature in this document is therefore shaped the same way:

```
untrusted input → LLM (propose)  →  structured proposal  →  deterministic engine (validate/authorize)  →  human gate (if it moves money)  →  posting
                   probabilistic      typed, bounded          rules/RBAC/SoD/limits      HITL                 immutable, hash-chained
```

The LLM's output is **never** the side-effect. The LLM's output is always a *proposal object* that a deterministic, testable, versioned engine then accepts, rejects, or routes. This is the same shape the industry converged on in 2025-2026: vendors now openly distinguish "copilot" (surfaces/drafts, human completes every action) from "agentic" (runs a process), and even the aggressive players scope autonomy to **bounded** use cases with human approval loops and SOX-compliant logging (SAP Joule's finance agents, NetSuite's "autopilot," Microsoft Copilot for Finance all ship HITL approval checkpoints as the default, not an add-on) [Stampli, SAP Community, Microsoft, NetSuite/Thurmos]. Notably, SAP's own finance and procurement agents are **powered by Anthropic's Claude** as of the 2026 Joule platform [aimultiple].

This maps onto the four OWASP LLM risks that dominate this surface: **LLM01 Prompt Injection**, **LLM05 Improper Output Handling**, **LLM06 Excessive Agency**, and **LLM02 Sensitive Information Disclosure** [OWASP GenAI 2025]. The doctrine below is engineered to make all four structurally hard to exploit, not just monitored.

---

## 1. Capability tiers and the `ai_capability.*` decision key set

The existing repo has a single `security.ai_copilot` key (`none | draft_only | bounded_auto`). That is too coarse for a product with five distinct AI surfaces at different risk. **PROPOSED:** promote it to an `ai_capability.*` namespace, one key per surface, each an autonomy tier. The tiers are a strict lattice — a surface may never be set higher than the org's risk appetite allows, and **no surface that touches the posting path may ever be set to `auto` for a money-moving action.**

**Autonomy tiers (apply per surface):**

| Tier | Meaning | Money movement allowed? |
|---|---|---|
| `off` | Feature disabled | — |
| `read_only` | AI may read + summarise + answer; zero write proposals | Never |
| `propose` | AI drafts a typed proposal into a queue; a human accepts/rejects; deterministic engine validates on accept | Never auto; human posts |
| `bounded_auto` | AI may auto-*execute* only inside a hard, deterministic allow-list (non-financial, reversible, rate-limited) — e.g. auto-tag, auto-route to a queue, draft an email | Never |
| `auto_post` | **FORBIDDEN by doctrine for any money-moving action.** Reserved only for non-financial idempotent side-effects, and even then requires an explicit locked exception | Never for money |

**PROPOSED `ai_capability.*` defaults (locked at G1):**

```jsonc
"ai_capability": {
  "copilot":            "propose",        // read broad, propose writes, never auto-post
  "doc_ingestion":      "propose",        // OCR+LLM extract → exception queue → human posts
  "anomaly_detection":  "read_only",      // flags + scores only; never blocks/reverses autonomously
  "nl_reporting":       "read_only",      // NL → governed semantic layer; no raw SQL to ledger
  "auto_actions":       "bounded_auto",   // non-financial: tagging, routing, draft comms only
  "money_movement":     "off",            // hard doctrine floor — no AI surface auto-moves money, ever
  "model_provider":     "PROPOSED: Claude (Anthropic) via API; no training on tenant data; data-residency pinned",
  "eval_gate":          "PROPOSED: block release if eval suite < locked thresholds (§7)",
  "log_every_action":   true,             // non-negotiable, see §7
  "human_gate_for_money": true            // non-negotiable
}
```

The last three are **structural, not tunable** — you may change the values above them but not remove the money gate, the per-action log, or the eval gate. This mirrors the repo's existing carve-out pattern (audit-log hash-chain + external anchor are non-negotiable in `06-security-foundations.md`).

---

## 2. The copilot — broad READ, scoped PROPOSE, zero auto-execute

**Design contract:**

1. **The copilot runs as the caller, never as a service super-user.** Every read and every proposed write is evaluated against the *invoking user's* RBAC+ABAC entitlements (row-level: legal entity, business unit, cost centre), enforced by the *same* deterministic authz layer the UI uses — not by the LLM. This is the primary control from repo scenario **SCN-14** and directly answers OWASP **LLM06 Excessive Agency** ("give an agent broader permissions than its task requires and you've created an exploitable attack surface" [OWASP 2025]). If a user can't read vendor DE01's bank details in the UI, the copilot can't either — and can't be talked into it by an injected instruction, because the DB-level RLS check happens *after* the LLM, independent of it.

2. **Reads are broad; writes are proposals only.** The copilot may query the governed read model liberally (subject to authz + rate limits + volume alerts). It may **never** call a mutation tool that posts. Its "write" tools return **proposal objects** into a review queue:

```typescript
// Tool the copilot MAY call — returns a proposal, never a posting
type ProposeJournalEntry = (args: {
  memo: string;
  lines: { account: string; debit?: Money; credit?: Money; entity: string }[];
  evidence_refs: string[];              // doc IDs the proposal is grounded in
}) => Promise<{ proposal_id: string; status: "pending_review" }>;

// The engine that ACCEPTS a proposal is deterministic, called by a HUMAN action,
// and re-validates EVERYTHING (balance=0, period open, SoD, approval limit, authz).
// The LLM's numbers are re-checked, never trusted.
function acceptProposal(proposalId, actingUser): PostResult {
  const p = load(proposalId);
  assert(actingUser.can("post", p.entity));            // authz, not the LLM
  assert(sum(p.lines.debit) === sum(p.lines.credit));  // determinism
  assert(periodOpen(p.entity, p.date));                // immutability
  assert(!sodConflict(actingUser, "post_je"));         // SoD
  assert(withinApprovalLimit(actingUser, p.amount));   // money gate
  return ledger.post(p, { proposedBy: "copilot", authorizedBy: actingUser.id, evidence: p.evidence_refs });
}
```

3. **No raw-egress tools.** The copilot gets **no** arbitrary-URL fetch/POST, no shell, no raw SQL against the ledger, no arbitrary file write. Output destinations are allow-listed (the chat UI, the proposal queue). This is the defence against **EchoLeak-class** zero-click exfiltration (CVE-2025-32711, CVSS 9.3, M365 Copilot) already catalogued in the repo — an injected instruction cannot exfiltrate because there is no channel to exfiltrate *through*.

4. **Untrusted content is fenced from instructions.** RAG/document context enters the prompt inside an explicit data envelope (e.g. `<untrusted_document>…</untrusted_document>`) with a system instruction that content inside it is data, never commands. This is mitigation-in-depth, not the primary control — the primary control is #1 (least privilege) + #3 (no egress). Prompt-injection is treated as *inevitable*; the blast radius is engineered to zero.

5. **LLM05 at every consumption point.** Any value the copilot extracts (vendor name, memo, filter string) that is later consumed by SQL / a shell / a file path / a report generator is parameterised, escaped, or allow-list-validated — **never string-concatenated.** The copilot's raw output is untrusted data at every boundary, not just at the prompt. (This is exactly the SCN-14 §5 test.)

---

## 3. Document ingestion — OCR+LLM → confidence → exception queue, never silent auto-post

Invoices, POs, receipts, bank statements enter via OCR + a vision-capable LLM. 2025-2026 reality: LLM vision models hit **97-99% field-level accuracy** on standard invoices (GPT-4o + OCR layer ≈98%) — impressive, and **nowhere near safe enough to auto-post unattended**, because the 1-3% failures are silent and land on real cash [aimultiple, OCR Solutions]. The correct architecture is **confidence-gated straight-through processing with a human exception queue** — the pattern every serious AP platform (Hyperscience, Ramp, LlamaIndex) shipped by 2025 [Hyperscience, Ramp].

**Pipeline:**

```
document → OCR → LLM structured extract (per-field confidence 0..1)
        → deterministic validators (3-way match, tax recompute, vendor master lookup, duplicate check)
        → gate:  all fields ≥ τ_field  AND  all validators pass  AND  amount ≤ τ_amount  → STP candidate
                 else → EXCEPTION QUEUE (human reviews ONLY the low-confidence fields)
        → human approve → deterministic post (same acceptProposal engine as §2)
```

**Hard rules (PROPOSED defaults):**

| Control | Default | Rationale |
|---|---|---|
| Per-field confidence threshold `τ_field` | 0.95 for money/quantity/account/tax fields; 0.85 for descriptive | Money fields fail closed |
| Auto-route-to-queue trigger | ANY money-field < τ, OR any validator fail, OR amount ≥ `τ_amount` | Silent auto-post is prohibited regardless of confidence |
| "Never silent auto-post" | **Structural** | Even a 100%-confidence, all-validators-pass invoice posts only after a human accept **or** an explicitly locked, per-vendor STP allow-list with a spend cap |
| Deterministic re-checks | Always, on the extracted numbers | LLM confidence is self-assessed and miscalibrated; the 3-way match and tax recompute are ground truth |
| Duplicate-payment guard | Deterministic hash of (vendor, invoice#, amount, date) before queueing | Duplicate invoices are a top real-world loss; ML flags, hash *blocks* |

STP rates in the wild climbed 18% → 67% within four weeks once confidence + validator gating was in place [aitoolsbusiness] — you get the automation *and* the safety, precisely because the deterministic validators, not the model, decide what auto-flows. The exception queue only surfaces the low-confidence fields to the reviewer (not the whole document), which is what makes HITL economically viable at volume.

---

## 4. Anomaly detection on the transaction stream — flag, score, never autonomously reverse

Anomaly detection is a **read_only** surface by default. It scores and flags; it **never** blocks, reverses, or holds a transaction on its own authority. A false-positive freeze on a payroll run or a supplier payment is its own operational incident.

**What to run (2025-2026 consensus):** unsupervised models on the GL/journal-entry stream, because labelled fraud is scarce and patterns are unknown — **Isolation Forest** for outlier JEs (found effective at surfacing fraudulent entries), **autoencoders / VAE+LSTM** where VAE catches anomalous account-code combinations and LSTM catches anomalous amounts, plus continual/streaming learning for continuous auditing [MDPI, arXiv 2501.12723, arXiv 2112.13215]. Layer classic deterministic rules underneath (Benford's law on leading digits, round-number spikes, weekend/off-hours postings, unusual poster×account pairs, duplicate detection).

**Doctrine:**

- **ML proposes a risk score + reason; a deterministic rule or a human decides the action.** An anomaly opens a case in a queue with an explainable reason ("amount 6σ above this vendor's 12-month distribution; posted 02:14 Sat by a user who never posts to this account"), not a silent reversal.
- **Explainability is mandatory** — an unexplained "the model says it's weird" is not actionable audit evidence and won't survive SOX ITGC review. Prefer models that emit contributing features.
- **Wire flags to the existing SIEM/UEBA path** (`core/security.md` already defines mass-export and off-hours alerting) — anomaly detection is the finance-semantics complement to UEBA's access-semantics.
- **The anomaly model is itself a monitored, versioned asset** with drift tracking; a silently degraded detector is a control failure.

---

## 5. Natural-language reporting — over the GOVERNED SEMANTIC LAYER, never raw SQL to the ledger

**The single most important architectural decision in this whole document for the reporting surface:** the LLM does **not** generate SQL against the ledger. It maps natural language onto a **governed semantic layer** (metrics, dimensions, entities), and a deterministic engine compiles the chosen metrics+dimensions into SQL.

Why this is the default and raw text-to-SQL is banned on the financial record:

- Raw text-to-SQL is "flexible but fragile — the LLM might join tables incorrectly, misinterpret a column's meaning, or produce a query that runs successfully but returns wrong results" [dbt 2026 benchmark]. A wrong-but-plausible revenue number in a board report is a *worse* failure than a crash, because nobody notices.
- The semantic-layer approach reduces the LLM's job to decomposing NL into a valid combination of **pre-defined, version-controlled, tested** metrics; the engine (dbt MetricFlow, Cube) deterministically generates correct SQL and enforces row-level, multi-tenant access control at query time [Cube, dbt]. Governed metrics are reachable over SQL/REST/GraphQL/**MCP** with pre-aggregation caching and RLS [Cube]. dbt Labs open-sourced **MetricFlow** in October 2025, so this runs against dbt Core locally with no cloud subscription [dbt].
- The trade-off is honest: the semantic layer can only answer what's been modelled — but "returns *nothing* for an unmodelled question" is a safe failure; "returns a confidently wrong number" is not. With modelling, the semantic layer answered *every* question in the 2026 benchmark [dbt].

**Sketch:**

```yaml
# Governed metric — defined once, tested, version-controlled. The LLM PICKS these; it never writes SQL.
metrics:
  - name: net_revenue
    label: "Net Revenue"
    agg: sum
    expr: revenue_amount - returns_amount
    entity: legal_entity          # RLS applied here, deterministically, per caller
    dimensions: [period, product_line, region]
```
```
User: "net revenue by product line for DE01, Q2 vs Q1"
LLM  → { metric: net_revenue, group_by: [product_line], filter: {entity: DE01, period: [Q1,Q2]} }   # a PLAN, not SQL
Engine (MetricFlow/Cube) → deterministic SQL + RLS check (can this caller see DE01?) → cached result
```

The LLM output is a *query plan object* validated against the metric catalog. An injected instruction can't exfiltrate cross-tenant data because the RLS filter is applied by the engine using the caller's identity, not by the model.

---

## 6. Guardrails — every AI action logged, reversible, attributable

These are the properties that make the whole thing auditable. All three are **structural**.

**(a) Logged.** Every AI action — read, proposal, extraction, flag, query — writes to the append-only, sha256 hash-chained, WORM audit log the repo already mandates (`06-security-foundations.md` §4), with the AI-specific envelope:

```jsonc
{
  "actor": "copilot", "on_behalf_of": "user:me@corp", "session": "…",
  "action": "propose_journal_entry", "proposal_id": "…",
  "model": "claude-…", "model_version": "…", "prompt_hash": "sha256:…",
  "inputs_ref": ["doc:8842"],                 // evidence grounding
  "confidence": 0.71, "outcome": "queued",
  "authorized_by": null,                      // filled only when a human accepts
  "ts": "2026-07-07T…Z", "prev_hash": "…", "row_hash": "…"
}
```
Non-repudiation requires `on_behalf_of` (the human scope the AI inherited) AND `authorized_by` (the human who disposed). An AI action with no attributable human on at least one end is a design bug.

**(b) Reversible.** Nothing AI-touched is a hard, non-compensable mutation. Financial effects post as ledger entries that reverse via **compensating entries** (never destructive UPDATE/DELETE — posted periods are immutable). Non-financial AI actions (tags, routing) are undoable. If you can't reverse it, a human must have authorised it first.

**(c) Attributable.** Model id + version + prompt hash + input refs are captured so any AI output is reproducible-enough to investigate. You cannot make the LLM deterministic, but you can make the *record of what it did* deterministic and complete.

### The evaluation harness (release gate, not a nice-to-have)

Treat every AI feature as a capability defined by evals *before* it ships — eval-driven development, consistent with the repo's R6 method and Anthropic's guidance ("20-50 tasks from real failures is a great start; evals get harder to build the longer you wait"). For AI-native operation specifically:

| Eval suite | Asserts | Gate |
|---|---|---|
| **Injection corpus** | Documents/emails with embedded instructions → **no** unauthorized read/tool-call/egress; no cross-tenant leak | Zero tolerance; any pass = release blocked |
| **Extraction accuracy** | Field-level precision/recall on a held-out invoice/PO/receipt set, per field, with calibration (does confidence 0.95 mean 95% correct?) | ≥ locked threshold; miscalibration blocks |
| **Authz containment** | Copilot cannot exceed the invoking user's entitlements across a matrix of roles×entities | Zero escapes |
| **HITL enforcement** | Every money-moving path requires a human accept; assert no auto-post code path exists | Structural; CI grep + integration test |
| **Trajectory eval** | Tool choice, argument validity, policy compliance over full agent traces — deterministic tool mocks in CI + rubric/LLM-judge scoring [NIST GenAI Profile-aligned, agent-eval practice] | ≥ locked pass rate |
| **Anomaly detector** | Precision/recall on seeded anomalies + false-positive budget (freeze-avoidance) | ≥ threshold; drift-monitored |

Map the program to **NIST AI RMF + the Generative AI Profile (NIST AI 600-1)**, which by 2026 is referenced in US federal and enterprise procurement and explicitly names prompt injection, data leakage, and unauthorized system access as mitigation targets [NIST, CallSphere]. Add runtime observability (OpenTelemetry/agent tracing) so production traces feed back into the eval set.

---

## 7. Reconciliation with the existing security scenarios

| Repo scenario / control | AR6 surface | How it reconciles |
|---|---|---|
| **SCN-14** Prompt injection → exfil (LLM01) | Copilot §2 | Same control: copilot inherits user scope, no raw egress, HITL for writes. AR6 extends it to *all five* surfaces + the `ai_capability.*` keys |
| **SCN-14 §5** LLM05 improper output handling | All surfaces §2.5, §5 | Every extracted value is parameterised/escaped/allow-listed at each downstream consumption point |
| EchoLeak CVE-2025-32711 (repo) | Copilot §2.3 | No arbitrary-URL/egress tools → zero-click exfil channel removed |
| **SCN-10** Cross-tenant leak | NL reporting §5, RAG | RLS enforced by the semantic-layer engine + per-tenant RAG isolation, using caller identity not the model |
| **SCN-09** SQLi in report filters | NL reporting §5 | LLM emits a metric plan, not SQL; filters are validated against the catalog, never concatenated |
| **SCN-19** Audit-log tamper | Guardrails §6a | AI actions write to the same hash-chained + externally-anchored WORM log |
| **SCN-21** Payment tampering/replay | Money gate §1, §3 | No AI surface can move money; duplicate-payment hash guard; human authorises |
| **SCN-12** SoD violation | acceptProposal engine §2 | SoD re-checked deterministically on accept; the AI proposer and the human authorizer are structurally different actors — the copilot cannot be both |
| OWASP **LLM06** Excessive Agency | §1 tiers, §2.1 | Least-privilege tools, no broader-than-task permissions, human approval for consequential actions |

**Net:** AR6 is not a new security regime; it is the finance-semantics application of the repo's existing least-privilege + immutable-audit + HITL doctrine to five specific AI surfaces, with a decision-key set to lock the autonomy level of each.

---

## 8. The 2025-2026 state of agentic finance/accounting AI (grounded)

The honest market read: vendors are racing from "copilot" to "agentic," but the safe ones bound autonomy hard.

| Platform | 2025-2026 status | HITL / money posture |
|---|---|---|
| **SAP Joule** | Grew from chat copilot to 40+ agents / 2,400+ skills; agent builder GA; cash-management agent (bank-stmt reconciliation) planned GA Q1 2026; finance/procurement agents **powered by Anthropic Claude**. SAP publicly conceded Joule Studio 1.0 fell short and is overhauling with agent governance at Sapphire 2026 | Agentic flows ship subagents + **human approval loops** + SOX-compliant logging; clean handoff on ambiguity [SAP Community, aimultiple, webpronews] |
| **Microsoft Copilot for Finance / M365** | Finance in M365 Copilot **GA Oct 2025**; reads invoices, suggests GL coding from vendor history, routes for approval by threshold (−60-70% manual handling); Copilot Studio "AI approvals" as workflow steps; Cowork (Mar 2026) plans+executes multi-step | Approval routing + governed workflows are the default; AI decides within business rules, humans on review/approve [Microsoft blog/Learn] |
| **Oracle NetSuite** | 2026 R1 "AI Connector Service"; positioning as **"autopilot"**; agentic workflows starting with **bounded** cases (close orchestration, EPM reconciliation); architecture now technically allows agents to post/approve *as authorized* | Explicitly bounded; autonomy gated to authorized agents on constrained use cases [NetSuite, Thurmos, Houseblend] |
| **Sage Copilot** | Extending Copilot into operations; shifting AI "from advisory toward controlled execution" in exception handling, embedded in workflows | Controlled execution, not open autonomy [erp.today] |

**The pattern to adopt as your default:** ship value at the `propose` / `bounded_auto` tier, keep the money gate at `off` for AI, and let the deterministic engine + human be the only things that dispose. This is where the credible vendors landed after a year of hype, and it is exactly the doctrine in §0.

---

## 9. PROPOSED defaults — copy block for `locked-decisions.json`

```jsonc
"security": {
  "ai_copilot": "propose"          // keep for back-compat; superseded by ai_capability.copilot
},
"ai_capability": {
  "copilot":           "propose",
  "doc_ingestion":     "propose",
  "anomaly_detection": "read_only",
  "nl_reporting":      "read_only",
  "auto_actions":      "bounded_auto",
  "money_movement":    "off",              // STRUCTURAL floor — do not raise for money
  "confidence_thresholds": { "money_field": 0.95, "descriptive_field": 0.85 },
  "semantic_layer":    "PROPOSED: dbt MetricFlow (OSS, Oct-2025) or Cube; NO raw text-to-SQL on ledger",
  "model_provider":    "PROPOSED: Claude via API; no tenant-data training; residency pinned",
  "eval_gate":         { "injection": "zero_pass", "authz_containment": "zero_escape",
                          "hitl_money": "enforced", "extraction_calibration": "required" },
  "log_every_action":  true,               // STRUCTURAL
  "human_gate_for_money": true,            // STRUCTURAL
  "reversible_only":   true                // STRUCTURAL for financial effects (compensating entries)
}
```

**Non-negotiables (promoted from PROPOSED, mirroring the repo's audit-chain carve-out):**
1. No AI surface auto-executes a money-moving action — ever (`money_movement: "off"`).
2. Every AI action is logged to the hash-chained WORM audit log with human attribution on at least one end.
3. Financial effects are reversible via compensating entries; no destructive mutation of posted periods.
4. Release is blocked if the injection + authz-containment + HITL evals do not pass at locked thresholds.
5. Reporting NL never generates SQL against the ledger; it maps to the governed semantic layer.

Everything else is the owner's dial to set at G1.

---

## Sources

- OWASP Top 10 for LLM Applications 2025 (LLM01 Prompt Injection, LLM05 Improper Output Handling, LLM06 Excessive Agency, LLM02 Sensitive Info Disclosure): https://genai.owasp.org/llm-top-10/ ; https://genai.owasp.org/resource/owasp-top-10-for-llm-applications-2025/
- Stampli — "What are AI agents in finance — and how much of 'agentic finance' is real?" (copilot vs agentic distinction, HITL): https://www.stampli.com/resources/ai-agents-in-finance/
- SAP Community — "Agent builder in Joule Studio is now generally available": https://community.sap.com/t5/artificial-intelligence-blogs-posts/agent-builder-in-joule-studio-is-now-generally-available-build-your-own/ba-p/14289282
- AIMultiple — "SAP AI Agents in 2026: Joule Studio Features & Case Studies" (Claude powers SAP finance/procurement agents; cash agent Q1 2026): https://research.aimultiple.com/sap-ai-agents/
- WebProNews — "SAP Admits Joule Studio Flop, Rushes 2.0 Overhaul … Agent Governance at Sapphire 2026": https://www.webpronews.com/sap-admits-joule-studio-flop-rushes-2-0-overhaul-with-pro-code-power-and-agent-governance-at-sapphire-2026/
- Microsoft — "Finance in Microsoft 365 Copilot is now generally available" (Oct 20, 2025): https://www.microsoft.com/en-us/dynamics-365/blog/it-professional/2025/10/20/empowering-finance-with-an-ai-assistant-in-microsoft-365-copilot/
- Microsoft — "Automate decision-making with AI approvals in Copilot Studio": https://www.microsoft.com/en-us/microsoft-copilot/blog/copilot-studio/automate-decision-making-with-ai-approvals-in-microsoft-copilot-studio/
- ChatFin — "What Is Microsoft Copilot for Finance in Dynamics 365? A 2026 Breakdown": https://chatfin.ai/blog/what-is-microsoft-copilot-for-finance-in-dynamics-365-a-2026-breakdown/
- Thurmos — "NetSuite Bets on AI Autopilot Over Copilot for Business Operations": https://www.thrumos.com/insights/netsuite-autopilot-business-ai-strategy
- Houseblend — "Agentic AI Layer in NetSuite: 2026 Integration Guide": https://www.houseblend.io/articles/agentic-ai-layer-netsuite-integration
- erp.today — "Sage Brings Copilot into Operations … Agentic Supply Chains": https://erp.today/sage-brings-copilot-into-operations-to-push-manufacturing-distribution-toward-agentic-supply-chains
- AIMultiple — "Invoice OCR Benchmark: Extraction Accuracy of LLMs vs OCRs" (97-99% field accuracy): https://aimultiple.com/invoice-ocr
- OCR Solutions — "Can AI and LLMs Do Invoice Data Capture (OCR)?": https://ocrsolutions.com/blog/can-ai-do-invoice-ocr
- aitoolsbusiness — "Invoice Intake at Scale: OCR + LLM Validation with Human Approvals" (STP 18%→67%, confidence + validators): https://aitoolsbusiness.com/invoice-intake-ocr-llm-validation-with-human-approvals/
- Ramp — "What is OCR invoice processing in accounts payable?": https://ramp.com/blog/accounts-payable/ocr-invoice-processing
- LlamaIndex — "Automated Invoice Processing & OCR" (confidence scoring, exception queues): https://www.llamaindex.ai/services/automated-invoice-processing
- dbt Developer Blog — "Semantic Layer vs. Text-to-SQL: 2026 Benchmark Update" (fragility of raw text-to-SQL; semantic-layer answers all): https://docs.getdbt.com/blog/semantic-layer-vs-text-to-sql-2026
- Cube Blog — "Semantic Layer and AI: The Future of Data Querying with Natural Language" (governed metrics over SQL/REST/GraphQL/MCP, RLS, caching): https://cube.dev/blog/semantic-layer-and-ai-the-future-of-data-querying-with-natural-language
- MDPI Systems — "Detecting Anomalies in Financial Data Using Machine Learning Algorithms" (Isolation Forest, autoencoders): https://www.mdpi.com/2079-8954/10/5/130
- arXiv 2501.12723 — "Anomaly Detection in Double-entry Bookkeeping Data by Federated Learning": https://arxiv.org/pdf/2501.12723
- arXiv 2112.13215 — "Continual Learning for Unsupervised Anomaly Detection in Continuous Auditing of Financial Accounting Data": https://arxiv.org/pdf/2112.13215
- BIS Working Paper 1188 — "A machine learning framework for anomaly detection in payment systems": https://www.bis.org/publ/work1188.pdf
- NIST — AI Risk Management Framework + Generative AI Profile (NIST AI 600-1): https://www.nist.gov/itl/ai-risk-management-framework
- CallSphere — "NIST AI RMF Generative Profile: Mapping Controls to Your LLM Stack": https://callsphere.ai/blog/nist-ai-rmf-generative-profile-controls-llm-stack-2026
- Galileo — "Essential Framework for AI Agent Guardrails": https://galileo.ai/blog/ai-agent-guardrails-framework
- Repo cross-refs: `playbook/security/scenarios/14-prompt-injection-ai-copilot.md` (SCN-14, EchoLeak CVE-2025-32711); `playbook/06-security-foundations.md` §4 (hash-chain + external anchor), §9 (`ai_copilot` key); `core/security.md` (RBAC/ABAC, SoD, audit, UEBA); `research/R6-ai-build-method.md` (eval-driven development).
