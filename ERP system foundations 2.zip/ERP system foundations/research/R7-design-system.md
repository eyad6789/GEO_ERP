# R7 — Design System: Enterprise UX Patterns + Anthropic Design Language for the ERP Build OS

**Track:** R7-design-system
**Date:** 2026-07-06
**Consumers:** AI agents authoring the ERP build-OS playbook; used to style owner-facing HTML "decision files" and to guide the ERP product UI.

---

## 0. Executive Recommendation (read this first)

Adopt a **two-surface design system with one shared token vocabulary**:

1. **Decision files & internal docs** (owner-facing HTML memos, ADRs, runbooks) → full **Anthropic-language treatment**: warm ivory/oat paper background, ink text, restrained clay/coral accent, a serif used with intent for headings/pull-quotes, generous whitespace, hairline borders (no drop shadows). These are *read*, so typography and calm pacing dominate.
2. **ERP product UI** (the actual app: grids, forms, dashboards) → the **same token palette**, but the layout grammar shifts from "document" to "instrument panel": density-first data grids, master-detail, saved views, bulk-action bars, role-based nav, and strict WCAG 2.2 AA compliance. Typography drops to the sans/mono faces almost entirely — serif is reserved for section headers and empty-states, never for tabular data or form labels.

Both surfaces share **one CSS variable block** (Section 5) so an agent can drop it into any HTML file and get correct light/dark behavior immediately. This is the proposed default; only override the accent hue for white-labeling.

---

## 1. Part A — Enterprise / ERP UX Patterns

Enterprise software is optimized for **repeat, expert use** (8+ hrs/day), not first-time delight. The core design bias is *density and speed over onboarding friction* — power users want keyboard paths, bulk operations, and predictable layout, not hand-holding animation (Pencil & Paper; UXPilot, 2025).

### 1.1 Data grids / tables

- **Sticky header + sticky first column** for wide tables; column resize, reorder, and per-column sort are table-stakes, not "advanced" features.
- **Inline (cell-level) editing** for high-frequency fields (qty, price, status) beats a full-row edit modal — reduces clicks for the dominant workflow.
- **Row density toggle** (compact / comfortable) — enterprise users self-select density; don't force one.
- **Selection model**: checkbox column → contextual bulk-action toolbar that *replaces* the default toolbar when ≥1 row is selected (pattern used by Gmail, Salesforce, Airtable, Linear). Always show a "X selected · Clear" affordance.
- **Empty, loading, and error states are first-class**: design them before the "happy path" table — enterprise grids are frequently empty (new tenant, filtered view) or partially failed (one column's data source down).
- Reference implementations to imitate: **Salesforce Lightning Design System** (data tables + list views), **AG Grid Enterprise** (virtualization, pivoting), **Airtable** (same dataset, multiple view types — grid/kanban/calendar/gallery/form reusing one component core).

### 1.2 Master-detail

Two canonical layouts (Webix / Nielsen-Norman-style pattern literature):
- **Side-by-side** (list left, detail right) — default for desktop/wide viewports; keeps context while inspecting a record.
- **Stacked / drill-in** (list → full-screen detail → back) — required below ~900px width; also the correct default for deep hierarchical detail (e.g., invoice → line items → line item history).
- Rule of thumb for the build-OS: **every entity list screen in the ERP should default to side-by-side master-detail on desktop, stacked on mobile/tablet**, with the split ratio persisted per user (localStorage / user preference row).

### 1.3 Forms & validation

- **Inline, on-blur validation** is the consensus best practice — validate after the user leaves a field, not on every keystroke (which produces a "flickering error" experience), and not only on submit (which hides problems until the end) (Smart Interface Design Patterns; LogRocket, 2025).
- Every error must (a) identify the field, (b) state what's wrong, (c) state how to fix it — never "Invalid input."
- Don't rely on color alone (WCAG 1.4.1) — pair red/error with an icon and text.
- **WCAG 2.2 adds two form-specific criteria directly relevant to ERP data entry**: *3.3.7 Redundant Entry* (don't make users re-enter data already supplied in the same process — e.g., re-typing a shipping address already on file) and *3.3.8/3.3.9 Accessible Authentication* (no cognitive-function tests like puzzle CAPTCHAs as the only login path). Both are Level AA/AAA in WCAG 2.2 and are realistic audit targets for an ERP's onboarding/checkout-like flows.

### 1.4 Bulk actions

- Contextual toolbar pattern (see 1.1); always confirm destructive bulk actions with an explicit count ("Delete 14 invoices?") — never a generic confirm.
- Bulk actions should be undo-able where feasible (soft delete + toast with "Undo") rather than confirm-modal-gated, which is friction for power users; reserve hard confirms for irreversible, high-blast-radius operations (bulk permission changes, bulk send).

### 1.5 Saved views & filters

- **Filters as composable chips** above the grid, with an explicit "Save as view" action once a filter/sort/column-set combination is non-trivial — modeled on Salesforce list views and Linear's filter model (status/assignee/priority/label as first-class filter dimensions) (Salesforce Ben; SaaSUI, 2026).
- Saved views should be **shareable at the team level and private at the user level** — both need to exist; ERPs are collaborative by nature (a controller's "Overdue AR > 60 days" view is org value, not personal preference).
- Favor **progressive disclosure**: default view is clean/whitespace-heavy (Linear's model — zero visual noise until the user invokes filters), with power features behind a filter bar / command palette rather than always-visible chrome.

### 1.6 Dashboards & KPIs

- Dashboards in ERPs must be **role-scoped by default** — a controller's dashboard and a warehouse manager's dashboard should share zero widgets by default; role-based dashboard composition is the norm in modern ERP (NetSuite, Meegle 2025-26 guidance).
- KPI tiles: **number + trend + sparkline**, not number alone; encode direction (up/down = good/bad) via a **semantic color that is separate from the brand accent** (this is a hard rule carried over from dataviz guidance — good/warn/critical is its own palette, never the same hue as your one brand accent, or state and brand collide visually).
- AI-era pattern worth adopting: **surfaced anomalies/recommendations inline on the dashboard** ("3 invoices flagged unusual," "forecast risk: Acme Co renewal") rather than requiring the user to go find them — this is now a 2025-26 expectation, not a novelty.

### 1.7 Role-based navigation

- Navigation and available actions should be generated from the **user's role/permission set**, not hidden via client-side CSS — a warehouse clerk should never see (even greyed-out) the GL posting screen. This is a security *and* UX requirement (RBAC-driven nav reduces cognitive load and eliminates whole classes of "why can't I click this" support tickets).
- Keep a **persistent, collapsed-by-default primary nav rail** (icons + label on hover/expand) + a **secondary in-context tab/subnav** per module — this two-tier nav is the de facto ERP standard (NetSuite, SAP Fiori, Salesforce all converge on it).

### 1.8 Approval workflow UI

- Model every approval as: **submitted → pending (with named approver + SLA clock) → approved/rejected (with reason) → done**, and always render this as a visible **stepper or status pill**, never buried in an activity log only.
- Provide **a single inbox view aggregating all pending approvals across modules** for a given approver ("My Approvals") — this is the highest-leverage single screen in an ERP for manager-role users, and is frequently the first screen an approver-role user should land on post-login.
- Bulk-approve should exist but require an explicit review step (e.g., "review 12 items" expandable list) before a single "Approve all" confirm — matches the bulk-action undo/confirm tradeoff in 1.4, but approvals are typically irreversible so lean toward confirm-with-list rather than undo-after.

### 1.9 Accessibility (WCAG 2.2)

- WCAG 2.2 (Oct 2023, still the current normative version as of 2026-07) has **87 success criteria**: 32 at A, +24 at AA (the practical legal/procurement bar), +31 at AAA. It **removed** 4.1.1 Parsing (obsolete) and **added 9 new criteria** vs. 2.1 (W3C WAI; TestParty, 2025).
- The 9 new criteria most relevant to an ERP build-OS default:
  | Criterion | Level | ERP relevance |
  |---|---|---|
  | 2.4.11/2.4.12 Focus Not Obscured (Min/Enhanced) | AA/AAA | Sticky headers/toolbars must never fully hide the focused element — common bug in data-grid UIs with sticky headers. |
  | 2.4.13 Focus Appearance | AAA | Focus ring must be clearly visible against your ink/cream tokens — see Section 5 `--focus-ring`. |
  | 2.5.7 Dragging Movements | AA | Any drag-reorder (columns, kanban) needs a non-drag (button/menu) alternative. |
  | 2.5.8 Target Size (Minimum) | AA | Interactive targets ≥24×24 CSS px (or spaced equivalently) — directly constrains dense-grid row-action icon buttons. |
  | 3.2.6 Consistent Help | A | If a help/support entry point exists, its location must be consistent across the ERP's modules. |
  | 3.3.7 Redundant Entry | A | See 1.3. |
  | 3.3.8/3.3.9 Accessible Authentication | AA/AAA | No memory/cognitive-only login step (e.g., "solve this puzzle") as the sole path. |
- **Automated tooling only catches ~40% of WCAG 2.2 issues** (TestParty, 2025) — the build-OS should mandate a manual keyboard-only pass and a screen-reader pass per module, not rely on axe/lighthouse alone. Budget **2–3 months of hardening for full compliance on a complex app** — plan this into the ERP build timeline rather than bolting it on pre-launch.
- Contrast: hold **4.5:1 for normal text, 3:1 for large text/UI components** (WCAG 1.4.3/1.4.11) — verify this explicitly against the token palette in Section 5, both themes (see contrast notes inline).

### 1.10 Responsive, keyboard-first, and theming

- **Keyboard-first**: every enterprise app in 2025-26 with power-user ambitions ships a **Cmd/Ctrl+K command palette** (Linear, Vercel, GitHub, Slack, Retool all converge on this) — treat it as a required primitive, not a nice-to-have, for an ERP build-OS default. It doubles as a self-teaching affordance: showing the keyboard shortcut next to each action inside the palette itself (Retool Blog, 2025; buildmvpfast.com, 2026).
- **Responsive**: master-detail collapses to stacked below ~900px (1.2); data grids degrade to a card-per-row list on narrow viewports rather than horizontal-scrolling a full table — horizontal scroll is acceptable only inside a deliberately-scoped `overflow-x:auto` container, never for the page itself.
- **Light/dark theming**: token-level theming (define semantic CSS variables once, redefine only the values per theme) is now the standard approach across both marketing sites and product design systems in 2025-26 — see Section 5 for the concrete implementation, which mirrors this project's own artifact-design conventions (`prefers-color-scheme` as default signal, `data-theme` attribute override in both directions).

---

## 2. Part B — The Anthropic Design Language, Distilled

### 2.1 Provenance (grounding)

Anthropic's visual identity was designed by **Geist** (Portland, OR design studio), a 2.5-year engagement from stealth through public launch, explicitly built to "align technology to human values" and to read as warmer/more human than typical cool-gray tech branding (Geist case study, geist.co/work/anthropic).

- **Typefaces**: Anthropic pairs **Styrene** (sans, by Commercial Type / Berton Hasebe — an "experiment exploring proportion" where normally-narrow letters like f, j, r, t are extended and squarish, giving it warmth versus a typical geometric grotesque) with **Tiempos** (serif, Klim Type Foundry). Anthropic's own site historically set headlines/subheads in Styrene and body copy in Tiempos (type.today journal); Anthropic has also developed a proprietary in-house type suite (**Anthropic Serif / Sans / Mono**, credited in part to Chester Jenkins of BSPK) used at "unprecedented scale for both body and display text" across product surfaces (shadcn.io design-system summary; companyfonts.com). **Both Styrene and Tiempos are commercial, licensed typefaces — do not embed them via `@font-face` data URI in artifacts/decision files without a license.** For the build-OS default, use metric-and-mood-compatible open alternatives (Section 4).
- **Colors** (converge across independent sources — Anthropic's own `anthropics/skills` brand-guidelines reference, shadcn.io's "Anthropic Design System for React," and third-party brand-asset aggregators): a **7-token core** —
  - `#141413` ink (primary text / dark backgrounds)
  - `#faf9f5` paper (light background / text-on-dark)
  - `#e8e6dc` subtle surface (cards, table zebra, dividers-adjacent fill)
  - `#b0aea5` muted/secondary text and borders
  - `#d97757` **clay** — primary accent (a warm terracotta/coral, NOT saturated red-orange; this is the signature "Claude" accent)
  - `#6a9bcc` **sky** — secondary accent (cool blue, used sparingly, often for links/info)
  - `#788c5d` **cactus** — tertiary accent (muted olive-green, semantic/dataviz use)
  - Plus a documented **dormant 8-swatch data/editorial accent set**: clay `#d97757`, fig `#c46686`, cactus `#bcd1ca`, sky `#6a9bcc`, heather, olive, manilla, kraft — used for research/index/dashboard categorical needs, i.e., this *is* Anthropic's own answer to a categorical dataviz palette (unverified exact hex for heather/olive/manilla/kraft as of 2026-07 — the four listed hexes above are confirmed, the remaining four names are attested but not hex-confirmed in sources retrieved).
- **System scale** (as documented in third-party design-system reconstructions of the public site, e.g. shadcn.io's Anthropic theme): roughly **21 color tokens, 11 typography levels across the 3 type families, a 4-step border-radius scale, and an 8-step spacing rhythm** — i.e., a small, disciplined token set, not a sprawling one. This "small number of tokens, used consistently" is itself a transferable principle for the build-OS.
- **Surface philosophy**: "ivory and oat neutrals replace the typical cool-gray tech palette, giving every surface a paper-like quality" — bias toward **warm, not cool, neutrals**; borders over shadows; no glassmorphism, no heavy elevation.

### 2.2 The aesthetic, as principles (not just tokens)

1. **Paper, not screen.** Background reads as warm ivory/cream, never pure white, never cool gray. Text is near-black ink (`#141413`), never pure `#000`.
2. **One accent, used sparingly.** Clay (`#d97757`) is the signature move — a muted terracotta, not a saturated brand-blue or a neon anything. It appears on primary buttons, links, active states, and small emphasis marks — never as a full-bleed background.
3. **Serif for authority, sans for function.** A serif display face carries headlines, pull-quotes, and section titles — it signals editorial care and slows the reader down at exactly the moments that deserve it. Everything operational (nav, buttons, table cells, form labels, timestamps) is sans.
4. **Borders over shadows.** Cards and panels are delineated by a 1px hairline border in the muted tone, not a drop shadow. Elevation, where used at all, is a barely-there single soft shadow — never a stacked/glossy shadow stack.
5. **Whitespace is a design material, not empty space.** Generous margins and line-height signal confidence; density is achieved by *repeating* the calm rhythm, not by shrinking whitespace.
6. **Radius is small and consistent.** Anthropic's product surfaces read as gently rounded (roughly 8–12px on cards/inputs, smaller ~4–6px on chips/buttons) — never fully pill-shaped for structural containers, never sharp 0px either.
7. **Data-viz is muted and warm-neutral-anchored.** Categorical charts pull from the clay/fig/cactus/sky/heather/olive/manilla/kraft family — all mid-saturation, all sitting comfortably next to the cream paper — rather than saturated primary-color chart defaults.

---

## 3. Reconciling A + B: applying Anthropic language to ERP UI

The Anthropic aesthetic was built for a **conversational product and marketing site** — it is not, out of the box, a data-grid design system. The build-OS should apply it selectively:

| Surface | Anthropic-language elements to keep | Enterprise-pattern elements that override it |
|---|---|---|
| Decision files / memos / ADRs (read-heavy, low interactivity) | Full treatment: serif headings, cream paper, clay accent, generous whitespace, hairline dividers | — |
| Dashboards | Cream/paper background, clay accent for the *one* primary CTA/highlight, cactus/sky/fig for categorical chart series | Dense KPI tiles, sparklines, semantic (not accent) color for status |
| Data grids / tables | Ink text on paper/subtle-surface zebra rows, hairline row dividers, clay for row-selected state | Compact row height option, sticky header, tabular-nums, no serif anywhere in cell content |
| Forms | Clay for primary submit, sky/cactus reserved (don't use as form-error color — define a separate semantic red) | Inline on-blur validation, 24px+ touch targets, visible focus ring meeting 2.4.13 |
| Nav / chrome | Warm neutral background, small consistent radius on nav items | Two-tier role-based nav, command palette, badge/pill for counts using semantic color |

**Hard rule for the build-OS**: never let clay (`#d97757`) double as both "brand accent" and "error/danger" — define a distinct, unrelated-hue semantic red for destructive/error state (e.g., a desaturated brick red, not clay, not a stock Bootstrap red) so state and brand never collide, per the dataviz guidance principle that semantic color is separate from the accent hue.

---

## 4. Concrete typography recommendation (license-safe)

Since Styrene and Tiempos are commercial, the build-OS default substitutes **metric-sympathetic, freely-embeddable faces** that preserve the *mood* (warm serif display + clean functional sans):

- **Display/serif** (headings, pull-quotes, decision-file titles): **"Source Serif 4"** or **"Lora"** (both open, both a warm transitional serif with the "editorial authority" quality) — system fallback stack `Georgia, "Iowan Old Style", "Palatino Linotype", serif`.
- **Body/UI sans** (everything operational): **"Public Sans"** or **"IBM Plex Sans"** as a warmer, slightly more characterful alternative to the overused Inter — system fallback stack `"Segoe UI", system-ui, -apple-system, sans-serif`. (If Inter is already the org standard, it is an acceptable, low-risk fallback for product UI — the "avoid Inter" guidance applies more strongly to editorial/hero treatments than to dense operational tables.)
- **Mono** (IDs, code, numeric ledgers): **"IBM Plex Mono"** or **"JetBrains Mono"** — fallback `ui-monospace, "SF Mono", Consolas, monospace`.
- Note per the artifact-design constraint: for HTML **artifacts**, inline the chosen open font as a `@font-face` data URI (CSP blocks font CDNs); for the actual ERP product codebase, self-host the font files normally.

---

## 5. Ready-to-use CSS variable block (PROPOSED DEFAULT)

Token-level theming: define semantics once, redefine values per theme, per this project's own artifact-design convention (`prefers-color-scheme` as default signal, `data-theme` attribute wins in both directions).

```css
:root {
  /* ---- Anthropic-inspired core palette (light) ---- */
  --paper:        #faf9f5;   /* page background */
  --paper-raised: #ffffff;   /* cards floating just above paper, rarely needed */
  --surface:      #e8e6dc;   /* subtle fill: zebra rows, chips, disabled bg */
  --ink:          #141413;   /* primary text */
  --ink-muted:    #575551;   /* secondary text (derived, darker than b0aea5 for AA body contrast) */
  --border:       #d9d6c9;   /* hairline borders, derived warm-neutral between surface and b0aea5 */
  --border-strong:#b0aea5;   /* emphasized borders, focus-adjacent chrome */

  /* ---- Accent family ---- */
  --accent:        #d97757; /* clay — primary accent: CTAs, links, active state */
  --accent-hover:  #c1613f; /* darkened clay for hover/pressed */
  --accent-soft:   #f3ded3; /* clay tint for selected-row / badge backgrounds */
  --accent-2:      #6a9bcc; /* sky — secondary accent, info */
  --accent-3:      #788c5d; /* cactus — tertiary accent, categorical/dataviz */

  /* ---- Semantic (NEVER reuse accent hue) ---- */
  --success:      #4b7d5c;
  --success-soft: #e1ede3;
  --warning:      #b8873a;
  --warning-soft: #f6ebd8;
  --danger:       #b1443a;  /* brick red — distinct from clay */
  --danger-soft:  #f5e0dd;
  --info:         #6a9bcc;  /* reuses sky, acceptable: info is not a brand-collision risk */
  --info-soft:    #e3ecf5;

  /* ---- Categorical dataviz (8-swatch, Anthropic-derived) ---- */
  --viz-1: #d97757; /* clay */
  --viz-2: #6a9bcc; /* sky */
  --viz-3: #788c5d; /* cactus */
  --viz-4: #c46686; /* fig */
  --viz-5: #a68b5b; /* kraft (approx — unverified exact hex as of 2026-07) */
  --viz-6: #8a8c5e; /* olive (approx — unverified exact hex as of 2026-07) */
  --viz-7: #b9ada0; /* heather (approx — unverified exact hex as of 2026-07) */
  --viz-8: #d8cba6; /* manilla (approx — unverified exact hex as of 2026-07) */

  /* ---- Typography ---- */
  --font-display: "Source Serif 4", Georgia, "Iowan Old Style", serif;
  --font-body:    "Public Sans", "Segoe UI", system-ui, -apple-system, sans-serif;
  --font-mono:    "IBM Plex Mono", ui-monospace, "SF Mono", Consolas, monospace;

  /* ---- Type scale (1.25 minor-third-ish, capped for density) ---- */
  --text-xs:   0.75rem;
  --text-sm:   0.875rem;
  --text-base: 1rem;
  --text-md:   1.125rem;
  --text-lg:   1.375rem;
  --text-xl:   1.75rem;
  --text-2xl:  2.25rem;

  /* ---- Spacing (8-step rhythm) ---- */
  --space-1: 0.25rem;
  --space-2: 0.5rem;
  --space-3: 0.75rem;
  --space-4: 1rem;
  --space-5: 1.5rem;
  --space-6: 2rem;
  --space-7: 3rem;
  --space-8: 4rem;

  /* ---- Radius (4-step) ---- */
  --radius-sm: 4px;   /* chips, small buttons */
  --radius-md: 8px;   /* inputs, table cells, tags */
  --radius-lg: 12px;  /* cards, panels, modals */
  --radius-full: 999px; /* avatars, pills only */

  /* ---- Elevation: borders over shadows ---- */
  --shadow-sm: 0 1px 2px rgba(20,20,19,0.06);
  --shadow-md: 0 2px 8px rgba(20,20,19,0.08);

  /* ---- Focus (WCAG 2.4.13-safe: high-contrast, clearly visible) ---- */
  --focus-ring: 0 0 0 2px var(--paper), 0 0 0 4px var(--accent);
}

/* ---- Dark theme values (same tokens, new values — never invert naively) ---- */
@media (prefers-color-scheme: dark) {
  :root {
    --paper:        #1c1b18;
    --paper-raised: #242320;
    --surface:      #2a2925;
    --ink:          #f2f0e9;
    --ink-muted:    #b7b3a8;
    --border:       #3a3833;
    --border-strong:#514e46;

    --accent:        #e08e6d;  /* lightened clay for AA contrast on dark paper */
    --accent-hover:  #eba489;
    --accent-soft:   #4a2f22;
    --accent-2:      #86b0d8;
    --accent-3:      #92a67c;

    --success:      #7fb48f;
    --success-soft: #22301f;
    --warning:      #d6a768;
    --warning-soft: #362b17;
    --danger:       #d17d72;
    --danger-soft:  #3a211d;
    --info:         #86b0d8;
    --info-soft:    #1f2b36;

    --shadow-sm: 0 1px 2px rgba(0,0,0,0.35);
    --shadow-md: 0 2px 10px rgba(0,0,0,0.45);
    --focus-ring: 0 0 0 2px var(--paper), 0 0 0 4px var(--accent);
  }
}

/* ---- Explicit override: viewer's in-app toggle always wins ---- */
:root[data-theme="light"] {
  --paper: #faf9f5; --paper-raised:#ffffff; --surface:#e8e6dc;
  --ink:#141413; --ink-muted:#575551; --border:#d9d6c9; --border-strong:#b0aea5;
  --accent:#d97757; --accent-hover:#c1613f; --accent-soft:#f3ded3;
}
:root[data-theme="dark"] {
  --paper:#1c1b18; --paper-raised:#242320; --surface:#2a2925;
  --ink:#f2f0e9; --ink-muted:#b7b3a8; --border:#3a3833; --border-strong:#514e46;
  --accent:#e08e6d; --accent-hover:#eba489; --accent-soft:#4a2f22;
}
```

**Contrast check (informal, against WCAG 1.4.3):** ink `#141413` on paper `#faf9f5` ≈ 17:1 (far exceeds AA). Dark-mode ink `#f2f0e9` on paper `#1c1b18` ≈ 15:1. Accent-on-paper `#d97757` on `#faf9f5` ≈ 3.3:1 — **sufficient for large text/icons/borders (3:1) but not for small body text set in clay** (keep clay for links ≥14px bold or UI chrome/icons, or underline links so color isn't load-bearing); dark-mode lightened accent `#e08e6d` on `#1c1b18` ≈ 6.9:1, safe for small text too. Verify with an actual contrast tool before shipping; treat these as engineering estimates, not certified values.

**Component defaults implied by the tokens:**
- Buttons: `--radius-md`, `--accent` fill / `--paper` text (primary), `1px solid --border-strong` + `--ink` text (secondary) — no shadow beyond `--shadow-sm` on hover only.
- Cards/panels: `--paper-raised` bg, `1px solid --border`, `--radius-lg`, `--shadow-sm` at most.
- Table rows: `--paper` / `--surface` zebra, `--accent-soft` for selected row, `1px solid --border` row divider only (no vertical cell borders).
- Inputs: `--radius-md`, `1px solid --border-strong`, `--focus-ring` on focus, error state uses `--danger` border + icon, never color alone.
- Badges/pills: `--radius-full`, background = `<state>-soft`, text = darker shade of same state hue (not `--ink`) so pills stay legible in both themes.

---

## 6. Open questions / things to verify before hard-locking as org standard

- Exact hex values for **heather / olive / manilla / kraft** in Anthropic's dormant 8-swatch accent set are attested by name but not independently hex-confirmed in the sources retrieved this session — treated as approximated (unverified as of 2026-07).
- Whether Anthropic's *current* (2026) product UI still uses Styrene+Tiempos vs. having fully migrated to the proprietary Anthropic Serif/Sans/Mono suite is not fully disambiguated between sources (marketing-site journal entry vs. later design-system summaries) — both are documented as true at different points, so treat "Styrene+Tiempos" as the safe historical/mood reference and "Anthropic Serif/Sans/Mono" as the aspirational proprietary target if the org ever licenses/commissions equivalent faces.
- Confirm actual computed contrast ratios with a tool (e.g., WebAIM contrast checker) against the final rendered font weights before certifying AA compliance — the estimates above are arithmetic approximations, not tool-verified.

---

## Sources

- [Anthropic Brand Guidelines skill (anthropics/skills, GitHub)](https://raw.githubusercontent.com/anthropics/skills/main/skills/brand-guidelines/SKILL.md)
- [Geist — Anthropic case study](https://geist.co/work/anthropic)
- [Styrene in use: ANTHROP\C — type.today journal](https://type.today/en/journal/anthropic)
- [Anthropic Design System for React — shadcn.io](https://www.shadcn.io/design/anthropic)
- [Anthropic — Database of Company Brand Fonts (companyfonts.com)](https://www.companyfonts.com/company/anthropic)
- [Claude Brand Color Palette — Mobbin](https://mobbin.com/colors/brand/claude)
- [My Styrene Soul: A Short Affair with Claude.ai — Dear Designer (Substack)](https://deardesigner.substack.com/p/my-styrene-soul-a-short-affair-with)
- [Anthropic Designed Its Own Type Family — Gooova Studio](https://gooova.com/en/anthropic-designed-its-own-type-family/)
- [Enterprise UX: essential resources to design complex data tables — Stéphanie Walter](https://stephaniewalter.design/blog/essential-resources-design-complex-data-tables/)
- [Data Table Design UX Patterns & Best Practices — Pencil & Paper](https://www.pencilandpaper.io/articles/ux-pattern-analysis-enterprise-data-tables)
- [8 Enterprise UX Design Best Practices and Principles — UXPilot](https://uxpilot.ai/blogs/enterprise-ux-design)
- [Master-Details Pattern for web applications — Webix](https://blog.webix.com/master-details-pattern-with-webix-ui/)
- [AG Grid Enterprise: Advanced Data Grid Features](https://www.ag-grid.com/landing-pages/enterprise-data-grid/)
- [Inline Validation UX — Smart Interface Design Patterns](https://smart-interface-design-patterns.com/articles/inline-validation-ux/)
- [The UX of form validation: Inline or after submission? — LogRocket](https://blog.logrocket.com/ux-design/ux-form-validation-inline-after-submission/)
- [What's New in WCAG 2.2 — W3C WAI](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/)
- [What Are All 87 WCAG 2.2 Success Criteria? — TestParty](https://testparty.ai/blog/wcag-22-success-criteria-list)
- [WCAG 2.2: Complete Compliance Guide 2025 — AllAccessible](https://www.allaccessible.org/blog/wcag-22-complete-guide-2025)
- [Web Content Accessibility Guidelines (WCAG) 2.2 — W3C TR](https://www.w3.org/TR/WCAG22/)
- [Role-Driven UI Design for ERP Systems — Medium](https://medium.com/@jeff377/how-should-erp-systems-determine-the-user-interface-role-driven-design-is-the-key-3777fb616f15)
- [ERP Dashboards for Businesses — NetSuite](https://www.netsuite.com/portal/resource/articles/erp/erp-dashboard.shtml)
- [Dashboard Design Principles: The Definitive Guide (2026) — UXPin](https://www.uxpin.com/studio/blog/dashboard-design-principles/)
- [25+ Salesforce UI Features to Implement in Every Org — Salesforce Ben](https://www.salesforceben.com/salesforce-ui-features-to-implement-in-every-org/)
- [7 SaaS UI Design Trends for 2026 — SaaSUI](https://www.saasui.design/blog/7-saas-ui-design-trends-2026)
- [How to build a remarkable command palette — Superhuman Blog](https://blog.superhuman.com/how-to-build-a-remarkable-command-palette/)
- [Designing Retool's Command Palette — Retool Blog](https://retool.com/blog/designing-the-command-palette)
- [How to Add a Cmd+K Command Palette to Your SaaS (2026) — buildmvpfast](https://www.buildmvpfast.com/blog/how-to-add-cmd-k-command-palette-saas-2026)
