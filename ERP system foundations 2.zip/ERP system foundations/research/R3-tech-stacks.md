# R3 — Tech Stacks for AI-Built ERP/Business Systems (2026)

**Track:** R3-tech-stacks | **Date:** 2026-07-06 | **Audience:** AI agents authoring an "ERP build operating system" playbook

**Purpose:** Give a single opinionated DEFAULT stack an agent should reach for by default when building an ERP/business system from scratch in 2026, plus a decision matrix for justified deviations. Every fast-moving claim below is sourced; anything I could not verify against a 2025-2026 primary source is flagged `(unverified as of 2026-07)`.

---

## 1. Evaluation criteria (weighted for THIS context)

| Criterion | Why it matters for AI-built ERP | Weight |
|---|---|---|
| **AI-buildability** | Volume of training data, idiom stability, how often Claude produces a *compiling, correct* first draft; how easy it is for an agent to self-verify (types, compiler, linter) rather than trust its own output | High |
| **Static typing strength** | ERP correctness bugs (wrong currency rounding, wrong tenant scoping, null GL account) are exactly the class of bug a strong type system catches at compile time, before a human reviews it | High |
| **Transactional integrity fit** | ACID transactions, serializable isolation, constraints, and audit-friendly schemas are non-negotiable for money-and-inventory systems | High |
| **Ecosystem maturity** | Battle-tested libraries for auth, payments, PDF/reporting, accounting math, migrations — reduces the surface Claude has to invent | Medium-High |
| **Long-term maintainability** | Humans (not just agents) will read this code for a decade; boring, explicit, greppable code beats clever code | Medium-High |
| **Operational simplicity** | Fewer moving parts an agent (or a small team) must operate correctly | Medium |

---

## 2. Backend language comparison

| Language | AI-buildability | Typing | Transactional fit | Ecosystem for ERP | Verdict |
|---|---|---|---|---|---|
| **TypeScript / Node** | Very high — largest training corpus of any stack, and Claude Sonnet/Opus produce idiomatic first-try code reliably; a 2026 13-language Claude Code benchmark found Ruby/Python/JS cheapest and fastest to generate, while statically-typed languages cost 1.4–2.6x more per run but that cost buys compiler-checked correctness | Strong *if* `strict: true` + no `any`; structural, gradual — an agent can weaken it accidentally | Good, not native — relies on ORM/driver for transactions; no built-in decimal type (must use a library) | Enormous — Prisma/Drizzle, NestJS, Zod/Valibot validation, huge npm surface | **Primary pick** — best AI-buildability × typing × ecosystem product for full-stack ERP UIs + APIs in one language |
| **Python** | Very high, cheapest/fastest for Claude Code per the 2026 benchmark above | Optional (type hints + mypy/pyright) — an agent *can* write fully-typed Python but nothing forces it, and dynamic escape hatches are everywhere in the ecosystem | Good via SQLAlchemy/Django ORM, but GIL and duck-typing invite silent type-coercion bugs in financial code | Excellent for data/reporting/analytics/ML side-cars; Django admin is a fast ERP-backoffice bootstrap | Strong **secondary** pick for data/reporting/automation layers, not the financial core, because typing discipline isn't enforced by the language itself |
| **Go** | High — small, orthogonal language; less idiomatic ambiguity means Claude's output is very consistent, though ecosystem is smaller so it invents less "magic" | Strong, explicit, no generics tricks needed for CRUD; nil and error-handling are verbose but hallucination-resistant (compiler catches unhandled errors) | Excellent — `database/sql` + explicit transactions is a very natural fit; sqlc generates fully-typed Go from raw SQL, eliminating ORM ambiguity entirely | Good, growing; fewer high-level ERP/accounting libraries than TS/Python/Java, more DIY | Excellent for **high-throughput services** (ledger posting engines, integration workers, webhooks) where explicitness and single-binary deploys matter |
| **Java / Kotlin (Spring Boot)** | Medium-high — verbose but extremely idiom-stable; Claude rarely improvises unconventional patterns in Spring because conventions are rigid and well-documented | Very strong (nominal, checked exceptions, mature generics) | Best-in-class — Spring's `@Transactional`, JTA, and decades of enterprise transaction-management patterns are purpose-built for financial systems | Enormous enterprise/ERP heritage (SAP, Oracle Fusion internals, Broadleaf, jOOQ) | Strongest **traditional enterprise** choice; heavier boilerplate and slower iteration make it a deliberate deviation, not the default, for an AI-agent-built greenfield system |
| **C# / .NET** | High — similar idiom stability to Java; **.NET 10 (LTS, released Nov 11 2025, supported to Nov 2028) with C# 14** is current | Very strong, nominal typing, nullable reference types, `decimal` type built into the language (critical for money) | Excellent — EF Core transactions, distributed transaction support, mature | Strong enterprise ecosystem, first-class Windows/on-prem integration (relevant for legacy ERP replacement) | Excellent **deviation pick** when the org is already a Microsoft shop, needs on-prem Windows integration, or wants `decimal` as a first-class language primitive |
| **Rust** | Medium — Claude can write correct Rust, but borrow-checker fights slow iteration; smaller ERP-specific ecosystem means more code must be generated from scratch | Very strong — best-in-class safety guarantees | Excellent — SQLx verifies queries against the live DB *at compile time*, eliminating a whole class of SQL bugs | By 2026 the core stack (Tokio, Axum, SQLx/SeaORM/Diesel, tracing) is genuinely production-mature, but ERP-domain libraries (accounting, tax, reporting) are thin | Reserve for narrow **high-integrity, high-throughput components** (e.g., a ledger/posting kernel) where correctness-per-CPU-cycle matters more than iteration speed — not a whole-ERP default |

**Bottom line:** for an AI agent authoring a whole ERP system end-to-end, **TypeScript is the default language** — it has the best combination of Claude-generation reliability, one language across frontend+backend (reduces context-switch hallucination), and an ecosystem deep enough to avoid reinventing infrastructure. Go is the best **escape hatch** for a standalone, highly transactional service (e.g., the ledger/posting core) where you want SQL-adjacent explicitness and zero ORM magic.

---

## 3. Backend framework comparison

| Framework | Language | Notes (2026) |
|---|---|---|
| **NestJS** | TypeScript | Current stable **v11.1.x** (v12.0 targeted ~Q3 2026 with full ESM migration, Standard Schema/Zod-native validation, Vitest/oxlint/Rspack default toolchain). Opinionated, Angular-inspired DI + module structure gives Claude a rigid template to follow — this rigidity is exactly what reduces architectural hallucination across a large, agent-generated codebase. Decorators + DTOs + Zod/class-validator map cleanly onto OpenAPI generation. **Recommended default backend framework.** |
| **Django (+ DRF)** | Python | Batteries-included (admin, ORM, migrations, auth) — fastest path to a working back-office CRUD app; DRF is mature for REST. Weaker fit when typing rigor across the whole codebase is required. |
| **Spring Boot** | Java/Kotlin | Gold standard for transaction management and enterprise integration (JMS, batch, scheduling); best pick when deviating toward a Java-shop or a bank/insurer with existing Spring infra. |
| **.NET (ASP.NET Core / Minimal APIs)** | C# | Extremely strong typed pipeline, native `decimal`, excellent EF Core migrations; pick when the org already runs Windows/SQL Server/Microsoft 365 stack. |
| **Rails** | Ruby | Fast to prototype, "convention over configuration" is AI-friendly for CRUD scaffolding, but weak static typing (Sorbet/RBS are bolt-ons, not defaults) makes it a weaker fit for financial-core correctness; reasonable for internal tools/prototypes, not the ERP system of record. |
| **Go stdlib + sqlc + chi/net-http** | Go | No framework magic at all — every route, every query is explicit generated code. This is the *most hallucination-resistant* option because there is nothing implicit for Claude to get wrong; recommended for the isolated ledger/integration-worker services, not the whole app (too much boilerplate for a full ERP UI-plus-API surface). |

**Recommended default:** **NestJS** for the API layer. Its module/controller/service/DTO structure is rigid enough that an agent extending the codebase months later (or a different agent session) can pattern-match existing modules reliably — this "template rigidity" property matters more for multi-session AI-authored codebases than for human teams.

---

## 4. Database: why PostgreSQL wins for ERP

**PostgreSQL 18** was released **2025-09-25**, is the current stable major version, and is the default recommendation for the ERP system of record. Reasons, each independently sufficient:

1. **True ACID transactions with configurable isolation** (up to `SERIALIZABLE`) — required for double-entry ledger correctness, inventory reservation, and multi-step order/invoice workflows that must never partially commit.
2. **Row-Level Security (RLS)** — lets the database itself enforce tenant/company isolation (`tenant_id = current_setting('app.tenant_id')::uuid`) so a bug in application code cannot leak Company A's invoices into Company B's report; this is the recommended default multi-tenancy pattern for SaaS-style ERPs (AWS, Aurora, and multiple 2025-2026 practitioner write-ups converge on this pattern). **Caveat:** RLS predicates must have `tenant_id` as the *leading column* of every relevant index or performance degrades by roughly two orders of magnitude — this is the single most common RLS production mistake.
3. **JSONB** — lets an agent model long-tail/variant ERP fields (custom fields per customer, flexible line-item attributes) without a migration for every tenant-specific field, while keeping the core schema strongly typed and relational. PostgreSQL 18 further sped up JSONB: `jsonb_path_query` is up to ~2x faster on deeply nested documents, and GIN-index containment lookups (`@>`) are faster too.
4. **Declarative table partitioning** — necessary at scale for append-heavy ERP tables (ledger entries, audit logs, stock movements); PG18's planner now prunes irrelevant partitions earlier, cutting planning time roughly in half for tables with hundreds of partitions, and improves partition-wise joins.
5. **Extensions that matter for ERP specifically:** `pgcrypto` (field-level encryption), `pg_partman` (partition automation), `pgvector` (semantic search/embeddings for AI features bolted onto the ERP — e.g., "find similar invoices"), full-text search built in (reduces the need for a separate search engine for most ERP-scale document/record search).
6. **One database, one operational surface.** ERPs are relational-by-nature (orders → lines → shipments → invoices → payments, all FK-linked); a single strongly-consistent relational store is simpler to reason about, back up, and audit than a polyglot-persistence architecture, which most ERPs do not need at typical (sub-hyperscale) transaction volumes.

**When to deviate from pure Postgres:** add Redis for caching/session/rate-limiting and a dedicated search engine (Meilisearch/Typesense/Elasticsearch) only once full-text/faceted search needs outgrow Postgres `tsvector`/GIN — not by default on day one.

---

## 5. ORM / query-layer comparison (the highest-leverage decision for AI-buildability)

This is arguably the most consequential choice for an AI-authored ERP, because it directly determines how often Claude's generated data-access code is *silently wrong* vs. *caught at compile time*.

| Layer | Language | Type safety model | Correctness trade-off | Fit for ERP |
|---|---|---|---|---|
| **Prisma** | TS | Schema-first, generates a typed client | **Prisma 7** (shipped late 2025) removed the Rust query engine entirely — the client is now pure TypeScript, bundle dropped ~14MB→~1.6MB, queries ~3x faster than Prisma 6, cold starts ~1-3s→~90ms. Very good migrations DX (`prisma migrate`), excellent schema-as-single-source-of-truth for an agent to read before generating code. Historically the safest, most productive default for teams on serverful infra. | Strong default for the **application/CRUD layer** of the ERP |
| **Drizzle ORM** | TS | Code-first, SQL-shaped TS API, ~7.4KB gzip, zero runtime deps | Stays closer to raw SQL (less abstraction to hide a subtly wrong query), wins decisively for serverless/edge cold-start-sensitive deployments (Cloudflare Workers, Vercel Edge, Lambda) | Preferred when deploying to **edge/serverless**; for a monolithic ERP on containers, Prisma 7's DX advantage usually outweighs Drizzle's bundle-size edge |
| **TypeORM** | TS | Decorator-based, Active Record or Data Mapper | Older, historically weaker type inference and more footguns around lazy-loading/N+1; largely superseded by Prisma/Drizzle for new projects | Not recommended for new builds |
| **sqlc** | Go | Generates fully-typed Go structs/functions from *hand-written SQL* + schema, verified at generation time | You write the SQL; sqlc guarantees the generated Go matches it exactly — the strongest correctness guarantee of any layer here because there is no query-builder abstraction to get subtly wrong, and an agent can visually verify the SQL itself before trusting the generated code | **Best-in-class for the transactional core** (ledger, inventory movements) where every query must be auditable as literal SQL |
| **SQLAlchemy** | Python | Core (SQL-forward) or ORM (declarative) | Extremely mature, but ORM sessions/lazy-loading are a well-known source of subtle bugs (N+1, stale session state) that an agent can easily reproduce unless explicitly warned | Fine for Python-side reporting/analytics services, not recommended for the financial core |
| **jOOQ** | Java/Kotlin | Generates typed DSL from the actual DB schema (like sqlc for JVM) | Strong compile-time SQL correctness, mature, verbose | Excellent when deviating to a JVM stack |

**Recommendation:** **Prisma 7** as the default ORM for the TypeScript/NestJS application layer (schema.prisma as the single readable source of truth an agent can diff against migrations), with **sqlc-style raw-SQL discipline** (hand-reviewed SQL for any function touching money — postings, payments, reconciliation) enforced as a house rule regardless of ORM, i.e., **never let the ORM auto-generate the SQL for a financial-posting write-path** — write and review that SQL explicitly (via Prisma's `$queryRaw`/`$transaction` or a raw migration-backed function) so a human/agent can audit exactly what hits the ledger.

---

## 6. Frontend

| Choice | 2026 status | Recommendation |
|---|---|---|
| **React + TypeScript** | Still the dominant enterprise UI baseline; largest Claude training corpus of any frontend stack | Default |
| **Next.js** | **Next.js 16.2.x** current (Turbopack default bundler, React 19.2, Cache Components, async `params`/`searchParams` as Promises, Server Actions stable since v14 and used by default for mutations without hand-written API routes) | Default meta-framework — Server Actions collapse a large share of ERP CRUD boilerplate (form → mutation → revalidate) into one reviewable function, which is good for AI-buildability |
| **TanStack Query / Table / Router** | Mature, framework-agnostic; commonly paired with Next.js for client-side cache/state that Server Components don't cover | Use for complex interactive grids (the bread-and-butter ERP data-table UI) — better for large sortable/filterable transactional tables than Server Components alone |
| **Server-driven UI** | Relevant for very large ERP suites (many similar CRUD screens) where a schema-driven form/table renderer reduces the number of near-duplicate screens an agent must generate and keep in sync | Consider once the app has 30+ near-identical CRUD screens; not needed for MVP |

---

## 7. API style: REST/OpenAPI vs GraphQL vs tRPC

| Style | Best fit | 2026 note |
|---|---|---|
| **tRPC** | Single-repo, single-language (TS front+back) internal ERP UI | Wins for pure TS monorepos: end-to-end type inference, zero codegen, fastest iteration for an agent because there's no schema-drift class of bug possible. **Constraint:** breaks down the moment you need a mobile app, a third-party integration, or a non-TS caller — then you need REST/OpenAPI anyway. |
| **REST + OpenAPI** | Public/partner integrations, third-party accounting/payment connectors, multi-client (web + mobile + external) | Still powers the large majority of public APIs; OpenAPI spec is the best artifact for an agent to generate client SDKs and for auto-generated integration tests. **Required regardless of internal choice**, because every real ERP eventually needs a documented external API (accountant exports, bank feeds, e-commerce connectors). |
| **GraphQL** | Complex, deeply nested data graphs consumed by many different front-ends/teams | Adds real complexity (resolver N+1, schema governance) that is rarely justified for a single-product ERP; reserve for large multi-team GraphQL federations, not the default. |

**Recommendation:** **tRPC internally** (NestJS-adjacent or NestJS+`nestjs-trpc`) for the first-party web app, **REST+OpenAPI** as the mandatory public/integration boundary (webhooks, partner API, accounting-system export). Do not add GraphQL by default.

---

## 8. Background jobs, caching, search

- **Background jobs:** Use a **queue (BullMQ on Redis)** for atomic, self-contained, restart-cleanly jobs — sending emails, generating a PDF invoice, processing an upload, nightly batch reports. Escalate to a **durable-execution engine (Temporal.io)** only for genuinely long-running, multi-step, stateful business processes that must survive crashes mid-flight and resume exactly where they left off (e.g., a multi-day approval-and-payment-release workflow, a multi-step month-end close). Don't default to Temporal for simple ERP CRUD side-effects — it's real infrastructure to operate; reserve it for processes that are "process-shaped," not "job-shaped."
- **Caching:** Redis, used narrowly (session storage, rate limiting, hot read-through caches for reference data) — never as a system of record for financial state.
- **Search:** Postgres full-text search (`tsvector`/GIN) is sufficient for most ERP-scale record search; add Meilisearch/Typesense only once faceted/fuzzy search UX requirements exceed what Postgres comfortably provides.

---

## 9. PROPOSED default full stack

> **PROPOSED — the opinionated default an agent should reach for absent a specific reason to deviate.**

| Layer | Choice | Version (verify at build time) |
|---|---|---|
| Language | TypeScript | 5.9+ stable (project should track latest stable minor at project start) |
| Runtime | Node.js | Latest **Active LTS** (Node 24 is Active LTS as of mid-2026; Node 26 enters LTS Oct 2026 — re-check at build time) |
| Backend framework | NestJS | v11.1.x stable (re-check for v12 GA, targeted ~Q3 2026) |
| ORM | Prisma | v7.x |
| Database | PostgreSQL | 18.x, RLS enabled per-tenant, partitioned ledger/audit tables |
| Cache/queue backing | Redis + BullMQ | current stable |
| Durable workflow (only if needed) | Temporal.io | current stable |
| Internal API | tRPC | current stable |
| External/partner API | REST + OpenAPI 3.1 | — |
| Frontend framework | Next.js (App Router) + React | Next.js 16.2.x, React 19.2 |
| Data-fetching/state | TanStack Query + TanStack Table | current stable |
| Validation | Zod (shared front/back schema) | current stable |
| Search (if/when needed) | Postgres FTS → Meilisearch escalation | — |

**Why this exact combination:** it is one language (TypeScript) end-to-end, minimizing the context-switch surface where an AI agent's mental model of types/idioms can drift between frontend and backend; it puts financial-transaction correctness in the database (Postgres ACID + RLS) rather than in application code where an agent could plausibly forget a check; and every layer (NestJS, Prisma, Next.js, tRPC/Zod) has enough 2025-2026 training-data density that Claude's first-draft code is reliably idiomatic and compiles.

---

## 10. Decision matrix — when to deviate from the default

| Signal | Deviate to |
|---|---|
| Org is an existing Microsoft/Windows shop, needs on-prem AD/SQL Server integration, wants native `decimal` type | **.NET 10 + EF Core**, C# 14 |
| Org is an existing Java/Spring enterprise (bank, insurer, existing SAP/Oracle integrations) | **Spring Boot (Kotlin or Java)** |
| Need a single, extremely high-throughput, high-integrity isolated service (ledger posting kernel, payment-settlement engine) alongside the main TS app | **Go + sqlc**, or **Rust + Axum + SQLx** for the most correctness-critical narrow component only |
| Deploying primarily to edge/serverless (Cloudflare Workers, Vercel Edge) with tight cold-start budgets | **Drizzle** instead of Prisma; consider lighter framework (Hono) instead of NestJS |
| Need fast internal back-office CRUD tooling, not the system of record | **Django + DRF** admin-driven prototype, migrate the financial core to the primary stack once validated |
| Multi-team org needing a federated data graph across many services | **GraphQL** (Apollo/Federation) at the aggregation layer only, keep tRPC/REST underneath |
| Genuinely long-running, multi-day, resumable business workflows (approval chains, month-end close orchestration) | **Temporal.io** in addition to the queue |

---

## 11. Key risks / open items

- The 2026 Claude Code language-cost benchmark (`(unverified as of 2026-07)` for exact multiplier reproducibility) suggests statically-typed languages cost materially more in agent tokens per equivalent task than Python/JS — budget for this in agent-cost planning, but the correctness payoff for financial code justifies it.
- NestJS v12 (ESM-only, Zod-native validation) is targeted for ~Q3 2026 but not yet GA as of this report; re-verify before committing to migration-sensitive decisions.
- Node.js is mid-transition to a new release cadence (one major/year from 2027, every release LTS) — re-check the Active LTS version at actual build time rather than trusting this document long-term.
- RLS performance requires disciplined composite indexing (`tenant_id` leading column) from day one; this is a correctness-adjacent operational risk that should become a house rule (checked in code review / migration lint), not a footnote.

---

## Sources

- [PostgreSQL 18.0 Release Notes](https://www.postgresql.org/docs/release/18.0/)
- [PostgreSQL 18: What's New and Why It Matters — Rivestack](https://rivestack.io/blog/postgresql-18-new-features)
- [PostgreSQL Documentation: Row Security Policies](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)
- [PostgreSQL Documentation: Table Partitioning](https://www.postgresql.org/docs/current/ddl-partitioning.html)
- [Multi-tenant data isolation with PostgreSQL Row Level Security — AWS](https://aws.amazon.com/blogs/database/multi-tenant-data-isolation-with-postgresql-row-level-security/)
- [Row-level security recommendations — AWS Prescriptive Guidance](https://docs.aws.amazon.com/prescriptive-guidance/latest/saas-multitenant-managed-postgresql/rls.html)
- [Shipping multi-tenant SaaS using Postgres Row-Level Security — Nile](https://www.thenile.dev/blog/multi-tenant-rls)
- [Drizzle vs Prisma ORM in 2026 — Makerkit](https://makerkit.dev/blog/tutorials/drizzle-vs-prisma)
- [Prisma ORM vs Drizzle — Prisma Docs](https://www.prisma.io/docs/orm/more/comparisons/prisma-and-drizzle)
- [Drizzle vs Prisma in 2026 — Encore](https://encore.dev/articles/drizzle-vs-prisma)
- [sqlc documentation / install](https://docs.sqlc.dev/en/latest/overview/install.html)
- [sqlc Releases — GitHub](https://github.com/sqlc-dev/sqlc/releases)
- [Node.js 26.0.0 (Current) blog](https://nodejs.org/en/blog/release/v26.0.0)
- [Node.js — Evolving the Node.js Release Schedule](https://nodejs.org/en/blog/announcements/evolving-the-nodejs-release-schedule)
- [Node.js endoflife.date](https://endoflife.date/nodejs)
- [Announcing TypeScript 5.9 — TypeScript Devblog](https://devblogs.microsoft.com/typescript/announcing-typescript-5-9/)
- [Announcing .NET 10 — .NET Blog](https://devblogs.microsoft.com/dotnet/announcing-dotnet-10/)
- [.NET 10 LTS for Enterprise Applications — DEV](https://dev.to/ismcagdas/what-net-10-lts-means-for-enterprise-applications-2cdh)
- [Next.js Docs: Server Actions (serverActions config)](https://nextjs.org/docs/app/api-reference/config/next-config-js/serverActions)
- [Next.js Updates — Releasebot, July 2026](https://releasebot.io/updates/vercel/next-js)
- [Next.js Getting Started: Mutating Data](https://nextjs.org/docs/app/getting-started/mutating-data)
- [REST vs GraphQL vs tRPC vs gRPC in 2026 — DEV Community](https://dev.to/pockit_tools/rest-vs-graphql-vs-trpc-vs-grpc-in-2026-the-definitive-guide-to-choosing-your-api-layer-1j8m)
- [tRPC vs GraphQL vs REST — SD Times](https://sdtimes.com/graphql/trpc-vs-graphql-vs-rest-choosing-the-right-api-design-for-modern-web-applications/)
- [Dynamic Languages Faster and Cheaper in 13-Language Claude Code Benchmark — InfoQ, April 2026](https://www.infoq.com/news/2026/04/ai-coding-language-benchmark/)
- [NestJS v12 Roadmap: ESM Migration, Standard Schema — InfoQ, April 2026](https://www.infoq.com/news/2026/04/nestjs-12-roadmap-esm/)
- [NestJS v12.0.0 major release PR — GitHub](https://github.com/nestjs/nest/pull/16391)
- [NestJS core package — npm](https://www.npmjs.com/package/@nestjs/core)
- [Rust Web Frameworks in 2026: Axum vs Actix Web vs Rocket vs Warp vs Salvo — Medium](https://aarambhdevhub.medium.com/rust-web-frameworks-in-2026-axum-vs-actix-web-vs-rocket-vs-warp-vs-salvo-which-one-should-you-2db3792c79a2)
- [Rust for Backend Development: Axum Guide 2026 — Rustify](https://rustify.rs/articles/rust-backend-development-axum-2026)
- [Temporal.io — Durable Execution Solutions](https://temporal.io/)
- [When a queue isn't enough — Inngest Blog](https://www.inngest.com/blog/when-a-queue-isnt-enough)
- [A Practical Guide to Temporal — HackerNoon](https://hackernoon.com/a-practical-guide-to-temporal-what-it-does-how-it-compares-and-when-to-use-it)
