# R4 — Deployment Topologies for ERP (2025-2026 grounding)

**Purpose:** give an ERP-build operating system a default, defensible answer to "where does this run" — for a single client and for a SaaS fleet — with sizing, HA, DR, and containerization defaults an agent can apply without re-litigating architecture per project.

**Bottom line up front:** for the overwhelming majority of SMB ERP engagements, the correct default is **single VPS (or one on-prem box) + Docker Compose + managed/self-hosted Postgres + Caddy/Traefik TLS + pgBackRest to two off-site immutable targets**. Kubernetes and multi-region HA are *opt-in* answers to a specific, named requirement (contractual uptime SLA, 10+ concurrent tenants, or a platform team that already exists) — not a starting posture. This mirrors the field consensus: "if your entire application can reasonably run on one VM without constant resource pain, Compose is still a strong option," and Kubernetes' operational tax "can consume 20-40% of an engineer's time" for a small team without a dedicated platform group [Better Stack / DEV.to, 2026].

---

## 1. The five topologies

### 1.1 Local single-server (on-prem box in the business)

**Architecture:** one physical or lightly-virtualized machine on the client's premises running the ERP app, DB, reverse proxy, and backup agent in Docker Compose. UPS for power, a NAS or second internal disk for local backup replica, and a scheduled off-site sync (cloud object storage or a rotated external drive taken off-site).

**When to choose:** client has spotty/expensive internet, wants zero recurring hosting fee, has 1 physical location, has compliance/comfort reasons to keep data in the building (workshop, clinic, single retail site), or explicitly distrusts "the cloud." Also the right default when the client already owns capable hardware.

**Pros:** no recurring infra bill beyond power/internet; data physically in the client's control; works fully offline for LAN clients even if WAN drops; simplest mental model for a non-technical owner.

**Cons:** hardware failure = full outage until you're on-site or a spare box is provisioned; DR depends entirely on the operator's backup discipline; scaling requires a forklift upgrade or migration; single point of failure for power, disk, and network unless you add a UPS and RAID.

**Security posture:** must be patched by someone (define who — this is usually the #1 gap); expose nothing to WAN unless you deliberately add remote access (VPN, not raw port-forwarding); local firewall + OS auto-updates + disk encryption (LUKS/BitLocker) at minimum; physical access control matters (locked closet, not the reception desk).

**Cost profile:** $800-$3,000 one-time hardware (mini-PC/tower to a small rack unit), ~$0-50/mo recurring (electricity, optional off-site backup storage), no monthly VPS fee.

**Sizing:** Odoo-class ERP scaling data (2025 field guidance): 2 GB RAM/dual-core viable to ~10 users; 4-8 GB RAM/quad-core for up to 50 users; 16 GB RAM/4-8 cores + 80-160 GB SSD for a mid-size deployment; separate DB from app tier once you cross ~100 users or see sustained heavy load [ERPixel/Ariashaw, 2025]. Always provision ~20% storage headroom for logs/growth.

### 1.2 LAN-only / air-gapped

**Architecture:** identical stack to 1.1, but with **no route to the internet at all** — updates and license files enter via a controlled one-way transfer (USB, sneakernet, or a DMZ jump host with manual review). Time sync via a local NTP server, not `pool.ntp.org`.

**When to choose:** defense/classified programs, GxP pharma manufacturing, critical-infrastructure OT, or any client whose contracts/regulators mandate it. "For defense contractors, pharma manufacturers under GxP, classified government programs, and critical infrastructure operators, air-gap is not a feature — it is the only compliance posture that satisfies regulators, auditors, and national security requirements simultaneously" [ifactoryapp, 2025]. Don't reach for this by default — it roughly doubles operational cost (manual patch cadence, no SaaS convenience, no remote support) and should be justified by a named regulatory driver.

**Pros:** removes the entire remote-attack surface; immune to internet-borne ransomware delivery vectors; satisfies the strictest data-residency/sovereignty demands.

**Cons:** every OS/app/CVE patch is a manual, scheduled event — patch lag is real risk; no vendor remote support without a supervised bridge; monitoring/alerting must also be local (no SaaS APM); backup verification and DR testing are entirely the client's/integrator's responsibility.

**Security posture:** hardened base OS image, no outbound DNS/NTP by default, USB port control policy, signed/verified update packages only, local certificate authority for internal TLS (self-signed internal root CA distributed to clients).

**Cost profile:** hardware similar to 1.1 plus a dedicated maintenance contract (patch runs, on-site visits) — budget 1.5-2x the ongoing labor of a networked on-prem box.

### 1.3 Single VPS

**Architecture:** one cloud VM (Hetzner/DigitalOcean/Vultr/Linode-class) running Docker Compose: app container(s), Postgres container (or managed DB add-on), Caddy/Traefik as reverse proxy with automatic Let's Encrypt TLS, and a backup sidecar pushing encrypted archives off-box.

**When to choose:** this is the **default** for a single-tenant client deployment when the client has no on-prem constraint and wants low fixed cost with someone else managing power/network/hardware failure. Best fit for 1-150 users, single-location or distributed-but-thin-client access, no hard data-residency requirement.

**Pros:** cheapest true "always-on, remotely accessible" option; predictable flat monthly cost; provider handles power/network/physical hardware; snapshot-based DR is built into most providers; trivially reproducible via IaC (one Terraform file + one `docker-compose.yml`).

**Cons:** still a single point of failure unless you pay for a second standby VM; "noisy" resource ceilings on shared-vCPU plans (use dedicated-vCPU tiers — e.g., Hetzner CCX line — for DB-heavy workloads); provider outage = your outage unless you have a DR VM in a second region/provider.

**Cost profile (2026 pricing, verified):** Hetzner CCX13 (2 dedicated vCPU, 8 GB RAM, 80 GB NVMe, 20 TB traffic) ≈ €14.86/mo; scales to CCX63 (48 vCPU/192 GB) ≈ €343/mo [Hetzner docs, 2026]. DigitalOcean Basic droplet 4 vCPU/8 GB ≈ $48/mo — roughly 60% more than Hetzner's equivalent dedicated-vCPU tier [Better Stack, 2026]. A right-sized small-ERP VPS (4 vCPU/8-16 GB/160 GB NVMe) lands at **$15-60/mo** depending on provider — call it $30/mo as the planning default.

**Sizing tiers (Postgres-backed ERP, rule of thumb):**

| Tier | Users | vCPU | RAM | Storage | Postgres shared_buffers |
|---|---|---|---|---|---|
| Micro | ≤10 | 2 | 4-8 GB | 40-80 GB SSD | 1-2 GB |
| Small | 10-50 | 2-4 | 8-16 GB | 80-160 GB NVMe | 2-4 GB |
| Medium | 50-150 | 4-8 | 16-32 GB | 160-500 GB NVMe, RAID1/10 | 4-8 GB |
| Large | 150+ | 8+ (split app/DB hosts) | 32 GB+ per host | 500 GB-2 TB NVMe | separate DB host, tuned per workload |

Above ~100-150 users or when write contention shows up, split app and DB onto separate hosts — this is the standard Odoo/ERPNext field guidance [ERPixel, 2025].

### 1.4 Cloud managed (AWS/GCP/Azure — managed Postgres, containers, serverless)

**Architecture:** managed Postgres (RDS/Aurora, Cloud SQL, Azure Database for PostgreSQL) + containerized app on ECS/Fargate, Cloud Run, or a managed Kubernetes service (EKS/GKE/AKS) behind a managed load balancer with ACM/Google-managed/Azure-managed TLS certs. IaC (Terraform/Pulumi) is mandatory here, not optional.

**When to choose:** you need built-in HA (Multi-AZ failover), point-in-time recovery as a checkbox not a script, compliance attestations (SOC2/HIPAA BAAs) inherited from the cloud provider, elastic scaling for bursty transaction volumes, or you're building the **multi-tenant SaaS** version of the ERP (see §6).

**Pros:** managed failover, automated backups/PITR, provider compliance certifications transfer to you, autoscaling, integrates with provider IAM/secrets/observability stack, serverless containers (Fargate/Cloud Run) remove host patching entirely.

**Cons:** materially higher cost than a VPS at the same capacity; steeper learning curve; vendor lock-in risk (especially with serverless-specific APIs); egress fees and "hidden" costs (NAT gateways, load balancers) commonly double the advertised compute price at scale [Cloud Burn / Sedai, 2026].

**Cost profile (2026, verified):**
- RDS Postgres: `db.t4g.micro` (2 vCPU burstable, 1 GiB) ≈ $11.68/mo compute; storage from $0.115/GB-mo (gp3-class); first 100 GB/mo backup storage free [AWS RDS pricing / Aiven, 2026]. A right-sized small-ERP managed DB (2 vCPU/8 GB, Multi-AZ) runs **$150-300/mo** once Multi-AZ doubling and storage/IOPS are included.
- Managed Kubernetes control plane: EKS $0.10/hr (~$73/mo) standard, $0.60/hr (~$438/mo) extended support; GKE Standard/Autopilot control plane free up to one cluster with a $74.40/mo credit; AKS free tier has no SLA, Standard tier ~$73/mo, Premium ~$438/mo [Sedai / OneUptime / CloudOptimo, 2026]. Control plane is a small fraction of total spend — at 200 nodes, all-in costs range **$43K-$52K/mo** across EKS/GKE/AKS once compute, load balancers, and egress are included [LeanOps, 2026]. This scale is irrelevant to almost every ERP build in this playbook; it's cited to make clear k8s at scale is an enterprise-platform cost, not an SMB one.

**Bottom line:** managed cloud is the right call when you need the *managed* part (failover, compliance, elastic scale) — not merely because "cloud" sounds more serious than a VPS. For a single client's ERP, a managed Postgres instance behind a single ECS/Fargate service (no k8s) is a reasonable middle tier between "VPS" and "full k8s SaaS platform."

### 1.5 Hybrid

**Architecture:** primary transactional system stays on-prem/VPS (low latency, data residency, cost control) while specific workloads — reporting/BI, backups, DR standby, email/notifications, AI/analytics add-ons — live in a managed cloud service. Site-to-site VPN or a lightweight message queue (webhook/SQS-style) bridges the two.

**When to choose:** client wants on-prem control of the system of record but needs cloud-scale reporting, wants an off-site DR replica without moving the primary, or is mid-migration from on-prem to cloud (hybrid is the *transition state*, not usually the destination). Also fits multi-location clients where one site hosts the primary DB and others connect over VPN/site-to-site links.

**Pros:** keeps sensitive/primary data where the client wants it while borrowing cloud elasticity for secondary workloads; natural off-site DR target (replicate on-prem Postgres to a cloud standby); good stepping-stone architecture.

**Cons:** most operationally complex option — two environments, two patch cadences, a network bridge that is itself a security-critical component and single point of failure; requires real network engineering (VPN health monitoring, split-DNS, latency budgeting).

**Cost profile:** on-prem/VPS cost (§1.1/1.3) + a modest cloud bill for the secondary workload (typically $50-300/mo) + VPN appliance/service cost.

---

## 2. Chooser matrix

| Driver | Local on-prem | LAN-only/air-gapped | Single VPS | Cloud managed | Hybrid |
|---|---|---|---|---|---|
| No/unreliable internet | ✅ best fit | ✅ | — | — | partial |
| Regulatory/data-sovereignty hard requirement | ✅ | ✅ best fit | conditional | ✅ (with region pinning + BAA) | ✅ |
| Lowest fixed monthly cost | ✅ (no recurring fee) | ✅ | ✅ (cheapest *hosted* option) | — | — |
| Needs someone else to own hardware/power/network | — | — | ✅ | ✅ | partial |
| Single client, 1-150 users, no HA SLA | ✅ or ✅ | if regulated | ✅ **default** | overkill | overkill |
| Multi-tenant SaaS fleet | — | — | only for very early MVP | ✅ **default** | — |
| Built-in automated failover / PITR required | ❌ (manual) | ❌ | manual scripting | ✅ | on secondary only |
| Client wants full data control + cloud DR | — | — | — | — | ✅ **default** |
| Team has no dedicated ops/platform engineer | ✅ | ✅ | ✅ | conditional (managed services reduce need) | risky |

---

## 3. Security posture summary

- **On-prem/LAN:** OS auto-patch policy with a named owner; disk encryption at rest; UPS; local firewall default-deny inbound; VPN (WireGuard/Tailscale) for any remote admin access — never raw port-forward RDP/SSH/DB ports to WAN.
- **VPS:** same OS hardening + provider firewall/security groups scoped to 80/443 only (SSH via key-only, ideally behind a bastion or Tailscale); automatic OS security updates (`unattended-upgrades`); fail2ban or equivalent; TLS everywhere via Caddy/Traefik automatic ACME.
- **Cloud managed:** provider IAM least-privilege, secrets manager (not env files) for DB credentials, VPC private subnets for DB (no public endpoint), security groups scoped to app tier only, provider-native audit logging (CloudTrail/Cloud Audit Logs) turned on from day one.
- **Multi-tenant SaaS:** Postgres Row-Level Security (RLS) as the standard defensive layer for pooled tenants, with tenant context set server-side at connection/session start — "never passing tenant_id from the client unchecked" [AWS Database Blog, 2025]. Treat RLS as necessary but not sufficient — pair with tenant-scoped service accounts and app-layer checks, since "if isolation relies entirely on RLS without additional middleware enforcement, a single database-level vulnerability can expose the entire customer base" [webkorps, 2025].

---

## 4. Backup & DR — the default policy

Adopt **3-2-1-1-0** as the non-negotiable baseline, per CISA/NIST-aligned modern guidance: 3 copies of data, on 2 different media, 1 off-site, 1 immutable/air-gapped, 0 errors on a *verified* restore [SentinelOne / Impossible Cloud, 2025]. Modern ransomware explicitly targets backup infrastructure — deleting snapshots, encrypting repositories, disabling backup software, and using stolen credentials against cloud backup consoles — so at least one copy must be genuinely unreachable/immutable from the production admin account [Huntress, 2025]. CISA's own recovery-testing guidance: verify you can actually restore at least seven days of operational data, not just that a backup job "succeeded" [CISA, 2025].

**Concrete implementation for Postgres-backed ERP:**
- Use **pgBackRest** for full/differential/incremental backups with parallel WAL archiving direct to S3/Azure Blob/GCS-compatible object storage — supports multiple repositories with independent retention, which is how you get the "1 immutable" copy cleanly (a second repo with object-lock/retention-lock enabled) [pgBackRest docs, 2025].
- Local repo (fast restore) + remote object-storage repo (off-site) + one retention-locked/immutable repo (ransomware-proof) = your 3-2-1-1.
- Automate a scheduled *restore test* (not just backup verification) — this is the "0" in 3-2-1-1-0 and the single most commonly skipped step in SMB ERP deployments.

**RPO/RTO tiers to standardize on (map the client's ERP into one, don't invent bespoke targets per project):**

| Tier | Example workload | RTO | RPO | Typical mechanism |
|---|---|---|---|---|
| Tier 1 — Mission-critical | Core ERP transactional DB, invoicing/payments | minutes-1 hr | near-0 to 15 min | continuous WAL archiving + standby replica or Multi-AZ |
| Tier 2 — Business-critical | Internal reporting, CRM sync, email/notifications | 1-4 hr | 1-4 hr | scheduled incremental backups + documented manual restore runbook |
| Tier 3 — Operational | Dev/staging, internal wikis, archives | 8-24 hr | 24 hr | nightly full backup only |

"Trying to get near-zero RPO and RTO for everything is incredibly expensive, and for most small and mid-sized businesses, it's also completely unnecessary" [DCHost/Rubrik, 2025] — the ERP build OS should default new clients to **Tier 2** unless the client explicitly needs and will pay for Tier 1 (Multi-AZ managed DB, standby replica, or clustered on-prem pair).

---

## 5. High availability

- **Single VPS/on-prem:** no built-in HA. Add a warm-standby VM/box with periodic WAL-shipping if the client's Tier justifies it; otherwise HA = fast restore from backup (RTO measured in tens of minutes to hours, which is fine for Tier 2/3 workloads).
- **Cloud managed:** Multi-AZ (RDS)/regional (Cloud SQL)/zone-redundant (Azure) failover is a checkbox — use it once a client is Tier 1. Don't pay for it by default; it roughly doubles DB cost.
- **Kubernetes:** only relevant once you have ≥3 nodes for real HA and a team that can absorb the "20-40% of an engineer's time" operational tax cited above [DEV.to, 2026]. Lightweight single-node distros (k3s/MicroK8s) exist for teams that want the API surface without a real cluster, but for this playbook's default client profile, they add complexity without adding real availability over a well-run Compose host with a standby.

---

## 6. Single-tenant-per-client vs multi-tenant SaaS

**Single-tenant (dedicated stack per client):** simplest security story (blast radius = one client), simplest compliance story (a breach or outage never crosses tenants), easiest to reason about backups/DR per client, but highest per-client marginal cost and highest ops overhead at fleet scale (N clients = N stacks to patch/monitor).

**Multi-tenant pooled (shared DB, `tenant_id` + RLS):** lowest cost and easiest to scale operationally (one stack, N logical tenants), but requires disciplined isolation — RLS plus app-layer enforcement, tenant-scoped credentials, and monitoring for the "noisy neighbor" problem where one tenant's heavy workload degrades everyone else's [bix-tech / arielsoftwares, 2025-2026].

**Bridge/hybrid (the pragmatic default for a growing SaaS ERP):** most tenants pooled, VIP/regulated/high-volume tenants get their own schema or database — "the pragmatic default for many B2B SaaS platforms" [zenn.dev, 2025]. **Recommend this bridge model as the default multi-tenant architecture** rather than committing to pure-pooled or pure-siloed at the outset — it lets the same codebase serve a $50/mo self-serve tenant and a $5,000/mo enterprise tenant with a dedicated schema, without a rewrite.

---

## 7. Containerization / IaC baseline

**Default:** Docker + Docker Compose for everything below "10+ services across multiple nodes with a dedicated platform team" [Better Stack, 2026]. One `docker-compose.yml` defines app, DB, reverse proxy, and backup sidecar; one `.env` per environment; version-pin every image tag (never `:latest` in production).

**Escalate to Kubernetes only when:** you have 10+ independently-scaled services, need zero-downtime rolling deploys at real scale, require multi-node auto-scaling, or already run a platform team maintaining k8s for other products. For a growing multi-tenant SaaS ERP that has outgrown one VPS, the honest middle step is **multiple Compose hosts behind a shared load balancer + managed Postgres**, not an immediate jump to EKS/GKE — k8s should be adopted when its *specific* capabilities (declarative autoscaling, self-healing across nodes, complex service mesh) are actually needed, not as a default "serious infra" signal.

**Reverse proxy/TLS default:** **Caddy** for the simplest automatic-HTTPS story (zero-config ACME/Let's Encrypt, ideal for a single client's VPS) [Caddy docs / Swetrix, 2025]; **Traefik** when you're already Docker-label-driven and running many services that need dynamic routing (multi-tenant SaaS with per-tenant subdomains is a good Traefik fit) [byte-guard/homelabstarter, 2026]. Either way: mount the cert/data volume persistently (losing it triggers Let's Encrypt rate limits on every container restart), enforce TLS 1.2+, HSTS, and force HTTP→HTTPS redirect.

**IaC baseline:** Terraform (or Pulumi) for anything touching a cloud provider — VPC, managed DB, load balancer, DNS — even for a "just one VPS" cloud deployment, so the environment is reproducible and the DR runbook is "run `terraform apply` + restore latest backup," not tribal knowledge.

---

## 8. Two concrete recipes

### 8.1 Small-business local server (recipe)

1. Mini-PC or small tower: 4-8 core CPU, 16-32 GB RAM, 2x NVMe in RAID1 (or ZFS mirror), UPS.
2. Ubuntu Server LTS, unattended-upgrades enabled, SSH key-only + Tailscale/WireGuard for remote admin (no port-forwarding).
3. Docker + Docker Compose: `app` (ERP), `postgres`, `caddy` (reverse proxy, internal LAN cert or public domain via split-DNS), `pgbackrest`/cron backup sidecar.
4. Backups: local repo on second disk (fast restore) + nightly encrypted push to cloud object storage (off-site) + weekly snapshot to a retention-locked bucket (immutable) = 3-2-1-1. Quarterly restore test, logged.
5. Monitoring: simple uptime check (self-hosted Uptime Kuma or a free external pinger) + disk/CPU alert via email.
6. Documented runbook: what to do if the box dies (spare-hardware plan or "reprovision from Terraform/Ansible + restore latest backup" if a spare box or VPS fallback is pre-arranged).

### 8.2 Multi-tenant cloud SaaS (recipe)

1. Terraform-managed VPC on AWS/GCP/Azure; private subnets for DB, public subnet only for load balancer.
2. Managed Postgres (RDS/Cloud SQL/Azure DB for PostgreSQL), Multi-AZ once any tenant is Tier 1; pooled schema with `tenant_id` + RLS policies as default isolation; dedicated schema/DB carve-out path for enterprise tenants (bridge model).
3. App containers on ECS/Fargate or Cloud Run to start (no k8s until service count/scale genuinely demands it); autoscaling group sized off request rate, not guesswork.
4. Traefik or a managed ALB/API Gateway for per-tenant routing (subdomain-per-tenant or path-based, decided at day one — this is hard to retrofit).
5. Backups: automated PITR from the managed DB service + a separate pgBackRest/logical-dump export to a second, immutable object-storage bucket in a different account/region (defense against a compromised primary cloud account) — don't rely solely on the provider's own snapshot mechanism for the "1 immutable" leg.
6. Secrets in the provider's secrets manager; per-tenant audit logging; centralized structured logging/APM (CloudWatch/Cloud Logging/Azure Monitor or a third-party APM) from day one — multi-tenant debugging without per-tenant log correlation is unworkable at scale.
7. IaC + CI/CD: every environment (staging, prod) reproducible from Terraform + a pinned container image tag; blue/green or rolling deploy via the platform's native mechanism (ECS deployment circuit breaker, Cloud Run revisions, etc.) before ever reaching for k8s-native rollout strategies.

---

## 9. Proposed defaults (for the ERP build operating system)

1. **Default topology for a new single-client engagement:** single VPS (dedicated-vCPU tier, e.g., Hetzner CCX-class or equivalent), Docker Compose, Caddy for TLS, pgBackRest to 2 off-site targets (one immutable). On-prem only when the client explicitly needs it (no/poor internet, physical control preference, or a real regulatory driver).
2. **Default RPO/RTO tier for a new client:** Tier 2 (1-4 hr RTO/RPO) unless the client's workload is explicitly transactional/revenue-critical, in which case escalate to Tier 1 with a standby replica or Multi-AZ managed DB.
3. **Default backup policy:** 3-2-1-1-0, implemented via pgBackRest with a quarterly logged restore test — non-negotiable regardless of topology.
4. **Default containerization:** Docker Compose until a named, specific requirement (10+ services, multi-node autoscale, existing platform team) justifies Kubernetes.
5. **Default multi-tenant architecture (once building the SaaS product, not a client-specific instance):** pooled Postgres + RLS as the base, with a documented escalation path to per-tenant schema/DB for enterprise or regulated tenants (the bridge model).
6. **Default reverse proxy:** Caddy for single-tenant/simple deployments; Traefik once routing many services/subdomains dynamically (multi-tenant SaaS).
7. **Default IaC:** Terraform for anything cloud-managed, even a lone VPS+managed-DB setup, so DR is "redeploy + restore," not institutional memory.

---

## 10. Open items / unverifiable-as-of-2026-07

- Exact current Let's Encrypt rate limits and any 2026 policy changes were not independently re-verified beyond the cited guides — treat specific numeric rate-limit figures as **(unverified as of 2026-07)** and check `letsencrypt.org` docs before hard-coding into tooling.
- Precise current per-GB egress pricing across AWS/GCP/Azure fluctuates by region/commitment tier; only representative control-plane and compute figures are cited above — always re-quote at proposal time.
- k3s/MicroK8s as a "lightweight k8s for one node" alternative is mentioned as a field pattern but was not independently benchmarked here — **(unverified as of 2026-07)** whether it's net-simpler than Compose for this playbook's target client profile; current recommendation is to skip it and use Compose directly.

---

## Sources

- CISA — Back Up Government Data: https://www.cisa.gov/audiences/state-local-tribal-and-territorial-government/secure-us-sltt/back-government-data
- SentinelOne — 3-2-1 Backup Strategy: https://www.sentinelone.com/cybersecurity-101/cybersecurity/3-2-1-backup-strategy/
- SentinelOne — Immutable Backups: https://www.sentinelone.com/cybersecurity-101/cybersecurity/immutable-backups/
- Impossible Cloud — 3-2-1 Backup Rule Modernized (3-2-1-1-0): https://www.impossiblecloud.com/en-us/magazine/3-2-1-backup-rule-v2-2-new
- Huntress — 3-2-1 Backup Rule Explained: https://www.huntress.com/blog/3-2-1-backup-rule
- Rubrik — RTO vs RPO: https://www.rubrik.com/insights/rto-rpo-whats-the-difference
- DCHost — RPO, RTO and DR Planning for Small Businesses: https://www.dchost.com/blog/en/rpo-rto-and-disaster-recovery-planning-for-small-businesses/
- AWS Cloud Operations Blog — Establishing RPO/RTO Targets: https://aws.amazon.com/blogs/mt/establishing-rpo-and-rto-targets-for-cloud-applications/
- Better Stack — Docker Compose vs Kubernetes: https://betterstack.com/community/guides/scaling-docker/docker-compose-vs-kubernetes/
- DEV.to — Docker Compose vs Kubernetes: When to Use Each in 2026: https://dev.to/_d7eb1c1703182e3ce1782/docker-compose-vs-kubernetes-when-to-use-each-in-2026-1hji
- Raff Technologies — Kubernetes vs Docker Compose for Small Teams: https://rafftechnologies.com/learn/guides/kubernetes-vs-docker-compose-small-teams
- AWS RDS PostgreSQL Pricing: https://aws.amazon.com/rds/postgresql/pricing/
- Aiven — db.t4g.micro pricing/specs: https://aiven.io/tools/instances/db.t4g.micro
- Cloud Burn — AWS RDS Cost Breakdown 2026: https://selfhost.dev/blog/aws-rds-cost-breakdown-2026/
- ERPixel — Odoo Server Hardware Requirements On-Premise 2025: https://erpixel.com/odoo-server-requirements/
- Ariashaw — Odoo Requirements Calculator 2025: https://ariashaw.com/toolkit/odoo-requirements-calculator
- Clerk — Multi-Tenant vs Single-Tenant SaaS Architecture: https://clerk.com/blog/multi-tenant-vs-single-tenant
- AWS Database Blog — Multi-tenant data isolation with PostgreSQL RLS: https://aws.amazon.com/blogs/database/multi-tenant-data-isolation-with-postgresql-row-level-security/
- Webkorps — Building Multi-Tenant SaaS: Architecture Decisions You Cannot Reverse: https://www.webkorps.com/blog/building-multi-tenant-saas-architecture/
- Zenn.dev — Multi-Tenant Architecture Patterns for SaaS 2025: https://zenn.dev/shineos/articles/saas-multi-tenant-architecture-2025?locale=en
- Bix-Tech — Multi-Tenant Architecture Complete Guide: https://bix-tech.com/multi-tenant-architecture-the-complete-guide-for-modern-saas-and-analytics-platforms-2/
- Hetzner Docs — Price Adjustment / Cloud pricing 2026: https://docs.hetzner.com/general/infrastructure-and-availability/price-adjustment/
- Better Stack — Hetzner Cloud Review 2026: https://betterstack.com/community/guides/web-servers/hetzner-cloud-review/
- Better Stack — DigitalOcean vs Hetzner Cloud 2026: https://betterstack.com/community/guides/web-servers/digitalocean-vs-hetzner/
- Caddy — official site (automatic HTTPS): https://caddyserver.com/
- Swetrix — Caddy Reverse Proxy Practical Guide: https://swetrix.com/blog/caddy-reverse-proxy
- Byte-Guard — Nginx Proxy Manager vs Traefik vs Caddy 2026: https://blog.byte-guard.net/nginx-proxy-manager-vs-traefik-vs-caddy/
- HomeLabStarter — Reverse Proxy Comparison: https://homelabstarter.com/reverse-proxy-traefik-caddy-nginx/
- ifactoryapp — Air-Gapped Deployment for Defense, Pharma, Regulated Industries: https://ifactoryapp.com/sap-integration/on-prem-ai/air-gapped-deployment-defense-pharma-regulated
- HPE — Air-gapped and threat-adaptive security for private cloud (2025): https://www.hpe.com/us/en/newsroom/blog-post/2025/04/locked-down-by-design-air-gapped-is-the-next-inflection-point-for-private-cloud.html
- pgBackRest — official docs: https://pgbackrest.org/
- pgBackRest — User Guide: https://pgbackrest.org/user-guide.html
- Sedai — Kubernetes Pricing 2026 EKS vs AKS vs GKE: https://sedai.io/blog/kubernetes-cost-eks-vs-aks-vs-gke
- OneUptime — Managed Kubernetes Pricing Comparison 2026: https://oneuptime.com/blog/post/2026-02-09-managed-kubernetes-pricing-comparison/view
- LeanOps — EKS vs AKS vs GKE Pricing 2026 (200-node comparison): https://leanopstech.com/blog/eks-vs-gke-vs-aks-pricing-2026/
- CloudOptimo — EKS vs GKE vs AKS Best Managed Kubernetes 2026: https://www.cloudoptimo.com/blog/eks-vs-gke-vs-aks-best-managed-kubernetes-service-in-2026/
