# R6 — AI-Assisted Build Methodology for ERP Systems

*Track: R6-ai-build-method · Compiled 2026-07-06 · For: ERP Build Operating System playbook*

## 0. Thesis and default recommendation

An ERP is a multi-year, multi-module, financially-liable codebase. The single biggest risk of AI-assisted ERP development is not "the AI writes bad code" — it's **the AI writes plausible-looking code that is subtly wrong, stubbed out, or untested, and nobody notices until a customer's ledger doesn't balance.** The methodology below treats every AI output as a *claim* that must be mechanically falsified before it counts as done. Nothing is trusted because it "looks right"; everything is trusted because a deterministic check (compiler, test runner, grep, coverage tool) says so.

**Default adopted for the ERP build OS:** Spec-first (GitHub Spec Kit-style four-gate flow) → test-first (red/green) → build in small task slices → independent verifier subagent reviews the diff against the spec → deterministic anti-stub/anti-dead-code CI gates → git commit per completed, verified task → state file + append-only log for resumability → context checkpoint/compaction discipline above ~75% window usage. This is not a nice-to-have; it is the enforcement layer that makes autonomous or semi-autonomous agent work safe to merge into a system of record.

---

## 1. Spec-driven development (SDD) as the entry gate

### 1.1 What it is and why it's now the industry default
GitHub's **Spec Kit** (open-sourced 2025, "agent-agnostic," supporting 30+ coding agents as of v0.11.0, June 2026) formalizes Spec-Driven Development: "specifications do not serve code, code serves specifications... the PRD is not a guide for implementation, it is the source that generates implementation" [github.blog, Microsoft DevBlog]. The core insight for LLM-driven engineering: "language models work exceptionally well at pattern completion, but not at mind reading" — vague prompts force the model to silently guess across thousands of unstated requirements, and it will guess wrong on the ones that matter (tax rounding, approval thresholds, multi-currency, period-close logic) [github.blog].

### 1.2 The four-phase gated workflow (adopt as-is for ERP modules)

| Phase | Command (Spec Kit convention) | Output artifact | Gate before proceeding |
|---|---|---|---|
| Specify | `/speckit.specify` | `SPEC.md` — user journeys, success metrics, explicit non-goals | Human confirms the spec captures actual intent, not just a plausible one |
| Plan | `/speckit.plan` | `PLAN.md` — architecture, stack, integration points, data model deltas | Confirm plan matches org constraints (e.g., "must use existing ledger service, not a new one") |
| Tasks | `/speckit.tasks` | `TASKS.md` — small, independently testable, independently reviewable units | Each task is concrete enough that "done" is unambiguous |
| Implement | `/speckit.implement` | code + tests, one task at a time | Diff reviewed against the *specific task*, not the whole feature |

Anthropic's own Claude Code guidance converges on the same shape independently: "Separate research and planning from implementation to avoid solving the wrong problem... Letting Claude jump straight to coding can produce code that solves the wrong problem" [code.claude.com/docs/best-practices]. Anthropic additionally recommends **having the agent interview you** before the spec is written: *"I want to build [X]. Interview me in detail using AskUserQuestion. Ask about technical implementation, UI/UX, edge cases, concerns, and tradeoffs... Keep interviewing until we've covered everything, then write a complete spec to SPEC.md."* Then start a **fresh session** to execute the spec — clean context, focused entirely on implementation [code.claude.com/docs/best-practices].

**ERP-specific rule:** every SPEC.md for a financial or master-data-touching module must name (a) the files/interfaces touched, (b) explicit out-of-scope items, (c) an end-to-end verification step that proves the feature works, and (d) the accounting/compliance invariants it must not violate (e.g., "sum of journal lines must equal zero," "posted periods are immutable"). Time spent making the spec precise "pays off more than time spent watching the implementation" [code.claude.com/docs/best-practices].

### 1.3 Known risk of SDD
Spec Kit is agent-agnostic and fast-moving (v0.11.0 as of June 2026); some practitioners flag it as "an antidote to piecemeal vibe coding" but note the tasks-breakdown step is where most quality is won or lost — if tasks are too large, you're back to vibe coding with extra paperwork (unverified as of 2026-07 whether GitHub has published task-granularity benchmarks).

---

## 2. Test-first with AI: red → green → verify, not "write code then write tests"

### 2.1 Why order matters for LLMs specifically
"Test-Driven Development, through its disciplined test-first approach, counters the 'dumping' behavior of LLMs by forcing incremental design evolution" [vijayanant.com]. The mechanism: an LLM asked to "implement X and also write tests" will often write tests that match whatever it happened to implement — tests become confirmatory, not falsifying. Writing the failing test **first**, from the spec/task description (not from the implementation), keeps the test an independent oracle.

### 2.2 Concrete protocol
1. From the task in `TASKS.md`, write one focused test that currently fails (`RED`). Example instruction pattern validated by Anthropic: *"users report that login fails after session timeout. check the auth flow... write a failing test that reproduces the issue, then fix it"* [code.claude.com/docs/best-practices].
2. Run the test, capture the failure output verbatim — this is the falsifiable baseline.
3. Instruct the agent to write **the minimum production code to pass this one test** (`GREEN`) — do not let it "also handle" unrequested cases; that's how partially-implemented, over-scoped stub code enters the tree.
4. Refactor only with the test suite green throughout.
5. Repeat per task. Never let "implement the whole module" be a single step — Spec Kit's task decomposition and Anthropic's "small task" guidance are saying the same thing from two directions.

### 2.3 Eval-driven development for agent *behavior* itself
For agentic components inside the ERP (e.g., an AI-assisted approval-routing agent, a reconciliation assistant), Anthropic's engineering guidance is to **practice eval-driven development: build evals that define planned capabilities before the agent can fulfill them, then iterate until it passes** [anthropic.com/engineering/demystifying-evals-for-ai-agents]. Do not wait for hundreds of eval cases — "20-50 simple tasks drawn from real failures is a great start," and evals get *harder* to construct the later you leave them, because early on product requirements translate directly into test cases, whereas later you're reverse-engineering success criteria from a live system [anthropic.com/engineering/demystifying-evals-for-ai-agents].

### 2.4 "Exercise every API in a test" as an anti-hallucination control
Every external library call, every internal service method, and every generated ORM/model method that ships must appear in at least one executed test path. This is the practical enforcement of "don't trust the API surface the model assumed exists — prove it by running it." Pair with coverage gating (below) rather than manual review, since manual review of AI-authored code systematically under-detects plausible-but-wrong calls.

---

## 3. The plan → build → review → verify loop, with hard phase gates

### 3.1 The loop, concretely
Anthropic's recommended default loop is **Explore → Plan → Implement → Commit**, and Claude Code's plan mode exists specifically to separate "read files and answer questions without making changes" from execution [code.claude.com/docs/best-practices]. Layer a fifth step, **Verify**, done by a role that did not write the code (Section 5):

```
1. EXPLORE   — subagent reads relevant code/spec, reports back, no edits
2. PLAN      — plan mode; human edits the plan file directly (Ctrl+G in Claude Code)
3. BUILD     — implement one task; write failing test first; make it pass
4. REVIEW    — a fresh-context subagent (or second session) diffs against PLAN.md/TASKS.md
5. VERIFY    — deterministic gate: typecheck, test suite, lints, stub/dead-code scans, all must exit 0
6. COMMIT    — one git commit per verified task, with evidence in the message/log
```

### 3.2 Evidence over assertions — the single most load-bearing rule
> "Have Claude show evidence rather than asserting success: the test output, the command it ran and what it returned, or a screenshot of the result. Reviewing evidence is faster than re-running the verification yourself, and it works for sessions you weren't watching." [code.claude.com/docs/best-practices]

Operationally: never accept "I implemented X and it works" as a completion signal. Require the actual stdout of the test run, the actual exit code of the build, or a screenshot diffed against the target UI. This single rule is what prevents "trust-then-verify gap": *"Claude produces a plausible-looking implementation that doesn't handle edge cases... Fix: Always provide verification (tests, scripts, screenshots). If you can't verify it, don't ship it."* [code.claude.com/docs/best-practices]

### 3.3 Gating mechanisms, from soft to hard
Per Anthropic's own framing, there is a spectrum of enforcement [code.claude.com/docs/best-practices]:

| Mechanism | Strength | Use for |
|---|---|---|
| Ask in-prompt ("run tests and iterate") | Advisory | Interactive single-session work |
| `/goal` condition, re-checked every turn | Semi-enforced | Multi-turn tasks with a human present |
| **Stop hook** — script that blocks turn-end until check passes | Deterministic gate | Unattended/autonomous runs (Claude Code overrides after 8 consecutive blocks — cap runaway loops) |
| Verification subagent / second Claude session with fresh context | Independent review | Before anything is called "done" |

**ERP default:** every module task requires at minimum the Stop-hook-level gate (typecheck + tests + lints + stub-scan, all exit 0) plus one independent subagent review before merge to the integration branch.

### 3.4 Adversarial review as a required step, not optional
> "The longer Claude works unattended, the more an independent check matters before you count the work as done. A reviewer running in a fresh subagent context sees only the diff and the criteria you give it, not the reasoning that produced the change, so it evaluates the result on its own terms." [code.claude.com/docs/best-practices]

Prompt shape that works: *"Use a subagent to review the diff against PLAN.md. Check that every requirement is implemented, the listed edge cases have tests, and nothing outside the task's scope changed. Report gaps, not style preferences."* Anthropic also warns of the failure mode this invites: a reviewer *asked* to find gaps will usually report some even when the work is sound — instruct it to flag only findings that affect correctness or stated requirements, or you'll get over-engineering and speculative defensive code as "fixes" [code.claude.com/docs/best-practices].

---

## 4. Anti-hallucination techniques

### 4.1 Compiler/typechecker as ground truth, not the model's self-report
LLMs "are not compilers and are not type-checkers... making a statistical guess about what sequence of characters is most likely to follow your prompt" [me.micahrl.com; thomaslandgraf.substack.com]. The fix is mechanical: run `tsc --noEmit` (or the equivalent strict compiler/typechecker for your stack) after every edit and feed the **error output back to the agent verbatim** — file, line, symbol. "Errors reference the same types/symbols, which the LLM can chase and correct. This creates a feedback loop where the TypeScript compiler serves as objective validation" (community synthesis, not an Anthropic primary source; treat as practitioner consensus). For ERP builds specifically: enable the strictest compiler settings available (`strict: true`, `noUncheckedIndexedAccess`, `exactOptionalPropertyTypes` for TS; `mypy --strict` for Python) — every relaxed flag is a hole hallucinated code can hide in.

### 4.2 Verify library/API symbols against installed `.d.ts`/stubs before use
Do not let the agent call an API it "remembers" from training data. Before using any library method:
```bash
# TypeScript/Node — confirm the symbol actually exists in the installed version
grep -R "export.*functionName" node_modules/<package>/dist/*.d.ts
node -e "console.log(Object.keys(require('<package>')))"

# Python — introspect the installed version directly, don't trust memory
python -c "import pandas as pd; print([m for m in dir(pd) if 'read_' in m])"
```
This mirrors the mechanism validated in the arXiv 2026 paper on **Knowledge Conflicting Hallucinations (KCH)**: a deterministic post-processing framework that parses generated code into an AST, cross-references calls against a **dynamically-generated knowledge base built via live library introspection** (not training data), and achieves **100% detection precision, 87.6% recall, F1 0.934, with a 77.0% automatic-fix rate (124/161 cases)** across three KCH categories — missing imports (97.9% detect/correct), mis-typed API calls e.g. `pd.read_exel` (84.5% detect / 70.0% correct), and contextual mismatches like reading `.csv` with `pd.read_excel` (33.3% detect / 0% correct, the hardest class) [arxiv.org/html/2601.19106v1]. **Practical takeaway:** automate the AST+introspection check where you can (custom lint rule or CI script per language), but expect semantic/contextual mismatches to require human or test-based catching — they're the residual category no static tool fully closes.

### 4.3 Pin versions — hallucinated/"slopsquatted" packages are now an active attack vector
"LLMs consistently hallucinate a shorter version of package names... and attackers have registered these hallucinated names with malicious payloads" — termed **slopsquatting**. A documented case: `react-codeshift` (a hallucinated blend of `jscodeshift` and `react-codemod`) propagated to 237 repositories before a researcher defensively claimed the name [devaitoolkit.com; hivesecurity.gitlab.io]. Rules:
- **Never let an agent run `npm install <new-package>` without a human confirming the package is real** (check npm registry page, download counts, publish history) — this is the single highest-leverage guardrail against supply-chain injection via hallucination.
- Lockfiles are the enforcement mechanism: `package-lock.json`/`poetry.lock`/etc. store cryptographic hashes; **use `npm ci` (or equivalent), never `npm install`, in CI and agent runs** — `npm ci` refuses to proceed if the lockfile and package.json disagree, `npm install` silently rewrites it [systemshardening.com; xygeni.io].
- "Agents should never regenerate a lockfile unless explicitly asked — if a lockfile exists, install from it exactly; if adding new dependencies is required, produce the lockfile diff for human review rather than installing and continuing" [nesbitt.io, "Package Security Defenses for AI Agents," 2026-04-09].
```bash
# enforcement commands
npm ci                       # fails closed on lockfile drift — use this, not npm install
npm audit signatures         # verify package provenance where supported
pip install --require-hashes -r requirements.txt   # Python equivalent
```

### 4.4 Exercise every API in a test (restated as a gate, not a suggestion)
Combine 2.4 with a coverage-diff gate: CI fails if new/changed production code lines are not covered by a test that actually executes them (not just imports the module). This directly targets the "plausible call that was never run" class of hallucination that typechecking alone won't catch (typecheckers verify shape, not behavior).

---

## 5. Separation of builder vs. verifier roles

### 5.1 Why one agent can't safely grade its own homework
2026 industry framing: "the shift from rigid assembly lines to a fluid Planner and Builder loop, which spawns ephemeral Task Agents for sub-routines... this architectural separation helps avoid the bias problems that arise when a single agent generates and verifies its own code" [aiagentsdirectory.com; dev.to/eira-wexford]. **AgentCoder**, a published multi-agent code-generation framework, "systematically separates code authoring, test case design, and test execution into specialized agent roles, orchestrated within an iterative refinement loop" [emergentmind.com/topics/agentcoder]. Caveat: multi-agent refinement frameworks "may show unstable performance or reduced generalizability across foundation models differing in size, architecture, or instruction-following capability" [arxiv.org/pdf/2604.16321] — role separation is not a silver bullet, it's a bias-reduction technique that must still be paired with deterministic gates.

### 5.2 Concrete pattern (validated by Anthropic directly)
> Writer/Reviewer pattern using two Claude Code sessions:
> - Session A (Writer): *"Implement a rate limiter for our API endpoints"*
> - Session B (Reviewer), fresh context: *"Review the rate limiter implementation in @src/... Look for edge cases, race conditions, and consistency with existing middleware patterns."*
> - Feed B's findings back to A: *"Here's the review feedback: [...]. Address these issues."*
> "You can do something similar with tests: have one Claude write tests, then another write code to pass them." [code.claude.com/docs/best-practices]

**ERP default:** Builder and Verifier must run in **separate contexts** (separate subagent invocation or separate session), and Verifier receives *only* the diff + the spec/task + explicit review criteria — not the Builder's reasoning trace. This is the mechanism that prevents the Verifier from inheriting the Builder's confirmation bias.

### 5.3 Role definitions for the ERP build OS

| Role | Sees | Allowed to do | Not allowed to do |
|---|---|---|---|
| Builder | Task spec, existing code, its own scratch context | Write code, write tests, run local checks, propose commit | Mark its own task "done"; merge; approve its own PR |
| Verifier | Diff + spec/task + criteria only (fresh context) | Run gates, flag correctness/requirement gaps, block merge | Add features, refactor beyond scope, rubber-stamp |
| Human/lead | Everything, evidence log | Final merge approval on financially-sensitive modules | — |

---

## 6. Enforceable definition-of-done (DoD)

### 6.1 Principle
"Give it clear intent, tight boundaries, and a definition of done. Keep the definition short, current, and enforceable" [medium.com/@eamonn.faherty]. "The agent produces evidence — files changed, commands run, checks passed, risks noted — that a human can audit efficiently... Skills shift the review from 'did the agent write correct code' to 'did the agent follow the team's definition of done.'" [developersdigest.tech]

### 6.2 The ERP DoD checklist (encode as a Stop hook / CI job, not prose)
A task is **not done** until all of the following exit 0, in this order:

```bash
# 1. Compile/typecheck — ground truth for API/shape correctness
npm run typecheck   # or: tsc --noEmit / mypy --strict / go build ./...

# 2. Test suite — the specific new/changed test(s) plus full regression
npm test -- --coverage
# fail the build if lines touched in this diff aren't covered:
# (use a coverage-diff tool, e.g. `diff-cover`, `nyc --check-coverage`)

# 3. Lints and formatting
npm run lint && npm run format:check

# 4. Stub / placeholder scan (Section 7)
! grep -RInE "TODO|FIXME|HACK|XXX|PLACEHOLDER|not implemented|NotImplementedError|throw new Error\\(.?(unimplemented|todo)" \
    --include="*.ts" --include="*.tsx" --include="*.py" src/

# 5. Dead-code / orphan-file scan (Section 7)
npx knip --exit-code

# 6. Dependency integrity — no unpinned/unverified/hallucinated packages
npm ci   # fails on any lockfile drift

# 7. Evidence recorded — actual command output, not a summary, in the phase log
```
Only after all seven pass does the task move from `in_progress` to `done` in the state file (Section 8), and only then is it eligible for the Verifier subagent review and commit.

### 6.3 What "done" explicitly excludes
- A function that returns a hardcoded/mock value "to make the test pass" without the underlying logic (a classic LLM shortcut — the coverage-diff + Verifier review pair is what catches this, since coverage alone doesn't).
- A file created but never imported anywhere (Section 7).
- A passing test that never actually calls the production code path (assert on a mock instead of the real function) — Verifier's explicit brief must include "confirm tests exercise real code, not mocks-of-mocks."

---

## 7. Preventing empty/stub files and orphan code

### 7.1 Grep-based placeholder/stub scan (cheap, first line of defense)
```bash
# Fails CI if any of these markers exist in source (not in test fixtures/docs)
grep -RInE "TODO|FIXME|HACK|XXX|PLACEHOLDER|STUB|not implemented|NotImplementedError|pass #|throw new Error\\(.?unimplemented" \
  --include="*.ts" --include="*.tsx" --include="*.py" --include="*.go" \
  src/ | grep -v "__tests__\|__fixtures__"
```
A static analyser purpose-built for this — **todocheck** — "integrating [it] in your development workflow and CI pipeline... ensure[s] there will be no half-baked issues closed with pending TODOs in the codebase" [github.com/presmihaylov/todocheck]. For broader pattern-based detection (including AI-specific anti-patterns like mock-returning stubs), **Semgrep** runs "as a pre-commit check, and as part of CI/CD workflows... exits with code 1, causing the job to fail, which blocks pull/merge requests from merging" [semgrep.dev; oneuptime.com].

### 7.2 Tiny-file / suspiciously-small-file scan
Empty or near-empty files are a common signature of an agent that "created the file" as a planning step and never filled it in, or that scaffolded a module and forgot to return to it.
```bash
# Flag any tracked source file under N bytes/lines (tune per language; 3 lines often = stub)
find src -type f \( -name "*.ts" -o -name "*.py" \) -exec wc -l {} \; | awk '$1 < 5 {print}'
```
Treat any hit as a build-blocking finding requiring explicit human sign-off ("this file is intentionally minimal because X"), not silent pass.

### 7.3 Dead-code / orphan-file detection — "every file must be imported and executed"
**Knip** is the 2026-current recommended tool for JS/TS (successor to the now-maintenance-mode `ts-prune`): it "reports unused dependencies and devDependencies from package.json, files that are never imported by non-test code, and missing dependencies... reports duplicate exports and unused class members and enum members" using a mark-and-sweep algorithm from declared entry points [knip.dev; effectivetypescript.com]. "CI is the enforcement mechanism; the cleanup is a one-time effort, while the CI check keeps the codebase clean over time... Knip exits with a non-zero code when it finds issues, making it the single most effective way to prevent dead code accumulation" [recca0120.github.io].
```bash
npx knip --exit-code               # JS/TS: unused files, exports, deps — fails CI on any finding
python -m vulture src/             # Python equivalent: dead code detector
go vet ./... && staticcheck ./...  # Go: unused code + suspicious constructs
```
**ERP-specific rule beyond "unused":** every generated module (e.g., a new posting-rule handler, a new report definition) must be reachable from an entry point **and** exercised by at least one test that actually invokes it end-to-end — reachability alone (imported somewhere) is necessary but not sufficient; execution in a test is the stronger bar from Section 2.4/4.4.

---

## 8. Recording work for resumability: state file + append-only log + git commits per phase

### 8.1 Why this matters more for ERP than typical SaaS work
ERP builds run over weeks/months across many sessions and possibly many agents/contributors. Context resets (compaction, new sessions, handoffs between builder/verifier) are constant. The industry-converged pattern: **"treat the agent like a long-running server process: write intermediate state to disk, checkpoint every N units of work, recover from failures... If the agent checkpoints after every unit of work, the worst case is losing one unit."** [zylos.ai, "AI Agent Workflow Checkpointing and Resumability," 2026-03-04]. "The state lives in files, not memory, with the context window just processing the delta" [zylos.ai, 2026-03-31].

### 8.2 Concrete three-part recording scheme
```
/project-state/
  STATE.json          # single-source-of-truth: current phase, current task id,
                       # per-task status (pending/in_progress/verified/done),
                       # last-good commit sha, open findings
  LOG.ndjson           # append-only, one JSON object per event — never edited, never truncated
                       # {"ts":..., "phase":"build", "task":"T-042", "event":"test_run",
                       #  "cmd":"npm test", "exit_code":0, "evidence":"...output tail..."}
  PLAN.md / TASKS.md   # from Section 1 — the spec artifacts, checked into git
```
Rules:
- `STATE.json` is small and always overwritten in place — it's "where am I now."
- `LOG.ndjson` is append-only and never summarized/rewritten — it's the audit trail an auditor or new agent session can replay to reconstruct exactly what was tried, what passed, what failed, in order. This is the closest primary-source-validated analog to academic proposals like **Git Context Controller (GCC)**, which "organizes contextual information as a structured, version-controlled file system... enabling milestone-based checkpointing... through explicit operations — COMMIT, BRANCH, MERGE, CONTEXT" [arxiv.org/html/2508.00031v2], and **Lore**, which "encodes decision context into the permanent project history so future agents benefit from it" via enriched commit messages [arxiv.org/html/2603.15566v1] (both academic proposals; treat as emerging practice, not yet an industry standard — unverified as of 2026-07 whether either has broad production adoption).
- One git commit per **verified** task (post-gate, post-Verifier), never per raw edit. Commit message includes the task id, the gate results summary, and a co-author trailer: `Co-Authored-By: <agent-name>` — machine-parseable so `git log --grep="Co-Authored-By: Claude"` finds every agent-assisted commit [buildmvpfast.com, "Git Workflow for AI-Assisted Development 2026"].
- Claude Code's own session management supports this directly: `claude --continue` resumes the most recent session, `claude --resume` lists sessions to pick from, and `/rename` lets you name a session like a branch ("oauth-migration") so a specific workstream's context can be picked back up later [code.claude.com/docs/best-practices]. This is a session-level convenience; it does **not** replace the on-disk STATE.json/LOG.ndjson, which must survive even if the session/tool is switched entirely.

### 8.3 Commit template
```
[T-042] Add multi-currency rounding to AP invoice posting

Gates: typecheck ✓ tests ✓ (14 new, 212 total) lint ✓ stub-scan ✓ knip ✓ npm-ci ✓
Verifier: reviewed by fresh subagent, 0 blocking findings
Evidence: see LOG.ndjson events e-1042-01..e-1042-07

Co-Authored-By: Claude Sonnet 5 <noreply@anthropic.com>
```

---

## 9. Context hygiene: checkpoint and compact above ~75% window usage

### 9.1 Why it's non-negotiable
"Most best practices are based on one constraint: Claude's context window fills up fast, and performance degrades as it fills... When the context window is getting full, Claude may start 'forgetting' earlier instructions or making more mistakes. The context window is the most important resource to manage." [code.claude.com/docs/best-practices] For an ERP build — dense schemas, long specs, multi-file diffs — this threshold arrives faster than in typical app work.

### 9.2 Mechanisms, in order of preference
1. **`/clear` between unrelated tasks** — full reset. "A clean session with a better prompt almost always outperforms a long session with accumulated corrections." Rule of thumb from Anthropic: **after two failed corrections on the same issue, `/clear` and restart with a better prompt** rather than continuing to patch in a polluted context [code.claude.com/docs/best-practices].
2. **Subagent delegation for exploration** — "Subagents run in separate context windows and report back summaries," keeping the main conversation's context budget for implementation, not investigation [code.claude.com/docs/best-practices]. This is the single best lever for staying under the 75% threshold on large ERP codebases: never let the main session read the whole schema/module tree itself.
3. **Automatic compaction** at the limit — "Claude Code automatically compacts conversation history when you approach context limits... Claude summarizes what matters most, including code patterns, file states, and key decisions." Tune it: `/compact <instructions>` (e.g., `/compact Focus on the API changes`), and in CLAUDE.md pin what must survive compaction: *"When compacting, always preserve the full list of modified files and any test commands"* [code.claude.com/docs/best-practices].
4. **Selective checkpoint summarization** — `Esc+Esc` or `/rewind`, pick a checkpoint, choose "Summarize from here" (condense forward, keep earlier context intact) or "Summarize up to here" (condense earlier, keep recent messages in full) [code.claude.com/docs/best-practices].
5. **`/btw` for side questions** — answer appears in a dismissible overlay and never enters conversation history, avoiding unnecessary context growth for one-off lookups [code.claude.com/docs/best-practices].

### 9.3 Operational rule for the ERP build OS
Treat 75% context usage as a **hard checkpoint trigger**, not a soft warning:
- At 75%: write current STATE.json + append a checkpoint event to LOG.ndjson *before* compacting, so the on-disk record is authoritative even if the in-context summary loses fidelity.
- Compact with explicit preserved-context instructions (modified files, test commands, open findings) rather than relying on default summarization for anything safety-relevant (ledger logic, tax rules, access control).
- For genuinely long single-problem sessions, Anthropic's counter-guidance still applies: "sometimes you *should* let context accumulate because you're deep in one complex problem and the history is valuable" [code.claude.com/docs/best-practices] — the 75% trigger is a forcing function for *recording state externally*, not a mandate to always clear.

---

## 10. Empirical grounding: what actually happens in practice (2026)

Anthropic's analysis of **~400,000 Claude Code sessions (Oct 2025–Apr 2026, ~235,000 users)** found verified success rates of **33% for expert-rated sessions vs. 15% for novice-rated sessions**, and that "people make about 70% of the planning decisions... and only about 20% of the execution decisions" — i.e., the human's leverage is concentrated almost entirely in spec/plan quality, not in typing code [anthropic.com/research/claude-code-expertise]. This is direct empirical support for weighting the methodology toward Sections 1–2 (spec and test quality) over manual code review: the bottleneck is what you ask for, not how the agent executes.

---

## 11. Summary — the enforceable loop, one page

```
SPEC   → /speckit.specify or agent-interview → SPEC.md (human-gated)
PLAN   → /speckit.plan → PLAN.md (human-gated, edited directly)
TASKS  → /speckit.tasks → small, testable, independently reviewable units
BUILD  (per task):
  1. write failing test from task description (RED)
  2. minimum code to pass (GREEN)
  3. gates: typecheck && tests --coverage && lint && stub-scan && knip && npm-ci
  4. record evidence (verbatim command output) to LOG.ndjson; update STATE.json
VERIFY (separate context/session, diff + spec only):
  - requirements fully implemented? edge cases tested? scope creep? real-code-not-mock tests?
  - report gaps only if they affect correctness/requirements
COMMIT one task per commit, gate results + evidence pointer in message
CONTEXT: checkpoint state to disk at 75% window usage before compacting;
  /clear after 2 failed corrections; delegate exploration to subagents always
```

---

## Sources

- GitHub Blog — "Spec-driven development with AI: Get started with a new open source toolkit" — https://github.blog/ai-and-ml/generative-ai/spec-driven-development-with-ai-get-started-with-a-new-open-source-toolkit/
- GitHub Spec Kit documentation — https://github.github.com/spec-kit/
- GitHub — spec-kit repository, AGENTS.md — https://github.com/github/spec-kit
- Microsoft for Developers — "Diving Into Spec-Driven Development With GitHub Spec Kit" — https://developer.microsoft.com/blog/spec-driven-development-spec-kit
- Visual Studio Magazine — "GitHub Spec Kit Takes Off as Antidote to Piecemeal 'Vibe Coding'" (2026-05-12) — https://visualstudiomagazine.com/articles/2026/05/12/github-spec-kit-takes-off-as-antidote-to-piecemeal-vibe-coding.aspx
- Claude Code Docs — "Best practices for Claude Code" — https://code.claude.com/docs/en/best-practices
- Anthropic — "How Claude Code is used in practice" (400K session study) — https://www.anthropic.com/research/claude-code-expertise
- Anthropic Engineering — "Demystifying evals for AI agents" — https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents
- arXiv 2601.19106 — "Detecting and Correcting Hallucinations in LLM-Generated Code via Deterministic AST Analysis" — https://arxiv.org/html/2601.19106v1
- vijayanant.com — "TDD for LLMs: Using Test-Driven Development to Prevent AI Hallucinations" — https://vijayanant.com/posts/driving-ai-code-why-test-driven-development-is-essential-in-the-llm-era/
- Zylos Research — "AI Agent Workflow Checkpointing and Resumability" (2026-03-04) — https://zylos.ai/research/2026-03-04-ai-agent-workflow-checkpointing-resumability/
- Zylos Research — "Context Window Management and Session Lifecycle for Long-Running AI Agents" (2026-03-31) — https://zylos.ai/research/2026-03-31-context-window-management-session-lifecycle-long-running-agents/
- arXiv 2508.00031 — "Git Context Controller: Manage the Context of Agents by Agentic Git" — https://arxiv.org/html/2508.00031v2
- arXiv 2603.15566 — "Lore: Repurposing Git Commit Messages as a Structured Knowledge Protocol for AI Coding Agents" — https://arxiv.org/html/2603.15566v1
- buildmvpfast.com — "Git Workflow for AI-Assisted Development 2026" — https://www.buildmvpfast.com/blog/git-workflow-ai-assisted-development-agent-commits-2026
- Knip documentation — https://knip.dev/
- effectivetypescript.com — "Recommendation Update: Use knip to detect dead code and types" — https://effectivetypescript.com/2023/07/29/knip/
- recca0120.github.io — "Find Dead Code with Knip: The Blind Spots ESLint and depcheck Miss" — https://recca0120.github.io/en/2026/05/02/knip-dead-code-detector/
- github.com/presmihaylov/todocheck — https://github.com/presmihaylov/todocheck
- Semgrep documentation/CI — https://semgrep.dev/docs/semgrep-ci/overview/
- Andrew Nesbitt — "Package Security Defenses for AI Agents" (2026-04-09) — https://nesbitt.io/2026/04/09/package-security-defenses-for-ai-agents.html
- systemshardening.com — "Dependency Confusion Attacks: How Private Package Shadowing Works and How to Stop It" — https://www.systemshardening.com/articles/cross-cutting/dependency-confusion-defence/
- Xygeni — "Lack of Version Pinning and Dependency Confusion" — https://xygeni.io/blog/lack-of-version-pinning-and-dependency-confusion/
- devaitoolkit.com — "Is Your npm Package Already Poisoned?" — https://devaitoolkit.com/blog/is-your-npm-package-already-poisoned/
- hivesecurity.gitlab.io — slopsquatting / AI-hallucination package supply-chain attack — https://hivesecurity.gitlab.io/blog/slopsquatting-ai-hallucination-package-supply-chain-attack/
- aiagentsdirectory.com — "2026 will be the Year of Multi-agent Systems" — https://aiagentsdirectory.com/blog/2026-will-be-the-year-of-multi-agent-systems
- dev.to/eira-wexford — "How to Build Multi-Agent Systems: Complete 2026 Guide" — https://dev.to/eira-wexford/how-to-build-multi-agent-systems-complete-2026-guide-1io6
- emergentmind.com — "AgentCoder: Multi-Agent Code Framework" — https://www.emergentmind.com/topics/agentcoder
- arXiv 2604.16321 — "LLM-Based Multi-Agent Systems for Code Generation: A Multi-Vocal Literature Review" — https://arxiv.org/pdf/2604.16321
- medium.com/@eamonn.faherty — "Bringing DoR and DoD to AI Coding Agents" — https://medium.com/@eamonn.faherty_58176/bringing-dor-and-dod-to-ai-coding-agents-why-your-ai-needs-clear-definitions-too-ba7a72d774d8
- developersdigest.tech — "Agent Skills Need Exit Criteria, Not More Prompt Lore" — https://www.developersdigest.tech/blog/agent-skills-production-checklist
- me.micahrl.com — "(Type) Checking the LLM" — https://me.micahrl.com/blog/type-checking-the-llm/
- thomaslandgraf.substack.com — "Why I Choose TypeScript for LLM-Based Coding" — https://thomaslandgraf.substack.com/p/why-i-choose-typescript-for-llmbased
