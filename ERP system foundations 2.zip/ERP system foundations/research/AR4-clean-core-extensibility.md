# AR4 — The Clean-Core Extension Boundary: Preventing Customization From Killing Upgradability

*Research brief for the ERP Build OS playbook. Grounded in SAP, Salesforce, ServiceNow, Odoo, and Shopify primary sources, 2025–2026.*

## 1. The core failure mode this boundary exists to prevent

Every legacy-ERP horror story reduces to the same mechanism: a business need arrives, no sanctioned extension point exists for it, so someone modifies the core (forks a table, patches core code, writes a trigger straight into a core object). The modification works today and becomes silently load-bearing. The next upgrade either (a) breaks it, or (b) is deferred indefinitely because breaking it is unacceptable — which is how ERPs end up frozen on a decade-old release. SAP's own language for this is blunt: extensions that touch unreleased, internal objects "will create serious upgrade and supportability risks" (SAP Clean Core A–D model, community.sap.com, Aug 2025). The fix is not "customize less" as a moral exhortation — it is an **architectural boundary with teeth**: a small, stable core; a finite, versioned, sanctioned surface for everything else; and a build-system gate that makes the unsanctioned path *harder to ship* than the sanctioned one.

This report catalogs what the incumbents actually built to enforce that boundary, what fails in practice, and proposes a default extension architecture for a new ERP build OS.

## 2. What the incumbents did — comparative table

| Platform | Core boundary mechanism | Sanctioned extension surface | Versioning/compat policy | Known failure mode |
|---|---|---|---|---|
| **SAP S/4HANA Cloud (Clean Core)** | ABAP Cloud restricted API surface; "released objects" only in core namespace | Key-user extensibility (custom fields/logic/UI via Fiori), developer extensions (on-stack ABAP Cloud), side-by-side on BTP | Formal **A–D extensibility levels** (Aug 2025): A = BTP/ABAP-Cloud on released APIs only (upgrade-safe); B = classic BAPI/IDoc/RFC (mostly stable); C = internal/unreleased objects (grey zone, needs SDB monitoring); D = direct core modification/implicit enhancement (non-compliant, SAP may refuse support) | Even with the model, "grey zone" C-level extensions accumulate because teams route around released-API gaps under deadline pressure |
| **Salesforce** | Multitenant single-codebase core; all customization lives in metadata + Apex in an org's namespace, never core code | Custom objects/fields, Apex triggers/classes, **Platform Events** (custom, developer-defined event schema) and **Change Data Capture** (auto-generated data-change events) on a unified Event Bus, managed packages for ISV distribution | Every API surface (REST, SOAP, Bulk, Metadata, Apex-in-packages) shares one **version number per release** (3 major releases/yr); deprecated versions get a published EOL policy — v21–v30 retired Summer '25 after ~10+ years of support; **3-year minimum support is a floor**, not a ceiling (v31, from 2014, still supported in 2026) | Managed packages pin their own API version — an org can be current while an *installed package* is stale and silently breaks on external calls |
| **ServiceNow** | Platform core (Glide) never touched directly; all customization lives in **scoped applications** (namespaced, sandboxed) or update sets | Scoped apps with declared ACLs, business rules, script includes, UI actions, REST/Scripted REST, Flow Designer, Store apps | Family release upgrades (e.g., Zurich, 2025) auto-carry scoped-app code forward but explicitly **do not auto-update Store-installed apps** — those need independent version validation | Global-scope customization (legacy, still permitted) and unscoped update sets remain the #1 cause of failed/blocked family upgrades; teams that never migrated to scoped apps inherit full core-coupling risk |
| **Odoo** | Python/XML core modules; DB schema owned by core | **Module inheritance**: `_inherit` (extension — add fields/methods, must call `super()`) vs `_inherits` (delegation/composition); Odoo Studio for no-code field/view/automation on top | No formal SemVer contract; upgrade is a paid **migration service** that replays Studio customizations against the new core schema; computed fields and inherited-view overrides are explicitly flagged "high risk" | Studio customizations are DB *records*, not code — much harder to diff/analyze than a git-tracked module, so upgrade regression surface is opaque even when "customization" was done the sanctioned way |
| **Shopify** | Platform core (checkout, storefront, admin) never customizable directly for public apps | **Admin GraphQL API**, webhooks, **Shopify Functions** (sandboxed Wasm business-logic injection, replacing "Scripts"), app extensions (UI extensions, checkout extensions) | **Calendar-versioned API** (`2026-04` etc.), released quarterly; every stable version supported **≥12 months**, with **≥9 months overlap** between consecutive versions; deprecations announced in a public changelog with a migration guide before removal; apps that keep calling removed endpoints face **App Store delisting ≥7 days** | REST Admin API declared legacy Oct 2024, GraphQL-only mandate for new public apps from Apr 2025, and **Shopify Scripts fully sunset June 30, 2026** — proof that even a well-run calendar-versioned system periodically forces a hard migration wave when an extension mechanism itself is deprecated |

**Cross-cutting lesson:** every mature platform converged on the same three-part shape — (1) a **narrow, explicitly released API/object surface** as the only thing extensions may touch, (2) an **out-of-process or sandboxed execution model** for anything beyond configuration (BTP, platform events, scoped apps, Wasm functions), and (3) a **published, dated compatibility/deprecation policy independent of the core's own release cadence**. None of them rely on developer discipline alone — Salesforce and Shopify enforce via API version pinning and store delisting; SAP enforces via ATC (ABAP Test Cockpit) static-analysis gates; ServiceNow enforces via scope sandboxing at runtime.

## 3. Anatomy of the sanctioned extension surface

A build OS should offer exactly four extension mechanisms, each with a distinct trust/latency/blast-radius profile. Anything a builder wants to do that doesn't fit one of these four is a signal to extend the *menu*, not to bypass it.

### 3.1 Typed user-defined fields (UDFs) and metadata-driven config

The most common request ("we need one more field") should never touch core DDL. The default pattern, validated across SaaS ERPs in 2025 (see multi-tenant schema literature): a **companion table keyed by entity + tenant**, storing typed values, with the core table untouched.

```sql
-- core table: NEVER altered per-tenant
CREATE TABLE core.purchase_order (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  vendor_id UUID NOT NULL,
  total_amount NUMERIC(18,2) NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- sanctioned extension surface: typed, validated, per-tenant
CREATE TABLE ext.field_definition (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  entity TYPE_NAME NOT NULL,          -- 'purchase_order'
  field_key TEXT NOT NULL,             -- 'customs_broker_ref'
  data_type TEXT NOT NULL CHECK (data_type IN ('string','number','bool','date','enum','ref')),
  is_required BOOLEAN DEFAULT false,
  validation JSONB,                    -- {"maxLength":40,"pattern":"^[A-Z]{2}\\d+$"}
  UNIQUE (tenant_id, entity, field_key)
);

CREATE TABLE ext.field_value (
  entity_id UUID NOT NULL,             -- FK to core.purchase_order.id (no FK constraint across schemas)
  field_def_id UUID NOT NULL REFERENCES ext.field_definition(id),
  value_string TEXT, value_number NUMERIC, value_bool BOOLEAN,
  value_date DATE, value_ref UUID,
  PRIMARY KEY (entity_id, field_def_id)
);
```

Why typed columns instead of a single JSONB blob: JSONB is the right call for *unstructured settings*, but for UDFs you want the platform to (a) validate types at write time, (b) index/filter efficiently, (c) expose them uniformly to search/reporting/UI-generation. A hybrid is the pragmatic default: **JSONB for tenant-level config and feature flags; a typed EAV-ish sidecar for UDFs that need query and validation** — this is exactly the split the 2025 multi-tenant SaaS literature converges on. Odoo's Studio custom fields and Salesforce custom fields both materialize as real typed columns under the hood (Salesforce) or ORM-declared fields (Odoo) for this reason — the "cost" of proper typing is paid once at the platform layer, not per tenant.

Metadata-driven config extends this to workflow: business rules, approval matrices, and validation logic should be **data the engine interprets**, not code the core ships. A rule engine (e.g., "if PO total > threshold(field) then require approval from role(field)") stored as rows, not `if` statements in core code, is what lets 80% of "customization requests" never become code changes at all.

### 3.2 Side-by-side extensions (out-of-core services reacting to events)

For logic that's genuinely bespoke — a custom pricing algorithm, a regulatory calculation, a bespoke integration — the answer is a **separate deployable**, not an in-process hook, reacting to domain events over a bus. This is SAP's "Level A side-by-side on BTP" and Salesforce's Platform-Events pattern generalized as a default:

```yaml
# event contract published by core — CloudEvents 1.0.2 envelope (cloudevents.io)
specversion: "1.0"
type: "com.erp.purchasing.po.approved.v1"
source: "/tenants/{tenant_id}/purchasing"
id: "3f2a9e2e-..."
time: "2026-07-07T10:15:00Z"
datacontenttype: "application/json"
data:
  po_id: "PO-00219"
  tenant_id: "..."
  total_amount: 48200.00
  approved_by: "user:2211"
```

The side-by-side service subscribes, does its bespoke thing (call a customs API, run a proprietary discount model), and — if it needs to affect the core record — writes back **only through the same public API the core exposes to everyone else**, never direct DB access. This is precisely the boundary SAP enforces structurally (BTP apps cannot reach S/4HANA's DB) and what makes it "Level A": the core cannot be broken by the extension because the extension has no privileged access path.

Design rule for the build OS: **event schemas are versioned artifacts** (`po.approved.v1`, `po.approved.v2`), additive changes ship as new fields on the same version, breaking changes require a new version published side-by-side with the old for a minimum deprecation window (see §4), exactly mirroring Shopify's ≥9-month overlap policy and Salesforce's decade-plus API version tail.

### 3.3 Hooks / webhooks

Webhooks are the lightweight, synchronous-adjacent cousin of side-by-side events — used for near-real-time notification to external systems rather than internal bespoke logic. Adopt **Standard Webhooks** (github.com/standard-webhooks, adopted by Anthropic, OpenAI, Stripe-adjacent ecosystem, Supabase, Twilio et al. per 2025 adoption list) rather than inventing a bespoke signing scheme:

```
POST /tenant-configured-endpoint
webhook-id: msg_2f8x...
webhook-timestamp: 1751877300
webhook-signature: v1,K5oZ...   # HMAC-SHA256(secret, id.timestamp.body)
content-type: application/json

{ "type": "po.approved.v1", "data": { ... } }
```

Rules the build OS should hard-code: signed with a per-tenant rotatable secret, timestamp tolerance to defeat replay, at-least-once delivery with idempotency key = event id, and dead-letter queue visible to the tenant. In-process "hooks" (synchronous callbacks executed inline in a core transaction) should be **disallowed by default** — this is the exact mechanism ("implicit enhancement") SAP classifies as Level D/non-compliant, because a slow or failing hook now blocks or corrupts a core transaction. If synchronous pre/post validation is genuinely required (e.g., "reject this order if external credit check fails"), it must go through a **declared synchronous extension point** with a timeout and a fail-open/fail-closed policy chosen explicitly per hook — not an ad hoc trigger.

### 3.4 Plugin API — its own versioning and deprecation policy

The plugin/extension API is a product in its own right and needs a lifecycle independent of the core's release train — this is the single most consistently-missed piece in home-grown ERPs. Concretely:

```json
// plugin manifest — declares compatibility, not just capability
{
  "plugin_id": "customs-broker-integration",
  "plugin_version": "2.3.0",
  "requires_platform_api": ">=2026-01 <2027-01",
  "extension_points": ["po.approved.v1", "po.line_item.ui_slot"],
  "permissions": ["read:purchase_order", "write:po.custom_field"],
  "webhook_endpoints": ["https://broker.example.com/hooks/po"]
}
```

Default policy to adopt (synthesized from Shopify's calendar-versioning + Salesforce's version-per-release model):

- **Calendar-quarter API versions** (`2026-Q3` style), not core software versions — decouples "the core shipped a release" from "the extension surface changed."
- **Minimum 12-month support per API version, ≥9-month overlap** before removal (Shopify's exact numbers — a defensible, externally-validated default).
- **Deprecate via additive-first**: new field/event version ships alongside old; old is marked deprecated with a `Sunset` HTTP header (RFC 8594) and `Deprecation` header (RFC 9745) or manifest-level flag; removal only after the overlap window.
- **A compatibility gate at plugin install/upgrade time**: the manifest's `requires_platform_api` range is checked against the tenant's current platform version before activation — refuse install rather than fail at runtime (this is what SemVer 2.0.0 caret/range semantics are for, and what Salesforce's managed-package version pinning gets *wrong* by making it easy for a stale package to silently break).
- **A public, dated changelog** for the plugin API surface, separate from the core changelog — Shopify's `shopify.dev/changelog` is the reference example: every deprecation gets an announcement, a migration guide, and a removal date before it happens.

## 4. The "no customization in core" gate — how the build OS enforces it, not just documents it

Policy without enforcement decays; every incumbent that succeeded backed the policy with automated gates:

| Enforcement layer | Mechanism | Reference |
|---|---|---|
| Static analysis at commit/CI time | Reject any diff that modifies a file/object under `core/**` from a non-core-team PR; run an ATC-style linter that flags direct writes to core tables, use of unreleased/internal APIs, or synchronous in-process hooks | SAP's ATC checks natively in S/4HANA 2025, retrofit via SAP Note 3565942 for 2023 systems |
| Schema boundary | Core migrations own `core.*` schema exclusively; extension schema (`ext.*`) is the only one plugin/tenant code can migrate; a migration linter blocks any DDL outside the tenant's owned schema | Pattern generalized from Salesforce (managed-package namespacing) and multi-tenant JSONB/EAV literature |
| Runtime boundary | Side-by-side/plugin code runs in a separate process/container with only the public API + event bus reachable — no DB credentials, no core code import | SAP BTP; Salesforce Apex-in-package sandboxing; Shopify Functions (Wasm sandbox) |
| Classification/reporting | Every extension is tagged A/B/C/D-equivalent (sanctioned-typed-field / sanctioned-side-by-side / grey-zone-internal-API / core-fork) at build time; a dashboard tracks the **% of extensions at each level**, with D=0 as a release-blocking invariant and C trending toward zero as a quarterly KPI | SAP Clean Core Level Concept + RISE Methodology Dashboard, formalized Aug 2025; "Clean Core Share" KPI |
| Version compatibility gate | Plugin manifest `requires_platform_api` range checked before activation/upgrade; incompatible plugins block the *plugin* update, never block the *core* upgrade | Shopify versioning model; SemVer 2.0.0 range semantics |
| Deprecation gate | Core cannot remove a released API/event version until its published sunset date has passed AND telemetry shows zero tenants still calling it (or all have been given the ≥9-month overlap) | Shopify overlap policy; Salesforce EOL practice (v21-30 retired only after ~10yr) |

The single highest-leverage rule for a build OS to hard-code: **a PR that touches anything under the core domain path and originates from an extension/tenant context fails CI automatically, with no override short of a core-team-only merge.** This single gate, mechanically enforced, is what "clean core" actually *is* — everything else (A–D taxonomy, KPI dashboards) is instrumentation to make that gate's cost visible before it's paid at upgrade time.

## 5. What fails even when the sanctioned surface exists

- **Grey-zone drift (SAP Level C):** deadline pressure pushes teams to internal/unreleased APIs when the released surface has a gap. Mitigation: treat every Level-C usage as a logged, budgeted "extensibility debt" ticket with an owner and a target release to close the gap in the released API, not just a linter warning.
- **Stale extension pinning (Salesforce managed packages):** an org can be current while an installed package's *own* API version is years stale, and it breaks silently on the next retirement wave. Mitigation: the build OS should surface a per-plugin "effective API version" and warn proactively, not only at breakage time.
- **Un-diffable customization (Odoo Studio):** config stored as DB records rather than version-controlled artifacts is a black box at upgrade time. Mitigation: every UDF/config/rule created through the sanctioned surface must be **exportable to a declarative file (YAML/JSON) that lives in the tenant's git-tracked config repo**, so "customization" is always diffable and reviewable like code, never only a database row.
- **Extension-mechanism obsolescence (Shopify Scripts → Functions):** even a good sandboxed mechanism gets deprecated wholesale when it can't be secured/scaled (Scripts, Ruby-in-checkout, sunset June 30 2026 in favor of Wasm Functions). Mitigation: the build OS's plugin API versioning policy (§3.4) must apply to the *extension mechanism itself*, not just individual endpoints — assume any given mechanism has a multi-year but finite lifespan and design the deprecation/migration story for it up front.
- **Synchronous hooks blocking the core transaction:** the most common real-world constraint violation is a "just call this webhook synchronously before commit" request. Default to async event + compensating action; require an explicit, reviewed exception (with timeout + fail policy) for true synchronous needs.

## 6. Proposed default extension architecture (summary spec for the build OS)

1. **Core** = narrow domain services behind a versioned public API (REST/GraphQL + event bus). No tenant/plugin code runs in-process with core. No direct DB access from outside `core.*` schema.
2. **Typed UDFs + metadata config** = sidecar schema (`ext.*`), typed and validated, exportable to declarative config files, tenant-scoped, engine-interpreted (rules-as-data) rather than compiled per tenant.
3. **Side-by-side services** = separately deployed, subscribe to versioned domain events (CloudEvents envelope), write back only via public API. This is the default location for anything with real bespoke logic.
4. **Webhooks** = Standard-Webhooks-signed, async, idempotent, at-least-once, dead-lettered; synchronous in-process hooks disallowed by default, allowed only via a declared, timeout-bounded, explicitly-reviewed extension point.
5. **Plugin API** = its own calendar-versioned surface, manifest-declared compatibility range, ≥12-month support / ≥9-month overlap deprecation policy, public changelog, install-time compatibility gate.
6. **Enforcement** = CI-blocking static gate on core-path diffs from non-core PRs; A/B/C/D-style extension classification with D=0 as release-blocking and C tracked to zero as a KPI; runtime sandboxing for anything beyond config.

This is deliberately closer to SAP's 2025 formalization and Shopify's calendar-versioned app model than to Odoo's inheritance-plus-paid-migration approach: the former two treat the extension boundary as a *governed product surface with its own lifecycle*, which is the property a build OS needs to make "customize without forking" a durable guarantee rather than a best-effort convention.

## Sources

- [Clean Core Extensibility: Balancing Standardization and Differentiation](https://community.sap.com/t5/enterprise-resource-planning-blog-posts-by-sap/clean-core-extensibility-balancing-standardization-and-differentiation/ba-p/14260149) — SAP Community
- [ABAP Extensibility Guide – Clean Core for SAP S/4HANA Cloud, August 2025 Update](https://community.sap.com/t5/technology-blog-posts-by-sap/abap-extensibility-guide-clean-core-for-sap-s-4hana-cloud-august-2025/ba-p/14175399)
- [SAP Clean Core 2026: BTP Extensions, Levels A–D and S/4HANA Migration Guide](https://www.erpimplementation.eu/en/sap-clean-core-strategy-btp-extensions-s4hana-2026/)
- [How to Extend SAP S/4HANA Cloud the Right Way — SAP News Center, Aug 2025](https://news.sap.com/2025/08/extend-sap-s4hana-cloud-right-way-clean-clear/)
- [S/4HANA Clean Core Update 2025: the A–D Extensibility Model Explained](https://avotechs.com/blog/what-is-clean-core-a-d-extensibility-model/)
- [New Clean Core Extensibility KPIs arrive on the RISE with SAP Dashboard](https://community.sap.com/t5/enterprise-resource-planning-blog-posts-by-sap/new-clean-core-extensibility-kpis-arrive-on-the-rise-with-sap-dashboard/ba-p/14257352)
- [Salesforce API Versions 21.0 through 30.0 Retirement — Salesforce Help](https://help.salesforce.com/s/articleView?id=000389618&language=en_US&type=1)
- [API End-of-Life Policy | REST API Developer Guide — Salesforce Developers](https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/api_rest_eol.htm)
- [Integration Using Change Data Capture and Platform Events — Salesforce Ben](https://www.salesforceben.com/integration-using-change-data-capture-and-platform-events/)
- [Change Data Capture Events — Platform Events Developer Guide, Salesforce Developers](https://developer.salesforce.com/docs/atlas.en-us.platform_events.meta/platform_events/platform_events_objects_change_data_capture.htm)
- [Integrate Agents with Platform Events — Salesforce Developers Blog, July 2025](https://developer.salesforce.com/blogs/2025/07/integrate-agents-with-platform-events)
- [ServiceNow Platform Upgrades — A Complete Guide (Zurich Q3 2025 release)](https://flyform.com/insights/articles/servicenow-platform-upgrades-a-complete-guide)
- [Clarification on Plugin upgrade versions and compatibility — ServiceNow Community](https://www.servicenow.com/community/now-assist-forum/clarification-on-plugin-upgrade-versions-and-compatibility/m-p/3542887)
- [About Shopify API versioning](https://shopify.dev/docs/api/usage/versioning)
- [Shopify Developer Changelog: Most Important API Changes in 2026](https://tenten.co/shopify/shopify-developer-changelog-api-changes-2026/)
- [Shopify Custom App Deprecation 2026 & Dev Dashboard Guide](https://datronixtech.com/shopify-custom-app-deprecation/)
- [Shopify Breaking Changes 2026: Scripts Deadline + Inventory API Migration Guide](https://weaverse.io/blogs/shopify-developer-breaking-changes-april-2026)
- [Upgrade a customized database — Odoo 19.0 documentation](https://www.odoo.com/documentation/19.0/developer/howtos/upgrade_custom_db.html)
- [Chapter 12: Inheritance — Odoo 19.0 documentation](https://www.odoo.com/documentation/19.0/developer/tutorials/server_framework_101/12_inheritance.html)
- [Extending Odoo Models Safely: Maintaining Compatibility During Upgrades](https://www.braincuber.com/tutorial/extending-odoo-models-safely-maintaining-compatibility-during-upgrades)
- [CloudEvents Specification, v1.0.2](https://github.com/cloudevents/spec/blob/v1.0.2/cloudevents/spec.md)
- [CloudEvents HTTP Webhook, v1.0.2](https://github.com/cloudevents/spec/blob/v1.0.2/cloudevents/http-webhook.md)
- [Standard Webhooks specification](https://github.com/standard-webhooks/standard-webhooks)
- [Semantic Versioning 2.0.0](https://semver.org/)
- [Beyond Configurability: Architecting Multi-Tenant SaaS for Enterprise-Grade Customization](https://medium.com/@TheArtificialDev/beyond-configurability-architecting-multi-tenant-saas-for-enterprise-grade-customization-58c30d265952)
- [People's experiences with approaches to multitenancy — Arkency Blog](https://blog.arkency.com/peoples-experiences-with-approaches-to-multitenancy/)
