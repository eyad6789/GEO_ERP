# AR2 — Provable Correctness for the Money Core

*Engineering-grade defaults for an ERP build operating system. Written 2026-07-07.*

The money core (ledger posting, tax, pricing, allocation, period close) is the one subsystem where "looks right in the demo" is not an acceptable bar. It needs (1) a numeric representation that cannot silently lose value, (2) decision logic that is checked for gaps/overlaps instead of buried in `if` chains, (3) state machines whose safety properties are checked exhaustively, not just tested, and (4) a fixed oracle of expected outputs that every future change must reproduce bit-for-bit. Below is the concrete, opinionated default stack.

---

## 1. Decimal/Money Discipline

### 1.1 The non-negotiable rule
**Never represent money as `float`/`double` anywhere it is stored, transmitted, summed, or compared for equality.** IEEE-754 binary floating point cannot represent 0.10 exactly, and repeated addition/subtraction accumulates drift that shows up as off-by-a-cent trial balances. This is standard, uncontested engineering guidance across every decimal library surveyed below (decimal.js docs explicitly warn against constructing a `Decimal` from an already-lossy float) (unverified precise wording, but the pattern is consistent across MikeMcl/decimal.js, rust_decimal, and Java BigDecimal documentation as of 2025-2026).

**Default representation: integer minor units (cents) as the wire/storage format, backed by an arbitrary-precision decimal type for intermediate math.**

| Layer | Representation | Tooling |
|---|---|---|
| DB column | `NUMERIC(19,4)` (or bigint minor-units, see below) — never `FLOAT`/`REAL`/`DOUBLE PRECISION` | Postgres `numeric`, SQL Server `decimal` |
| App language — Java/Kotlin | `java.math.BigDecimal`, `MathContext` + explicit `RoundingMode` | JDK stdlib |
| App language — JS/TS | `decimal.js` (arbitrary-precision, string-safe construction) | github.com/MikeMcl/decimal.js |
| App language — Python | `decimal.Decimal` with a module-level `getcontext().prec` and explicit `ROUND_*` | stdlib `decimal` |
| App language — Rust | `rust_decimal` (128-bit fixed-point, ~28-29 significant digits) or `bigdecimal` crate for arbitrary precision | docs.rs/rust_decimal |
| Wire format (JSON/API) | Money as `{ "amountMinorUnits": 123450, "currency": "USD", "exponent": 2 }` — **never** a bare JSON number for currency amounts | Custom `Money` value type |

Key implementation rule: internal ledger storage should carry **one more digit of precision than the display/settlement currency** (e.g., store USD to 4 decimal places even though it settles at 2) so that unit-price × quantity × tax-rate chains don't force premature rounding; round only at the posting/settlement boundary, with the rounding difference explicitly booked to a rounding-gain/loss account, never silently dropped.

### 1.2 Rounding modes are a jurisdiction/domain decision, not a coder's default
Do not let the language's default rounding mode leak into financial code. Three different, legitimate rounding regimes coexist in one ERP:

- **Round-half-up (arithmetic rounding)** — the mode the US IRS instructs taxpayers to use on tax forms: drop amounts under 50 cents, round 50–99 cents up (Claimyr/IRS rounding guidance, 2025). Use this for statutory tax computations in US filings.
- **Round-half-even ("banker's rounding")** — minimizes systematic bias when *summing many rounded values*, which is why it is the recommended default for accounting/statistical aggregation contexts (LegalClarity, "Rounding in Accounting," 2025) and is also IEEE-754's default rounding rule. Use as the **general ledger default** for line-level extension and allocation math.
- **Round-down / truncation** — required in specific statutory contexts (e.g., some VAT regimes truncate rather than round).

**Proposed default:** implement rounding as a pluggable strategy resolved by `(jurisdiction, transaction_type)`, not a global constant:

```python
from decimal import Decimal, ROUND_HALF_EVEN, ROUND_HALF_UP, ROUND_DOWN

ROUNDING_POLICY = {
    ("US", "SALES_TAX"): ROUND_HALF_UP,      # matches IRS convention
    ("US", "GL_POSTING"): ROUND_HALF_EVEN,   # unbiased aggregation
    ("EU", "VAT"): ROUND_HALF_UP,
    ("*",  "GL_POSTING"): ROUND_HALF_EVEN,   # safe fallback
}

def round_money(amount: Decimal, jurisdiction: str, txn_type: str, exponent: int) -> Decimal:
    mode = ROUNDING_POLICY.get((jurisdiction, txn_type), ROUNDING_POLICY[("*", "GL_POSTING")])
    quantum = Decimal(1).scaleb(-exponent)
    return amount.quantize(quantum, rounding=mode)
```

Every rounding call site must be traceable to an explicit `(jurisdiction, txn_type)` pair recorded in a decision table (Section 2), not hard-coded — tax auditors will ask "why did you round this way," and "it's what the language defaulted to" is not an answer that survives an audit.

### 1.3 Allocation / proration without losing cents — Largest Remainder Method
The classic bug: split $100.00 three ways → $33.33 × 3 = $99.99, one cent vanishes. This is provably solved by the **Largest Remainder Method** (a.k.a. Hamilton/Hare-Niemeyer method, used since 1792 for apportionment; the same algorithm is the standard fix for rounding-preserving proportional allocation — GitHub `kschu91/largest-remainder-method`, `Normally/largest-remainder`, 2025 implementations reviewed):

1. Compute each share's exact (unrounded) amount.
2. Floor every share to the target minor-unit precision.
3. Compute `total_remainder = total_amount − sum(floored_shares)` in minor units (an integer count of "leftover cents").
4. Sort shares by the size of their fractional remainder, descending.
5. Distribute one minor unit each to the top `total_remainder` shares (ties broken deterministically — e.g., by a stable secondary key such as line-item ID — never by insertion order alone, or replay across environments will disagree).

```python
def allocate_largest_remainder(total_minor_units: int, weights: list[Decimal]) -> list[int]:
    total_weight = sum(weights)
    exact = [total_minor_units * w / total_weight for w in weights]
    floors = [int(e) for e in exact]  # truncate toward zero
    remainder = total_minor_units - sum(floors)
    # distribute `remainder` extra minor units to largest fractional remainders
    fracs = sorted(range(len(weights)), key=lambda i: (exact[i] - floors[i], -i), reverse=True)
    result = floors[:]
    for i in fracs[:remainder]:
        result[i] += 1
    assert sum(result) == total_minor_units   # invariant: no cent created or destroyed
    return result
```

**Invariant to test (property-based, Section 3): `sum(allocate(total, weights)) == total` for all valid inputs, always** — this is a two-line fast-check/Hypothesis property and should be a permanent CI gate on every allocation function (invoice line splitting, tax apportionment across jurisdictions, revenue recognition schedules, multi-currency settlement).

### 1.4 Currency and minor-unit handling
- Use **ISO 4217** as the source of truth for minor-unit exponent per currency: exponent 2 is the majority case (USD, EUR, GBP), exponent 0 for JPY/KRW/VND (no subunit), exponent 3 for KWD/BHD/OMR (Wikipedia ISO 4217 / Adyen currency docs, 2025). Never hard-code "divide by 100" — look up the exponent from a currency table.
- A `Money` value object should be `(amount: Decimal, currency: ISO4217Code)` and must reject construction that mixes currencies in arithmetic (`USD(10) + EUR(5)` is a type error, not an auto-convert). This is the classic Fowler/Kent Beck "Money pattern," still the correct default in 2026 — implement it as a real domain type, not a `(number, string)` tuple passed around ad hoc.
- FX conversion is a **recorded transaction with a rate, rate source, and rate timestamp** — never an inline multiplication buried in display logic.

---

## 2. Decision Tables for Tax/Pricing/Eligibility

### 2.1 Why scattered `if` statements are the enemy
Tax/pricing/eligibility rules are combinatorial (jurisdiction × product category × customer type × date range × threshold …). Encoded as nested conditionals, they are (a) unauditable — a tax analyst cannot review Java/Python, (b) untestable for completeness — nobody can eyeball 40 nested `if/elif` and state "every combination is covered, no combination is double-covered," and (c) impossible to diff meaningfully in a PR (a one-line rule change produces a noisy diff spread across control flow). **Decision tables make coverage and overlap a property the tool checks, not a property a human eyeballs.**

### 2.2 DMN (Decision Model and Notation) — the standard
DMN is an OMG standard for expressing decision logic as decision tables with a **hit policy** that formally defines what happens when multiple rules match. The critical hit policies for financial rule tables:

| Hit Policy | Symbol | Meaning | Where to use |
|---|---|---|---|
| **Unique (U)** | U | Exactly one rule may match; engine raises an error at *authoring time* if two rules overlap, and validates all input combinations are covered | Tax rate lookup, eligibility gates — you want compile-time proof of no-overlap |
| **Any (A)** | A | Multiple rules may match but must agree on the output | Redundant-but-consistent rule sets |
| **Priority (P)** | P | Multiple matches allowed; highest-priority output wins | Discount stacking with explicit precedence |
| **Collect (C)** | C, C+, C<, C>, C# | All matching rules fire; outputs aggregated (sum/min/max/count) | Multi-jurisdiction tax stacking (sum all applicable taxes) |
| **First (F)** | F | First matching rule in table order wins | Legacy migration only — avoid for new tables, it hides gaps |

Camunda's own 2025 guidance is explicit: the **Unique** hit policy is what makes a decision table *provably* non-overlapping and *exhaustively* covering — "Unique" both flags any overlapping rule pairs as invalid at modeling time and, when combined with the tool's coverage checker, confirms all input value combinations are handled (Camunda docs, "Choosing the DMN hit policy," camunda.com/blog/2025/02/decision-tables-for-automating-business-rules). **Default recommendation: author every tax-rate and eligibility table with hit policy `U` (Unique) unless you have a specific, documented reason for stacking (`C`) or overriding (`P`).**

### 2.3 Concrete tools (2025-2026 landscape)

| Tool | Type | Conformance | Notes |
|---|---|---|---|
| **Camunda 8 (Web Modeler + DMN engine)** | Commercial + OSS core | DMN 1.3 | Full modeler UI non-technical tax/pricing analysts can edit directly; integrates with the BPMN process engine for period-close workflows; SaaS or self-managed (docs.camunda.io) |
| **Apache KIE / Drools DMN** | OSS (Apache 2.0) | Conformance Level 3 (100% of the DMN spec) | Embeddable in Java; the reference OSS engine, contributes to the DMN TCK (kie.apache.org/components/drools/drools_dmn) |
| **jDMN** | OSS | Participates in DMN TCK | Lightweight, good for embedding a table-only evaluator without a full BPM engine |
| **DMN TCK (Technology Compatibility Kit)** | Test suite, not an engine | — | github.com/dmn-tck/tck — a shared, cross-vendor test corpus; **run your chosen engine's DMN tables through the TCK harness as a CI gate** so you have independent proof your rule authoring tool behaves per spec, not just per your own tests |

**Proposed default:** author decision tables as versioned `.dmn` XML artifacts in the repo (not as rows in a mutable admin-UI table with no diff history). Treat a decision table change exactly like a schema migration: PR review, automated overlap/coverage check (via the engine's own validator, run in CI), and a golden-reference regression run (Section 4) before merge. Effective-dated variants of the *same* logical rule (e.g., a tax rate that changes July 1) are new rows with `valid_from`/`valid_to` input columns — never an in-place edit of history, because past periods must still re-evaluate identically for restatements and audits.

---

## 3. Formal / Model-Checked Invariants — Where They Pay Off vs. Property-Based Testing

### 3.1 The two tools are complementary, not competing
- **Property-based testing (fast-check, Hypothesis)** generates many concrete random inputs and checks a property holds; it's excellent at catching arithmetic bugs (allocation losing a cent, rounding drift) in **code you already have**, cheaply, in every CI run.
- **Model checking (TLA+, Alloy)** exhaustively (or near-exhaustively, bounded) explores the **state space of a protocol/design**, before or independent of code, and is the right tool when the bug is a *race*, an *interleaving*, or a *missing case in a state machine* — the kind of bug that requires a very specific sequence of concurrent events to trigger, which random testing may need billions of trials to hit by chance.

**Rule of thumb for the ERP money core:**

| Question | Use |
|---|---|
| "Does my allocation/rounding function preserve invariants over many random inputs?" | fast-check / Hypothesis |
| "Can two concurrent postings to the same period, or a period-close racing an in-flight posting, ever produce an inconsistent ledger state (double-post, lost update, close-then-post)?" | TLA+ / Alloy |
| "Is my period state machine (Open → Soft-Close → Hard-Close → Locked, plus reopen) missing a transition that lets a document post into a closed period?" | Alloy (structural/relational) or TLA+ (temporal) |
| "Does the DMN tax table have gaps or overlapping rules?" | DMN engine's own Unique-hit-policy validator (Section 2), not a general model checker |

### 3.2 TLA+ for period-close and posting concurrency
TLA+ specifies a system as **variables + an initial predicate + a next-state relation (actions)**, and the TLC model checker exhaustively explores reachable states up to a bound, checking safety invariants (`Inv`) and, optionally, liveness/temporal properties. 2025-2026 activity: the TLA+ Foundation ran a "GenAI-accelerated TLA+ Challenge" in 2025 to explore LLM-assisted spec authoring, and financial-domain formal-methods work published in 2025 has applied TLA+-style state-machine specification to loan-lifecycle smart contracts (interest accrual, repayment schedule, termination) as a way to catch interleaving bugs analytically rather than by testing (ResearchGate, "Formal Specification and Verification of Smart Contract-Based Loan Management System Using TLA+," 2025). Applying the same method to period close:

```tla
---- MODULE PeriodClose ----
EXTENDS Integers, Sequences
CONSTANTS Periods, Documents
VARIABLES periodState, postedDocs, pendingPost

Init ==
    /\ periodState = [p \in Periods |-> "OPEN"]
    /\ postedDocs = {}
    /\ pendingPost = {}

\* A document begins posting: check the period is OPEN at the moment posting starts.
BeginPost(d, p) ==
    /\ periodState[p] = "OPEN"
    /\ d \notin pendingPost
    /\ pendingPost' = pendingPost \cup {d}
    /\ UNCHANGED <<periodState, postedDocs>>

\* Commit only if the period is STILL open — this is the race the spec exists to catch.
CommitPost(d, p) ==
    /\ d \in pendingPost
    /\ periodState[p] = "OPEN"           \* <-- must re-check, not assume from BeginPost
    /\ postedDocs' = postedDocs \cup {d}
    /\ pendingPost' = pendingPost \ {d}
    /\ UNCHANGED periodState

CloseSoft(p)  == periodState[p] = "OPEN"      /\ periodState' = [periodState EXCEPT ![p] = "SOFT_CLOSE"] /\ UNCHANGED <<postedDocs, pendingPost>>
CloseHard(p)  == periodState[p] = "SOFT_CLOSE" /\ pendingPost = {} \* cannot hard-close with in-flight posts
              /\ periodState' = [periodState EXCEPT ![p] = "HARD_CLOSE"] /\ UNCHANGED <<postedDocs, pendingPost>>

\* SAFETY INVARIANT: no document is ever recorded against a hard-closed period.
NoPostToClosedPeriod ==
    \A d \in postedDocs : \A p \in Periods :
        (periodState[p] = "HARD_CLOSE") => (d \notin { doc \in postedDocs : DocPeriod(d) = p } \/ TRUE) \* illustrative; real spec keys postedDocs by period

Next == \E d \in Documents, p \in Periods : BeginPost(d,p) \/ CommitPost(d,p) \/ CloseSoft(p) \/ CloseHard(p)
====
```

The point of writing this is not the syntax — it is that **TLC will find, in minutes, the interleaving where `BeginPost` succeeds while `OPEN`, a concurrent `CloseHard` fires, and `CommitPost` naively re-uses the stale check from `BeginPost` instead of re-validating** — a bug class that a property test would need a very specifically-timed concurrent harness to reproduce, and that a unit test almost never catches because it isn't written with that interleaving in mind. **Proposed default:** write a TLA+ spec (not necessarily verified by an automated pipeline, but authored and TLC-checked by an engineer) for exactly three subsystems: (1) period open/close/lock lifecycle, (2) the posting-commit protocol (to catch the close-race above and double-posting under retries), (3) multi-currency settlement/allocation concurrency if settlement is distributed. Do **not** attempt to TLA+-spec the whole ERP — this is a scalpel for the highest-blast-radius concurrency invariants, not a general design tool.

### 3.3 Alloy for structural/relational invariants
Alloy 6 (current stable line, released with temporal/mutable-state extensions — alloytools.org/alloy6.html, latest point release 6.2.0 as of Jan 2025 per alloytools.org) is better suited than TLA+ for **structural** invariants — e.g., "every posted journal entry has balanced debits/credits across exactly one period, and every period belongs to exactly one fiscal year, and no two periods overlap in their date ranges." Alloy's relational logic + automated SAT-based analyzer is a natural fit for checking these *data-shape* invariants (schema-level referential/structural constraints), whereas TLA+ is the better fit for *temporal/ordering* invariants (this-happens-before-that). **Default: use Alloy to check the fiscal-calendar data model (periods, fiscal years, no gaps/overlaps) once at design time; use TLA+ for the live concurrency protocol.**

### 3.4 Property-based testing — the everyday workhorse
Run these on every commit, not just at design time.

- **fast-check** (JS/TS): current major line is **4.x** (4.0.0 shipped March 2025, ending the 3.x series with API cleanup; 4.7.0 shipped April 2026 — fast-check.dev/blog). Supports a **model-based/stateful** testing mode (`fc.commands`) purpose-built for state machines: you define a set of possible commands (post document, close period, reopen period) with pre/post-conditions, and fast-check generates random command sequences and checks invariants hold after each — this is the practical, cheap complement to a full TLA+ spec for the *same* period-close state machine, run in CI on every PR rather than only when a human re-runs TLC.
- **Hypothesis** (Python): current version **6.156.1** (hypothesis.readthedocs.io, 2026) with `hypothesis.stateful.RuleBasedStateMachine`, `@rule`, `Bundle`, and `@invariant()` decorators for the same model-based state-machine testing pattern.

```python
from hypothesis import strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant, Bundle

class PeriodCloseMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.period_state = "OPEN"
        self.posted = []
        self.pending = []

    @rule(doc=st.integers())
    def begin_post(self, doc):
        if self.period_state == "OPEN":
            self.pending.append(doc)

    @rule()
    def commit_post(self):
        if self.pending and self.period_state == "OPEN":
            self.posted.append(self.pending.pop())

    @rule()
    def close_hard(self):
        if self.period_state == "SOFT_CLOSE" and not self.pending:
            self.period_state = "HARD_CLOSE"

    @invariant()
    def no_post_after_hard_close(self):
        # if this ever fires after a HARD_CLOSE, a doc slipped through the race
        assert not (self.period_state == "HARD_CLOSE" and self.pending)

TestPeriodClose = PeriodCloseMachine.TestCase
```

**Proposed default division of labor:** TLA+/Alloy spec once, by hand, for the three highest-value invariants (3.2); translate the same invariants into a fast-check/Hypothesis stateful model that runs on every CI build; keep both — the formal spec is the design-time proof, the property test is the regression guard that catches a future code change that violates the already-proven design.

---

## 4. The Golden-Reference Oracle

**Definition:** a fixed, versioned corpus of input transactions (sales orders, invoices, payments, credit memos, tax events, FX revaluations, period-close runs) paired with the **exact expected financial statements** (trial balance, P&L, balance sheet, tax return lines, AR/AP aging) they must produce — down to the cent, down to which GL account each cent landed in.

### 4.1 Why this is the highest-leverage correctness artifact in the whole system
Unit tests check functions in isolation; the golden-reference oracle checks the **entire posting pipeline end-to-end** the way an auditor would: "given these source documents, does the trial balance match, to the cent, what a human accountant/auditor already certified?" It is the financial-domain instance of **golden master / characterization testing** — capture a known-good output, then diff every future build's output against it byte-for-byte (or cent-for-cent) (Understand Legacy Code, "Characterization Tests or Approval Tests"; SitePoint, "Golden Master Testing," pattern confirmed as current industry practice for ERP financial-output regression in 2025 per allconsultingfirms.com "Regression Testing for ERP: Best Practices 2025"). Because rounding, allocation, and decision-table changes are exactly the kind of one-line change that silently shifts a cent three modules downstream, this is the test that catches what unit tests miss.

### 4.2 Concrete structure
```
/golden-reference/
  scenarios/
    001-simple-cash-sale/
      input/transactions.json        # ordered source documents, deterministic clock
      expected/trial_balance.json    # account -> {debit, credit} to the minor unit
      expected/p_and_l.json
      expected/balance_sheet.json
      expected/tax_return_lines.json
    002-multi-currency-fx-revaluation/
      ...
    003-prorated-subscription-with-largest-remainder/
      ...
    004-period-close-with-late-arriving-invoice/
      ...
  runner/replay_and_diff.py           # replays inputs through the current build, diffs vs expected
```

**Determinism requirements (non-negotiable, or the oracle is unusable):**
- Freeze the clock (inject a fixed `now()`), freeze FX rate lookups (fixture rate table, not live), freeze ID generation (deterministic sequence or fixed UUIDs), freeze locale/rounding policy inputs.
- Diff at the minor-unit level with **zero tolerance** — a passing golden-reference run means byte-identical amounts per account per period, not "within a cent." Any intentional change (e.g., a rate table update) requires an explicit, reviewed update to the `expected/` fixtures in the same PR, with the diff visible to reviewers — this makes "we changed the tax logic" a visible, reviewable financial-statement diff, not a silent behavior change.
- Cover, at minimum: a simple single-currency cash sale; a multi-line invoice needing largest-remainder allocation; a multi-jurisdiction tax stack (Collect hit policy); an FX revaluation; a prior-period adjustment posted into a still-open prior period; a period-close with a late-arriving document; a full 13-period fiscal year rollover; a reversal/credit-memo round trip.

### 4.3 Where it plugs into CI
Run the golden-reference suite (a) on every PR touching `ledger/`, `tax/`, `pricing/`, `period-close/`; (b) as a release gate before any tagged build; (c) after every DMN decision-table change (Section 2) and every rounding-policy change (Section 1). Treat a golden-reference diff exactly like a schema migration review — it requires a named financial/product approver, not just an engineering approver, because it is asserting "this is what correct output looks like" as a business fact, not just a code fact.

---

## 5. Fiscal Calendar & Period State Machine Rigor

### 5.1 Calendar variants to support explicitly
| Variant | Structure | Notes |
|---|---|---|
| **Standard monthly** | 12 calendar-month periods | Simplest; misaligned week-days across periods hurt week-over-week retail/ops comparisons |
| **4-4-5** | 4 quarters × (4 wk, 4 wk, 5 wk) = 13 weeks/quarter, 52 weeks/yr | Standard retail/manufacturing convention so each period has a consistent number of weekends (Chargebee RevRec docs, 2025; 4-4-5 calendar, Wikipedia) |
| **13-period (4-4-4-1 / "13 four-week periods")** | 13 periods × 4 weeks exactly | Most comparable period-over-period, since every period is structurally identical (getmyfixe.com, "Monthly vs 4-4-5 vs 13-period," 2025) |
| **Period 13 (closing period)** | 12 or 13 operating periods + a synthetic "Period 13" | Used by D365 F&O and similar ERPs to record audit/year-end adjustments *without* touching the operational periods already reported to the business (ERP Software Blog, "Period 13 Posting for Year-End Closing Adjustments in Microsoft D365 Finance," Nov 2025) |

**Proposed default:** model the fiscal calendar as its own versioned entity — `FiscalYear { periods: [Period] }`, `Period { number, start_date, end_date, type: OPERATING | ADJUSTMENT }` — decoupled from the posting engine, so 4-4-5 vs. calendar-month vs. 13-period is a **configuration of the calendar entity**, not a fork in application code. Validate with an Alloy-style structural invariant: periods within a fiscal year are contiguous, non-overlapping, and exhaustively cover the year's date range (see Section 3.3).

### 5.2 Three distinct dates — never conflate them
This is one of the most common ERP defects: treating "the date" as a single field.

| Date | Meaning | Who controls it | Effect |
|---|---|---|---|
| **Document date** | The date on the source business document (invoice date, PO date) | The counterparty / business event | Drives due-date and aging calculations |
| **Posting date** | The GL period the transaction is recorded into | The accountant/system, constrained by period-lock state | Determines *which period's* financial statements the amount lands in |
| **System/entry date** | The timestamp the record was actually created in the database | The system clock, immutable audit fact | Forensic/audit trail only — never used for financial calculation |

A transaction with document date in June can validly have posting date in July (late-arriving invoice) — this must be an explicit, permitted state, not an error, but it must be **impossible** to set a posting date into a period whose state is `HARD_CLOSE`/`LOCKED`. Enforce this as a database-level check constraint or transaction-boundary guard, not only an application-layer `if` — the period lock is a money-core invariant and deserves defense in depth.

### 5.3 Period state machine — proposed default states
```
DRAFT/FUTURE → OPEN → SOFT_CLOSE → HARD_CLOSE → LOCKED
                  ↑___________________|  (reopen, audited, requires elevated approval)
```
- **OPEN**: normal posting allowed.
- **SOFT_CLOSE**: no new *operational* postings; adjustment-only postings allowed (e.g., accruals, true-ups) — this is the window operations teams use to finish sub-ledger reconciliation before the accountants finalize.
- **HARD_CLOSE**: no postings at all; financial statements for the period are considered final and are the input to the golden-reference oracle comparison.
- **LOCKED**: HARD_CLOSE plus an explicit compliance/audit flag — reopening requires a recorded approval workflow (who, why, ticket reference), and reopening emits an audit-log event distinct from a normal state transition.
- **Reopen** is always a *new*, logged transition (`REOPENED_FROM_LOCKED_BY: user, reason, ticket`), never a silent revert — this is exactly the kind of transition an Alloy/TLA+ spec should enumerate explicitly so "can you post after the period looks closed" is a property that's checked, not assumed.

**Proposed default checklist per period-close cycle:**
1. Soft-close: block new operational postings; freeze sub-ledger→GL sync inputs.
2. Run allocation/proration jobs (largest-remainder, Section 1.3) and confirm `sum(allocated) == sum(source)` invariant holds for every run (should be a CI-style check inside the close job itself, not just in test).
3. Run tax/eligibility decision tables (Section 2) against the period's transactions; diff against prior period's rule-table version to flag any *unintentional* rule drift.
4. Run the golden-reference oracle scenarios that correspond to this period type (Section 4) as a pre-hard-close gate.
5. Hard-close: block all postings; snapshot trial balance immutably (append-only, hash-chained if audit requirements demand tamper-evidence).
6. Optionally lock; reopening thereafter requires the elevated, logged workflow above.

---

## Proposed Defaults — Summary Table

| Area | Default |
|---|---|
| Money representation | Integer minor units on the wire; `BigDecimal`/`decimal.js`/`Decimal`/`rust_decimal` in-process; `NUMERIC`, never `FLOAT`, in the DB |
| Rounding | Explicit `(jurisdiction, txn_type) → RoundingMode` policy table; `HALF_EVEN` GL default, `HALF_UP` for US tax filings |
| Allocation | Largest Remainder Method everywhere money is split; `sum(parts)==total` as a permanent property-test invariant |
| Currency | ISO 4217 lookup table for minor-unit exponent; typed `Money(amount, currency)` value object, no cross-currency arithmetic |
| Rule logic | DMN tables, hit policy `Unique` by default, `Collect` for stacking; author as versioned `.dmn` files; validate against DMN TCK |
| Decision engine | Camunda 8 DMN engine or Apache KIE/Drools DMN (OSS, Conformance Level 3) |
| Concurrency/state proofs | TLA+ spec for posting-commit race + period-close lifecycle; Alloy for fiscal-calendar structural invariants |
| Everyday regression | fast-check 4.x (JS) / Hypothesis 6.x (Python) stateful/model-based tests mirroring the TLA+ invariants, run every CI build |
| Regression oracle | Golden-reference transaction→statement corpus, zero-tolerance minor-unit diff, gated on every ledger/tax/pricing/close PR |
| Fiscal calendar | Configurable 4-4-5 / 13-period / monthly + synthetic adjustment period, modeled as versioned data, not code forks |
| Dates | Distinct document date / posting date / system date fields; posting date write blocked at HARD_CLOSE/LOCKED by a DB-level constraint |
| Period lifecycle | OPEN → SOFT_CLOSE → HARD_CLOSE → LOCKED, with explicit logged REOPEN transition requiring elevated approval |

---

## Sources

- [Choosing the DMN hit policy — Camunda 8 Docs](https://docs.camunda.io/docs/components/best-practices/modeling/choosing-the-dmn-hit-policy/)
- [The Power of Decision Tables for Automating Business Rules — Camunda (Feb 2025)](https://camunda.com/blog/2025/02/decision-tables-for-automating-business-rules/)
- [DMN Decision Engine — Camunda](https://camunda.com/platform/decision-engine/)
- [DMN | Apache KIE (incubating) — Drools DMN, Conformance Level 3](https://kie.apache.org/components/drools/drools_dmn/)
- [DMN TCK — Decision Model and Notation Technology Compatibility Kit](https://github.com/dmn-tck/tck)
- [Camunda DMN TCK](https://github.com/camunda/dmn-tck)
- [Formal Specification and Verification of Smart Contract-Based Loan Management System Using TLA+ (2025)](https://www.researchgate.net/publication/390515541_Formal_Specification_and_Verification_of_Smart_Contract-Based_Loan_Management_System_Using_TLA)
- [TLA+ for System Design: A CTO/L7 Engineer's Guide](https://wal.sh/research/tla-plus-system-design/)
- [Alloy — official site, Alloy 6 / 6.2.0](https://alloytools.org/)
- [Alloy 6 release notes](https://alloytools.org/alloy6.html)
- [Formal Software Design with Alloy 6 — overview](https://haslab.github.io/formal-software-design/overview/index.html)
- [largest-remainder-method (PHP implementation)](https://github.com/kschu91/largest-remainder-method)
- [Normally/largest-remainder — proportional distribution](https://github.com/Normally/largest-remainder)
- [Largest remainder method — electowiki](https://electowiki.org/wiki/Largest_remainder_method)
- [decimal.js — arbitrary-precision Decimal for JavaScript](https://github.com/MikeMcl/decimal.js)
- [rust_decimal — docs.rs](https://docs.rs/rust_decimal/latest/rust_decimal/)
- [bigdecimal — Rust crate](https://docs.rs/bigdecimal)
- [ISO 4217 — Wikipedia (minor units)](https://en.wikipedia.org/wiki/ISO_4217)
- [Currency codes and minor units — Adyen Docs](https://docs.adyen.com/development-resources/currency-codes)
- [Rounding in Accounting: Rules, Methods, and Pitfalls — LegalClarity](https://legalclarity.org/rounding-in-accounting-methods-and-best-practices/)
- [What Is Banker's Rounding and How Does It Work? — LegalClarity](https://legalclarity.org/what-is-bankers-rounding-and-how-does-it-work/)
- [Why does the IRS round up/down on tax returns? — Claimyr (2025)](https://claimyr.com/government-services/irs/Why-does-the-IRS-round-updown-on-tax-returns-Is-there-any-logic-to-it/2025-04-11)
- [fast-check — official documentation](https://fast-check.dev/)
- [What's new in fast-check 4.0.0? (March 2025)](https://fast-check.dev/blog/2025/03/10/whats-new-in-fast-check-4-0-0/)
- [What's new in fast-check 4.7.0? (April 2026)](https://fast-check.dev/blog/2026/04/18/whats-new-in-fast-check-4-7-0)
- [fast-check — npm](https://www.npmjs.com/package/fast-check)
- [Hypothesis 6.156.1 documentation](https://hypothesis.readthedocs.io/)
- [Hypothesis stateful testing docs](https://github.com/HypothesisWorks/hypothesis/blob/master/hypothesis-python/docs/stateful.rst)
- [4–4–5 calendar — Wikipedia](https://en.wikipedia.org/wiki/4%E2%80%934%E2%80%935_calendar)
- [4-4-5 Accounting Calendar — Chargebee RevRec Docs](https://www.chargebee.com/docs/revrec/revrec-445-accounting.html)
- [Comparing restaurant accounting calendars: Monthly vs 4-4-5 vs 13-period — Get My FIXE](https://www.getmyfixe.com/comparing-restaurant-accounting-calendars-monthly-vs-4-4-5-vs-13-period/)
- [Period 13 Posting for Year-End Closing Adjustments in Microsoft D365 Finance — ERP Software Blog (Nov 2025)](https://erpsoftwareblog.com/2025/11/period-13-posting-for-year-end-closing-adjustments-in-microsoft-d365-finance/)
- [Fiscal Years and Periods — SAP Help Portal](https://help.sap.com/docs/SAP_ERP/e054164e736046be90f4aec602391321/213dde531ed3424de10000000a174cb4.html)
- [Golden Master Testing: Refactor Complicated Views — SitePoint](https://www.sitepoint.com/golden-master-testing-refactor-complicated-views/)
- [Characterization test / Approval Tests — Understand Legacy Code](https://understandlegacycode.com/blog/characterization-tests-or-approval-tests/)
- [Regression Testing for ERP: Best Practices 2025 — All Consulting Firms](https://www.allconsultingfirms.com/blog/regression-testing-for-erp-best-practices-2025/)
