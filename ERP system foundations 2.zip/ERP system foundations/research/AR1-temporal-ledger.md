# AR1 — The Temporal & Ledger Core

**Audience:** AI agents authoring an "ERP build operating system" playbook.
**Stance:** Opinionated defaults an ERP builder adopts unless a documented reason overrides.
**Date:** 2026-07-07. Fast-moving claims are grounded in 2025–2026 primary sources; unverifiable items marked `(unverified as of 2026-07)`.

---

## 0. The one-paragraph thesis

An ERP is a machine for answering "what did we believe was true, about what point in time, and when did we come to believe it?" Every hard ERP requirement — restatement, audit, as-of reporting, drift detection, lineage — is a corollary of that sentence. So the core is not "tables of current state." It is **(a) an append-only event log** for the money- and quantity-moving facts (GL postings, inventory movements), and **(b) bitemporal storage** (valid-time × transaction-time) for the facts that have a business-effective date distinct from when we recorded them. Balances, trial balances, aged reports, and stock-on-hand are **projections** rebuilt from the log. Get this substrate right on day one and correctness, audit, and reporting become queries instead of rescue projects. Get it wrong and you spend the ERP's life reconciling.

---

## 1. Bitemporality: the highest-leverage decision

### 1.1 Two independent time axes

| Axis | Question it answers | Controlled by | Example |
|---|---|---|---|
| **Valid time** (a.k.a. application/effective time) | *When is this fact true in the business world?* | The business/user | A price is effective 2026-01-01; a hire starts 2026-03-01 |
| **Transaction time** (a.k.a. system/knowledge time) | *When did the database record we believed it?* | The system, immutably | We entered that price on 2025-12-14 at 09:32 |

Uni-temporal systems collapse these and lose information the moment reality and recording diverge — which is *always*, because of backdating, corrections, late invoices, and retroactive rate changes. Bitemporality is the model formalized by Snodgrass & Jensen (1994) and standardized in **ISO SQL:2011** ([XTDB docs](https://docs.xtdb.com/concepts/key-concepts.html)).

### 1.2 Why it is worth the complexity

Four ERP-defining capabilities fall out **natively** from keeping both axes:

- **Native restatement.** A retroactive vendor credit dated last quarter is a *new* row with `valid_from` in the past and `system_from` = now. Nothing is overwritten; last quarter's *as-reported* numbers still reproduce exactly, and the corrected view also reproduces exactly.
- **As-of reporting.** "Show the P&L for Q1 **as we knew it on the filing date**" is `WHERE system_time @> '2026-04-15'`. "Show it **with everything we know now**" drops that predicate. Same table, two truths, both defensible to an auditor.
- **Audit reconstruction.** "Who knew what, when" is a range query, not a forensic archaeology dig through backups.
- **Bug forensics.** When a projection is wrong you can replay the exact transaction-time slice the bug ran against.

**The bet:** the recurring cost of bolting these on later (shadow audit tables, "correction" hacks, backup-restore reporting) vastly exceeds the up-front cost of two timestamp columns and range constraints. This is the single highest-value architecture decision in an ERP. **Adopt bitemporality as the default for financially/legally significant, restatable master and transactional data.**

### 1.3 Implementation in PostgreSQL

**PostgreSQL 18 (released 2025-09-25)** is the inflection point. It adds native **temporal constraints**: `PRIMARY KEY`/`UNIQUE ... WITHOUT OVERLAPS` over a range column, and `FOREIGN KEY ... PERIOD` for temporal referential integrity ([PostgreSQL 18 release announcement](https://www.postgresql.org/about/news/postgresql-18-released-3142/); [Neon PG18 temporal constraints](https://neon.com/postgresql/postgresql-18/temporal-constraints)). This lets the *database* — not application triggers — guarantee "at most one valid price per SKU per instant."

Note the axes are handled by two different mechanisms, and this is the crucial nuance:

- **Valid time** → a **range column** + `WITHOUT OVERLAPS` (application-managed, the business sets it).
- **Transaction time** → **append-only rows** with a `system_time` range the app never mutates, closed by setting `system_to = now()` and inserting a successor. PostgreSQL still has **no native SQL:2011 system-versioned tables** — that remains extension/pattern territory ([PostgreSQL wiki: SQL2011Temporal](https://wiki.postgresql.org/wiki/SQL2011Temporal)).

**Proposed default DDL — bitemporal master data (a price list):**

```sql
CREATE EXTENSION IF NOT EXISTS btree_gist;   -- needed to mix scalar (sku) + range in one exclusion/GiST index

CREATE TABLE price (
    price_id      bigint GENERATED ALWAYS AS IDENTITY,
    sku           text        NOT NULL,
    amount_minor  bigint      NOT NULL,       -- integer minor units; NEVER float for money
    currency      char(3)     NOT NULL,
    valid_time    tstzrange   NOT NULL,       -- business-effective window
    system_time   tstzrange   NOT NULL DEFAULT tstzrange(now(), NULL, '[)'),  -- knowledge window; NULL upper = "currently believed"
    recorded_by   text        NOT NULL,
    -- One valid price per SKU per instant, but ONLY among currently-believed rows.
    CONSTRAINT price_no_overlap
      EXCLUDE USING gist (sku WITH =, valid_time WITH &&)
      WHERE (upper_inf(system_time))
);
```

The partial `WHERE (upper_inf(system_time))` is load-bearing: superseded (transaction-time-closed) rows are *expected* to overlap their successors in valid time, so the non-overlap invariant applies only to the live knowledge slice. On PG18 you can alternatively lift the valid-time key into a real temporal `PRIMARY KEY (sku, valid_time WITHOUT OVERLAPS)` on a current-only partition/view.

**Correcting a fact (bitemporal update = close + append, never `UPDATE ... SET amount`):**

```sql
BEGIN;
-- 1. Close the currently-believed row's knowledge window.
UPDATE price
   SET system_time = tstzrange(lower(system_time), now(), '[)')
 WHERE sku = 'WIDGET-1' AND upper_inf(system_time);

-- 2. Append the corrected belief (note valid_from can be in the PAST — a restatement).
INSERT INTO price (sku, amount_minor, currency, valid_time, recorded_by)
VALUES ('WIDGET-1', 1899, 'USD', tstzrange('2026-01-01', NULL, '[)'), 'clerk:42');
COMMIT;
```

**As-of query — the whole point:**

```sql
-- What price did we consider effective for 2026-03-15, as we understood things on 2026-04-15?
SELECT amount_minor, currency
FROM   price
WHERE  sku = 'WIDGET-1'
  AND  valid_time  @> timestamptz '2026-03-15'
  AND  system_time @> timestamptz '2026-04-15';
```

**Three viable Postgres patterns, ranked:**

1. **Append-only + effective/knowledge ranges (recommended default).** Two `tstzrange` columns, `btree_gist` exclusion constraints, correction = close+insert. Full control, portable to PG14+, and the model an ERP actually needs. This is the playbook default.
2. **PG18 native temporal `WITHOUT OVERLAPS` / `PERIOD` FKs** for the *valid-time* dimension, layered on pattern (1). Use it — let the engine enforce non-overlap and temporal FKs — but you still hand-roll transaction-time.
3. **History-table extensions** (`periods`, `temporal_tables`). Fine for *audit shadowing* of otherwise-uni-temporal tables (cheap "who changed this row"), but they don't give you first-class *valid-time* business modeling. Use as an add-on, not the core.

### 1.4 Where XTDB / Datomic-style stores fit vs Postgres

**XTDB v2** (GA'd June 2025; JUXT acquired by Grid Dynamics) is a purpose-built **immutable, bitemporal SQL database**: *every* row is bitemporal automatically via built-in `_valid_from/_valid_to` and `_system_from/_system_to` columns, it enforces `WITHOUT OVERLAPS` internally, speaks SQL:2011 temporal syntax **over the Postgres wire protocol**, and stores data as an LSM-tree over object storage with bitemporal partitioning ([XTDB](https://xtdb.com/); [XTDB key concepts](https://docs.xtdb.com/concepts/key-concepts.html)). **Datomic** offers transaction-time (`asOf`/history) natively but valid-time is user-modeled.

**Opinionated call:** Default to **PostgreSQL**. It's the operational center of gravity, your team knows it, and PG18 + the append-only pattern covers the 90% case. Reach for **XTDB** only when bitemporality is *pervasive* (nearly every entity needs both axes and you're tired of hand-rolling it), when time-travel/as-of is a *primary product surface*, or in heavily regulated domains where "immutable by construction" is a compliance argument. Treat XTDB as a specialized bitemporal store alongside Postgres, not a wholesale replacement, until it's proven in your ops. `(XTDB production-hardening maturity: unverified as of 2026-07 — validate with a load test before betting the ledger on it.)`

---

## 2. The GL as an event-sourced log

### 2.1 What to event-source — and the boundary discipline

Event sourcing stores every change as an immutable, append-only sequence of events; current state is *derived*, not stored ([Baytech, 2025](https://www.baytechconsulting.com/blog/event-sourcing-explained-2025)). Double-entry bookkeeping is the original event-sourced system — journal entries are immutable events, balances are the fold ([DEV: Event Sourcing and the History of Accounting](https://dev.to/dealeron/event-sourcing-and-the-history-of-accounting-1aah)). Event Sourcing + CQRS is now mainstream, reported adopted by ~57% of surveyed orgs pairing the two ([IntuitionLabs, 2025](https://intuitionlabs.ai/articles/event-sourcing-vs-queue-systems)).

**The critical boundary — memorize this table.** Event-sourcing the wrong things is how teams drown.

| Event-source it (immutable facts that *happened*) | Do **NOT** event-source it (current-state records that *are*) |
|---|---|
| GL journal postings | Chart of accounts (master data) |
| Inventory movements (receipts, issues, transfers, adjustments) | Item master, BOMs |
| Payments, receipts, settlements | Customer/vendor master, addresses |
| Invoice issued / credited | User accounts, roles, permissions |
| Stock counts, revaluations | Config, tax rates *as current lookup* |

**Rule:** *Money and quantity movements are events. The nouns they reference are master data.* Master data is **bitemporal state** (Section 1), not an event stream. Blurring this — modeling "customer" as an event stream — buys you replay complexity with zero audit benefit, because nobody restates a customer's phone number the way they restate a ledger. Keep master data in bitemporal tables; keep movements in the append-only log; let events *reference* master data by `(id, valid_time)`.

### 2.2 The ledger event schema

**Proposed default — immutable journal, integer money, balanced-by-construction:**

```sql
CREATE TABLE journal_entry (            -- the "transaction" envelope (an event)
    entry_id     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    occurred_at  timestamptz NOT NULL,  -- valid time: business/effective date of the economic event
    recorded_at  timestamptz NOT NULL DEFAULT now(),  -- transaction time: when booked
    description  text        NOT NULL,
    source_type  text        NOT NULL,  -- 'ap_invoice','inventory_receipt',... (lineage)
    source_id    uuid        NOT NULL,  -- FK into the originating document
    reversed_by  uuid REFERENCES journal_entry(entry_id)  -- corrections = reversing entries, never DELETE
);

CREATE TABLE journal_line (             -- the postings (immutable)
    line_id      bigint GENERATED ALWAYS AS IDENTITY,
    entry_id     uuid    NOT NULL REFERENCES journal_entry(entry_id),
    account_id   bigint  NOT NULL REFERENCES account(account_id),
    -- Signed integer minor units. Positive = debit, negative = credit (pick ONE convention, enforce forever).
    amount_minor bigint  NOT NULL,
    currency     char(3) NOT NULL,
    CHECK (amount_minor <> 0)
);

-- INVARIANT enforced at write time: each entry's lines net to zero (debits == credits).
CREATE CONSTRAINT TRIGGER journal_balanced
AFTER INSERT ON journal_line
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION assert_entry_balanced();  -- SUM(amount_minor) per entry_id = 0
```

**Non-negotiable rules:** (1) **Never `UPDATE`/`DELETE` a posted line** — corrections are *reversing entries* (`reversed_by`) or new adjusting entries. (2) **Money is integer minor units**, never float/`double`; store currency; scale via `numeric` only at report edges. (3) **Balance is an invariant at the boundary**, checked as the entry is written (deferred within the transaction).

### 2.3 Balances are projections

```sql
-- Read model: account balance as a fold over the immutable log.
CREATE MATERIALIZED VIEW account_balance AS
SELECT jl.account_id,
       jl.currency,
       SUM(jl.amount_minor) AS balance_minor,
       max(je.recorded_at)  AS as_of
FROM   journal_line jl
JOIN   journal_entry je USING (entry_id)
GROUP  BY jl.account_id, jl.currency;
```

An **as-of balance** is the same fold with `WHERE je.recorded_at <= :cutoff` (transaction-time) and/or `je.occurred_at <= :cutoff` (valid-time). A **trial balance** is `SUM(amount_minor) GROUP BY currency` across all accounts — which must equal **zero** if the log is sound. That equality *is* the continuous-close invariant (Section 3).

### 2.4 Outbox / CDC to build read models

Don't have services publish events out-of-band from their DB writes — you'll drop or duplicate. Use the **transactional outbox**: write the domain change and an `outbox` row in the *same* transaction; a CDC relay tails the WAL and forwards. **Debezium 2.5+** is the 2025 industry-standard relay; because it reads the WAL, not the table, you can delete outbox rows immediately after insert and consumers get **at-least-once** delivery (so **projections must be idempotent** — upsert keyed by `entry_id`/event id) ([Conduktor: Outbox Pattern](https://www.conduktor.io/glossary/outbox-pattern-for-reliable-event-publishing); [SeatGeek engineering](https://chairnerd.seatgeek.com/transactional-outbox-pattern/)). Watch the single-outbox-table hot-spot under high write throughput; partition or shard the outbox if it becomes a bottleneck.

```sql
-- Same transaction as the journal write:
INSERT INTO outbox (id, aggregate_type, aggregate_id, event_type, payload)
VALUES (gen_random_uuid(), 'journal_entry', :entry_id, 'EntryPosted', :json);
-- Debezium tails WAL -> Kafka topic -> projection consumers (idempotent upsert by event id).
```

### 2.5 Snapshotting

Folding millions of lines per balance query doesn't scale. **Snapshot** periodically: persist `account_balance` at a checkpoint (event offset / `recorded_at`), then compute live balance = snapshot + fold of events *after* the checkpoint. Rebuild any projection from zero by replaying the log (the recovery guarantee). Keep snapshots **derived and disposable** — the log is the source of truth; a snapshot is a cache with a watermark. **Default:** daily period-end snapshots per account + on-demand snapshot when an account's post-snapshot event count crosses a threshold (e.g. 10k).

---

## 3. Continuous close & reconciliation

The month-end close exists because legacy systems only *discover* imbalance in batch. An event-sourced, invariant-checked ledger is **always balanced by construction**, so shift discovery **left to the moment of drift**. This is the operational payoff of Sections 1–2.

**Invariants to monitor live (run as scheduled SQL + alert on non-zero):**

| Invariant | Check | Alert when |
|---|---|---|
| Debits == credits | `SUM(amount_minor) OVER all lines` per currency | `<> 0` |
| Entry-level balance | per-`entry_id` sum | `<> 0` (should be impossible if trigger holds — a breach means the trigger was bypassed) |
| Sub-ledger ↔ GL tie-out | `SUM(AP subledger)` vs GL control account | delta `<> 0` |
| Inventory value ↔ GL | `SUM(movement value)` vs inventory GL account | delta `<> 0` |
| Projection freshness | `max(recorded_at)` in read model vs log head | lag > SLA |

```sql
-- Global trial-balance invariant: the whole ledger must net to zero, now.
SELECT currency, SUM(amount_minor) AS imbalance_minor
FROM   journal_line
GROUP  BY currency
HAVING SUM(amount_minor) <> 0;   -- ANY row returned => page on-call. Should always be empty.
```

**Proposed default:** run the invariant suite continuously (e.g. every 1–5 min via `pg_cron` or the orchestrator) and **alert same-day on drift** instead of discovering it at month-end. Sub-ledger↔GL tie-outs become a live dashboard, not a spreadsheet reconciliation. A drift alert should carry the offending `source_id`/`entry_id` so triage starts with the exact event.

**Specialized ledger engines.** If ledger throughput or safety exceeds what a general RDBMS gives you, **TigerBeetle** is a purpose-built double-entry financial database — two primitives (`accounts`, `transfers`), designed for millions of transfers/sec with strict consistency, first production release March 2024 and actively developed through 2025 ([TigerBeetle docs](https://docs.tigerbeetle.com/single-page/); [tigerbeetle.com](https://tigerbeetle.com/)). **Default:** start with Postgres; adopt TigerBeetle as the hot ledger-of-record when you have a genuine high-throughput payments/transfers workload, keeping Postgres for reporting/master data.

---

## 4. Lineage as a first-class query

Every reported number must **drill to the source events that produced it** — not by convention, but as a schema-enforced path. The chain is: **report figure → projection rows → journal lines → journal entry → source document (`source_type`, `source_id`) → originating event.** Because postings are immutable and carry `source_type`/`source_id`, lineage is a join, not a metadata system.

```sql
-- "This $X on the Q1 P&L came from where?" — full drill-down in one query.
SELECT je.entry_id, je.occurred_at, je.recorded_at,
       je.source_type, je.source_id,      -- <- the originating business document
       jl.account_id, jl.amount_minor, je.description
FROM   journal_line  jl
JOIN   journal_entry je USING (entry_id)
WHERE  jl.account_id = :account
  AND  je.occurred_at <@ tstzrange('2026-01-01','2026-04-01')  -- the reported period (valid time)
  AND  je.recorded_at <= :report_run_time                       -- as-of knowledge (transaction time)
ORDER  BY je.occurred_at;
```

**Design rules that make lineage free:** (1) every projection row retains the `entry_id`s (or an aggregate keyed to them) it was folded from; (2) `source_type`/`source_id` are **mandatory NOT NULL** on every entry — no orphan postings; (3) reversals link via `reversed_by`, so a number's *full* history (posted, then corrected) is reachable. **Default:** lineage drill-down is a supported product feature and an API endpoint, not a DBA favor.

---

## 5. When NOT to use bitemporal everywhere (the caution)

Bitemporality and event sourcing are **taxes** — write amplification, query complexity, mandatory idempotency, more surface for bugs. "Rethinking Event Sourcing" (2025) documents teams for whom the pattern's overhead outweighed benefits ([bemi.io](https://blog.bemi.io/rethinking-event-sourcing/)). Apply the substrate **surgically**:

| Use full bitemporal + event sourcing | Uni-temporal or plain current-state is fine |
|---|---|
| GL / journal, inventory movements | Session state, caches, feature flags |
| Anything restatable or legally auditable (prices, tax, payroll rates, contracts) | High-churn telemetry, logs, ephemeral queues |
| Sub-ledgers, revenue recognition | UI preferences, draft/scratch data |
| Regulated master data | Reference lookups that are never restated |

**Anti-patterns to reject explicitly:**
- Event-sourcing **master data** (customer, item) — it's bitemporal *state*, not a movement stream (Section 2.1).
- **Bitemporal-everything by reflex.** If a table is never restated and never queried as-of, two range columns are pure overhead. Add a plain `updated_at`.
- **Float money.** Ever. Integer minor units.
- **Mutable postings.** Corrections are reversing entries; `UPDATE` on a posted line is a data-integrity incident.
- **Publishing events without the outbox** — dual-write races lose money.

**Decision heuristic:** *Ask "will anyone ever need to restate this, or ask how it looked at a past instant?" If yes → bitemporal. Is it a money/quantity movement? If yes → event-sourced immutable log. Otherwise → current-state table with a plain audit column.*

---

## 6. Proposed defaults (adopt unless documented otherwise)

1. **PostgreSQL 18+** as the core; `btree_gist` enabled; money as **integer minor units** + explicit currency.
2. **Bitemporal via append-only + `valid_time`/`system_time` `tstzrange`** columns; corrections = close-and-append; use PG18 `WITHOUT OVERLAPS`/`PERIOD` FKs for the valid-time dimension.
3. **Event-source only money/quantity movements** (GL, inventory); **master data stays bitemporal state**, referenced by `(id, valid_time)`.
4. **Immutable journal**, per-entry balanced-by-construction (deferred constraint trigger); corrections via reversing entries.
5. **Balances/trial balance/aged reports = projections**; snapshot per period-end + threshold; rebuildable from the log.
6. **Transactional outbox + Debezium 2.5+ CDC**; idempotent, upsert-keyed projections.
7. **Continuous invariant monitors** (debits==credits, sub-ledger↔GL, inventory↔GL, projection lag) every 1–5 min; **same-day drift alerts** carrying `entry_id`/`source_id`.
8. **Lineage as a first-class query/API**: every figure drills report → line → entry → source document.
9. **Escalation stores:** **XTDB v2** when bitemporality is pervasive or time-travel is a product surface; **TigerBeetle** for high-throughput transfers-of-record. Both as specialized companions to Postgres, proven under load first.

---

## Sources

- PostgreSQL 18 Released (2025-09-25), temporal constraints — https://www.postgresql.org/about/news/postgresql-18-released-3142/
- Neon — PostgreSQL 18 Temporal Constraints (WITHOUT OVERLAPS / PERIOD) — https://neon.com/postgresql/postgresql-18/temporal-constraints
- Hashrocket — PostgreSQL 18 Temporal Constraints — https://hashrocket.com/blog/posts/postgresql-18-temporal-constraints
- PostgreSQL wiki — SQL2011Temporal (native system-versioning status) — https://wiki.postgresql.org/wiki/SQL2011Temporal
- PostgreSQL wiki — Temporal Extensions (`periods`, `temporal_tables`) — https://wiki.postgresql.org/wiki/Temporal_Extensions
- XTDB — immutable bitemporal SQL database — https://xtdb.com/
- XTDB docs — Key concepts (bitemporality, valid/system time, SQL:2011) — https://docs.xtdb.com/concepts/key-concepts.html
- TigerBeetle docs (accounts/transfers, double-entry) — https://docs.tigerbeetle.com/single-page/
- TigerBeetle — https://tigerbeetle.com/
- Baytech — Event Sourcing Explained (2025) — https://www.baytechconsulting.com/blog/event-sourcing-explained-2025
- IntuitionLabs — Event Sourcing vs Queue Systems (adoption stats, 2025) — https://intuitionlabs.ai/articles/event-sourcing-vs-queue-systems
- DEV — Event Sourcing and the History of Accounting — https://dev.to/dealeron/event-sourcing-and-the-history-of-accounting-1aah
- Conduktor — Outbox Pattern for Reliable Event Publishing — https://www.conduktor.io/glossary/outbox-pattern-for-reliable-event-publishing
- SeatGeek ChairNerd — Transactional Outbox Pattern (Debezium CDC) — https://chairnerd.seatgeek.com/transactional-outbox-pattern/
- bemi.io — It's Time to Rethink Event Sourcing (caution, 2025) — https://blog.bemi.io/rethinking-event-sourcing/
