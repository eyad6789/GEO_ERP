# research/ — provenance for the playbook

These are the research reports (2026-07, web-grounded) that the `playbook/*.md` files distilled into doctrine. They exist so that a playbook file's `depends_on:` front-matter and any inline "per R3-tech-stacks §…" citation **resolve to a real file** — read them for the full reasoning and sources behind a rule.

| File | Backs |
|---|---|
| `R1-security-doctrine.md` | 05, 06 — threat modeling, multi-tenant isolation, audit log, secrets, AI/LLM threats |
| `R2-attack-scenarios.md` | the 20+ `playbook/security/scenarios/*` |
| `R3-tech-stacks.md` | 04 — stack decision + matrices |
| `R4-deployment.md` | 05, 11 — deployment topologies, sizing, backup/DR |
| `R5-claude-code.md` | 01 — Claude Code features, hooks, subagents, context mgmt |
| `R6-ai-build-method.md` | 02, 09, 10 — spec-first, test-first, verification, anti-hallucination |
| `R7-design-system.md` | 03, 08, `templates/decision-file.html` — Anthropic design tokens + ERP UX |
| `R8-testing-migration.md` | 07, 10, 11 — test doctrine, migration runbook |
| `verification-results.md` | 01 — the flagged-claims register (44 claims re-checked vs primary sources) |

**Fallback rule:** if a cited research doc is ever absent, treat the playbook file's own inline summary as authoritative and log the gap in `progress/phase-log.md` — a missing citation must never stall a build. These reports are dated 2026-07; re-verify fast-moving facts via `playbook/01-freshness-check.md`, don't trust them as permanently current.
