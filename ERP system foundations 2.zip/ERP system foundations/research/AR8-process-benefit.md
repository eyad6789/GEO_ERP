# AR8 — Process-First & Benefit Realization: The Non-Technical Truth That Decides ERP Success

*Track: AR8-process-benefit · Compiled 2026-07-07 · For: ERP Build Operating System playbook*
*Scope: the gate that must exist BEFORE feature-building starts, and the measurement loop that must exist AFTER go-live. This is not UX polish — it is the single highest-leverage failure point in ERP delivery.*

---

## 0. The one doctrine that governs everything below

> **A feature built for an unexamined process does not deliver value — it hard-codes waste and makes it harder to remove.** No feature ships until (a) the process it automates is mapped and classified as fit-to-standard or a justified deviation, and (b) a named business outcome with a baseline, a target, and an owner exists for it. No project is "done" at go-live — it is done when the benefit register shows realized value against target, measured on a fixed cadence, for a minimum of 12 months.

This is not a stylistic preference. It is the direct, evidenced answer to *why ERP projects fail on schedule and in budget but still get scored as failures*: Gartner's own research states that **more than 70% of recently implemented ERP initiatives will fail to fully meet their original business case goals through 2027, with as many as 25% failing catastrophically** — and separately that **roughly 75% of ERP strategies are not strongly aligned with the overall business strategy** [Gartner via Godlan 2025]. These are not technology failures. A system can go live on time, on budget, pass every UAT script, and still be a failure — because "failure" here is defined against the *business case*, and most projects never rigorously defined or re-measured that business case in the first place. Prosci's 2025 *Unlocking ERP Implementations* study is blunt about where the lever actually is: **human/organizational factors matter roughly 6x more than technical factors** in determining realized ERP benefit, and projects with **no formal success metrics defined at all (26% success) outperform projects with poorly-defined metrics (7% success)** — bad metrics are worse than no metrics, and only **comprehensive metrics maturity reaches ~28% full-success** [Prosci 2025, "Governing ERP Benefits Beyond Go-Live"]. The build OS therefore treats "define the process and the outcome metric before writing a feature" as a **structural gate**, not a recommendation a PM can skip under deadline pressure.

---

## 1. Process mapping and fit-to-standard vs. fit-to-process

### 1.1 Why this is the first gate, not a nice-to-have

The industry's own standard methodology has already converged on this. SAP Activate's Explore phase replaced the old multi-month "blueprinting" era with **Fit-to-Standard (F2S) workshops**: stakeholders walk each pre-packaged "scope item" (a standard end-to-end process) against SAP's best-practice reference process, using **BPMN models in SAP Signavio Process Manager** (or equivalent) as the shared artifact, and every place the org's actual process diverges from standard is captured as an explicit, justified **delta** — not silently built [SAP Community 2025; SAP Signavio docs 2025]. The stated principle: **"any proposed customization must be motivated against business value"** [SAP Help, "Value Accelerators in a Fit-to-Standard Scenario," 2025-08]. That is the operating principle this playbook adopts wholesale, generalized beyond SAP: **the default is standard; a deviation is a documented, cost-justified exception, never an unexamined default.**

The failure mode this prevents has a name in the industry: **"paving the cow path"** — automating the existing broken process as-is because it's familiar, rather than asking whether the process itself should change. Panorama Consulting frames it directly: **"to customize a bad process is a sure guarantee of runaway costs and could potentially ruin an otherwise successful ERP implementation"** [Panorama Consulting, "What Not To Do When Customizing ERP Software"]. Every dollar spent hard-coding a broken approval chain, a redundant reconciliation step, or a manual workaround into the new system is a dollar that makes the waste permanent and harder to remove later, because now it has test coverage, training material, and organizational muscle memory defending it.

### 1.2 Fit-to-standard vs. fit-to-process — the actual decision rule

These are not synonyms and the build OS must force the distinction explicitly at the point a gap is found:

| | **Fit-to-standard** | **Fit-to-process** (justified deviation) |
|---|---|---|
| Default posture | Business adapts to the software's reference process | Software (or an extension) adapts to a business process that is a genuine differentiator |
| When to choose | Commodity function: AP, AR, standard GL close, standard procurement | Core competitive differentiator: proprietary pricing logic, a regulatory carve-out, a genuinely unique supply chain step |
| Cost/time signal | ~50-60% cheaper, ~6-12 month typical rollout | Materially higher cost, 12-18+ months, ongoing upgrade drag [Protiviti 2025; Panorama 2025] |
| Governance requirement | None beyond recording the scope item as accepted | **Mandatory written justification tied to a quantified business value**, signed by a process owner, logged in the deviation register |
| Technical debt implication | Low — stays in the clean core, upgrades safely | High — every deviation is a future upgrade/maintenance cost; must be tracked as debt, not forgotten |

Operating rule for the build OS (**PROPOSED**, adapted from SAP Activate + Protiviti's 2025 decision framework): classify every candidate gap as **(a) core differentiator — worth building**, or **(b) commodity — conform to standard**, using a two-question test before any feature ticket is opened:
1. Does this process differentiate us competitively or is it required by law/regulation in a way the standard process cannot satisfy? If no → fit-to-standard, close the gap by changing the business process, not the software.
2. If yes — what is the quantified business value of the deviation, and does it exceed the fully-loaded cost of building + testing + upgrading it forever? If the value case can't be written down, the deviation is rejected by default.

### 1.3 BPMN as the shared artifact — concrete sketch

BPMN 2.0 (OMG spec, ratified as ISO 19510; the spec text itself has been stable since **2.0.2, Jan 2014**, and remains the de facto standard for this purpose — no material 2025/2026 revision was found; treat "BPMN 2.0.2" as current) [OMG BPMN 2.0.2] is the notation to standardize on because it is simultaneously (a) readable by a business stakeholder as a flowchart and (b) a literal, executable XML artifact an orchestration engine (Camunda, or SAP Signavio's own engine) can validate and even run [Camunda BPMN primer 2025]. Concretely, the build OS should require every in-scope process to exist as a `.bpmn` file (BPMN 2.0 XML) in the repo before a feature ticket referencing that process can be opened:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
                   xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI"
                   id="proc-p2p-invoice-approval" targetNamespace="erp-build-os">
  <bpmn:process id="Process_InvoiceApproval" name="Invoice Approval (AS-IS)" isExecutable="false">
    <bpmn:startEvent id="Start_InvoiceReceived" name="Invoice received"/>
    <bpmn:task id="Task_ManualMatch" name="Manually match to PO (no tolerance rule)"/>
    <bpmn:exclusiveGateway id="Gate_OverThreshold" name="&gt; $5,000?"/>
    <bpmn:task id="Task_CFOApproval" name="CFO approves in person (no delegate)"/>
    <bpmn:task id="Task_Post" name="Post to GL"/>
    <bpmn:endEvent id="End_Posted" name="Invoice posted"/>
    <!-- sequence flows omitted for brevity -->
  </bpmn:process>
</bpmn:definitions>
```

The AS-IS map above is deliberately annotated with waste markers in plain text (`no tolerance rule`, `no delegate`) — this is the artifact the fit-to-standard workshop reviews against the vendor's reference process, producing a TO-BE map plus a delta list. `bpmn-js` (bpmn.io, MIT-licensed, maintained by Camunda) is the recommended open-source viewer/editor to embed this in the build OS's interview tooling — it round-trips BPMN XML in the browser with a few lines of JS and requires no vendor lock-in [bpmn.io toolkit docs].

Process mining tools are the verification layer, not the design layer: **Celonis** (strongest for cross-ERP extraction — SAP, Oracle, Dynamics) and **SAP Signavio Process Intelligence** (native for SAP shops, with 2026 releases adding continuous data replication via SAP Datasphere) let a team compare the *designed* BPMN against the *actual* event-log-derived process post-go-live, closing the loop between what was mapped and what people actually do [mybusinessfuture 2026; SAP Community, Signavio Feb-2026 release]. Documented outcomes at this scale are real, not theoretical: **Johnson & Johnson cut touch time 30% and price-change cycle time 40%** using process mining to redesign delivery; **Accenture cut procurement cycle time 75%** identifying P2P bottlenecks with Celonis [mybusinessfuture 2026]. A mid-size ERP build cannot expect Celonis-scale numbers, but the mechanism — mine the actual event log, don't trust the interview — transfers directly and should be the post-go-live verification step (Section 3).

---

## 2. Value engineering — outcomes and metrics before features

### 2.1 The rule

**No feature-building sprint starts until every in-scope process has a named business outcome, a numeric baseline, a numeric target, and an accountable owner.** This is the direct fix for the Prosci finding that undefined or poorly-defined metrics are the dominant predictor of failure — worse, even, than defining none at all, because a bad metric creates false confidence and gets gamed [Prosci 2025]. The build OS's interview phase must produce, per major process area, a structured **Value Case** object — not a paragraph of prose benefits, a schema:

```yaml
value_case:
  process_id: proc-p2p-invoice-approval
  business_outcome: "Reduce invoice-to-post cycle time and eliminate late-payment penalties"
  baseline:
    metric: days_invoice_to_post
    value: 14.2
    measured_as_of: 2026-06-01
    source: "AP aging report, current ERP export"
  target:
    metric: days_invoice_to_post
    value: 3.0
    by_date: 2027-01-15   # 3 months post go-live
  secondary_metrics:
    - { metric: late_payment_penalty_usd_per_qtr, baseline: 18400, target: 0 }
    - { metric: pct_touchless_invoices, baseline: 4, target: 60 }
  owner: "AP Manager — J. Ruiz"
  measurement_method: "Query on invoice.created_at vs gl_posting.posted_at, automated dashboard"
  gate_status: DEFINED   # DEFINED | BASELINED | LOCKED | AT_RISK | REALIZED
```

This is deliberately closer to a data contract than a slide. If a process area cannot produce this object with a real baseline number (not "we think it's slow"), that is itself a finding: it means the org doesn't currently measure the thing it wants the ERP to fix, and the first work item is instrumenting the *current* state, not building the *future* one.

### 2.2 Where this comes from, credibly

This mirrors the **Managing Benefits (MoP)** framework's core discipline — identify, appraise, plan, realize, review benefits explicitly across the project lifecycle rather than treating them as a one-time business-case exercise [APMG International, Managing Benefits certification; UK Government Project Delivery Teal Book, ch.19 "Benefits management"]. The UK government's own delivery standard requires a **Benefits Realisation Plan**, a **Benefits Register**, and named ownership as mandatory artifacts for public-sector technology programs — the same rigor is appropriate for any ERP build with real budget behind it, and the build OS should treat it as the default rather than something only regulated public projects do.

### 2.3 Concrete scoring at the gate

Value cases should be scored, not just collected, so the build OS can rank feature work. **PROPOSED** scoring rubric per value case (0-3 each, gate requires ≥7/12 or explicit executive override logged):

| Dimension | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| Baseline quality | No baseline | Estimated/anecdotal | Derived from a report, one-time pull | Automated, repeatable query against source system |
| Target specificity | Vague ("improve X") | Directional, no number | Numeric target, no date | Numeric target + date + named owner |
| Measurability post-launch | No plan to measure | Manual survey only | Semi-automated report | Fully automated dashboard tied to production data |
| Process fit classification done | Not done | AS-IS mapped only | AS-IS + TO-BE mapped | AS-IS + TO-BE + fit-to-standard/deviation decision logged |

A feature ticket referencing a process whose value case scores below the threshold is **blocked from entering the build backlog** — this is the enforceable teeth described in Section 4.

---

## 3. Benefit realization — the measurement that almost never happens

### 3.1 Why this is the most common and least visible failure mode

Go-live is treated, almost universally in practice, as the finish line. It is not. Prosci's language is precise: organizations that stop at go-live "misunderstand when ERP value materializes" — the real business value surfaces through post-launch process refinement, user feedback, and automation opportunities discovered only after the system is in daily use [Prosci 2025]. This is exactly the phase where measurement stops happening, because the project team disbands, the budget line closes, and nobody owns the follow-through. Gartner's >70%-fail-business-case statistic is a direct consequence of this gap: the system works, the project closed "successfully" on the PM's scorecard, and eighteen months later nobody can say whether the promised benefit ever showed up, because nobody was measuring it against the original baseline.

The financial stakes are not small. Gartner-sourced cost-overrun data puts **average cost overruns at 189% across industries, and 215% for discrete manufacturing** [Godlan, citing Gartner, 2025] — overruns of this size are typically justified internally by pointing at *future* benefit that, absent a benefit-realization mechanism, is never actually checked.

### 3.2 The Benefit Realization Plan — required artifact, not optional appendix

**PROPOSED** minimum structure, directly generated from the Value Cases defined pre-build (Section 2), now converted into a live tracking object:

```yaml
benefit_realization_plan:
  process_id: proc-p2p-invoice-approval
  value_case_ref: value_case.proc-p2p-invoice-approval
  review_cadence: monthly    # weekly for first 90 days, then monthly to month 12
  dashboards:
    - name: "AP Cycle Time"
      query: "avg(gl_posting.posted_at - invoice.created_at) group by month"
      owner: "AP Manager — J. Ruiz"
  checkpoints:
    - at: T+30d,  expect: "cycle_time <= 10 days (interim)"
    - at: T+90d,  expect: "cycle_time <= 5 days"
    - at: T+180d, expect: "cycle_time <= 3 days (target met)"
    - at: T+365d, expect: "sustained at target; re-baseline if process changed"
  status_states: [ON_TRACK, AT_RISK, MISSED, ESCALATED, REALIZED]
  escalation_rule: "2 consecutive AT_RISK/MISSED checkpoints -> escalate to steering committee with root-cause + remediation plan"
```

The review rhythm matters as much as the metric itself: monthly or quarterly executive reviews of system usage, process efficiency, and alignment to the original business objectives are the governance mechanism that keeps benefit tracking alive after the project team is gone [Prosci 2025, "Governing ERP Benefits Beyond Go-Live"]. **This checkpoint schedule, minimum 12 months post go-live, is a non-negotiable deliverable of the build OS**, not a stretch goal contingent on someone remembering to ask for it.

### 3.3 What to actually measure — a defaults table

The build OS should ship a default KPI taxonomy (derived from TechTarget's 12-KPI framework, mapped to the four categories Panorama/Prosci both converge on) so teams aren't inventing metrics from scratch:

| Category | Example default metrics | Source-of-truth query pattern |
|---|---|---|
| Financial | ROI = (Value − Cost)/Cost; reduced operating expense; DSO/DPO change | ERP GL + AP/AR aging, compared to pre-implementation baseline export |
| Operational efficiency | Cycle time (order-to-cash, procure-to-pay, invoice-to-post); inventory turnover; year-end close duration | Timestamp diffs between lifecycle events in the ledger/workflow tables |
| Data & process quality | Data entry error rate; % touchless transactions (STP rate); exception/manual-override rate | Validation failure logs; workflow exception queue counts |
| Adoption & experience | Active users per module; user satisfaction score; support ticket volume/type | Auth/session logs; helpdesk ticket tags; periodic pulse survey |

[TechTarget, "12 ERP KPIs for post-implementation success," 2025]

Financial ROI in particular should be reported with an honest time horizon, not gamed to look good at month 3: **"ROI increases over time — some companies see the biggest return within five to ten years"** [Panorama Consulting, "ERP System Go-live: How To Measure ROI & Benefits Realization"]. The build OS's dashboard should therefore show a trend line against the target curve, not a single point-in-time pass/fail, so a legitimately slow-burn benefit isn't misclassified as a failure at the 90-day checkpoint.

---

## 4. How the build OS enforces this — the proposed gate design

This is the section that turns the above from advice into a structural constraint the build loop cannot route around.

### 4.1 Gate placement in the pipeline

```
 INTERVIEW/DECISION PHASE                         BUILD LOOP                          POST-GO-LIVE
┌──────────────────────────┐   ┌──────┐   ┌─────────────────────────┐   ┌──────┐   ┌───────────────────────┐
│ G0: Process Discovery     │──▶│ GATE │──▶│ Feature backlog opens   │──▶│ ship │──▶│ Benefit Realization    │
│  - AS-IS BPMN map         │   │  P1  │   │  only for process_ids   │   └──────┘   │  Tracking (min. 12 mo) │
│  - Fit/deviation decision │   └──────┘   │  with gate_status=LOCKED│              │  - monthly checkpoints │
│  - Value Case (baseline,  │              │  on their Value Case    │              │  - escalation on 2x    │
│    target, owner)         │              └─────────────────────────┘              │    AT_RISK/MISSED      │
└──────────────────────────┘                                                        └───────────────────────┘
```

### 4.2 Gate P1 — hard pass/fail criteria (PROPOSED, machine-checkable)

A process area is **LOCKED** (feature tickets may reference it) only if all of the following are true; the build OS's decision schema should encode this as a literal validator, not a checklist a human eyeballs:

1. `process.bpmn_file` exists and is valid BPMN 2.0 XML (parseable, has at least one start/end event) for both AS-IS and TO-BE.
2. `process.fit_decision` is one of `fit_to_standard` or `justified_deviation`; if the latter, `process.deviation_justification` is non-empty and references a quantified cost/value comparison.
3. `value_case.baseline.value` is a number with a `source` field that is not `"estimated"` or `"anecdotal"` (i.e., must trace to a real query/report/export) — self-reported guesses fail the gate.
4. `value_case.target.value`, `value_case.target.by_date`, and `value_case.owner` (a named individual, not a department) are all populated.
5. `value_case` scoring rubric (Section 2.3) totals ≥ 7/12, OR an explicit `executive_override` record exists with a named approver and a written reason.
6. `benefit_realization_plan.checkpoints` exists with at minimum the T+30/90/180/365 structure and a `dashboards` entry with a runnable query, not a manual-only method.

If any check fails, the decision engine returns `gate_status: BLOCKED` and the build loop's ticket-creation tool refuses to open a feature ticket tagged to that `process_id` — this should be a literal code-level check in whatever tracker/orchestrator the build OS uses (e.g., a pre-commit-style hook on the backlog schema, or a CI check on the decision-record repo), not a policy documented in a wiki that people route around under deadline pressure. The mechanism is the same shape as the repo's existing decision-key gates (`security.*`, `ai_capability.*` locking at G1) — **process/value gating belongs in that same locked-decision-record system**, not a separate governance process.

### 4.3 Post-go-live enforcement

The same mechanism runs in reverse after launch: a `benefit_realization_plan` with two consecutive `AT_RISK` or `MISSED` checkpoint evaluations auto-generates an escalation record requiring a named remediation owner and a revised plan within a fixed window (**PROPOSED: 15 business days**) — mirroring Prosci's finding that ongoing governance rhythm, not one-time measurement, is what separates orgs that actually capture benefit from orgs that "declared victory" at go-live and moved on [Prosci 2025]. Escalations that go three checkpoints without remediation should be visible on the same steering-committee dashboard used for security/architecture escalations — benefit shortfall is a program risk of the same order as a security finding, and should be triaged with the same seriousness, not relegated to a separate "business side" conversation nobody in engineering ever sees.

### 4.4 What this deliberately does NOT allow

- **No "we'll define the metrics after go-live."** The gate is pre-build. A Value Case created retroactively at go-live has no real baseline (the old system's data is now stale or the process already changed) and is functionally useless for measuring delta.
- **No process mapping performed only by IT.** The BPMN AS-IS/TO-BE session must include the actual process owner and front-line users, mirroring SAP Activate's workshop model — an architect describing what they assume the AP team does is not a process map, it's a guess with a diagram around it.
- **No feature justified purely by "the vendor's other customers wanted this."** Every deviation from standard requires the specific org's quantified value case, per the fit-to-standard vs fit-to-process test in Section 1.2.

---

## 5. Summary table — defaults this playbook locks in

| Decision | Default | Rationale |
|---|---|---|
| Process mapping notation | BPMN 2.0 XML (`.bpmn` files, bpmn-js/Camunda-compatible) | Industry standard, dual-readable by business + machine-executable [OMG BPMN 2.0.2; Camunda] |
| Default posture on gaps | Fit-to-standard; deviation requires written, quantified justification | SAP Activate F2S principle, generalized [SAP Help 2025] |
| Feature-build gate | Blocked until `process_id` has BPMN map + scored Value Case ≥7/12 (or exec override) | Directly targets Prosci's "bad metrics worse than none" finding [Prosci 2025] |
| Benefit tracking horizon | Minimum 12 months post go-live, checkpoints at T+30/90/180/365 | ROI materializes over years, not weeks [Panorama 2025] |
| Escalation trigger | 2 consecutive AT_RISK/MISSED checkpoints → mandatory remediation plan in 15 business days | Governance rhythm is the actual predictor of realized benefit [Prosci 2025] |
| Verification mechanism post-launch | Process mining (Celonis/SAP Signavio or equivalent) comparing actual event logs to the TO-BE BPMN map | Closes the interview-vs-reality gap; proven at scale (J&J, Accenture) [mybusinessfuture 2026] |

---

## Sources

- Gartner ERP failure statistics (>70% fail to meet business case by 2027, 25% catastrophic; ~75% strategy misalignment; cost overruns 189%/215%), via Godlan — "ERP Implementation Failure Statistics: 2025 Research": https://godlan.com/erp-implementation-failure-statistics/
- Prosci — "From Promised ROI to Delivered ROI: Governing ERP Benefits Beyond Go-Live" (2025 Unlocking ERP Implementations study — metrics maturity 28% vs 7% vs 26% no-metrics; human factors 6x technical; 11-31% "fail to deliver 70% of expected benefit" range): https://www.prosci.com/blog/governing-erp-benefits-beyond-go-live
- Prosci — "Why Do ERP Implementations Fail?": https://www.prosci.com/blog/why-do-erp-implementations-fail
- Panorama Consulting — "ERP System Go-live: How To Measure ROI & Benefits Realization" (ROI formula, cost/benefit categories, 5-10yr ROI horizon): https://www.panorama-consulting.com/erp-benefits-realization/
- Panorama Consulting — "What Not To Do When Customizing ERP Software" (cow-path warning): https://www.panorama-consulting.com/customizing-erp-software-dont-pave-the-cow-path/
- Panorama Consulting — 2026 ERP Report (data foundations/governance as top failure cause): https://www.panorama-consulting.com/resource-center/erp-report/
- SAP Community — "SAP Activate – Explore Phase: Use Fit-to-Standard to confirm business process fit and identify gaps": https://community.sap.com/t5/enterprise-resource-planning-blog-posts-by-sap/sap-activate-explore-phase-use-fit-to-standard-to-confirm-business-process/ba-p/13331140
- SAP Community — "Fit-To-Standard process in Activate Methodology": https://community.sap.com/t5/enterprise-resource-planning-blog-posts-by-sap/fit-to-standard-process-in-activate-methodology/ba-p/13576452
- SAP Help — "Value Accelerators in a Fit-to-Standard Scenario" (2025-08-22): https://help.sap.com/doc/d20e44eaf2424f7992b0b86a50535841/SHIP/en-US/3a62c38a0e9146b795faf9ad7f0c6511_EN_1.pdf
- Consulting Solutions — "SAP Activate Blog Series, Post 3: Explore Phase – Fit-to-Standard Workshops" (2025-05-29): https://www.consultingsolutions.com/2025/05/29/sap-activate-blog-series-post-3-explore-phase-fit-to-standard-workshops/
- Protiviti — "Fit-to-Standard vs. Customization in SAP S/4HANA: How to Decide What's Right" (2025-12-02, cost/timeline comparison): https://tcblog.protiviti.com/2025/12/02/fit-to-standard-vs-customization-in-sap-s-4hana-how-to-decide-whats-right/
- OMG — BPMN 2.0.2 specification (current version, published Jan 2014, ISO 19510): https://www.omg.org/spec/BPMN/2.0.2/About-BPMN
- Camunda — BPMN primer, Camunda 8 docs: https://docs.camunda.io/docs/components/modeler/bpmn/bpmn-primer/
- bpmn.io — bpmn-js toolkit (open-source BPMN 2.0 rendering/modeling): https://bpmn.io/toolkit/bpmn-js/
- mybusinessfuture — "Mid-Market Process Mining 2026: Celonis, SAP Signavio, and UiPath in Action" (J&J 30%/40%, Accenture 75% procurement cycle time reduction): https://mybusinessfuture.com/en/mid-market-process-mining-2026-celonis-sap-signavio-and/
- SAP Community — "SAP Signavio February 2026 Release: Process Insights and Intelligence" (Datasphere continuous extraction): https://community.sap.com/t5/technology-blog-posts-by-sap/sap-signavio-february-2026-release-sap-signavio-process-insights-and/ba-p/14325159
- TechTarget — "12 ERP KPIs for post-implementation success": https://www.techtarget.com/searcherp/tip/ERP-KPIs-for-post-implementation-success
- APMG International — "Managing Benefits™ Certification" (benefits identify/execute/sustain lifecycle): https://apmg-international.com/product/managing-benefits
- UK Government Project Delivery — "Teal Book, Chapter 19: Benefits management" (Benefits Register, Benefits Realisation Plan as mandatory artifacts): https://projectdelivery.gov.uk/teal-book/home/part-e-planning-and-control/chapter-19-benefits-management/
- Repo cross-refs (assumed): the ERP build OS's locked-decision-record system (`security.*`, `ai_capability.*` gating pattern in AR6-ai-native-operation.md) as the mechanism `process.*` / `value_case.*` gating should reuse.
