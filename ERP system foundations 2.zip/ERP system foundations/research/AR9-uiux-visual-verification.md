# AR9 — UI/UX Excellence + Visual Verification (Enforced)

**Doctrine for the ERP Build OS. Date: 2026-07-07.**

> Thesis: A functionally correct ERP with mediocre UI is a *failed* ERP. Its value is invisible to the CFO, the AP clerk, and the auditor who actually decide adoption. And an AI builder that never *looks* at the screen it generated is shipping blind. This track sets a high enterprise-UX bar **and** makes "the model must SEE and DRIVE its own UI" an enforced build gate — not a code-review nicety.

---

## 1. Enterprise ERP UX Excellence — "functions" ≠ "usable"

An ERP screen is not a marketing page. It is a **data-dense workbench** an expert operator lives in 8 hours a day. The bar is set by tools like Linear, Retool, Ramp, and modern SAP Fiori/Horizon — not by generic SaaS dashboards. The failure mode of AI-generated ERP UIs is predictable: a naive `<table>` dump, no empty states, no keyboard support, no bulk actions, modal soup, and a "works on my 500-row seed" grid that dies at 100k rows.

### The non-negotiable pattern library

| Pattern | "Functions" (reject) | "Usable/delightful" (the DEFAULT bar) |
|---|---|---|
| **Data grid** | `<table>` renders all rows | Virtualized rows (TanStack Virtual / AG Grid), sticky header + first column freeze, resizable/reorderable columns, per-column sort + filter, inline (Excel-like) edit, right-aligned numerics with tabular figures, zebra or hairline rows |
| **Master–detail** | separate page per record | Split view / drawer detail; list stays as context; deep-link URL per record; back preserves scroll + filters |
| **Bulk actions** | one row at a time | Row checkboxes (reveal on hover), "select all matching filter (N)", sticky action bar appears only when ≥1 selected, optimistic apply + undo toast |
| **Saved views** | filters reset on reload | Named, shareable, per-user + per-team views encoded in the URL/querystring; "unsaved changes" affordance; default view per role |
| **Keyboard-first** | mouse only | `j/k` row nav, `x` select, `/` focus search, `Enter` open, `e` edit, `Esc` close; visible focus ring; full tab order |
| **Command palette** | buried nav menus | `Cmd/Ctrl-K` global palette: jump to any object, run any action, switch company/period — the power-user's ERP transaction-code (`/nXXXX`) reborn |
| **Approvals inbox** | scattered per-module queues | One unified inbox: what needs *me*, grouped by SLA/age, approve/reject inline with reason, keyboard-drivable, bulk-approve with guardrails |
| **Progressive disclosure** | 60-field form wall | Show the 8 fields that matter; "Advanced" / "More" reveals the rest; defaults pre-filled; dependent fields appear on demand |
| **Empty / loading / error** | blank white screen | Empty = onboarding CTA + example; Loading = skeleton rows (not spinner); Error = cause + retry + support ref; **partial** = show what loaded |
| **Responsive** | desktop-only | Grid degrades to card/stacked list on narrow; primary actions never hidden below the fold; touch targets ≥ 44px |
| **Theme** | light only | System-driven dark/light via CSS custom properties + `prefers-color-scheme`; charts/status colors re-map, not just invert |

### Why this drives adoption AND perceived value
- **Adoption is a UX function, not a feature-count function.** Friction (extra clicks, cognitive load, dead-ends) is the #1 reason ERP rollouts stall; enterprise UX is fundamentally about *removing workflow friction* — mapping the UI to how the clerk actually works, not to your data model ([Onething](https://www.onething.design/post/top-7-enterprise-ux-design-patterns), [Tenet](https://www.wearetenet.com/blog/enterprise-ux-design)).
- **Perceived value is visual.** The non-technical stakeholder cannot read your event-sourced ledger or your RLS policies. They judge the entire system by the polish of the screen in the demo. A clean approvals inbox *is* the ROI story to them.
- **Data-dense done well is a competitive moat.** In 2026 a grid is expected to virtualize large datasets, support real-time updates, and offer Excel-like edit/filter while staying performant ([Telerik](https://www.telerik.com/blogs/best-practices-creating-user-friendly-data-grids), [Medium/Grid 2026](https://medium.com/@vishal.p_95435/choosing-the-right-javascript-grid-for-enterprise-applications-in-2026-9f72fdbbcde2)). This is the hardest thing to fake and the thing users notice first.

**DEFAULT stance:** every list surface is a real grid with virtualization, saved views, bulk actions, and keyboard nav from day one. Every screen ships all four states (empty/loading/error/partial). No exceptions — these are acceptance criteria, not enhancements.

---

## 2. The Visual Verification Loop — the model must SEE and DRIVE

The core doctrine: **an AI builder may not claim a UI works until it has rendered it, screenshotted it, looked at the pixels with its own multimodal vision, driven the flow as a user, and diffed against a baseline.** "It compiles / the test is green" is *not* evidence the UI is usable or even visible.

### The loop (five stages, enforced in order)

```
        ┌─────────────────────────────────────────────────────┐
        │  BUILD  →  RENDER  →  SEE  →  DRIVE  →  DIFF  →  SCORE │
        └─────────────────────────────────────────────────────┘
```

1. **RENDER** — start the app; navigate to the built route via Playwright / Playwright MCP.
2. **SEE (multimodal self-review)** — `browser_take_screenshot` (use `scale:"device"` for Retina-accurate pixels — added in playwright-mcp June 2026, PR #41465), then the model *loads the image back into its own context* and grades it against the design system + the §5 rubric. This is the step that makes "shipped a UI I never looked at" impossible: the screenshot is fed back to the vision model, not just saved to disk.
3. **DRIVE** — exercise the real user flow: `browser_snapshot` (accessibility tree, ~2–5 KB, 20–50× cheaper than a screenshot — use it for *acting*, screenshots for *judging*), then `browser_click` / `browser_fill_form` / `browser_type` / `browser_press_key` through the happy path AND one error path. Confirm empty/loading/error states actually appear.
4. **DIFF** — `expect(page).toHaveScreenshot()` against the committed baseline; fail on unexpected pixel drift.
5. **SCORE** — emit the §5 Design-QA rubric score; below threshold blocks the phase.

> **Screenshot vs. snapshot — use both, deliberately.** The a11y snapshot is the agent's *hands* (cheap, structured, stable selectors for driving). The screenshot is the agent's *eyes* (expensive, pixel-truth, the only thing that catches "white text on white", overlap, clipped tables, broken dark mode). An agent that only uses snapshots is blind; one that only screenshots is slow and burns tokens. ([Playwright MCP](https://github.com/microsoft/playwright-mcp), [Bug0 hi-res](https://bug0.com/blog/playwright-mcp-hires-screenshots-ai-test-agents-2026))

### Why the "SEE" step is the whole point
A visual regression diff catches *changes* from a known-good baseline — but the *first* baseline could itself be broken. Only a multimodal look ("does this table have visible headers? is any text invisible? is the primary button reachable?") catches a UI that is broken-but-stable. The gate therefore requires **both**: subjective multimodal review (catches new/first-time breakage) *and* objective pixel diff (catches regressions).

---

## 3. Tooling — the 2026 concrete stack

| Layer | Tool | Role in the loop | Notes (2026) |
|---|---|---|---|
| E2E driver | **Playwright Test** (`@playwright/test`) | RENDER + DRIVE + DIFF | Auto-wait, trace viewer, component testing, cross-browser. `toHaveScreenshot()` waits for network-idle + no CSS animation + no JS before capture, then diffs via `pixelmatch` ([docs](https://playwright.dev/docs/test-snapshots)) |
| Agent browser | **Playwright MCP** (v0.0.77, Jun 2026) | RENDER + SEE + DRIVE | Exposes `browser_navigate`, `browser_snapshot`, `browser_take_screenshot`, `browser_click`, `browser_fill_form`, `browser_type`, `browser_press_key`, `browser_console_messages`, `browser_network_requests`. Lets the *agent* observe and act live ([repo](https://github.com/microsoft/playwright-mcp)) |
| Agent browser (alt) | **Chrome DevTools MCP** | perf traces, console, network | Complements Playwright MCP for CWV/console debugging ([agentskillshub](https://agentskillshub.dev/scenarios/mcp-browser-automation/)) |
| Visual regression | **Playwright native snapshots** (DEFAULT) | DIFF | Free, zero-dep, local, ~200–500 ms/assert, baselines in `*-snapshots/` keyed by browser+platform (e.g. `-chromium-darwin.png`) |
| Visual regression (hosted, optional) | **Chromatic** or **Percy** | DIFF + human review | Add only when you need hosted approval UI / cross-env review. Chromatic is Storybook-first, ~2–5% false-positive on dynamic content; Percy is CI-first, ~8–15%. Both ~5k free snapshots/mo; Chromatic paid from ~$179/mo ([Delta-QA](https://delta-qa.com/en/blog/chromatic-vs-percy-comparison-2026/), [Bug0 VRT](https://bug0.com/knowledge-base/visual-regression-testing-tools)) |
| Accessibility | **@axe-core/playwright** | SCORE gate | `AxeBuilder` runs axe-core in-page; catches ~57% of WCAG issues by volume ([Deque/TestDino](https://testdino.com/blog/playwright-accessibility)). Target **WCAG 2.2 AA** (tags `wcag2a,wcag2aa,wcag21a,wcag21aa,wcag22aa`) |
| Accessibility (audit) | **Lighthouse a11y** / **Pa11y** | secondary SCORE | Broad audit; not a substitute for axe assertions |
| Performance | **Lighthouse CI** + **Core Web Vitals** | SCORE gate | 2026 "good": **LCP < 2.5 s, INP < 200 ms, CLS < 0.1** at p75 ([corewebvitals.io](https://www.corewebvitals.io/core-web-vitals)). INP is the most-failed vital in 2026 — data grids are the usual culprit |

### Visual regression: native vs. hosted — the opinionated call
**DEFAULT = Playwright native `toHaveScreenshot()`.** It lives beside functional tests, is free, runs locally in CI, and needs no account. Reach for Chromatic/Percy **only** when (a) a design team needs a hosted human approval workflow, or (b) you have a Storybook-driven design system and want component-level coverage (Chromatic). Do not adopt a paid visual service before you have native snapshots green in CI — that's premature.

### Key config sketches

**`playwright.config.ts`** — deterministic snapshots (kill flake before it starts):

```ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  expect: {
    toHaveScreenshot: {
      maxDiffPixelRatio: 0.01,   // ≤1% drift tolerated
      animations: 'disabled',    // freeze CSS animations
      caret: 'hide',             // no blinking text caret
      scale: 'css',
    },
  },
  use: {
    colorScheme: 'light',        // pin theme; run a second project for dark
    timezoneId: 'UTC',           // determinism for date-heavy ERP grids
    locale: 'en-US',
  },
  projects: [
    { name: 'light', use: { colorScheme: 'light' } },
    { name: 'dark',  use: { colorScheme: 'dark'  } },
  ],
});
```

**Visual + a11y in one spec** — mask volatile ERP data (timestamps, running balances, doc numbers) so diffs are stable:

```ts
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('invoices grid — visual + a11y + interaction', async ({ page }) => {
  await page.goto('/ap/invoices?view=needs-approval');
  await expect(page.getByRole('grid')).toBeVisible();

  // DRIVE: real flow — filter, bulk-select, open detail
  await page.getByPlaceholder('Search').fill('vendor:acme');
  await page.getByRole('row').nth(1).getByRole('checkbox').check();
  await expect(page.getByRole('toolbar', { name: 'Bulk actions' })).toBeVisible();

  // DIFF: baseline, masking volatile columns
  await expect(page).toHaveScreenshot('invoices-needs-approval.png', {
    mask: [page.locator('[data-col="posted_at"], [data-col="balance"]')],
  });

  // SCORE: WCAG 2.2 AA, zero violations gate
  const a11y = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'])
    .analyze();
  expect(a11y.violations, JSON.stringify(a11y.violations, null, 2)).toEqual([]);
});
```

---

## 4. Wiring it into the Build OS

### 4a. New build-loop UI stage
Insert a mandatory **UI verification stage** into the build loop for any phase that touches a rendered surface. The stage runs *after* code+unit-test and *before* the phase can be marked done:

```
build → typecheck/unit → [UI STAGE] → design-QA review → commit
                              │
   ┌──────────────────────────┴───────────────────────────┐
   │ 1. render app + navigate (Playwright MCP)             │
   │ 2. screenshot → model LOADS IMAGE BACK → grades §5     │  ← the "SEE" gate
   │ 3. drive happy path + 1 error path (assert 4 states)   │
   │ 4. axe-core WCAG 2.2 AA  → 0 violations                │
   │ 5. toHaveScreenshot vs baseline → no unexpected diff   │
   │ 6. Lighthouse: LCP<2.5s, INP<200ms, CLS<0.1            │
   │ 7. emit rubric score ≥ threshold                       │
   └────────────────────────────────────────────────────────┘
```

The orchestrator MUST require the screenshot artifact **and** the model's written multimodal assessment of it in the phase output. A phase whose output lacks a looked-at screenshot is auto-rejected. This is the mechanism that makes "ship a UI I never saw" structurally impossible.

### 4b. New `verify-phase.sh` gates for UI phases

```bash
#!/usr/bin/env bash
# verify-phase.sh — UI phase gates. Any non-zero exit BLOCKS the phase.
set -euo pipefail
PHASE_KIND="${1:?ui|api|data}"
[[ "$PHASE_KIND" != "ui" ]] && { echo "non-ui phase, skipping visual gates"; exit 0; }

echo "▶ E2E + interaction (happy + error paths)"
npx playwright test --project=light --project=dark --grep @ui

echo "▶ Visual regression vs baseline"
# fails on unexpected pixel drift; baselines are committed & reviewed
npx playwright test --grep @visual   # do NOT pass --update-snapshots in CI

echo "▶ Accessibility (WCAG 2.2 AA, zero violations)"
npx playwright test --grep @a11y

echo "▶ Performance budget (LCP<2.5s INP<200ms CLS<0.1, a11y≥0.95)"
npx lhci autorun \
  --assert.assertions.categories:accessibility=0.95 \
  --assert.assertions.largest-contentful-paint=2500 \
  --assert.assertions.cumulative-layout-shift=0.1

echo "▶ Design-QA rubric score (agent self-grade, artifact required)"
node scripts/design-qa-score.mjs --min 85 --require-screenshot

echo "✅ UI phase gates passed"
```

**Baseline governance:** snapshot PNGs live in-repo under `*-snapshots/`, are code-reviewed like source, and are updated **only** via an explicit `--update-snapshots` run by a human/reviewer with the diff attached — never auto-updated in CI (that would let a regression silently become the new "truth").

### 4c. CI wiring notes
- Pin the Playwright container image (`mcr.microsoft.com/playwright:vX-jammy`) so font rendering is byte-stable across dev and CI — font hinting differences are the #1 source of false-positive diffs.
- Run visual + a11y as **required** status checks. A red visual diff blocks merge until either the code is fixed or the baseline is explicitly, reviewably updated.
- Store trace-viewer traces + screenshots as CI artifacts for every failure so the diff is inspectable.

---

## 5. Design-QA Rubric (agent self-scores its own UI)

The agent grades the screenshot it just captured against this rubric, in writing, before the phase closes. **Pass = ≥ 85/100 AND no category scoring 0.** A zero in any category is an automatic block regardless of total.

| # | Category | Wt | 0 (block) | 3 | 5 (target) |
|---|---|---|---|---|---|
| 1 | **Visibility & legibility** | 15 | invisible/low-contrast text, overlap, clipped grid | minor contrast issues | all text ≥ 4.5:1, nothing clipped, tabular numerics aligned |
| 2 | **Data grid quality** | 15 | plain dump, no sort/filter | sortable, static | virtualized, sticky header, resize, filter, inline-edit |
| 3 | **State coverage** | 12 | missing empty/error | some states | empty + loading(skeleton) + error + partial all present |
| 4 | **Keyboard & command palette** | 10 | mouse-only | tab order OK | full kbd nav + `Cmd-K` palette + visible focus ring |
| 5 | **Bulk actions & saved views** | 10 | none | bulk only | bulk + "select all matching" + named URL-encoded views |
| 6 | **Accessibility (axe/WCAG 2.2 AA)** | 12 | axe violations > 0 | minor warns | 0 violations, roles/labels/landmarks correct |
| 7 | **Consistency w/ design system** | 8 | off-system colors/spacing | mostly on | tokens only; spacing/typography scale honored |
| 8 | **Responsive & dark/light** | 8 | breaks on narrow or in dark | one theme solid | both themes + card degrade, targets ≥44px |
| 9 | **Performance (CWV)** | 6 | INP>200 or LCP>2.5s | borderline | LCP<2.5s, INP<200ms, CLS<0.1 |
| 10 | **Feedback & error affordance** | 4 | silent failures | toasts | optimistic + undo, actionable errors w/ ref |

The agent must cite *evidence from the screenshot/trace* per row (e.g. "row 1: header sticky visible in screenshot at y=64; contrast on status pill = 5.1:1"). Scores asserted without visual evidence are treated as 0.

---

## Recommended DEFAULT (adopt this)

- **UI framework/grid:** React + a virtualization-first grid (TanStack Table/Virtual for control, AG Grid Enterprise where Excel-parity is required). Design tokens via CSS custom properties; dark/light from `prefers-color-scheme`.
- **Verification stack:** **Playwright Test** (E2E + component + native `toHaveScreenshot` visual regression) as the spine; **Playwright MCP** so the agent renders/sees/drives live; **@axe-core/playwright** for WCAG 2.2 AA; **Lighthouse CI** for Core Web Vitals. Add **Chromatic/Percy only** for hosted human approval or Storybook design-system coverage — not before native snapshots are green.
- **The enforced gate:** Every UI phase must produce (1) a device-scale screenshot, (2) the model's written multimodal review of that screenshot against the §5 rubric, (3) a green E2E interaction run exercising happy + error paths and all four states, (4) zero axe violations, (5) a clean visual diff vs. reviewed baseline, (6) CWV within budget. Missing the screenshot-plus-assessment artifact = automatic phase rejection.

**Bottom line for the AI builder:** you have not built the UI until you have looked at it. Render it, screenshot it, read the pixels back into your own eyes, drive it like the AP clerk will, and diff it against the baseline. Green unit tests are not permission to ship a screen you never saw.

---

## Sources
- Playwright — Visual comparisons (`toHaveScreenshot`): https://playwright.dev/docs/test-snapshots
- Playwright — Snapshot assertions API: https://playwright.dev/docs/api/class-snapshotassertions
- Playwright — Accessibility testing: https://playwright.dev/docs/accessibility-testing
- Playwright MCP (repo, v0.0.77): https://github.com/microsoft/playwright-mcp
- Playwright MCP introduction: https://playwright.dev/mcp/introduction
- Bug0 — Playwright MCP hi-res screenshots for AI test agents (2026): https://bug0.com/blog/playwright-mcp-hires-screenshots-ai-test-agents-2026
- Bug0 — Best visual regression testing tools 2026: https://bug0.com/knowledge-base/visual-regression-testing-tools
- Delta-QA — Percy vs Chromatic 2026 (pricing): https://delta-qa.com/en/blog/chromatic-vs-percy-comparison-2026/
- TestDino — Playwright accessibility testing: https://testdino.com/blog/playwright-accessibility
- QAMadness — axe-core Playwright guide: https://www.qamadness.com/a-you-oriented-guide-to-axe-core-playwright-accessibility-testing/
- corewebvitals.io — LCP/INP/CLS thresholds (2026): https://www.corewebvitals.io/core-web-vitals
- web.dev — Defining Core Web Vitals thresholds: https://web.dev/articles/defining-core-web-vitals-thresholds
- Telerik — Best practices for user-friendly data grids: https://www.telerik.com/blogs/best-practices-creating-user-friendly-data-grids
- Pencil & Paper — Enterprise data tables UX patterns: https://www.pencilandpaper.io/articles/ux-pattern-analysis-enterprise-data-tables
- Stéphanie Walter — Designing complex data tables: https://stephaniewalter.design/blog/essential-resources-design-complex-data-tables/
- Onething — Enterprise UX design patterns: https://www.onething.design/post/top-7-enterprise-ux-design-patterns
- We Are Tenet — Enterprise UX design 2026: https://www.wearetenet.com/blog/enterprise-ux-design
- Medium — Choosing the right JS grid for enterprise (2026): https://medium.com/@vishal.p_95435/choosing-the-right-javascript-grid-for-enterprise-applications-in-2026-9f72fdbbcde2
- agentskillshub — MCP browser automation (Chrome DevTools & Playwright) 2026: https://agentskillshub.dev/scenarios/mcp-browser-automation/
