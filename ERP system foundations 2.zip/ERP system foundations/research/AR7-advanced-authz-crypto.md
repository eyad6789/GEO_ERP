# AR7 — Frontier AuthZ, Cryptographic Audit Anchoring, and Spec-Driven Generation for ERP

*Research brief for the ERP Build Operating System playbook. Grounded in 2025–2026 primary sources; opinionated defaults marked **DEFAULT**.*

---

## 1. ReBAC for ERP Authorization

### 1.1 Why RBAC+ABAC breaks on the canonical ERP authz sentence

The test sentence every ERP authz model must pass:

> "This cost-center's manager can approve up to $X for these expense categories during open fiscal periods."

Decompose it: it needs (a) a **relationship** (manager-of this specific cost center, not "manager" as a global role), (b) a **hierarchy** (cost centers roll up, delegation chains, org-unit inheritance), (c) an **attribute condition** (dollar ceiling, category allow-list), and (d) a **temporal/state condition** (period must be open — not closed/soft-closed). Pure RBAC ("role=Approver") cannot scope to *this* cost center without exploding into one role per cost center × approval tier — the classic "role explosion" failure mode. Pure ABAC can express the dollar/category/period conditions but has no native way to answer graph questions like "which cost centers roll up to me" or "who can approve for this center including delegates while the primary is on leave" without re-deriving hierarchy in every policy.

**ReBAC (Relationship-Based Access Control)**, formalized by Google's Zanzibar paper and its 2025-refreshed IETF/RFC-adjacent spec work, models authorization as a directed graph of `object#relation@user` tuples and answers checks by graph traversal/set operations rather than rule evaluation. It natively subsumes RBAC (a role is just a relation) and layers ABAC on top via **conditions** — CEL-like expressions evaluated against tuple context — for exactly the "up to $X" and "during open periods" clauses (OpenFGA docs, openfga.dev/docs/authorization-concepts, 2026).

**DEFAULT: model ERP authz as ReBAC-with-conditions, not RBAC-with-overrides.** Roles alone are a permanently interim state for any ERP with more than ~3 approval tiers or matrixed org structures.

### 1.2 2026 tool state

| Tool | Model fidelity to Zanzibar | Storage | Notable 2025-2026 development | Best fit |
|---|---|---|---|---|
| **OpenFGA** (CNCF, backed by Auth0/Okta) | High — DSL + Conditions (CEL) + Contextual Tuples | Postgres/MySQL/SQLite | Conditions (ABAC hybrid) GA; used for Auth0 FGA product | Teams wanting broad SDK/language coverage, Auth0 integration, fastest onboarding |
| **SpiceDB** (AuthZed) | Highest — schema language closest to the original paper | Postgres/CockroachDB/Spanner/MySQL | **v1.36 "Relationship Integrity"**: cryptographically signs every relationship tuple with a key only SpiceDB holds; on read, signature is reverified and mismatches reject the whole load — protects against a DBA or attacker with raw datastore access silently editing grants (authzed.com/blog/spicedb-relationship-integrity, 2026). Also shipping a Query Planner and schema `use import`/`use partial` composition (2026). | Teams that need the strongest tamper-evidence story for permission data itself, not just app data |
| **Permify** | High — YAML schema, Zanzibar-inspired | Postgres | Acquired by **FusionAuth** in 2026; Community Edition stays open-source; up to ~1M req/s claimed, ~10ms checks (permify.co, 2026) | Teams wanting a visual playground + fast DX, or already adopting FusionAuth for authn |
| **Ory Keto** | Medium — Zanzibar-inspired, simpler | Postgres/MySQL/CRDB | Mature, less actively marketed for FGA-specific features vs. the above three | Teams already in the Ory ecosystem |

**DEFAULT: OpenFGA for the general case (fastest path to a working model, CNCF governance, strong SDK matrix); SpiceDB when the compliance/regulatory bar explicitly requires tamper-evident permission data** (financial services, SOX-heavy ERPs) — its Relationship Integrity feature is the only one of the three with a shipped, first-party answer to "what if the DBA edits the grants table directly." **(unverified as of 2026-07: exact GA status/version number of Relationship Integrity beyond the vendor blog — verify against the SpiceDB CHANGELOG before pinning a version in production configs.)**

### 1.3 Modeling ERP authz as a relation graph — concrete sketch

OpenFGA-style DSL for the target sentence:

```
model
  schema 1.1

type user

type cost_center
  relations
    define parent: [cost_center]
    define manager: [user] or manager from parent
    define delegate: [user]
    define approver: manager or delegate

type expense_category
  relations
    define allowed_for: [cost_center]

type approval_request
  relations
    define cost_center: [cost_center]
    define category: [expense_category]
  condition within_limit_and_open_period(amount: double, period_status: string, ceiling: double) {
    amount <= ceiling && period_status == "open"
  }
  relations
    define can_approve: approver from cost_center with within_limit_and_open_period
```

Tuple + contextual-tuple pattern at check time:

```jsonc
// stored relationship tuples (written once, rarely change)
{"object":"cost_center:CC-4410","relation":"manager","user":"user:priya"}
{"object":"cost_center:CC-4410","relation":"parent","user":"cost_center:CC-4400"} // rollup

// contextual tuple + condition context supplied PER-REQUEST (not stored)
{
  "object": "approval_request:REQ-9931",
  "relation": "can_approve",
  "user": "user:priya",
  "context": { "amount": 4200.00, "period_status": "open", "ceiling": 5000.00 }
}
```

This is exactly the pattern OpenFGA's own docs recommend for "maximum amount for a bank transfer" as a canonical Conditions example (openfga.dev/docs/modeling/conditions, openfga.dev/blog/conditional-tuples-announcement, 2026) — the ERP approval-limit case is a direct structural analog, not a stretch.

**Delegation and "who can approve while I'm out"**: model `delegate` as its own relation with a validity-window condition; `approver` becomes `manager or delegate`, so revocation/expiry is a single tuple write, not an application-code branch. **DEFAULT: never encode approval-limit numbers in application code or a role table — always as condition parameters resolved from the cost-center/category master data at check time**, so a finance re-org (new ceiling, re-parented cost center) is a data change, not a deploy.

### 1.4 When ReBAC is overkill

If the ERP is single-tenant, has ≤3 static roles, and never needs hierarchy-aware checks (rare for real ERPs, common for point-solution add-ons), plain RBAC in the app's own tables is still cheaper to operate — don't stand up a Zanzibar-style service for a expense-report micro-tool. The break-even is roughly: **the moment you need "who can access this AND everything under it in the org tree" or "up to $X" as a first-class query, ReBAC pays for itself.**

### 1.5 AI-agent angle (2026-relevant)

AuthZed shipped **SpiceBox / spicedb-dev** and a `langchain-spicedb` integration specifically to give AI coding agents and LangChain/LangGraph agent workflows enforced, relationship-scoped permissions rather than ambient trust (authzed.com/blog/spicedb-dev-and-spicebox..., 2026) — relevant if the ERP build itself includes agentic automation (e.g., an AP-matching agent) that needs the same authz graph the human UI enforces, not a parallel shadow permission system.

---

## 2. Cryptographic Audit Anchoring

### 2.1 The threat model this section defends against

A hash-chained audit log (each row includes `hash(row_n) = H(row_n_data || hash(row_n-1))`) proves *internal* consistency — no row was altered without breaking the chain from that point forward. It does **not** prove the chain wasn't *entirely regenerated* by someone with full DB access (a compromised or malicious DBA, a cloud provider insider, a court-ordered tamper). The chain lives in the same trust domain as the data it's supposed to protect. **The fix is anchoring: periodically publish a commitment to the chain's current state somewhere the DBA cannot rewrite.**

### 2.2 The three building blocks

**(a) Merkle transparency logs — RFC 9162 (Certificate Transparency v2.0).** CT logs are append-only Merkle trees where each entry addition can be proven via an **inclusion proof** (this entry is in the tree) and later states proven via a **consistency proof** (this newer tree is a superset of that older tree) — so a log operator cannot silently delete or reorder history without a verifier detecting it (rfc-editor.org/rfc9162, IETF). RFC 9162 is the certificate-specific instantiation, but the *mechanism* — Merkle inclusion/consistency proofs over an append-only log, periodically signed — is domain-agnostic and is exactly what you want for an audit log.

**(b) A generic transparency-log implementation: Sigstore Rekor / Trillian-Tessera.** Rekor is a public, Merkle-tree-backed transparency log originally built for software supply-chain attestations (signatures, SBOMs), explicitly designed to be extensible to arbitrary "entry types" beyond certificates (docs.sigstore.dev/logging/overview, chainguard.dev). **Rekor v2 went GA in October 2025**, rebuilt on **Trillian-Tessera**, a tile-based transparency-log backend, which is the actively-maintained successor to the original Trillian project used for Certificate Transparency itself (sigstore.dev, 2025). This is the most credible **off-the-shelf, run-yourself-or-use-public-instance** building block for anchoring an ERP audit chain: periodically submit `merkle_root(audit_log_segment)` as a Rekor entry and retain the inclusion proof + signed tree head.

**(c) Trusted timestamping — RFC 3161.** A Time-Stamping Authority (TSA) — a third party independent of the ERP operator — signs `(hash(data), time)` so the data's existence *before* that instant is provable without revealing the data (rfc-editor.org/rfc3161; metaspike.com, forensics context). TSAs are typically audited to eIDAS/WebTrust standards, giving RFC 3161 tokens legal-evidentiary weight in many jurisdictions independent of any blockchain. Free/low-cost public TSAs exist (e.g., FreeTSA) for non-critical anchoring; regulated deployments should use a commercial, audited TSA.

**(d) Notarization / external anchoring services.** **OpenTimestamps** is the pragmatic, vendor-neutral option: it batches many hashes into a single Bitcoin transaction via a Merkle tree, so the marginal cost of anchoring one more audit-log root approaches zero, and verification requires no ongoing relationship with any vendor — anyone can re-derive the proof against the public Bitcoin chain (opentimestamps.org). 2026 development: **"rolling timestamps"** (Simple Proof) continuously anchor streaming data rather than batch-anchoring, explicitly marketed for audit-log use cases (per 2026 vendor sources — **unverified as of 2026-07**, treat as directionally useful but confirm production maturity before depending on it). A notable real-world instance: El Salvador began timestamping official government documents on Bitcoin via OpenTimestamps in November 2025 — evidence the pattern is moving from crypto-niche to institutional use.

### 2.3 Why NOT to reach for a bespoke blockchain or AWS QLDB

**AWS discontinued QLDB**: support ended July 31, 2025, with a one-year shutdown clock on existing databases; AWS's own recommended migration path is Aurora PostgreSQL + application-level audit trails (pgAudit, Database Activity Streams) — i.e., **AWS itself no longer offers a managed immutable-ledger primitive** (InfoQ 2024; AWS Database Blog migration guide, 2025). This is a load-bearing fact for the playbook: **do not default to "use a managed ledger database"** as the anchoring mechanism — that category is contracting, not maturing, on the major hyperscalers. Open-source alternatives exist (immudb, Dolt, ScalarDL, Azure SQL Ledger) but each reintroduces the exact problem this section solves (trust concentrated in one operator's infra) unless *they themselves* anchor externally.

**DEFAULT for the ERP audit chain:**
1. Hash-chain every audit-log row as already planned (this is necessary but insufficient alone).
2. Batch rows into fixed windows (e.g., hourly or daily, or every N rows) and compute a Merkle root per window.
3. Submit that root as an entry to (i) a self-hosted or public Rekor/Trillian-Tessera instance for inclusion + consistency proofs, **and** (ii) an RFC 3161 TSA for a legally-recognized timestamp token, **and** (iii) optionally OpenTimestamps for a free, vendor-independent Bitcoin-anchored fallback proof.
4. Store all three proof artifacts (inclusion proof, TSA token, OTS proof) alongside the window's root hash in the audit table itself — the proofs must outlive the system that produced them.
5. Publish (or make independently fetchable) the periodic signed tree heads so an external auditor, not just internal staff, can verify no window was retroactively altered.

This gives three independent, differently-trusted anchors (a transparency-log operator, an audited TSA, a public blockchain) — a compromised DBA would need to *simultaneously* suppress detection across all three, which is the point.

### 2.4 Minimal schema sketch

```sql
CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  occurred_at TIMESTAMPTZ NOT NULL,
  actor_id UUID NOT NULL,
  event_type TEXT NOT NULL,
  payload JSONB NOT NULL,
  prev_hash BYTEA NOT NULL,
  row_hash BYTEA NOT NULL  -- H(payload || prev_hash || occurred_at || actor_id)
);

CREATE TABLE audit_anchor (
  id BIGSERIAL PRIMARY KEY,
  window_start BIGINT NOT NULL REFERENCES audit_log(id),
  window_end   BIGINT NOT NULL REFERENCES audit_log(id),
  merkle_root  BYTEA NOT NULL,
  rekor_uuid   TEXT,          -- Rekor entry ID, for inclusion-proof lookup
  rekor_proof  JSONB,         -- cached inclusion + consistency proof
  tsa_token    BYTEA,         -- RFC 3161 TimeStampToken (DER)
  ots_proof    BYTEA,         -- OpenTimestamps .ots proof, optional
  anchored_at  TIMESTAMPTZ NOT NULL
);
```

A DBA can still edit `audit_log` rows directly — but doing so breaks `row_hash` chaining from that point AND makes the corresponding `merkle_root` in `audit_anchor` unreproducible, which is detectable by anyone (auditor, regulator, external monitor) who independently recomputes the root and compares it against the externally-anchored proof. That's the non-repudiation property regulators actually want.

---

## 3. Spec-Driven / Model-Driven Generation

### 3.1 Why this is the deepest anti-hallucination lever available

Every other defense against AI-generated ERP bugs (tests, code review, linting) operates *after* code exists and can itself be hallucinated alongside the code. **Spec-driven development (SDD) inverts the artifact hierarchy: the formal spec is the source of truth, and code, tests, migrations, and docs are all regenerable, disposable projections of it.** If the agent hallucinates in the *spec* phase, a human reviews one dense, structured artifact instead of thousands of lines of generated code across five files — the review surface shrinks by an order of magnitude, and drift between code/tests/docs becomes structurally impossible because they share one origin.

By 2026 this went mainstream: "every major AI coding tool — GitHub Spec Kit, AWS Kiro, Claude Code, Cursor, OpenSpec, BMAD, Tessl, Google Antigravity — has shipped its own flavor of SDD," with early adopter reports from GitHub and AWS citing **3–10× higher first-pass success rate** on non-trivial AI-agent tasks when work is spec-anchored versus prompted ad hoc (MarkTechPost, 2026; Martin Fowler, "Understanding Spec-Driven Development," 2026).

### 3.2 Tool landscape

| Tool | Maturity (2026) | Spec artifact | Generation scope | Fit for ERP |
|---|---|---|---|---|
| **GitHub Spec Kit** | v0.8.7 (May 2026), most community-adopted, 30+ agent integrations | Markdown: Spec → Plan → Tasks → Implement | Code + tests + docs, agent-agnostic (Claude Code, Copilot, Gemini, etc.) | **DEFAULT starting point** — open, no vendor lock, works with whatever agent the builder already runs |
| **AWS Kiro** | Launched mid-2025, agentic IDE on Code OSS | Requirements → Design → Tasks (structured, not free markdown) | Code + tests, tightly coupled to Kiro IDE | Good if already AWS/Kiro-committed; less portable |
| **Tessl** | Actively pursuing "spec-as-source": generated code carries `// GENERATED FROM SPEC — DO NOT EDIT` | Tessl spec (richer than markdown; closer to executable) | Code + tests; spec is the file you edit, code is a build artifact | Most philosophically pure version of this section's thesis; newer, smaller ecosystem — pilot, don't bet the farm yet |
| **TypeSpec** (Microsoft) | **1.0 GA** in 2026, stable core + production emitters | TypeSpec DSL → OpenAPI 3.1 / gRPC / client+server stubs (.NET, JS, Java, Python in preview) | API surface, SDKs, docs — not business logic itself | **DEFAULT for the API/contract layer**: promote TypeSpec (or Smithy) to source of truth, demote OpenAPI to a *generated* artifact, not a hand-maintained one |
| **DMN (Decision Model & Notation, OMG standard)** | Mature, ISO/OMG-governed, decades of BPM tooling (Camunda, Trisotech) | Decision tables + Decision Requirements Diagrams | Executable decision logic (e.g., approval-limit tables) that both business users and engines can read | **DEFAULT for approval-rule / spend-policy logic specifically** — express "up to $X for category Y" as a DMN decision table, generate the condition parameters (§1.3) from it, so finance can edit policy without a code PR |

### 3.3 The layered spec stack this playbook should prescribe

No single tool covers "one formal domain spec → code+tests+migrations+docs" end to end yet in 2026 — the credible move is **layering narrow, mature spec formats per concern**, not waiting for one universal DSL:

```
┌─────────────────────────────────────────────────────────┐
│ Business-rule layer:  DMN decision tables                │  → approval limits, tax rules, matching tolerances
├─────────────────────────────────────────────────────────┤
│ API/contract layer:   TypeSpec (or Smithy)                │  → OpenAPI, gRPC, typed SDKs, server stubs
├─────────────────────────────────────────────────────────┤
│ Data/schema layer:    JSON Schema / a migration DSL       │  → DB migrations, validators, fixtures
│                       (e.g., Atlas HCL, Prisma schema)    │
├─────────────────────────────────────────────────────────┤
│ AuthZ layer:          OpenFGA/SpiceDB DSL (§1)            │  → permission checks, generated from same domain nouns
├─────────────────────────────────────────────────────────┤
│ Process/orchestration: GitHub Spec Kit Spec→Plan→Tasks    │  → the AI-agent execution harness that consumes the above
│                        artifacts as authoritative context │     as *inputs*, not as things it's free to invent
└─────────────────────────────────────────────────────────┘
```

**DEFAULT: treat every layer's spec file as checked-in, versioned, code-reviewed source — and treat the corresponding generated code/OpenAPI/migrations as build output that CI regenerates and diffs, never hand-edits.** A generated-file diff that doesn't match a clean regen is itself a CI failure signal ("someone hand-edited a generated artifact — spec is now a lie").

### 3.4 Formal methods as a deeper-but-narrower option

TLA+ (Lamport's specification language, used heavily inside AWS for distributed-systems correctness — lamport.azurewebsites.net/tla/formal-methods-amazon.pdf) can model-check concurrency and consistency properties (e.g., "can two concurrent postings double-book the same GL period") that no test suite exhaustively covers. 2025-2026 research (TLAi+Bench) is actively measuring whether LLMs can author correct TLA+ specs, with mixed results — **treat TLA+ as a targeted tool for the 3-5 scariest concurrency/consistency invariants in the ledger core (e.g., period-close race conditions), not as a general spec layer for CRUD-shaped ERP modules.** The ROI is concentrated exactly where hash-chained audits and Merkle anchoring (§2) also concentrate: the ledger/period-close boundary.

### 3.5 Test and migration generation specifics

- **From TypeSpec/OpenAPI**: contract tests and typed client/server stubs are a solved, mature generation target (Speakeasy, TypeSpec's own emitters) — **DEFAULT: never hand-write an OpenAPI file if TypeSpec (or Smithy) is in play; it is a compile target only.**
- **From DMN decision tables**: golden-file tests are natural — every row of a decision table is a test case waiting to be materialized; several DMN engines (Camunda) can execute the table directly, so "tests" and "the policy" can literally be the same rows, closing the drift gap completely for approval-limit logic.
- **From JSON Schema / Atlas HCL**: migrations, fixture generators, and property-based test strategies (e.g., feeding a schema into a Hypothesis/fast-check style generator) are a mature pattern — schema is the spec, migration SQL is the generated artifact, never the other way around.

---

## 4. Consolidated Defaults for the Playbook

1. **AuthZ**: Model ERP permissions as a ReBAC relation graph (cost centers, roles, delegates, categories as nodes; manager/delegate/approver as relations) with **conditions** carrying dollar ceilings and period-state — never encode limits as static roles. Default engine: **OpenFGA**; upgrade to **SpiceDB** (for its Relationship Integrity signing) when the compliance bar requires tamper-evident permission data itself, not just tamper-evident application data.
2. **Audit anchoring**: Hash-chain the audit log (necessary, not sufficient) AND periodically anchor Merkle roots of log windows to (a) a transparency log (Rekor/Trillian-Tessera, self-hosted or public), (b) an RFC 3161 TSA, and (c) OpenTimestamps as a free, vendor-independent fallback. Store all proof artifacts in the DB itself. Do **not** rely on a managed "ledger database" as the sole mechanism — AWS QLDB's 2025 discontinuation confirms that category is not a durable dependency.
3. **Spec-driven generation**: Adopt a layered spec stack — DMN for approval/business rules, TypeSpec (or Smithy) for the API contract, a schema DSL for data/migrations, an OpenFGA/SpiceDB DSL for authz, and GitHub Spec Kit's Spec→Plan→Tasks harness to orchestrate AI-agent execution against all of the above as fixed inputs. CI must regenerate and diff every generated artifact; a mismatch is a build failure. Reserve TLA+ for the handful of highest-stakes concurrency invariants in the ledger core, not as a general-purpose spec layer.

---

## Sources

- Google Zanzibar paper and OpenFGA authorization-concepts docs — https://openfga.dev/docs/authorization-concepts
- OpenFGA Conditions — https://openfga.dev/docs/modeling/conditions
- OpenFGA Conditional Tuples announcement — https://openfga.dev/blog/conditional-tuples-announcement
- OpenFGA Contextual Tuples — https://openfga.dev/docs/interacting/contextual-tuples
- OpenFGA vs Permify vs SpiceDB (2026) — https://www.pkgpulse.com/guides/openfga-vs-permify-vs-spicedb-zanzibar-authorization-2026
- SpiceDB — Relationship Integrity — https://authzed.com/blog/spicedb-relationship-integrity
- SpiceDB / SpiceBox / spicedb-dev for AI coding agents — https://authzed.com/blog/spicedb-dev-and-spicebox-add-permissions-for-ai-coding-agents
- AuthZed / SpiceDB GitHub — https://github.com/authzed/spicedb
- Permify GitHub (FusionAuth acquisition note) — https://github.com/Permify/permify
- RFC 9162 — Certificate Transparency Version 2.0 — https://datatracker.ietf.org/doc/html/rfc9162
- RFC 3161 — Time-Stamp Protocol — https://datatracker.ietf.org/doc/html/rfc3161 ; forensics context: https://www.metaspike.com/trusted-timestamping-rfc-3161-digital-forensics/
- Sigstore Rekor overview — https://docs.sigstore.dev/logging/overview/
- Rekor v2 / Trillian-Tessera GA (Oct 2025) context — https://blog.sigstore.dev/using-rekor-monitor/ ; https://edu.chainguard.dev/open-source/sigstore/rekor/an-introduction-to-rekor/
- OpenTimestamps — https://opentimestamps.org/
- AWS QLDB discontinuation — https://www.infoq.com/news/2024/07/aws-kill-qldb/ ; migration guide: https://aws.amazon.com/blogs/database/replace-amazon-qldb-with-amazon-aurora-postgresql-for-audit-use-cases/
- GitHub Spec Kit docs — https://github.github.com/spec-kit/
- Understanding Spec-Driven Development: Kiro, spec-kit, Tessl (Martin Fowler) — https://martinfowler.com/articles/exploring-gen-ai/sdd-3-tools.html
- 9 Best AI Tools for Spec-Driven Development in 2026 — https://www.marktechpost.com/2026/05/08/9-best-ai-tools-for-spec-driven-development-in-2026-kiro-bmad-gsd-and-more-compare/
- TypeSpec overview / 1.0 GA — https://learn.microsoft.com/en-us/azure/developer/typespec/overview ; https://typespec.io/
- API Schema Landscape 2026 (TypeSpec/Smithy as source of truth) — https://www.youngju.dev/blog/culture/2026-05-14-api-schema-2026-json-schema-openapi-3-1-asyncapi-graphql-grpc-deep-dive.en
- DMN standard (OMG) — https://www.omg.org/dmn/ ; overview: https://en.wikipedia.org/wiki/Decision_Model_and_Notation
- TLA+ at Amazon — https://lamport.azurewebsites.net/tla/formal-methods-amazon.pdf
- LLMs modeling systems in TLA+ (2026 ACM SIGOPS) — https://www.sigops.org/2026/can-llms-model-real-world-systems-in-tla/
