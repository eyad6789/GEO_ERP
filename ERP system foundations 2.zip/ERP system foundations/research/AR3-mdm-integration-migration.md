# The Data Seam Where ERPs Die: MDM, Integration Contracts, Continuous Reconciled Migration

**Scope**: This is the seam that kills ERP programs — not the app layer, the *data* layer. Three interlocking defaults: (1) a canonical MDM layer with real survivorship rules, (2) an anti-corruption contract layer per external system with schema versioning and contract tests, (3) a migration pipeline built *first* and run continuously as a shadow reconciliation engine from day one, so cutover is a non-event. All three share one design principle: **the legacy system and the new ERP are both untrusted until reconciled against a control total.**

---

## 1. Master Data Management

### 1.1 Why MDM is the actual failure point

ERP RFPs get judged on modules and UX. ERP *failures* are almost always: duplicate customers/vendors, orphaned GL account mappings, inconsistent item/UOM master data, and address/tax-jurisdiction drift across subsidiaries. None of that is fixed by picking NetSuite vs. Odoo vs. Dynamics — it's fixed (or not) by whether you have a canonical entity model with enforced match/merge/survivorship *before* go-live. Treat MDM as the first subsystem you build, not a "phase 2" cleanup.

### 1.2 Canonical entity model (default)

Adopt a minimal, ERP-agnostic canonical schema per core domain, independent of any one ERP's internal tables. Party (customer/vendor/employee) is the highest-leverage domain because it's shared by AR, AP, procurement, and CRM.

```yaml
# canonical-party.schema.yaml (JSON Schema sketch)
Party:
  id: uuid                # canonical MDM id, never reused, never exposed to end users as "the" ID
  party_type: enum[organization, person]
  golden_name: string
  tax_ids:                # array — an org can have multiple (VAT, EIN, local)
    - { scheme: string, value: string, country: string }
  addresses:
    - { type: enum[legal, shipping, billing], line1, line2, city, region, postal, country, valid_from, valid_to }
  identifiers:             # cross-references to source systems — THIS is the integration key
    - { system: string, external_id: string, external_type: string, confidence: float, last_seen: datetime }
  status: enum[active, merged, deprecated, pending_review]
  survivorship_trace: [ { field, winning_source, rule, timestamp } ]
  merged_into: uuid?        # tombstone pointer for dead golden records
```

The `identifiers[]` cross-reference array is the single most important design decision: **never let a foreign system's primary key become your canonical ID.** Every source system (legacy ERP, CRM, e-commerce, bank feed) gets a row here. This is what makes the reconciliation pipeline in Section 3 possible — it's the join key across systems.

### 1.3 Match / merge / survivorship

- **Match** (candidate generation + scoring): deterministic keys first (tax ID + country, exact DUNS, email domain + name), then probabilistic (Fellegi-Sunter model) for the long tail — name/address fuzz, transliteration, subsidiary naming drift.
  - Default tool: **Splink** (Ministry of Justice, UK) — Python, Fellegi-Sunter probabilistic linkage, runs on DuckDB for <10M records or Spark/Athena for scale, no server dependency, MIT-licensed. It has real production pedigree (used in a 2025 UK Civil Service Award–winning case-linkage system) [Splink docs, MoJ]. Prefer it over rolling your own fuzzy-match SQL.
  - Alternative for active-learning-driven matching at bigger scale: **Zingg** (Spark-native, human-in-the-loop labeling loop).
  - Do NOT default to LLM-similarity matching for financial master data (customers/vendors/GL) — nondeterministic, unauditable, hard to defend to an auditor. LLM matching is acceptable for *candidate surfacing* in the steward's queue, never for auto-merge of financial entities.
- **Merge**: never destructive. Merging two source records into a golden record creates a *new* survivorship-traced golden record; old external IDs are retained as aliases (`merged_into` tombstone), so historical transactions in the legacy ERP still resolve.
- **Survivorship rules** — pick per-field, not per-record. Typical default rule set:

| Field | Rule | Rationale |
|---|---|---|
| Legal name | Most-recent-wins from system-of-record (usually legal entity registry) | legal name changes are authoritative from one place |
| Tax ID | Most-trusted-source-wins (govt-registry-fed system > CRM > spreadsheet) | financial/compliance risk if wrong |
| Address | Most-recent-non-null, with active/expired banding | shipping addresses churn often |
| Payment terms | ERP-of-record wins (never CRM) | financial risk |
| Credit limit | Highest-authority-system wins, human approval required on conflict | risk control |
| Email/phone | Most-recent-non-null | low risk, freshness matters most |

Every rule fires into `survivorship_trace` — an auditor must be able to answer "why does this golden record say NET-30" six months after go-live.

### 1.4 Golden records, data quality gates, stewardship workflow

- **Data quality gates**: run before *and after* survivorship, not just at ingestion. Default: **Soda Core** or **Great Expectations (GX Core)** — both open source, both support "data contract" style declarative expectations (`not_null`, `valid_values`, referential checks, freshness) that block promotion of a batch to golden if failed [GX Core / Soda Core, 2025–2026 landscape reviews]. Wire these as a CI gate on every MDM batch run — treat data quality suites exactly like unit tests, versioned in git next to the match/merge code.
- **Golden record publication**: golden records are published as an event (`party.golden_record.updated.v1`) to the integration bus (Section 2), never written directly into ERP tables by a side process. Every consuming system subscribes and reconciles.
- **Stewardship workflow** (default shape, tool-agnostic — a lightweight Retool/internal-tool screen is fine, don't buy a full MDM suite for step 1):
  1. Auto-match confidence ≥ 0.98 → auto-merge, logged.
  2. Confidence 0.80–0.98 → steward review queue, side-by-side diff, one-click accept/reject/edit-then-accept.
  3. Confidence < 0.80 → no merge, flagged as "possible duplicate," does not block operations.
  4. Every steward decision is fed back as a labeled training pair to improve match model (this is what makes Splink/Zingg's active-learning loop worthwhile).
  5. SLA: unresolved review-queue items > 30 days get escalated to data owner, not silently ignored.

### 1.5 Commercial vs. open source — the honest default

Gartner's 2025/2026 MDM Magic Quadrant leaders are Profisee, Semarchy, Stibo, Reltio, Informatica [Semarchy/Profisee vendor comparisons, 2026]. Notably **SAP acquired Reltio in March 2026** — a strong signal that MDM is being pulled *into* the ERP vendor stack, which is exactly the vendor lock-in this playbook argues against. There is no mature pure-open-source MDM platform with golden-record UI, workflow, and stewardship at the level of Profisee/Semarchy; **AtroCore** (MIT-ish enterprise-open-source, GitHub-hosted, does MDM+PIM+BPM) is the most credible open-source contender if you need a UI-driven platform rather than hand-rolled pipelines [AtroCore GitHub, 2025].

**Default recommendation for a build-your-own ERP program**: start hand-rolled (Splink + dbt + Soda Core + a thin steward UI) because it's cheap, auditable, and fits the "migration pipeline is the product" philosophy in Section 3 — the match/merge code and the migration pipeline are *the same codebase*. Graduate to Profisee/Semarchy only when you have >5 source systems feeding one domain and stewardship volume exceeds what a 2-person data team can triage weekly.

---

## 2. Integration Contract Layer

### 2.1 Principle: anti-corruption layer per external system

Every external system (legacy ERP, bank, tax engine, EDI/VAN, e-commerce, CRM, payroll) gets its own **anti-corruption layer (ACL)**: a translation service that owns (a) the external system's native shape, (b) a canonical internal event/schema, and (c) the mapping between them. No downstream service ever parses a legacy system's native format directly — it consumes canonical events only. This is the pattern that lets you swap the legacy ERP for the new ERP without touching 40 downstream integrations: only the ACL's inbound adapter changes.

```
[Legacy ERP] --native format--> [ACL: legacy-erp-adapter] --canonical event--> [Event Bus] --> [MDM] [New ERP] [Warehouse]
[New ERP]    --native format--> [ACL: new-erp-adapter]    --canonical event--> [Event Bus]
```

During migration, *both* adapters publish the same canonical event type — which is precisely what makes shadow reconciliation (Section 3) mechanical rather than bespoke.

### 2.2 Idempotent, replayable interfaces

- Every event carries a **business idempotency key** independent of transport (e.g., `source_system + source_id + version`), not just a transport-level message ID. Consumers persist a dedupe ledger (`(idempotency_key) -> last_applied_version`) and no-op on replay.
- Every ACL adapter must support **full replay from source-of-record** — reprocessing the legacy ERP's last 90 days of transactions must reproduce identical canonical events byte-for-byte (except timestamps of processing). This is your disaster-recovery and reconciliation backbone, not just a testing nicety.
- Recommended transport default: **Kafka** with **Debezium** for CDC-sourced adapters where the legacy system is a database you can tail (log-based CDC, no polling load on legacy prod) [Debezium docs, debezium.io, 2025]. For systems only reachable by API/file (EDI, SFTP, SOAP), the ACL adapter still normalizes into the same canonical event schema and publishes to the same bus — the internal contract doesn't care how the byte got there.

### 2.3 Event schema versioning

- Use **CloudEvents 1.0** as the event envelope (id, source, type, time, `dataschema`, `data`) — it's a CNCF-graduated spec with wide tooling support (Azure Event Grid, AWS EventBridge, Knative) and gives you a standard `type`/`dataschema` versioning slot rather than inventing one [CloudEvents spec, cloudevents/spec GitHub, 2025]. Version the **`type`** field explicitly: `com.acmeco.party.golden_record.updated.v1`, bump to `.v2` on any breaking change; never silently mutate `.v1`'s shape.
- Document the event catalog with **AsyncAPI 3.0** (released March 2024, current stable major as of 2026) — treat the AsyncAPI document as the source of truth for channel/message/schema, with Confluent Schema Registry (or a self-hosted Avro/JSON-Schema registry) as the *runtime enforcement point* [AsyncAPI 3.0 docs; Confluent Stream Governance docs, 2025]. Compatibility mode: `BACKWARD` at minimum (new schema can read old data) enforced at registry level — a producer cannot register a breaking schema without a version bump.

### 2.4 Contract testing: Pact + broker

- Default: **Pact** for consumer-driven contract testing between the ACL and both the legacy system's API surface (where testable) and every internal consumer of canonical events. Pact ≥ v4 supports message-based (async/event) contracts, not just HTTP request/response, which is the relevant mode here [Pact docs, docs.pact.io, 2025–2026].
- Run a **Pact Broker** (self-hosted OSS or PactFlow hosted) as the integration-contract registry's *verification* half — every consumer publishes its expectations, every provider (ACL adapter) verifies against all registered consumer contracts in CI before deploy. This is what turns "did we break the warehouse feed" from a production incident into a merge-blocking CI failure.
- Concrete gate: **`can-i-deploy`** check in CI — an ACL adapter cannot ship to prod unless Pact Broker confirms every currently-deployed consumer's contract is satisfied by the candidate version.

### 2.5 Integration-contract registry (recommended shape)

A single registry (can literally be a Git repo of AsyncAPI YAML + Pact broker + a thin index page) that answers, per external system: schema version history, current consumers, contract test status, replay/backfill runbook link, and ACL owner. Minimum viable version: one folder per external system under `integration-contracts/`, each with `asyncapi.yaml`, `CONTRACT.md` (owner, SLAs, replay procedure), and a link to its Pact Broker pacticipant page. Do not defer this to "documentation later" — an unregistered integration is an unowned integration, and unowned integrations are exactly what breaks silently three weeks after cutover.

---

## 3. Continuous Reconciled Migration

### 3.1 The core bet: build the migration pipeline first, run it as a shadow from day one

**Default doctrine**: the ERP migration pipeline is not a project-end deliverable — it is the *first* thing built, and it runs continuously in production-shadow mode against the live legacy system from week one of the program, long before the new ERP is "ready." This inverts the typical program plan (build new system → freeze → migrate → cutover → hope) into: build pipeline → shadow-run daily → reconcile nightly → fix drift continuously → cutover is just "flip which side is authoritative," a config change, not an event.

This directly targets the **big-bang failure mode**: months of silent migration-script rot, a single high-stakes cutover weekend, and discovering reconciliation breaks *after* the legacy system is decommissioned and there's no fallback. Continuous shadow migration converts every reconciliation break into a bug found on a Tuesday with the legacy system still live to check against, instead of a P0 during cutover weekend.

### 3.2 Pipeline architecture

```
Legacy ERP (system of record, T0)
   │  CDC (Debezium) or scheduled extract
   ▼
Landing zone (raw, immutable, append-only) ── S3/Parquet or equivalent
   │
   ▼
Transform + canonicalize (dbt models) ──────► MDM match/merge (Splink) ──► Golden records
   │                                                                             │
   ▼                                                                             ▼
New ERP staging schema  ◄───────────── load (idempotent upsert) ────────────────┘
   │
   ▼
Nightly reconciliation job ──► control totals, tie-outs ──► drift report ──► steward/finance review
```

- **Landing zone is append-only and immutable.** Never mutate raw extracts; corrections happen downstream. This is what lets you replay the entire migration history when a survivorship rule changes.
- **Transform layer**: **dbt** (or dbt-core equivalent) for the canonicalization/transform logic — SQL-testable, version-controlled, has built-in `dbt test` assertions that double as part of the data-quality gate.
- **Load into new ERP staging** is idempotent upsert keyed by the canonical `identifiers[]` cross-reference (Section 1.2) — rerunning the whole pipeline against an unchanged legacy state must be a no-op.

### 3.3 Nightly reconciliation: control totals and financial tie-outs

This is the mechanism that makes "cutover is a non-event" true rather than aspirational. Every night, for every financial domain, compute and diff **three-way control totals**: legacy system, migration pipeline's staged output, and (once live) new ERP.

| Control | Legacy | Pipeline Output | New ERP (post-cutover) | Tolerance |
|---|---|---|---|---|
| AR open balance by customer | SUM(open invoices) | SUM(golden AR) | SUM(AR module) | $0.00, zero tolerance |
| AP open balance by vendor | SUM(open bills) | SUM(golden AP) | SUM(AP module) | $0.00 |
| GL trial balance by account | SUM(debits)=SUM(credits) | same | same | $0.00 |
| Customer/vendor count | count(active party) | count(golden party) | count(party) | 0, with named-diff list |
| Inventory qty on hand by SKU/location | SUM(qty) | SUM(qty) | SUM(qty) | 0 units, or documented in-transit exception |
| Bank cash balance | statement balance | derived balance | GL cash account | $0.00 |

Design rules:
- **Every diff is enumerated, never just a percentage.** "99.98% match" is useless; you need the *list* of the 12 customers whose balance is off and why (timing difference vs. real defect).
- **Reconciliation output is itself an event** (`reconciliation.nightly.completed.v1`) with pass/fail per control, published to the same bus — treat reconciliation as a first-class producer/consumer in the contract registry, not a side script.
- **Timing differences are a named category, not noise**: e.g., a payment posted in legacy at 11:58pm and captured in pipeline extract the next day. Classify every diff as `timing`, `mapping-defect`, or `data-quality-defect` — only the last two are steward work items; timing diffs should shrink to zero as extract frequency increases (moving from nightly batch to CDC-streaming closes this class entirely, which is another reason to prefer Debezium CDC over batch extracts once volumes justify it).
- **Freeze gate for cutover readiness, not a single freeze event**: define a rolling readiness metric — e.g., "14 consecutive nightly reconciliations with zero unexplained mapping/data-quality diffs across all financial controls" — as the quantitative cutover-go criterion, reviewed weekly starting months before target go-live. This turns "are we ready to cut over" from a subjective program-management judgment call into a metric on a dashboard anyone can check.

### 3.4 Runbook (concrete, condensed)

1. **Week 1 of program**: stand up landing zone + CDC/extract from legacy for the highest-risk domain (usually GL + AR/AP) before any new-ERP configuration work starts.
2. **Week 2–4**: build canonical schema + dbt transforms + first-pass MDM match rules; wire nightly reconciliation job even though the "new ERP" side is empty/stubbed (reconcile pipeline-output vs. legacy only, to validate transform correctness first).
3. **Ongoing, from week 4**: nightly job runs unattended; failures page the data team, not the program manager. Weekly steward triage of the match-review queue.
4. **New ERP available (any environment)**: extend pipeline to also load into new-ERP staging; three-way reconciliation begins. Expect a spike in diffs (mapping defects) — this is the point of doing it early, while there's no time pressure.
5. **T-90 days to planned cutover**: reconciliation must be running daily with a published dashboard; freeze non-essential legacy config changes (chart of accounts, tax codes) — configuration drift during the countdown is a top real-world cause of surprise diffs.
6. **T-14 days**: begin the rolling "N consecutive clean nights" readiness clock (Section 3.3).
7. **Cutover weekend**: no bespoke migration scripts run — the same pipeline that has run nightly for months simply gets pointed at "new ERP is now source of record for new transactions; legacy read-only." The pipeline continues running *backwards* (new ERP → legacy shape) in shadow for 30–60 days as a fallback verification, not as the primary flow.
8. **T+30 to T+60**: decommission legacy only after the reconciliation job shows zero drift for the full window and finance has signed off on the final trial balance tie-out.

### 3.5 Big-bang vs. continuous — the comparison to put in front of sponsors

| | Big-bang migration | Continuous reconciled migration |
|---|---|---|
| When migration code is first run for real | Days before cutover | Week 1 of program |
| When reconciliation defects are found | Cutover weekend, under time pressure | Continuously, months in advance, no pressure |
| Fallback if cutover fails | Rollback to legacy, redo scripts, re-schedule (often loses weeks) | None needed — legacy still authoritative until readiness metric is hit |
| Auditor/CFO confidence at go-live | "We tested in staging" | "We have 90+ days of nightly tie-outs to show" |
| Cost profile | Spike of contractor/consultant effort pre-cutover | Steady data-engineering investment from day one |
| Failure mode | Silent — surfaces as customer complaints/wrong invoices post-cutover | Loud — surfaces as a failed nightly job, days/weeks before it matters |

---

## Proposed Defaults (summary for the playbook)

1. **MDM**: canonical party/item/GL-mapping schema with an explicit `identifiers[]` cross-reference array as the integration join key. Match with **Splink** (probabilistic, Fellegi-Sunter). Survivorship rules per-field, versioned and audit-traced. Data quality gates via **Soda Core / GX Core** block promotion to golden. Start hand-rolled; graduate to **Profisee or Semarchy** only past ~5 source systems per domain.
2. **Integration**: one anti-corruption layer per external system; canonical events wrapped in **CloudEvents 1.0**; catalog in **AsyncAPI 3.0**; schema registry with `BACKWARD` compatibility enforced; **Debezium**-based CDC preferred over polling/batch for database-backed legacy systems; **Pact + Pact Broker** contract tests gate every ACL deploy via `can-i-deploy`; a lightweight git-based integration-contract registry (AsyncAPI + CONTRACT.md + Pact link per system) is mandatory, not optional documentation.
3. **Migration**: build the pipeline in week 1, not phase 3. Landing zone append-only; **dbt** for canonicalized transforms; nightly three-way reconciliation with enumerated (not aggregated) diffs classified as timing/mapping-defect/data-quality-defect; rolling "N consecutive clean nights" as the quantitative cutover-readiness gate; run the pipeline backward for 30–60 days post-cutover as a live fallback check before legacy decommission.

## Open Risks / Unverifiable Items

- Exact current pricing/tiering of Profisee/Semarchy/Reltio not verified — treat any specific dollar figure as unverified as of 2026-07.
- SAP's product roadmap for Reltio post-acquisition (March 2026) is not yet public in detail; do not assume Reltio remains vendor-neutral going forward (unverified as of 2026-07).
- AtroCore's production-scale track record at MDM (vs. PIM) specifically is thinner than Profisee/Semarchy's — treat as a credible but less battle-tested open-source option (unverified as of 2026-07).

---

## Sources

- [Splink documentation and GitHub (moj-analytical-services)](https://github.com/moj-analytical-services/splink) — probabilistic record linkage, Fellegi-Sunter model, DuckDB/Spark backends.
- [Best Open Source Entity Resolution Libraries: Splink, Zingg, dedupe](https://tilores.io/content/best-open-source-entity-resolution-and-record-linkage-libraries-splink-zingg-dedupe-and-when-to-move-beyond-them/)
- [GX Core: Open Source Data Quality Platform — Great Expectations](https://greatexpectations.io/)
- [Soda Core — data quality and data contract verification engine](https://www.linuxlinks.com/soda-core-data-quality-data-contract-verification-engine/)
- [The 2026 Open-Source Data Quality and Data Observability Landscape — DataKitchen](https://datakitchen.io/blog/the-2026-open-source-data-quality-and-data-observability-landscape/)
- [The Definitive Guide to Data Contracts — Soda](https://soda.io/blog/guide-to-data-contracts)
- [CloudEvents Specification (main spec, cloudevents/spec GitHub)](https://github.com/cloudevents/spec/blob/main/cloudevents/spec.md)
- [CloudEvents releases](https://github.com/cloudevents/spec/releases)
- [AsyncAPI 3.0: Event-Driven API Specification Complete Guide](https://iotdigitaltwinplm.com/asyncapi-3-event-driven-api-specification-complete-guide/)
- [Using AsyncAPI with Stream Governance — Confluent Documentation](https://docs.confluent.io/cloud/current/stream-governance/async-api.html)
- [Pact Docs — consumer-driven contract testing](https://docs.pact.io/)
- [Contract testing with Pact — Best Practices in 2025 Practical Guide](https://www.sachith.co.uk/contract-testing-with-pact-best-practices-in-2025-practical-guide-feb-10-2026/)
- [Pactflow Contract Testing Platform (hosted Pact Broker)](https://pactflow.io/)
- [Debezium — change data capture platform](https://debezium.io/)
- [Debezium GitHub repository](https://github.com/debezium/debezium)
- [Top 25+ Master Data Management Tools — Profisee (2026)](https://profisee.com/30-best-master-data-management-tools/)
- [Top 17 Master Data Management Solutions Compared — Semarchy (2026)](https://semarchy.com/blog/top-master-data-management-solutions-compared/)
- [AtroCore — flexible, configurable open source MDM system](https://github.com/atrocore/atrocore)
- [Open Source Master Data Management Explained — AtroCore](https://www.atrocore.com/en/blog/open-source-master-data-management)
