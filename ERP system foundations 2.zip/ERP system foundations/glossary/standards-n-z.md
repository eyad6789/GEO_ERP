# Standards, Regulations & Frameworks (N–Z)

| Identifier | Full name | Domain | Jurisdiction | Primary file(s) |
|---|---|---|---|---|
| NACHA Standard Entry Class (SEC) | NACHA Operating Rules — Standard Entry Class codes for ACH transactions | Financial reporting / Payments | US | verticals/financial-services.md |
| NADCAP | National Aerospace and Defense Contractors Accreditation Program | Quality / Aerospace | Global | verticals/aerospace-defense.md |
| NAIC SSAP | National Association of Insurance Commissioners Statutory Statement of Accounting Principles | Financial reporting / Insurance | US | verticals/financial-services.md |
| NAUPA Unclaimed Property Standards | National Association of Unclaimed Property Administrators — Unclaimed Property Reporting Standards | Financial reporting | US | verticals/financial-services.md |
| NERC CIP-003-9 | North American Electric Reliability Corporation Critical Infrastructure Protection Standard 003-9 — Security Management Controls | Security / Energy | North America | verticals/oil-gas-energy.md |
| NERC CIP-005-7 | North American Electric Reliability Corporation Critical Infrastructure Protection Standard 005-7 — Electronic Security Perimeters | Security / Energy | North America | verticals/oil-gas-energy.md |
| NERC CIP-010-4 | North American Electric Reliability Corporation Critical Infrastructure Protection Standard 010-4 — Configuration Change Management and Vulnerability Assessments | Security / Energy | North America | verticals/oil-gas-energy.md |
| NERC CIP-012-2 | North American Electric Reliability Corporation Critical Infrastructure Protection Standard 012-2 — Communications between Control Centers | Security / Energy | North America | verticals/oil-gas-energy.md |
| NERC CIP-013-2 | North American Electric Reliability Corporation Critical Infrastructure Protection Standard 013-2 — Supply Chain Risk Management | Security / Energy | North America | verticals/oil-gas-energy.md |
| NERC CIP-015-1 | North American Electric Reliability Corporation Critical Infrastructure Protection Standard 015-1 — Internal Network Security Monitoring | Security / Energy | North America | verticals/oil-gas-energy.md |
| New York Labor Law Article 8 | New York Labor Law Article 8 — Prevailing Wages on Public Work | Labour / Payroll | US | verticals/construction-realestate.md |
| NF525 | NF 525 — French standard for accounting software and cash register systems (Certification NF 525) | Tax / Fiscal | France | core/localization-tax.md |
| NIS2 Directive (EU) 2022/2555 | Directive (EU) 2022/2555 on measures for a high common level of cybersecurity across the Union (NIS2) | Security | EU | core/security.md |
| NIST Cybersecurity Framework (CSF) | NIST Cybersecurity Framework — voluntary framework for managing cybersecurity risk | Security | US / Global | core/security.md |
| NIST SP 800-162 | Guide to Attribute Based Access Control (ABAC) Definition and Considerations | Security | US | core/security.md |
| NIST SP 800-171 Rev. 2 | Protecting Controlled Unclassified Information in Nonfederal Systems and Organizations, Revision 2 | Security | US | core/security.md |
| NIST SP 800-171 Rev. 3 | Protecting Controlled Unclassified Information in Nonfederal Systems and Organizations, Revision 3 | Security | US | core/security.md |
| NIST SP 800-172 | Enhanced Security Requirements for Protecting Controlled Unclassified Information | Security | US | core/security.md |
| NIST SP 800-52 Rev. 2 | Guidelines for the Selection, Configuration, and Use of Transport Layer Security (TLS) Implementations, Revision 2 | Security | US | core/security.md |
| NIST SP 800-53 Rev. 5 | Security and Privacy Controls for Information Systems and Organizations | Security | US | core/security.md |
| NIST SP 800-63B | Digital Identity Guidelines: Authentication and Lifecycle Management | Security | US | core/security.md |
| NY Education Law § 2-d | New York Education Law Section 2-d — Student Data Privacy | Data privacy | US | verticals/education.md |
| OASIS xAL | OASIS extensible Address Language — Address Data Model Standard | Integration / Data | Global | core/localization-tax.md |
| OAuth 2.0 | OAuth 2.0 Authorization Framework (RFC 6749) | Security / Integration | Global | core/security.md |
| OCC 12 CFR Part 30 Appendix D | OCC Heightened Standards — Guidelines Establishing Standards for Recovery Planning (Appendix D to 12 CFR Part 30) | Financial services / Risk | US | verticals/financial-services.md |
| OCC 2011-12 | OCC Supervisory Guidance on Model Risk Management | Financial services / Risk | US | verticals/financial-services.md |
| OData v4 (OASIS Standard) | Open Data Protocol Version 4.0 — OASIS Standard | Integration / API | Global | core/architecture.md |
| OECD BEPS Action 13 | OECD Base Erosion and Profit Shifting Action 13 — Country-by-Country Reporting and Transfer Pricing Documentation | Tax | Global | verticals/financial-services.md |
| OECD BEPS Action 4 | OECD Base Erosion and Profit Shifting Action 4 — Interest Deduction Limitation Rules | Tax | Global | verticals/financial-services.md |
| OECD CRS (2014) | OECD Common Reporting Standard for Automatic Exchange of Financial Account Information (2014) | Tax / Financial reporting | Global | verticals/financial-services.md |
| OECD Pillar Two GloBE Model Rules (December 2021) | OECD/G20 Pillar Two Global Anti-Base Erosion Model Rules — 15% Global Minimum Tax | Tax | Global | verticals/financial-services.md |
| OECD Transfer Pricing Guidelines (2022) | OECD Transfer Pricing Guidelines for Multinational Enterprises and Tax Administrations (2022 edition) | Tax | Global | core/architecture.md |
| OMB Circular A-11 | OMB Circular A-11 — Preparation, Submission, and Execution of the Budget | Public sector / Financial reporting | US | verticals/government-publicsector.md |
| OMB Circular A-123 | OMB Circular A-123 — Management's Responsibility for Enterprise Risk Management and Internal Control | Public sector / Internal control | US | verticals/government-publicsector.md |
| OMB Circular A-136 | OMB Circular A-136 — Financial Reporting Requirements (SFFAS-based Financial Statements) | Public sector / Financial reporting | US | verticals/government-publicsector.md |
| OpenAPI 3.x | OpenAPI Specification Version 3.x (formerly Swagger) — REST API Description Format | Integration / API | Global | core/features-core.md |
| OpenID Connect 1.0 | OpenID Connect 1.0 — Identity Layer on Top of OAuth 2.0 | Security / Integration | Global | core/security.md |
| pain.001.001.0x | ISO 20022 pain.001 Customer Credit Transfer Initiation — used for AP payment file generation to bank; SEPA Credit Transfer (SCT) message | Banking / Payments | Global | core/localization-tax.md |
| pain.002.001.0x | ISO 20022 pain.002 Payment Status Report — bank acknowledgement/rejection message returned to ERP after payment submission | Banking / Payments | Global | core/localization-tax.md |
| pain.007.001.0x | ISO 20022 pain.007 Customer Payment Reversal — used for payment recall or reversal requests in ERP AP/AR workflows | Banking / Payments | Global | core/localization-tax.md |
| pain.008.001.0x | ISO 20022 pain.008 Customer Direct Debit Initiation — used for AR direct debit collection; covers SEPA Direct Debit Core (SDD Core) and B2B (SDD B2B) | Banking / Payments | Global | core/localization-tax.md |
| PCAOB AS 2201 | PCAOB Auditing Standard AS 2201 — An Audit of Internal Control Over Financial Reporting That Is Integrated with an Audit of Financial Statements | Financial reporting / Audit | US | core/security.md |
| PCI DSS v4.0 | Payment Card Industry Data Security Standard Version 4.0 | Security / Payments | Global | core/security.md |
| PCI DSS v4.0.1 | Payment Card Industry Data Security Standard Version 4.0.1 (all future-dated requirements mandatory from 31 March 2025) | Security / Payments | Global | core/security.md |
| PCI P2PE | PCI Point-to-Point Encryption Standard | Security / Payments | Global | verticals/retail-ecommerce.md |
| PCI Secure SLC Standard | PCI Secure Software Lifecycle Standard | Security / Payments | Global | verticals/retail-ecommerce.md |
| PCI Secure Software Standard v1.2 | PCI Secure Software Standard Version 1.2 (December 2022) | Security / Payments | Global | verticals/retail-ecommerce.md |
| PCI SSF (Software Security Framework) | PCI Security Standards Council Software Security Framework — comprising Secure Software Standard and Secure SLC Standard | Security / Payments | Global | verticals/retail-ecommerce.md |
| PEPPOL BIS Billing 3.0 | Pan-European Public Procurement Online Business Interoperability Specification Billing 3.0 (UBL 2.1-based e-invoicing) | Tax / e-invoicing | Global | core/localization-tax.md |
| PLP 68/2023 (Brazil) | Brazilian Complementary Law PLP 68/2023 — Constitutional Amendment 132/2023 Tax Reform (NFS-e national mandate) | Tax / e-invoicing | Brazil | core/localization-tax.md |
| PPAP | Production Part Approval Process (AIAG PPAP 4th Edition) — 18-element new/changed part approval for automotive series production | Quality / Automotive | Global | verticals/manufacturing.md |
| PRA PS1/26 | UK Prudential Regulation Authority Policy Statement PS1/26 — Implementation of Basel 3.1: Final Rules (effective 1 January 2027) | Financial services / Capital | UK | verticals/financial-services.md |
| PRA SS3/18 | UK Prudential Regulation Authority Supervisory Statement SS3/18 — Model Risk Management | Financial services / Risk | UK | verticals/financial-services.md |
| PRA SS4/21 | UK Prudential Regulation Authority Supervisory Statement SS4/21 — Operational Resilience | Financial services / Operational resilience | UK | verticals/financial-services.md |
| Privacy Act of 1974 (5 USC § 552a) | Privacy Act of 1974 — Federal Agency Requirements for Personal Data Systems of Records | Data privacy | US | verticals/government-publicsector.md |
| Privacy and Other Legislation Amendment Act 2024 (Cth) | Privacy and Other Legislation Amendment Act 2024 (Commonwealth of Australia) — Enhanced Privacy Penalties and Requirements | Data privacy | Australia | core/security.md |
| Prompt Payment Act (31 USC §§ 3901–3907) | Prompt Payment Act — Federal Agency Payment Timing Requirements | Public sector / Finance | US | verticals/government-publicsector.md |
| Prosci ADKAR model | Prosci ADKAR Change Management Model (Awareness, Desire, Knowledge, Ability, Reinforcement) | Change management | Global | core/implementation.md |
| Public Contracts Regulations 2015 (PCR 2015) | Public Contracts Regulations 2015 — UK Transposition of EU Directive 2014/24/EU (transitional, for procurements begun before 24 February 2025) | Public sector / Procurement | UK | verticals/government-publicsector.md |
| Public Law 107-188 (Bioterrorism Act 2002) | Public Health Security and Bioterrorism Preparedness and Response Act of 2002 — FDA Food Facility Registration and Traceability | Food safety | US | verticals/agriculture-food.md |
| Purdue Reference Model | Purdue Enterprise Reference Architecture — Industrial Control System Network Segmentation Model (ISA-95/ISA-99 conceptual framework) | Manufacturing / OT security | Global | verticals/manufacturing.md |
| RD 1514/2007 (Spain PGC) | Real Decreto 1514/2007 — Spanish Plan General de Contabilidad (General Accounting Plan) | Financial reporting | Spain | core/localization-tax.md |
| Registrierkassenpflicht | Austrian Mandatory Cash Register Requirement with Cryptographic Signature (DEP chaining, since 2016) | Tax / e-invoicing | Austria | core/localization-tax.md |
| Regulation (EU) 2016/161 (EU FMD) | Commission Delegated Regulation (EU) 2016/161 — Falsified Medicines Directive: Unique Identifier and Safety Features for Medicinal Products | Healthcare / Pharmaceuticals | EU | verticals/healthcare-lifesciences.md |
| Regulation (EU) 2016/679 | General Data Protection Regulation | Data privacy | EU | core/security.md |
| Regulation (EU) 2017/745 (EU MDR) | EU Medical Device Regulation (EU) 2017/745 — Medical Device Conformity Assessment and UDI Requirements | Healthcare / Medical devices | EU | verticals/healthcare-lifesciences.md |
| Regulation (EU) 2017/746 (EU IVDR) | EU In Vitro Diagnostic Medical Device Regulation (EU) 2017/746 | Healthcare / Medical devices | EU | verticals/healthcare-lifesciences.md |
| Regulation (EU) 2021/451 | EU Net Stable Funding Ratio Regulation — Minimum NSFR Requirements for Credit Institutions | Financial services / Liquidity | EU | verticals/financial-services.md |
| Regulation (EU) 2024/1620 (AMLA) | Regulation (EU) 2024/1620 — Establishing the EU Anti-Money Laundering Authority (AMLA, operational 1 July 2025) | Financial services / AML | EU | verticals/financial-services.md |
| Regulation (EU) 2024/1624 (AML Single Rulebook) | Regulation (EU) 2024/1624 — EU AML Single Rulebook (directly applicable from 10 July 2027) | Financial services / AML | EU | verticals/financial-services.md |
| RFC 6238 | RFC 6238 — TOTP: Time-Based One-Time Password Algorithm | Security | Global | core/security.md |
| Russia Federal Law No. 242-FZ | Russian Federation Federal Law No. 242-FZ — Personal Data Localisation Requirement for Russian Citizens (effective 1 September 2015) | Data privacy | Russia | core/architecture.md |
| SAE EIA 748E-2026 | ANSI/EIA-748-E (SAE EIA 748E-2026) — Earned Value Management Systems Standard (27 guidelines; published February 2026) | Aerospace / Project management | Global | core/features-core.md |
| SAFT-PT | Standard Audit File for Tax — Portugal (SAF-T PT) — Monthly Invoicing and Annual Accounting XML Submission | Tax / e-invoicing | Portugal | core/localization-tax.md |
| SAML 2.0 | Security Assertion Markup Language 2.0 — OASIS SSO Protocol | Security / Integration | Global | core/security.md |
| SAP ABAP Cloud development model | SAP ABAP Cloud Development Model — S/4HANA Clean-Core Extensibility Architecture Restricting Access to Released APIs Only | ERP platform | Global | core/cautions.md |
| SAP Clean Core (S/4HANA extensibility framework) | SAP Clean Core Principle — S/4HANA Extensibility Framework (Five Pillars: Processes, Extensibility, Data, Integrations, Operations) | ERP platform | Global | core/cautions.md |
| Sarbanes-Oxley Act of 2002 (SOX) | Sarbanes-Oxley Act of 2002 (US Public Law 107-204) — Corporate Financial Reporting Accountability and Internal Control Requirements | Financial reporting / Audit | US | core/security.md |
| Saudi Arabia PDPL Royal Decree M/19 | Saudi Arabia Personal Data Protection Law — Royal Decree M/19 (effective 14 September 2023; full enforcement 14 September 2024) | Data privacy | Saudi Arabia | core/security.md |
| SCIM 2.0 RFC 7643 | System for Cross-domain Identity Management 2.0 — Core Schema (RFC 7643) | Security / Integration | Global | core/features-core.md |
| SCIM 2.0 RFC 7644 | System for Cross-domain Identity Management 2.0 — Protocol (RFC 7644) | Security / Integration | Global | core/features-core.md |
| SEC Regulation S-K Item 1202 | SEC Regulation S-K Item 1202 — Proved Oil and Gas Reserve Disclosures in SEC Filings | Financial reporting | US | verticals/oil-gas-energy.md |
| SEC Regulation S-X Rule 4-10 (17 CFR § 210.4-10) | SEC Regulation S-X Rule 4-10 — Accounting for Oil and Gas Producing Activities (Full-Cost Method Definition; Ceiling Test) | Financial reporting | US | verticals/oil-gas-energy.md |
| SEC Rule 15c2-12 | SEC Rule 15c2-12 — Municipal Securities Continuing Disclosure Requirements | Financial reporting | US | verticals/government-publicsector.md |
| Service Contract Act (41 U.S.C. §§ 6701-6707) | McNamara-O'Hara Service Contract Act — Prevailing Wage and Fringe Benefit Requirements for Federal Service Contracts | Labour / Payroll | US | verticals/construction-realestate.md |
| SFAS 52 | SFAS 52 — Foreign Currency Translation (superseded; codified into ASC 830) | Financial reporting | US | core/architecture.md |
| SFFAS (Statements of Federal Financial Accounting Standards) | Statements of Federal Financial Accounting Standards — US Federal Government Accounting Standards Issued by FASAB | Financial reporting | US | verticals/government-publicsector.md |
| SFFAS 5 | SFFAS 5 — Accounting for Liabilities of the Federal Government (including Pension Obligations) | Financial reporting | US | verticals/government-publicsector.md |
| SFFAS 54 | SFFAS 54 — Leases (US Federal Government Lease Accounting Standard) | Financial reporting | US | verticals/government-publicsector.md |
| Singapore PDPA 2012 (amended 2020/2021) | Singapore Personal Data Protection Act 2012 (significantly amended 2020/2021) | Data privacy | Singapore | core/security.md |
| SOC 1 Type II (SSAE 18 / ISAE 3402) | Service Organization Control 1 Type II Report — Internal Controls over Financial Reporting (SSAE 18 / ISAE 3402) | Audit / Security | Global | core/security.md |
| SOC 2 Type II (AICPA/CIMA Trust Services Criteria) | Service Organization Control 2 Type II Report — Security, Availability, Processing Integrity, Confidentiality, Privacy | Audit / Security | Global | core/security.md |
| Solvency II Directive 2009/138/EC | EU Solvency II Directive 2009/138/EC — Prudential Framework for Insurance and Reinsurance Undertakings (Three-Pillar Structure; SCR, MCR, QRTs) | Financial services / Insurance | EU | verticals/financial-services.md |
| SOP 81-1 | AICPA Statement of Position 81-1 — Accounting for Performance of Construction-Type and Certain Production-Type Contracts (superseded by ASC 606) | Financial reporting | US | verticals/construction-realestate.md |
| South Dakota v. Wayfair Inc. 585 U.S. 162 (2018) | South Dakota v. Wayfair Inc., 585 U.S. 162 (2018) — US Supreme Court Ruling Establishing Economic Nexus for Sales Tax | Tax | US | core/localization-tax.md |
| South Korea PIPA (amended September 2023) | South Korea Personal Information Protection Act (originally 2011; significantly amended effective 15 September 2023) | Data privacy | South Korea | core/security.md |
| SOX Section 302 | Sarbanes-Oxley Act Section 302 — Corporate Responsibility for Financial Reports (CEO/CFO Certifications) | Financial reporting / Audit | US | core/security.md |
| SOX Section 404 | Sarbanes-Oxley Act Section 404 — Management Assessment of Internal Controls over Financial Reporting; External Auditor Attestation per PCAOB AS 2201 | Financial reporting / Audit | US | core/security.md |
| SQF Edition 10 | Safe Quality Food Edition 10 — GFSI-Recognized Food Safety and Quality Management Standard (published March 2026; audits not prior to 2 January 2027) | Quality / Food safety | Global | verticals/agriculture-food.md |
| SQF Edition 9 | Safe Quality Food Edition 9 — GFSI-Recognized Food Safety and Quality Management Standard (current for audits until Edition 10 is permitted) | Quality / Food safety | Global | verticals/agriculture-food.md |
| SWIFT CSP/CSCF v2024 | SWIFT Customer Security Programme — Customer Security Controls Framework v2024 (Mandatory Annual Self-Attestation for SWIFT-Connected Institutions) | Financial services / Security | Global | verticals/financial-services.md |
| TAPA FSR (Freight Security Requirements) | Transported Asset Protection Association Freight Security Requirements — Graded (A/B/C) Warehouse Security Criteria for High-Value Cargo | Supply chain / Security | Global | verticals/distribution-logistics.md |
| TAPA TSR (Trucking Security Requirements) | Transported Asset Protection Association Trucking Security Requirements — Graded (A/B/C) In-Transit Security Criteria for High-Value Cargo | Supply chain / Security | Global | verticals/distribution-logistics.md |
| Texas Natural Resources Code § 91.402 | Texas Natural Resources Code Section 91.402 — statutory deadlines for oil and gas royalty payments (oil: 60 days; gas: 90 days after production month-end) | Oil & gas / Royalties | US (Texas) | verticals/oil-gas-energy.md |
| Texas Property Code Chapter 53 | Texas Property Code Chapter 53 — Mechanic's, Contractor's, or Materialman's Lien; governs lien rights, monthly sworn statements from subcontractors, and constitutional lien provisions for residential projects | Construction / Lien law | US (Texas) | verticals/construction-realestate.md |
| Thailand PDPA B.E. 2562/2019 | Thailand Personal Data Protection Act B.E. 2562 (2019), enforcement effective June 1, 2022 | Data privacy | Thailand | core/security.md |
| TIBER-EU | Threat Intelligence-Based Ethical Red-teaming — European Union framework | Security/Cyber resilience | EU | core/security.md, verticals/financial-services.md |
| Truth in Lending Act (TILA) | Truth in Lending Act — US consumer-protection law (15 U.S.C. §§ 1601 et seq.) requiring disclosure of APR, total payment, and credit terms before commitment | Financial services / Consumer credit | US | verticals/financial-services.md, verticals/retail-ecommerce.md |
| TSA Security Directive Pipeline-2021-01 | Transportation Security Administration Security Directive Pipeline-2021-01 (and subsequent revisions -02, -02C, -02D) — OT/IT cybersecurity requirements for pipeline operators following the Colonial Pipeline ransomware attack | Security/Critical infrastructure | US | verticals/oil-gas-energy.md |
| UAE Federal Decree-Law No. 45 of 2021 | UAE Federal Decree-Law No. 45 of 2021 on Personal Data Protection, effective January 2, 2022; executive regulations issued 2023 | Data privacy | UAE | core/security.md |
| UB-04 / CMS-1450 Revenue Codes | UB-04 / CMS-1450 Revenue Codes — National Uniform Billing Committee (NUBC) revenue codes required on institutional claims (837I) to classify healthcare services | Healthcare / Billing | US | verticals/healthcare-lifesciences.md |
| UBL 2.1 | Universal Business Language version 2.1 — OASIS XML standard for electronic business documents (invoices, orders, despatch advice) used in PEPPOL, ZATCA, and numerous national e-invoicing mandates | Tax/e-invoicing | Global | core/localization-tax.md |
| UBL-TR | UBL 2.1 Turkey Profile — Turkish Revenue Administration (GİB) e-Fatura and e-Arşiv XML format based on UBL 2.1 with Turkish-specific extensions; signed with XAdES | Tax/e-invoicing | Turkey | core/localization-tax.md |
| UETA | Uniform Electronic Transactions Act — NCCUSL model law adopted by 49 US states + DC + PR + USVI granting legal effect to electronic signatures and records | Electronic signatures | US | core/features-core.md |
| UK Companies Act 2006 Section 388 | UK Companies Act 2006 Section 388 — requires retention of accounting records for 6 years (public companies) or 3 years (private companies) | Financial reporting / Records retention | UK | core/security.md |
| UK GDPR | UK General Data Protection Regulation — retained EU law post-Brexit, functionally equivalent to EU GDPR; enforced by the ICO; UK IDTAs govern international transfers | Data privacy | UK | core/security.md, verticals/retail-ecommerce.md |
| UK Procurement Act 2023 | UK Procurement Act 2023, commenced 24 February 2025 — replaces PCR 2015; introduces transparency notices, debarment register, and open frameworks for public procurement | Public sector / Procurement | UK | verticals/government-publicsector.md |
| UN/CEFACT CII 3.0 | UN/CEFACT Cross Industry Invoice version 3.0 — XML schema for structured e-invoices; embedded data layer in Factur-X and ZUGFeRD hybrid formats; EN 16931-compliant | Tax/e-invoicing | Global | core/localization-tax.md |
| UN/EDIFACT (ORDERS, INVOIC, DESADV) | United Nations Electronic Data Interchange for Administration, Commerce and Transport — core message set (ORDERS, INVOIC, DESADV) for international B2B EDI exchanges | Supply chain / EDI | Global | core/architecture.md, core/features-core.md |
| UN/EDIFACT (ORDERS, ORDRSP, DESADV, INVOIC, WHSORD, WHSRSP) | UN/EDIFACT extended message set including warehouse management messages WHSORD (940 equivalent) and WHSRSP (945 equivalent) used in distribution and 3PL EDI | Supply chain / EDI | Global | verticals/distribution-logistics.md |
| UN/EDIFACT DESADV | UN/EDIFACT DESADV — Despatch Advice message (Advance Ship Notice equivalent) | Supply chain / EDI | Global | core/architecture.md, core/features-core.md |
| UN/EDIFACT INVOIC | UN/EDIFACT INVOIC — Invoice message | Supply chain / EDI | Global | core/architecture.md, core/features-core.md |
| UN/EDIFACT ORDERS | UN/EDIFACT ORDERS — Purchase Order message | Supply chain / EDI | Global | core/architecture.md, core/features-core.md |
| Unicode CLDR | Unicode Common Locale Data Repository — provides plural rules, date/time formats, number formats, and other locale data used by ERP i18n engines | Internationalization | Global | core/localization-tax.md |
| UPMIFA (NCCUSL 2006) | Uniform Prudent Management of Institutional Funds Act (NCCUSL 2006) — governs endowment investment and spending for nonprofit institutions; adopted in 49 states + DC + USVI | Nonprofit / Endowment management | US | verticals/education.md, verticals/nonprofit-ngo.md |
| US BSA 31 U.S.C. §§5311–5336 | US Bank Secrecy Act — 31 U.S.C. §§ 5311–5336; requires AML programmes, Currency Transaction Reports (CTRs), Suspicious Activity Reports (SARs), and CDD records | Financial services / AML | US | verticals/financial-services.md |
| US Section 321 de minimis | US Customs Section 321 de minimis exemption — $800 per-person-per-day duty-free threshold; suspended for China/Hong Kong (May 2, 2025) and all origins (August 29, 2025); status confirmed suspended as of February 2026 proclamation | Trade / Customs | US | verticals/retail-ecommerce.md |
| USAID ADS 303 | USAID Automated Directives System 303 — Assistance Instruments; governs USAID grants and cooperative agreements to NGOs; layered on 2 CFR Part 200 via 2 CFR Part 700 | Public sector / Grant compliance | US/Global | verticals/nonprofit-ngo.md |
| W3C Web Authentication (WebAuthn) | W3C Web Authentication (WebAuthn) — standard enabling phishing-resistant FIDO2 hardware-token and passkey authentication; recommended for all privileged ERP accounts | Security / Authentication | Global | core/security.md |
| Wachstumschancengesetz (March 22 2024) | Wachstumschancengesetz (Growth Opportunities Act, Germany, enacted March 22, 2024) — establishes B2B e-invoice mandate: receive by January 1, 2025; issue for revenue > €800K by January 1, 2027; all businesses by January 1, 2028 | Tax/e-invoicing | Germany | core/localization-tax.md |
| XAdES-BES | XML Advanced Electronic Signatures — Basic Electronic Signature profile (ETSI EN 319 132); used for digitally signing e-invoices in Italy (FatturaPA) and other mandates | Electronic signatures / e-invoicing | EU/Global | core/localization-tax.md |
| XLIFF 1.2 | XML Localisation Interchange File Format version 1.2 — OASIS standard for exchanging localizable software resources with language service providers | Internationalization | Global | core/localization-tax.md |
| XLIFF 2.0 | XML Localisation Interchange File Format version 2.0 — OASIS standard; successor to XLIFF 1.2 with modular extension architecture for translation exchange | Internationalization | Global | core/localization-tax.md |
| XML_DTE | XML Documento Tributario Electrónico — Chile's mandatory e-invoice format (clearance model via SII); digitally signed XML; 6-year archiving requirement | Tax/e-invoicing | Chile | core/localization-tax.md |
| ZUGFeRD 2.x | ZUGFeRD version 2.x (version 2.3+ recommended) — hybrid PDF/A-3 plus embedded UN/CEFACT CII XML; EN 16931-compliant; German equivalent of French Factur-X; cross-compatible | Tax/e-invoicing | Germany | core/localization-tax.md |
