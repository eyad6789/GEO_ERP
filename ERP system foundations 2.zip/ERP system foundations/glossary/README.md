# Glossary — Index & Lookup Protocol

The master glossary, split for agent retrieval (the original single file was too large to Read in one call — grep it, don't open it whole).

**1196 acronyms/terms** + **614 standards/regulations** = 1810 entries. Verified 2026-07.

## Files
| Part | Contents |
|---|---|
| `acronyms-a-m.md` | Acronyms & terms, A–M (736) |
| `acronyms-n-z.md` | Acronyms & terms, N–Z + symbols (460) |
| `standards-a-m.md` | Standards/regulations, A–M + numeric (479) |
| `standards-n-z.md` | Standards/regulations, N–Z (135) |

## Lookup protocol (grep-first, never full-read)
```
grep -rni "^| ZATCA " glossary/          # exact term/identifier
grep -rni "e-invoicing" glossary/         # concept search
```
Acronyms columns: `Term | Expansion | Meaning in ERP context | Primary file(s)`.
Standards columns: `Identifier | Full name | Domain | Jurisdiction | Primary file(s)`.
The **Primary file(s)** column routes you to the core/vertical doc with the depth.
