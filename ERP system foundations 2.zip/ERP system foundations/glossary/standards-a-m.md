# Standards, Regulations & Frameworks (A–M, numeric)

| Identifier | Full name | Domain | Jurisdiction | Primary file(s) |
|---|---|---|---|---|
| §147 AO | Abgabenordnung Section 147 (German Fiscal Code § 147) — mandates 10-year retention of tax-relevant records in Germany; ERP document archiving must comply | Tax / Records retention | Germany | core/features-core.md |
| 15 CFR 762.6 | Export Administration Regulations – Recordkeeping (15 CFR 762.6) | Export controls | US | verticals/aerospace-defense.md |
| 15 CFR Parts 730-774 (EAR) | Export Administration Regulations | Export controls | US | verticals/aerospace-defense.md |
| 15 U.S.C. § 6501-6506 (COPPA) | Children's Online Privacy Protection Act | Data privacy | US | core/security.md |
| 18 CFR § 141.1 FERC Form 1 | Federal Energy Regulatory Commission Form 1 – Annual Report of Major Electric Utilities | Energy / Financial reporting | US | verticals/oil-gas-energy.md |
| 18 CFR § 141.11 FERC Form 2 | Federal Energy Regulatory Commission Form 2 – Annual Report of Major Natural Gas Companies | Energy / Financial reporting | US | verticals/oil-gas-energy.md |
| 18 CFR § 141.2 FERC Form 1-F | Federal Energy Regulatory Commission Form 1-F – Annual Report of Nonmajor Public Utilities | Energy / Financial reporting | US | verticals/oil-gas-energy.md |
| 18 CFR § 141.400 FERC Form 3-Q | Federal Energy Regulatory Commission Form 3-Q – Quarterly Financial Report | Energy / Financial reporting | US | verticals/oil-gas-energy.md |
| 2 CFR 200 | Uniform Administrative Requirements, Cost Principles, and Audit Requirements for Federal Awards | Public sector / Grants | US | verticals/government-publicsector.md |
| 2 CFR 200.332 | Requirements for Pass-Through Entities (Uniform Guidance) | Public sector / Grants | US | verticals/government-publicsector.md |
| 2 CFR 200.334 | Retention Requirements for Records (Uniform Guidance) | Public sector / Grants | US | verticals/government-publicsector.md |
| 2 CFR 200.344 | Closeout (Uniform Guidance) | Public sector / Grants | US | verticals/government-publicsector.md |
| 2 CFR 200.414 | Indirect (F&A) Costs (Uniform Guidance) | Public sector / Grants | US | verticals/government-publicsector.md |
| 2 CFR 200.430 | Compensation – Personal Services (Uniform Guidance) | Public sector / Grants | US | verticals/government-publicsector.md |
| 2 CFR 200.501 | Audit Requirements – Single Audit Threshold (Uniform Guidance) | Public sector / Audit | US | verticals/government-publicsector.md |
| 2 CFR Appendix III to Part 200 | Indirect (F&A) Cost Identification and Assignment, and Rate Determination for Institutions of Higher Education (IHEs) | Public sector / Education | US | verticals/education.md |
| 2 CFR Part 200 | Uniform Guidance – Uniform Administrative Requirements, Cost Principles, and Audit Requirements for Federal Awards | Public sector / Grants | US | verticals/government-publicsector.md |
| 2 CFR Part 700 | USAID Uniform Administrative Requirements, Cost Principles, and Audit Requirements for Federal Awards | Public sector / Grants | US | verticals/nonprofit-ngo.md |
| 20 CFR Part 655 Subpart B (H-2A DOL regulations) | Department of Labor Regulations for H-2A Temporary Agricultural Workers | Agriculture / Labor | US | verticals/agriculture-food.md |
| 20 U.S.C. § 1070 (HEA Title IV) | Higher Education Act Title IV – Federal Student Aid | Education / Financial aid | US | verticals/education.md |
| 20 U.S.C. § 1232g (FERPA) | Family Educational Rights and Privacy Act | Education / Data privacy | US | verticals/education.md |
| 21 CFR Part 1 Subpart S (FSMA 204 Food Traceability Rule) | FSMA Section 204 Food Traceability Rule | Food safety / Traceability | US | verticals/agriculture-food.md |
| 21 CFR Part 11 | Electronic Records; Electronic Signatures | Healthcare / Quality | US | verticals/healthcare-lifesciences.md |
| 21 CFR Part 112 (FSMA Produce Safety Rule) | FSMA Standards for the Growing, Harvesting, Packing, and Holding of Produce for Human Consumption | Food safety | US | verticals/agriculture-food.md |
| 21 CFR Part 117 (FSMA Preventive Controls for Human Food) | FSMA Current Good Manufacturing Practice, Hazard Analysis, and Risk-Based Preventive Controls for Human Food | Food safety | US | verticals/agriculture-food.md |
| 21 CFR Part 121 (FSMA Intentional Adulteration Rule) | FSMA Mitigation Strategies to Protect Food Against Intentional Adulteration | Food safety / Security | US | verticals/agriculture-food.md |
| 21 CFR Part 1271 | Human Cells, Tissues, and Cellular and Tissue-Based Products (HCT/Ps) | Healthcare / Biologics | US | verticals/healthcare-lifesciences.md |
| 21 CFR Part 211 | Current Good Manufacturing Practice for Finished Pharmaceuticals | Healthcare / Quality | US | verticals/healthcare-lifesciences.md |
| 21 CFR Part 312 | Investigational New Drug Application | Healthcare / Clinical trials | US | verticals/healthcare-lifesciences.md |
| 21 CFR Part 803 | Medical Device Reporting | Healthcare / Medical devices | US | verticals/healthcare-lifesciences.md |
| 21 CFR Part 820 (QMSR) | Quality Management System Regulation for Medical Devices (effective February 2, 2026) | Healthcare / Quality | US | verticals/healthcare-lifesciences.md |
| 21 CFR Part 830 | Unique Device Identification (UDI) | Healthcare / Medical devices | US | verticals/healthcare-lifesciences.md |
| 21 CFR Parts 210/211 | Current Good Manufacturing Practice for Manufacturing, Processing, Packing, or Holding of Drugs | Healthcare / Quality | US | verticals/healthcare-lifesciences.md |
| 21 CFR §211.68 | Automatic, Mechanical, and Electronic Equipment (cGMP) | Healthcare / Quality | US | verticals/healthcare-lifesciences.md |
| 21 CFR §820.180 | General Requirements for Records (QMSR/QSR) | Healthcare / Quality | US | verticals/healthcare-lifesciences.md |
| 21 U.S.C. § 360eee (DSCSA) | Drug Supply Chain Security Act | Healthcare / Supply chain | US | verticals/healthcare-lifesciences.md |
| 22 CFR 122.5 | International Traffic in Arms Regulations – Registration Requirements | Export controls / Defense | US | verticals/aerospace-defense.md |
| 22 CFR Parts 120-130 (ITAR) | International Traffic in Arms Regulations | Export controls / Defense | US | verticals/aerospace-defense.md |
| 26 U.S.C. § 117 | Gross Income Exclusion – Qualified Scholarships | Education / Tax | US | verticals/education.md |
| 26 U.S.C. § 170(f)(8) | Charitable Contribution Substantiation Requirements | Nonprofit / Tax | US | verticals/nonprofit-ngo.md |
| 26 U.S.C. § 511-514 | Unrelated Business Taxable Income (UBTI) | Nonprofit / Tax | US | verticals/nonprofit-ngo.md |
| 26 U.S.C. § 6033 | Returns by Exempt Organizations | Nonprofit / Tax | US | verticals/nonprofit-ngo.md |
| 26 U.S.C. § 6050S | Returns Relating to Higher Education Tuition and Related Expenses (Form 1098-T) | Education / Tax | US | verticals/education.md |
| 26 U.S.C. § 6103 | Confidentiality and Disclosure of Returns and Return Information | Tax / Data privacy | US | core/security.md |
| 29 CFR Parts 2590 and 2560 | ERISA – Group Health Plan Requirements and Claims Procedure | Healthcare / Employee benefits | US | verticals/healthcare-lifesciences.md |
| 29 U.S.C. 201 et seq. (FLSA) | Fair Labor Standards Act | Labor / Payroll | US | core/features-core.md |
| 30 CFR Part 1210 | Royalty Management – Production Accounting and Auditing | Oil & Gas / Royalties | US | verticals/oil-gas-energy.md |
| 30 CFR § 1218.50 | Collection of Royalties, Rentals, Bonuses, and Other Monies | Oil & Gas / Royalties | US | verticals/oil-gas-energy.md |
| 32 CFR Part 170 (CMMC) | Cybersecurity Maturity Model Certification | Security / Defense | US | core/security.md |
| 34 CFR 668.164 | Disbursing Student Financial Assistance | Education / Financial aid | US | verticals/education.md |
| 34 CFR 668.22 | Treatment of Title IV Funds When a Student Withdraws | Education / Financial aid | US | verticals/education.md |
| 34 CFR 668.24 | Record Retention and Examination (Student Financial Assistance) | Education / Financial aid | US | verticals/education.md |
| 34 CFR 685.309 | Discharge of a Loan Obligation (Direct Loan Program) | Education / Financial aid | US | verticals/education.md |
| 34 CFR Part 668 | Student Assistance General Provisions | Education / Financial aid | US | verticals/education.md |
| 34 CFR Part 674 | Federal Perkins Loan Program | Education / Financial aid | US | verticals/education.md |
| 34 CFR Part 685 | William D. Ford Federal Direct Loan Program | Education / Financial aid | US | verticals/education.md |
| 34 CFR Part 99 (FERPA) | Family Educational Rights and Privacy Act Regulations | Education / Data privacy | US | verticals/education.md |
| 38 U.S.C. § 3313 | Educational Assistance for Veterans – Post-9/11 GI Bill | Education / Veterans benefits | US | verticals/education.md |
| 40 CFR Part 170 (Worker Protection Standard) | EPA Worker Protection Standard for Agricultural Pesticides | Agriculture / Safety | US | verticals/agriculture-food.md |
| 40 CFR Part 98 EPA GHGRP | EPA Mandatory Greenhouse Gas Reporting Rule | Environmental / ESG | US | verticals/oil-gas-energy.md |
| 42 U.S.C. § 17901 et seq. (HITECH Act) | Health Information Technology for Economic and Clinical Health Act | Healthcare / Data privacy | US | verticals/healthcare-lifesciences.md |
| 45 CFR Part 164, Subpart C (HIPAA Security Rule) | HIPAA Security Rule | Healthcare / Data privacy | US | verticals/healthcare-lifesciences.md |
| 45 CFR Part 164, Subpart E (HIPAA Privacy Rule) | HIPAA Privacy Rule | Healthcare / Data privacy | US | verticals/healthcare-lifesciences.md |
| 45 CFR §§ 164.400–414 (HIPAA Breach Notification Rule) | HIPAA Breach Notification Rule | Healthcare / Data privacy | US | verticals/healthcare-lifesciences.md |
| 48 CFR Part 9903 | Cost Accounting Standards (CAS) Board Rules and Regulations | Financial reporting / Government contracts | US | verticals/government-publicsector.md |
| 49 CFR (U.S. HazMat / PHMSA) | Hazardous Materials Regulations (Pipeline and Hazardous Materials Safety Administration) | Transportation / Safety | US | verticals/distribution-logistics.md |
| 49 CFR Parts 190-199 PHMSA | Pipeline Safety Regulations (PHMSA) | Oil & Gas / Pipeline safety | US | verticals/oil-gas-energy.md |
| 49 CFR Parts 191 and 195 | Pipeline Safety: Gas and Hazardous Liquid Pipeline Reporting | Oil & Gas / Pipeline safety | US | verticals/oil-gas-energy.md |
| 7 CFR Part 205 (USDA National Organic Program) | USDA National Organic Program | Agriculture / Organic certification | US | verticals/agriculture-food.md |
| 8 U.S.C. 1101(a)(15)(H)(ii)(a) (H-2A) | Immigration and Nationality Act – H-2A Temporary Agricultural Worker Visa Classification | Agriculture / Labor / Immigration | US | verticals/agriculture-food.md |
| 87 FR 70752 (FSMA 204 Final Rule) | FSMA Section 204 Food Traceability Rule – Final Rule (21 Nov 2022) | Food safety / Traceability | US | verticals/agriculture-food.md |
| 9 CFR Part 416 (USDA FSIS Sanitation SOPs) | USDA FSIS Sanitation Standard Operating Procedures | Food safety | US | verticals/agriculture-food.md |
| 9 CFR Part 417 (USDA FSIS HACCP) | USDA FSIS Hazard Analysis and Critical Control Points Systems | Food safety | US | verticals/agriculture-food.md |
| 90 FR 2025-14967 (FSMA 204 compliance date extension) | FSMA Section 204 Food Traceability Rule – Compliance Date Extension (7 Aug 2025) | Food safety / Traceability | US | verticals/agriculture-food.md |
| A New Tax System (Goods and Services Tax) Act 1999 | A New Tax System (Goods and Services Tax) Act 1999 | Tax / GST | Australia | core/localization-tax.md |
| ABA Model Rules Rule 1.15 | ABA Model Rules of Professional Conduct – Rule 1.15 (Safekeeping Property) | Legal / Professional services | US | verticals/professional-services.md |
| ABA Model Rules Rule 1.5 | ABA Model Rules of Professional Conduct – Rule 1.5 (Fees) | Legal / Professional services | US | verticals/professional-services.md |
| ADGM Data Protection Regulations 2021 | Abu Dhabi Global Market Data Protection Regulations 2021 | Data privacy | UAE | core/security.md |
| ADR 2025 (UNECE) | European Agreement Concerning the International Carriage of Dangerous Goods by Road (2025 edition) | Transportation / Hazardous goods | Global | verticals/distribution-logistics.md |
| AIA A312-2010 | AIA Document A312-2010 – Performance Bond and Payment Bond | Construction / Surety | US | verticals/construction-realestate.md |
| AIA G702-2017 | AIA Document G702-2017 – Application and Certificate for Payment | Construction / Financial | US | verticals/construction-realestate.md |
| AIA G703-2017 | AIA Document G703-2017 – Continuation Sheet | Construction / Financial | US | verticals/construction-realestate.md |
| AIAG MMOG/LE | Automotive Industry Action Group Materials Management Operations Guideline / Logistics Evaluation | Manufacturing / Automotive supply chain | Global | verticals/manufacturing.md |
| AIAG MSA 4th Edition | Automotive Industry Action Group Measurement System Analysis Reference Manual, 4th Edition | Manufacturing / Quality | Global | verticals/manufacturing.md |
| AIAG SPC 2nd Edition | Automotive Industry Action Group Statistical Process Control Reference Manual, 2nd Edition | Manufacturing / Quality | Global | verticals/manufacturing.md |
| AIAG-VDA FMEA Handbook 1st Edition (June 2019) | AIAG & VDA Failure Mode and Effects Analysis Handbook, 1st Edition | Manufacturing / Quality / Risk | Global | verticals/manufacturing.md |
| ANSI ASC X12 (850, 810, 856, 820, 940) | American National Standards Institute ASC X12 EDI Transaction Sets (Purchase Order, Invoice, Ship Notice, Payment, Warehouse Shipping Order) | EDI / Supply chain | US | verticals/distribution-logistics.md |
| ANSI X12 | American National Standards Institute ASC X12 Electronic Data Interchange Standards | EDI / Supply chain | US | verticals/distribution-logistics.md |
| ANSI X12 810 | ANSI X12 EDI Transaction Set 810 (Invoice) | EDI/Supply chain | US/Global | verticals/distribution-logistics.md |
| ANSI X12 850 | ANSI X12 EDI Transaction Set 850 (Purchase Order) | EDI/Supply chain | US/Global | verticals/distribution-logistics.md |
| ANSI X12 856 | ANSI X12 EDI Transaction Set 856 (Ship Notice/Manifest) | EDI/Supply chain | US/Global | verticals/distribution-logistics.md |
| ANSI/ASHRAE/IES Standard 90.1-2022 | Energy Standard for Sites and Buildings Except Low-Rise Residential Buildings | Energy/Building | US | verticals/construction-realestate.md |
| ANSI/EIA-748-E | Earned Value Management Systems (EVMS) Standard (February 2026) | Project management | US | verticals/aerospace-defense.md |
| ANSI/ISA-95 / IEC 62264 | Enterprise-Control System Integration (Manufacturing Operations Management interface standard) | Quality / Manufacturing | Global | verticals/manufacturing.md |
| Anti-Deficiency Act (31 USC § 1341) | Anti-Deficiency Act — prohibition on federal obligations exceeding appropriations | Public sector/Financial | US | verticals/government-publicsector.md |
| APQP | Advanced Product Quality Planning (AIAG APQP) | Quality/Manufacturing | Global | verticals/manufacturing.md |
| Article 196 Directive 2006/112/EC | EU VAT Directive Article 196 — Reverse charge for services supplied by non-established taxable persons | Tax/VAT | EU | core/localization-tax.md |
| Article 199 Directive 2006/112/EC | EU VAT Directive Article 199 — Reverse charge for specific domestic supplies (construction, scrap, etc.) | Tax/VAT | EU | core/localization-tax.md |
| Articles 262-271 Directive 2006/112/EC | EU VAT Directive Articles 262-271 — EC Sales List (recapitulative statement) obligations | Tax/VAT | EU | core/localization-tax.md |
| AS2 | Applicability Statement 2 (EDI-over-HTTPS transport protocol, RFC 4130) | EDI/Data exchange | Global | verticals/distribution-logistics.md |
| AS5553E | Fraudulent/Counterfeit Electronic Parts — Avoidance, Detection, Mitigation and Disposition (SAE AS5553E, November 2025) | Aerospace/Defense | Global | verticals/aerospace-defense.md |
| AS9100:2016 Rev D | Quality Management Systems — Requirements for Aviation, Space, and Defense Organizations | Quality/Aerospace | Global | verticals/aerospace-defense.md |
| AS9102B | Aerospace First Article Inspection Requirement (Revision B) | Aerospace/Quality | Global | verticals/aerospace-defense.md |
| AS9102C | Aerospace First Article Inspection Requirement (Revision C, July 2023) | Aerospace/Quality | Global | verticals/aerospace-defense.md |
| AS9110C | Quality Management Systems — Requirements for Aviation Maintenance Organizations | Quality/Aerospace | Global | verticals/aerospace-defense.md |
| AS9120:2016 Rev B | Quality Management Systems — Requirements for Aviation, Space, and Defense Distributors | Quality/Aerospace | Global | verticals/aerospace-defense.md |
| ASC 205 | FASB Accounting Standards Codification Topic 205 (Presentation of Financial Statements) | Financial reporting | US | verticals/financial-services.md |
| ASC 225 | FASB Accounting Standards Codification Topic 225 (Income Statement) | Financial reporting | US | verticals/financial-services.md |
| ASC 230 | FASB Accounting Standards Codification Topic 230 (Statement of Cash Flows) | Financial reporting | US | verticals/financial-services.md |
| ASC 310 | FASB Accounting Standards Codification Topic 310 (Receivables) | Financial reporting | US | verticals/financial-services.md |
| ASC 326 | FASB Accounting Standards Codification Topic 326 (Credit Losses — CECL) | Financial reporting | US | verticals/financial-services.md |
| ASC 330 | FASB Accounting Standards Codification Topic 330 (Inventory) | Financial reporting | US | verticals/manufacturing.md |
| ASC 340-40 | FASB Accounting Standards Codification Topic 340-40 (Costs to Obtain or Fulfill a Contract with a Customer) | Financial reporting | US | verticals/professional-services.md |
| ASC 410 | FASB Accounting Standards Codification Topic 410 (Asset Retirement and Environmental Obligations) | Financial reporting | US | verticals/oil-gas-energy.md |
| ASC 606 | FASB Accounting Standards Codification Topic 606 (Revenue from Contracts with Customers) | Financial reporting | US | core/features-core.md |
| ASC 715 | FASB Accounting Standards Codification Topic 715 (Compensation — Retirement Benefits) | Financial reporting | US | verticals/financial-services.md |
| ASC 810 | FASB Accounting Standards Codification Topic 810 (Consolidation) | Financial reporting | US | verticals/financial-services.md |
| ASC 815 | FASB Accounting Standards Codification Topic 815 (Derivatives and Hedging) | Financial reporting | US | verticals/financial-services.md |
| ASC 820 | FASB Accounting Standards Codification Topic 820 (Fair Value Measurement) | Financial reporting | US | verticals/financial-services.md |
| ASC 830 | FASB Accounting Standards Codification Topic 830 (Foreign Currency Matters) | Financial reporting | US | core/localization-tax.md |
| ASC 842 | FASB Accounting Standards Codification Topic 842 (Leases) | Financial reporting | US | core/features-core.md |
| ASC 910 | FASB Accounting Standards Codification Topic 910 (Contractors — Construction) | Financial reporting | US | verticals/construction-realestate.md |
| ASC 944 | FASB Accounting Standards Codification Topic 944 (Financial Services — Insurance) | Financial reporting | US | verticals/financial-services.md |
| ASC X12 270/271 | ANSI X12 EDI Transaction Sets 270/271 (Healthcare Eligibility Benefit Inquiry and Response) | Healthcare/EDI | US | verticals/healthcare-lifesciences.md |
| ASC X12 277CA | ANSI X12 EDI Transaction Set 277CA (Healthcare Claim Acknowledgment) | Healthcare/EDI | US | verticals/healthcare-lifesciences.md |
| ASC X12 834 | ANSI X12 EDI Transaction Set 834 (Benefit Enrollment and Maintenance) | Healthcare/EDI | US | verticals/healthcare-lifesciences.md |
| ASC X12 835 | ANSI X12 EDI Transaction Set 835 (Healthcare Claim Payment/Advice) | Healthcare/EDI | US | verticals/healthcare-lifesciences.md |
| ASC X12 837D | ANSI X12 EDI Transaction Set 837D (Dental Healthcare Claim) | Healthcare/EDI | US | verticals/healthcare-lifesciences.md |
| ASC X12 837I | ANSI X12 EDI Transaction Set 837I (Institutional Healthcare Claim) | Healthcare/EDI | US | verticals/healthcare-lifesciences.md |
| ASC X12 837P | ANSI X12 EDI Transaction Set 837P (Professional Healthcare Claim) | Healthcare/EDI | US | verticals/healthcare-lifesciences.md |
| ASC X12 997 | ANSI X12 EDI Transaction Set 997 (Functional Acknowledgment) | EDI | US/Global | verticals/distribution-logistics.md |
| ASC X12 999 | ANSI X12 EDI Transaction Set 999 (Implementation Acknowledgment) | EDI | US/Global | verticals/distribution-logistics.md |
| ASC X12 EDI 830 | ANSI X12 EDI Transaction Set 830 (Planning Schedule with Release Capability) | EDI/Supply chain | US/Global | verticals/manufacturing.md |
| ASC X12 EDI 862 | ANSI X12 EDI Transaction Set 862 (Shipping Schedule) | EDI/Supply chain | US/Global | verticals/manufacturing.md |
| ASC X12 version 4010 | ANSI X12 EDI Standard Version 4010 | EDI | US | verticals/healthcare-lifesciences.md |
| ASC X12 version 5010 | ANSI X12 EDI Standard Version 5010 | EDI | US | verticals/healthcare-lifesciences.md |
| Australia Privacy Act 1988 | Privacy Act 1988 (Cth) — Australian federal privacy legislation | Data privacy | Australia | core/security.md |
| Australia Privacy Principles (APP) 11 | Australian Privacy Principle 11 — Security of Personal Information | Data privacy | Australia | core/security.md |
| BACSTEL-IP Standard 18 | BACSTEL-IP Standard 18 — UK Bacs Approved Bureau security standard | Banking/Payments | UK | verticals/financial-services.md |
| BAI2 | Bank Administration Institute Cash Management Balance Reporting Specification Version 2 | Banking/Financial | US/Global | verticals/financial-services.md |
| Bank Secrecy Act | Bank Secrecy Act (31 USC § 5311 et seq.) — US anti-money-laundering reporting requirements | Financial/AML | US | verticals/financial-services.md |
| Basel III | Basel III — International Regulatory Framework for Banks (BCBS 2010, revised 2017) | Banking/Capital adequacy | Global | verticals/financial-services.md |
| Basel IV / Final Basel III | Final Basel III Framework (BCBS December 2017) — Revised standardised and internal model approaches for credit, market, and operational risk | Banking/Capital adequacy | Global | verticals/financial-services.md |
| BCBS 239 | Principles for Effective Risk Data Aggregation and Risk Reporting (January 2013) | Banking/Risk | Global | verticals/financial-services.md |
| BCBS 248 | Basel Committee on Banking Supervision — Sound Principles for the Management and Supervision of Operational Risk | Banking/Risk | Global | verticals/financial-services.md |
| BPMN 2.0 | Business Process Model and Notation 2.0 (OMG standard) | Business process | Global | core/architecture.md |
| Brazil LGPD Law No. 13.709/2018 | Lei Geral de Proteção de Dados Pessoais (LGPD) — Brazilian General Data Protection Law | Data privacy | Brazil | core/security.md |
| BRCGS Food Safety Issue 9 | BRCGS Global Standard for Food Safety Issue 9 | Food safety/Quality | Global | verticals/agriculture-food.md |
| BSI TR-03153 | BSI Technical Guideline TR-03153 — Technical Security Systems for Electronic Cash Registers (TSE) | Tax/Fiscal | Germany | core/localization-tax.md |
| C-TPAT | Customs-Trade Partnership Against Terrorism — CBP five-tier program | Trade/Customs | US | verticals/distribution-logistics.md |
| CA AB 1584 (SOPIPA) | California Assembly Bill 1584 — Student Online Personal Information Protection Act (SOPIPA) | Data privacy/Education | US (California) | verticals/education.md |
| CAC Standard Contract (June 2023) | Cyberspace Administration of China Standard Contract for Cross-Border Transfer of Personal Information (June 2023) | Data privacy | China | core/security.md |
| California Civil Code §§ 8000-8848 | California Mechanics Lien Law | Construction | US | verticals/construction-realestate.md |
| California Civil Code §§ 8132-8138 | California Preliminary Notice Requirements | Construction | US | verticals/construction-realestate.md |
| California DIR prevailing wage | California Department of Industrial Relations Prevailing Wage Requirements | Labor/Construction | US | verticals/construction-realestate.md |
| California IWC Wage Order No. 14 | California Industrial Welfare Commission Wage Order No. 14 (Agricultural Occupations) | Labor/Agriculture | US | verticals/agriculture-food.md |
| California SB 61 (Civil Code § 8811) | California Senate Bill 61 — Stop Payment Notice Rights | Construction | US | verticals/construction-realestate.md |
| camt.052.001.0x | ISO 20022 camt.052 Bank-to-Customer Account Report (intraday) — equivalent to SWIFT MT942; used for intraday liquidity monitoring in ERP cash management | Banking / Payments | Global | core/localization-tax.md |
| camt.053.001.0x | ISO 20022 camt.053 Bank-to-Customer Statement — equivalent to SWIFT MT940; used for end-of-day bank reconciliation in ERP | Banking / Payments | Global | core/localization-tax.md |
| camt.054.001.0x | ISO 20022 camt.054 Bank-to-Customer Debit/Credit Notification — equivalent to SWIFT MT900/MT910; used for individual transaction notification in ERP cash management | Banking / Payments | Global | core/localization-tax.md |
| Canada PIPEDA | Personal Information Protection and Electronic Documents Act | Data privacy | Canada | core/localization-tax.md |
| CAS 401 | Cost Accounting Standard 401 — Consistency in Estimating, Accumulating and Reporting Costs (48 CFR Chapter 99) | Government contracting | US | verticals/government-publicsector.md |
| CAS 402 | Cost Accounting Standard 402 — Consistency in Allocating Costs Incurred for the Same Purpose (48 CFR Chapter 99) | Government contracting | US | verticals/government-publicsector.md |
| CAS 405 | Cost Accounting Standard 405 — Accounting for Unallowable Costs (48 CFR Chapter 99) | Government contracting | US | verticals/government-publicsector.md |
| CAS 406 | Cost Accounting Standard 406 — Cost Accounting Period (48 CFR Chapter 99) | Government contracting | US | verticals/government-publicsector.md |
| CAS 418 | Cost Accounting Standard 418 — Allocation of Direct and Indirect Costs (48 CFR Chapter 99) | Government contracting | US | verticals/government-publicsector.md |
| CCPA | California Consumer Privacy Act (Cal. Civil Code § 1798.100 et seq.) | Data privacy | US (California) | core/security.md |
| CFDI 4.0 | Comprobante Fiscal Digital por Internet version 4.0 — Mexican electronic invoice standard (SAT) | Tax/E-invoicing | Mexico | core/localization-tax.md |
| China PIPL (2021) | China Personal Information Protection Law | Data privacy | China | core/localization-tax.md |
| CISA BOD 22-01 | CISA Binding Operational Directive 22-01 — Reducing the Significant Risk of Known Exploited Vulnerabilities | Security/Cybersecurity | US | core/security.md |
| CMMC 2.0 | Cybersecurity Maturity Model Certification 2.0 (32 CFR Part 170; 48 CFR DFARS) | Security/Defense | US | verticals/aerospace-defense.md |
| Codex Alimentarius CXC 1-1969 (revised 2020) | General Principles of Food Hygiene (HACCP System) | Food safety | Global | verticals/agriculture-food.md |
| Colombia Decree 1377 of 2013 | Colombia Personal Data Protection Regulatory Decree | Data privacy | Colombia | core/localization-tax.md |
| Colombia Statutory Law 1581 of 2012 | Colombia Personal Data Protection Law | Data privacy | Colombia | core/localization-tax.md |
| Commission Delegated Regulation (EU) 2025/1496 | EU Delegated Regulation supplementing DORA on ITS oversight | Security/Financial services | EU | verticals/financial-services.md |
| Commission Delegated Regulation (EU) 2025/2152 | EU Delegated Regulation supplementing CRR3 on own funds | Financial reporting | EU | verticals/financial-services.md |
| Constitutional Amendment 132/2023 (Brazil) | Brazil Tax Reform Constitutional Amendment (CBS/IBS) | Tax/e-invoicing | Brazil | core/localization-tax.md |
| COPAS MF-8 2022 | Council of Petroleum Accountants Societies Model Form Accounting Procedure for Joint Operations 2022 | Oil & Gas/Accounting | US | verticals/oil-gas-energy.md |
| COPAS MFI-45 | Council of Petroleum Accountants Societies Model Form Interpretation 45 | Oil & Gas/Accounting | US | verticals/oil-gas-energy.md |
| COPAS MFI-58 2022 | Council of Petroleum Accountants Societies Model Form Accounting Procedure Interpretation 58 (2022) | Oil & Gas/Accounting | US | verticals/oil-gas-energy.md |
| Corporate Transparency Act (2021) | Corporate Transparency Act — Beneficial Ownership Reporting | Financial reporting/Compliance | US | verticals/financial-services.md |
| Council Directive 2006/112/EC | EU VAT Directive | Tax/e-invoicing | EU | core/localization-tax.md |
| CPRA | California Privacy Rights Act | Data privacy | US | core/security.md |
| CPT (AMA) | Current Procedural Terminology (American Medical Association) | Healthcare | US | verticals/healthcare-lifesciences.md |
| CRD6 Directive (EU) 2024/1619 | Capital Requirements Directive 6 | Financial services | EU | verticals/financial-services.md |
| CRR3 Regulation (EU) 2024/1623 | Capital Requirements Regulation 3 (Basel III implementation) | Financial services | EU | verticals/financial-services.md |
| CSI MasterFormat 2016 | Construction Specifications Institute MasterFormat 2016 Edition | Construction | Global | verticals/construction-realestate.md |
| cXML | Commerce XML — Ariba/SAP punchout catalog and procurement document standard used for eProcurement integrations between ERP and supplier catalogs | Procurement / e-commerce integration | Global | verticals/education.md |
| D406 | AIADA/AIA Document D406 — Digital Practice Documents | Construction | US | verticals/construction-realestate.md |
| DATA Act (P.L. 113-101) | Digital Accountability and Transparency Act of 2014 | Public sector/Financial reporting | US | verticals/government-publicsector.md |
| Data Protection Act 2018 | UK Data Protection Act 2018 | Data privacy | UK | core/security.md |
| Davis-Bacon Act (40 U.S.C. §§ 3141-3148) | Davis-Bacon and Related Acts — Federal Prevailing Wage | Labor/Construction | US | verticals/construction-realestate.md |
| Davis-Bacon Related Acts | Davis-Bacon Related Acts — Federally Assisted Construction Prevailing Wage | Labor/Construction | US | verticals/construction-realestate.md |
| DDMRP (APICS/ASCM) | Demand-Driven Material Requirements Planning (APICS/ASCM Standard) | Manufacturing/Supply chain | Global | verticals/manufacturing.md |
| Decision (EU) 2024/3150 | EU Decision 2024/3150 (implementing measure under financial services regulation) | Financial services | EU | verticals/financial-services.md |
| Delegated Regulation (EU) 2015/35 | EU Delegated Regulation 2015/35 — Solvency II | Financial services/Insurance | EU | verticals/financial-services.md |
| Delegated Regulation (EU) 2015/61 | EU Delegated Regulation 2015/61 — Liquidity Coverage Requirement (LCR) | Financial services | EU | verticals/financial-services.md |
| DFARS 252.204-7012 | Defense Federal Acquisition Regulation Supplement — Safeguarding Covered Defense Information | Security/Defense | US | verticals/aerospace-defense.md |
| DFARS 252.204-7019 | DFARS Clause — NIST SP 800-171 DoD Assessment Requirements | Security/Defense | US | verticals/aerospace-defense.md |
| DFARS 252.204-7020 | DFARS Clause — NIST SP 800-171 DoD Assessment Requirements (Medium/High) | Security/Defense | US | verticals/aerospace-defense.md |
| DFARS 252.234-7002 | DFARS Clause — Earned Value Management System | Program management/Defense | US | verticals/aerospace-defense.md |
| DFARS 252.234-7998 | DFARS Clause — EVMS Implementation (deviation) | Program management/Defense | US | verticals/aerospace-defense.md |
| DFARS 252.234-7999 | DFARS Clause — EVMS Compliance (deviation) | Program management/Defense | US | verticals/aerospace-defense.md |
| DFARS 252.242-7005 | DFARS Clause — Contractor Business Systems | Defense contracting | US | verticals/aerospace-defense.md |
| DFARS 252.242-7006 | DFARS Clause — Accounting System Administration | Defense contracting | US | verticals/aerospace-defense.md |
| DFARS Class Deviation 2026-O0011 | DFARS Class Deviation 2026-O0011 (CMMC/cybersecurity) | Security/Defense | US | verticals/aerospace-defense.md |
| DFARS — 48 CFR Chapter 2 | Defense Federal Acquisition Regulation Supplement | Defense contracting | US | verticals/aerospace-defense.md |
| DI-MGMT-81861 | Data Item Description — Integrated Master Schedule (IMS) | Defense/Program management | US | verticals/aerospace-defense.md |
| DIAN Resolution 000119/2024 | Colombia DIAN Resolution 000119/2024 — Electronic Invoicing | Tax/e-invoicing | Colombia | core/localization-tax.md |
| DIFC Data Protection Law 2020 | Dubai International Financial Centre Data Protection Law 2020 | Data privacy | UAE | core/localization-tax.md |
| Directive (EU) 2024/1640 | EU Anti-Money Laundering Directive 2024 (6th AMLD recast) | Financial services/AML | EU | verticals/financial-services.md |
| Directive (EU) 2025/2 | EU Directive 2025/2 (financial markets) | Financial services | EU | verticals/financial-services.md |
| DoD Instruction 5000.02 | DoD Instruction 5000.02 — Operation of the Adaptive Acquisition Framework | Defense acquisition | US | verticals/aerospace-defense.md |
| DOL 2023 Davis-Bacon Final Rule (88 Fed. Reg. 57526) | Department of Labor 2023 Davis-Bacon Final Rule | Labor/Construction | US | verticals/construction-realestate.md |
| DOL Form WH-347 (rev. January 2025) | Department of Labor Certified Payroll Form WH-347 | Labor/Construction | US | verticals/construction-realestate.md |
| DORA Regulation (EU) 2022/2554 | Digital Operational Resilience Act | Security/Financial services | EU | verticals/financial-services.md |
| DSCSA (Public Law 113-54) | Drug Supply Chain Security Act | Healthcare/Pharma | US | verticals/healthcare-lifesciences.md |
| EAR (15 CFR Parts 730-774) | Export Administration Regulations | Trade/Defense | US | verticals/aerospace-defense.md |
| EASA Part 145 | EASA Regulation Part 145 — Approved Maintenance Organisations | Aerospace/MRO | EU | verticals/aerospace-defense.md |
| EBA Guidelines EBA/GL/2019/02 | EBA Guidelines on ICT and Security Risk Management | Security/Financial services | EU | verticals/financial-services.md |
| EBICS 3.0 | Electronic Banking Internet Communication Standard 3.0 | Financial services/Payments | EU | verticals/financial-services.md |
| ECB Regulation (EU) 2016/867 (ECB/2016/13) | ECB Regulation on the Collection of Granular Credit and Credit Risk Data (AnaCredit) | Financial services | EU | verticals/financial-services.md |
| ECHO FAFA | European Commission Humanitarian Office Framework Agreement for Humanitarian Aid | Nonprofit/Aid | EU | verticals/nonprofit-ngo.md |
| EDI X12 | ANSI ASC X12 Electronic Data Interchange Standard | Supply chain/Integration | Global | verticals/distribution-logistics.md |
| EDI X12 856 | ANSI ASC X12 856 — Advance Ship Notice (ASN) | Supply chain/Integration | Global | verticals/distribution-logistics.md |
| EDI X12 861 | ANSI ASC X12 861 — Receiving Advice/Acceptance Certificate | Supply chain/Integration | Global | verticals/distribution-logistics.md |
| EDIFACT | UN/EDIFACT — United Nations Electronic Data Interchange for Administration, Commerce and Transport | Supply chain/Integration | Global | verticals/distribution-logistics.md |
| eIDAS Regulation (EU) No 910/2014 | EU Regulation No 910/2014 on Electronic Identification and Trust Services (eIDAS) — establishes legal framework for electronic signatures (SES, AdES, QES), seals, timestamps, and registered delivery services across EU member states | Electronic signatures / Identity | EU | core/features-core.md, core/localization-tax.md |
| EN 16931:2017+A1:2019 | European Standard for Electronic Invoicing (Core Invoice Usage Specification) | Tax/e-invoicing | EU | core/localization-tax.md |
| ENERGY STAR | EPA ENERGY STAR Program | Energy/Environmental | US | verticals/oil-gas-energy.md |
| EPA PFAS Reporting Rule (2024) | EPA Per- and Polyfluoroalkyl Substances (PFAS) Reporting Rule under TSCA Section 8(a)(7) | Environmental | US | verticals/manufacturing.md |
| ESIGN Act 15 U.S.C. §7001 | Electronic Signatures in Global and National Commerce Act | Legal/Digital signatures | US | core/features-core.md |
| EU 4th AMLD Directive 2015/849/EU | Fourth EU Anti-Money Laundering Directive | Financial services/AML | EU | verticals/financial-services.md |
| EU 5th AMLD Directive 2018/843/EU | Fifth EU Anti-Money Laundering Directive | Financial services/AML | EU | verticals/financial-services.md |
| EU 6th AMLD (criminal) Directive 2018/1673/EU | Sixth EU Anti-Money Laundering Directive (criminal law) | Financial services/AML | EU | verticals/financial-services.md |
| EU Annex 11 (EudraLex Vol. 4 Annex 11) | EudraLex Volume 4 Annex 11 — Computerised Systems (GMP) | Healthcare/Pharma | EU | verticals/healthcare-lifesciences.md |
| EU Consumer Rights Directive 2011/83/EU | EU Consumer Rights Directive | Retail/Consumer protection | EU | verticals/retail-ecommerce.md |
| EU DAC6 Directive 2018/822/EU | EU Directive on Mandatory Disclosure of Cross-Border Tax Arrangements | Tax | EU | core/localization-tax.md |
| EU Directive 2014/24/EU | EU Public Procurement Directive | Public sector | EU | verticals/government-publicsector.md |
| EU Directive 2022/2523 | EU Directive implementing Pillar Two Global Minimum Tax (15%) | Tax | EU | core/localization-tax.md |
| EU FMD 2011/62/EU | EU Falsified Medicines Directive | Healthcare/Pharma | EU | verticals/healthcare-lifesciences.md |
| EU Food Information Regulation (EC) No 1169/2011 | EU Food Information to Consumers Regulation | Food safety/Retail | EU | verticals/agriculture-food.md |
| EU GDP Guideline 2013/C 343/01 | EU Good Distribution Practice Guideline for Medicinal Products | Healthcare/Pharma | EU | verticals/healthcare-lifesciences.md |
| EU GMP (EudraLex Vol. 4) | EU Good Manufacturing Practice — EudraLex Volume 4 | Healthcare/Pharma | EU | verticals/healthcare-lifesciences.md |
| EU GPSR 2023/988 | EU General Product Safety Regulation | Retail/Consumer safety | EU | verticals/retail-ecommerce.md |
| EU Methane Regulation (EU) 2024/1787 | EU Methane Emissions Regulation for the Energy Sector | Energy/Environmental | EU | verticals/oil-gas-energy.md |
| EU REACH (EC) No 1907/2006 | EU Regulation on Registration, Evaluation, Authorisation and Restriction of Chemicals | Environmental/Manufacturing | EU | verticals/manufacturing.md |
| EU Regulation (EU) 2016/679 (GDPR) | General Data Protection Regulation | Data privacy | EU | core/security.md |
| EU Regulation (EU) 952/2013 (Union Customs Code) | EU Union Customs Code | Trade/Customs | EU | core/localization-tax.md |
| EU RoHS Directive 2011/65/EU | Restriction of Hazardous Substances Directive 2011/65/EU | Environmental/Manufacturing | EU | verticals/manufacturing.md |
| EU Textile Regulation 1007/2011 | Textile Fibre Names and Related Labelling Regulation (EU) No 1007/2011 | Retail/Labelling | EU | verticals/retail-ecommerce.md |
| EU VAT Directive 2006/112/EC | Council Directive 2006/112/EC on the Common System of Value Added Tax | Tax/e-invoicing | EU | core/localization-tax.md |
| EU VAT IOSS (Import One-Stop Shop) | EU VAT Import One-Stop Shop scheme for distance sales of imported goods | Tax/e-invoicing | EU | core/localization-tax.md |
| EU Working Time Directive 2003/88/EC | Directive 2003/88/EC concerning certain aspects of the organisation of working time | Labour/HR | EU | core/localization-tax.md |
| (EU) 2018/848 | EU Organic Regulation | Agriculture / Organic certification | EU | verticals/agriculture-food.md |
| EudraLex Vol. 4 Chapter 3 (GDP guidelines) | EudraLex Volume 4 Good Manufacturing Practice Chapter 3 — Premises and Equipment (also Good Distribution Practice guidelines) | Healthcare/Pharmaceuticals | EU | verticals/healthcare-lifesciences.md |
| EudraLex Vol. 4, Annex 11 (2011) | EudraLex Volume 4 GMP Annex 11 — Computerised Systems (2011) | Healthcare/Pharmaceuticals | EU | verticals/healthcare-lifesciences.md |
| EudraLex Vol. 4, Annex 13 | EudraLex Volume 4 GMP Annex 13 — Manufacture of Investigational Medicinal Products | Healthcare/Pharmaceuticals | EU | verticals/healthcare-lifesciences.md |
| FAA 14 CFR Part 145 | Federal Aviation Regulations Part 145 — Repair Stations | Aerospace | US | verticals/aerospace-defense.md |
| FAA AC 120-16 | FAA Advisory Circular 120-16 — Air Carrier Maintenance Programs | Aerospace | US | verticals/aerospace-defense.md |
| Fair Housing Act (42 U.S.C. §§ 3601-3619) | Fair Housing Act — prohibition of discrimination in housing | Real estate/Finance | US | verticals/construction-realestate.md |
| False Claims Act 31 U.S.C. §§ 3729–3733 | False Claims Act — civil and criminal penalties for fraudulent government claims | Government Contracting | US | verticals/government-publicsector.md |
| FAR 31.201-2 | Federal Acquisition Regulation 31.201-2 — Determining Allowability of Contract Costs | Government Contracting | US | verticals/government-publicsector.md |
| FAR 31.205 | Federal Acquisition Regulation 31.205 — Selected Costs (allowable/unallowable cost categories) | Government Contracting | US | verticals/government-publicsector.md |
| FAR 31.205-33(f) | Federal Acquisition Regulation 31.205-33(f) — Professional and Consultant Service Costs | Government Contracting | US | verticals/government-publicsector.md |
| FAR 4.703 | Federal Acquisition Regulation 4.703 — Contractor Record Retention | Government Contracting | US | verticals/government-publicsector.md |
| FAR 52.204-21 | Federal Acquisition Regulation Clause 52.204-21 — Basic Safeguarding of Covered Contractor Information Systems | Security | US | verticals/aerospace-defense.md |
| FAR 52.215-2 | Federal Acquisition Regulation Clause 52.215-2 — Audit and Records — Negotiation | Government Contracting | US | verticals/government-publicsector.md |
| FAR 52.216-7 | Federal Acquisition Regulation Clause 52.216-7 — Allowable Cost and Payment | Government Contracting | US | verticals/government-publicsector.md |
| FAR 52.222-6 | Federal Acquisition Regulation Clause 52.222-6 — Construction Wage Rate Requirements | Government Contracting/Construction | US | verticals/construction-realestate.md |
| FAR 52.222-8 | Federal Acquisition Regulation Clause 52.222-8 — Payrolls and Basic Records | Government Contracting | US | verticals/government-publicsector.md |
| FAR 52.232-5 | Federal Acquisition Regulation Clause 52.232-5 — Payments under Fixed-Price Construction Contracts | Government Contracting/Construction | US | verticals/construction-realestate.md |
| FAR 52.234-4 | Federal Acquisition Regulation Clause 52.234-4 — Earned Value Management System | Government Contracting | US | verticals/government-publicsector.md |
| FAR Part 31 | Federal Acquisition Regulation Part 31 — Contract Cost Principles and Procedures | Government Contracting | US | verticals/government-publicsector.md |
| FAR — 48 CFR Chapter 1 | Federal Acquisition Regulation — Title 48 Code of Federal Regulations Chapter 1 | Government Contracting | US | verticals/government-publicsector.md |
| FASB ASC 250 | FASB Accounting Standards Codification 250 — Accounting Changes and Error Corrections | Financial reporting | US | verticals/financial-services.md |
| FASB ASC 360 | FASB Accounting Standards Codification 360 — Property, Plant, and Equipment (Impairment of Long-Lived Assets) | Financial reporting | US | verticals/financial-services.md |
| FASB ASC 410-20 | FASB Accounting Standards Codification 410-20 — Asset Retirement Obligations | Financial reporting | US | verticals/oil-gas-energy.md |
| FASB ASC 606 | FASB Accounting Standards Codification 606 — Revenue from Contracts with Customers | Financial reporting | US | core/features-core.md |
| FASB ASC 815 | FASB Accounting Standards Codification 815 — Derivatives and Hedging | Financial reporting | US | verticals/financial-services.md |
| FASB ASC 820 | FASB Accounting Standards Codification 820 — Fair Value Measurement | Financial reporting | US | verticals/financial-services.md |
| FASB ASC 842 | FASB Accounting Standards Codification 842 — Leases | Financial reporting | US | core/features-core.md |
| FASB ASC 853 | FASB Accounting Standards Codification 853 — Service Concession Arrangements | Financial reporting | US | verticals/government-publicsector.md |
| FASB ASC 932 | FASB Accounting Standards Codification 932 — Extractive Activities — Oil and Gas | Financial reporting | US | verticals/oil-gas-energy.md |
| FASB ASC 958 | FASB Accounting Standards Codification 958 — Not-for-Profit Entities | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASC 958-205 | FASB ASC 958-205 — Not-for-Profit Entities: Presentation of Financial Statements | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASC 958-310 | FASB ASC 958-310 — Not-for-Profit Entities: Receivables | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASC 958-320 | FASB ASC 958-320 — Not-for-Profit Entities: Investments — Debt and Equity Securities | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASC 958-605 | FASB ASC 958-605 — Not-for-Profit Entities: Revenue Recognition | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASC 958-720 | FASB ASC 958-720 — Not-for-Profit Entities: Other Expenses | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASU 2014-09 | FASB Accounting Standards Update 2014-09 — Revenue from Contracts with Customers (Topic 606) | Financial reporting | US | core/features-core.md |
| FASB ASU 2016-02 | FASB Accounting Standards Update 2016-02 — Leases (Topic 842) | Financial reporting | US | core/features-core.md |
| FASB ASU 2016-13 | FASB Accounting Standards Update 2016-13 — Measurement of Credit Losses on Financial Instruments (CECL) | Financial reporting | US | verticals/financial-services.md |
| FASB ASU 2016-14 | FASB Accounting Standards Update 2016-14 — Presentation of Financial Statements of Not-for-Profit Entities | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASU 2017-12 | FASB Accounting Standards Update 2017-12 — Derivatives and Hedging (Topic 815) | Financial reporting | US | verticals/financial-services.md |
| FASB ASU 2018-08 | FASB Accounting Standards Update 2018-08 — Clarifying the Scope and the Accounting Guidance for Contributions Received and Contributions Made | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASU 2018-12 | FASB Accounting Standards Update 2018-12 — Targeted Improvements to the Accounting for Long-Duration Contracts | Financial reporting | US | verticals/financial-services.md |
| FASB ASU 2020-07 | FASB Accounting Standards Update 2020-07 — Presentation and Disclosures by Not-for-Profit Entities for Contributed Nonfinancial Assets | Financial reporting | US | verticals/nonprofit-ngo.md |
| FASB ASU 2020-11 | FASB Accounting Standards Update 2020-11 — Effective Date and Early Application (Insurance Entities) | Financial reporting | US | verticals/financial-services.md |
| FASB ASU 2022-01 | FASB Accounting Standards Update 2022-01 — Fair Value Hedging — Portfolio Layer Method | Financial reporting | US | verticals/financial-services.md |
| FATCA IRC §§1471–1474 | Foreign Account Tax Compliance Act — Internal Revenue Code Sections 1471–1474 | Tax/Financial reporting | US/Global | verticals/financial-services.md |
| FATF 40 Recommendations | FATF 40 Recommendations on Anti-Money Laundering and Combating the Financing of Terrorism (2012, updated November 2023) | Financial/AML | Global | verticals/financial-services.md |
| FATF Recommendation 8 | FATF Recommendation 8 — Non-Profit Organisations (NPO) AML/CFT measures | Financial/AML | Global | verticals/nonprofit-ngo.md |
| FatturaPA XML | Italian Electronic Invoice (Fattura Pubblica Amministrazione) XML Schema | Tax/e-invoicing | Italy/EU | core/localization-tax.md |
| FCDO Programme Operating Framework (PrOF) | UK Foreign, Commonwealth & Development Office Programme Operating Framework | Public sector/Aid | UK | verticals/government-publicsector.md |
| FCRA (15 U.S.C. § 1681 et seq.) | Fair Credit Reporting Act | Data privacy/Financial | US | verticals/financial-services.md |
| FDA 21 CFR Part 1, Subpart S (FSMA Rule 204) | FDA Food Safety Modernization Act Traceability Rule — 21 CFR Part 1, Subpart S | Food safety | US | verticals/agriculture-food.md |
| FDA 21 CFR Part 11 | FDA 21 CFR Part 11 — Electronic Records; Electronic Signatures | Healthcare/Pharmaceuticals | US | verticals/healthcare-lifesciences.md |
| FDA CSA Guidance (September 2022) | FDA Computer Software Assurance for Production and Quality System Software Guidance (September 2022) | Healthcare/Pharmaceuticals | US | verticals/healthcare-lifesciences.md |
| FDA Cybersecurity in Medical Devices final guidance (September 2023) | FDA Cybersecurity in Medical Devices: Quality System Considerations and Content of Premarket Submissions (September 2023) | Healthcare/Security | US | verticals/healthcare-lifesciences.md |
| FDA/EMA Guiding Principles of Good AI Practice in Drug Development (January 14, 2026) | FDA/EMA Guiding Principles on Good AI Practice in Pharmaceutical Drug Development (January 14, 2026) | Healthcare/Pharmaceuticals | US/EU | verticals/healthcare-lifesciences.md |
| FedRAMP High | FedRAMP High Impact Authorization baseline for Cloud Service Providers | Security/Public sector | US | core/security.md |
| FedRAMP Moderate | FedRAMP Moderate Impact Authorization baseline for Cloud Service Providers | Security/Public sector | US | core/security.md |
| FERC Order No. 887 | FERC Order 887 — Advanced Metering Infrastructure Data | Energy | US | verticals/oil-gas-energy.md |
| FERC Order No. 898 | FERC Order 898 — Revisions to Electric Quarterly Reports | Energy | US | verticals/oil-gas-energy.md |
| FERC Uniform System of Accounts (18 CFR Parts 101 and 201) | FERC Uniform System of Accounts for Public Utilities and Licensees (18 CFR Part 101) and for Natural Gas Companies (18 CFR Part 201) | Energy/Financial reporting | US | verticals/oil-gas-energy.md |
| FERC XBRL Taxonomy Version 2024-04-01 | FERC XBRL Financial Reporting Taxonomy Version 2024-04-01 | Energy/Financial reporting | US | verticals/oil-gas-energy.md |
| FFATA (2006) | Federal Funding Accountability and Transparency Act of 2006 | Public sector/Financial reporting | US | verticals/government-publicsector.md |
| FIFRA (7 U.S.C. 136 et seq.) | Federal Insecticide, Fungicide, and Rodenticide Act | Agriculture/Environmental | US | verticals/agriculture-food.md |
| FinCEN CDD Rule 31 CFR §1010.230 | FinCEN Customer Due Diligence Requirements for Financial Institutions — 31 CFR §1010.230 | Financial/AML | US | verticals/financial-services.md |
| FINMA Circular 2023/1 | FINMA Circular 2023/1 — Operational Risks and Resilience for Banks | Financial/Security | Switzerland | verticals/financial-services.md |
| FIPS PUB 140-2 | Federal Information Processing Standard 140-2 — Security Requirements for Cryptographic Modules | Security | US | core/security.md |
| FIPS PUB 140-3 | Federal Information Processing Standard 140-3 — Security Requirements for Cryptographic Modules | Security | US | core/security.md |
| FIPS Publication 199 | Federal Information Processing Standard 199 — Standards for Security Categorization of Federal Information and Information Systems | Security | US | core/security.md |
| FISMA (44 USC § 3551) | Federal Information Security Modernization Act (44 U.S.C. § 3551 et seq.) | Security/Public sector | US | verticals/government-publicsector.md |
| FLSA | Fair Labor Standards Act | Labour/HR | US | core/localization-tax.md |
| FpML | Financial products Markup Language — XML standard for OTC derivatives | Financial reporting | Global | verticals/financial-services.md |
| FRB SR 11-7 | Federal Reserve Board Supervisory Letter SR 11-7 — Guidance on Model Risk Management | Financial/Risk | US | verticals/financial-services.md |
| FSMA | Food Safety Modernization Act (21 U.S.C. § 2201 et seq.) | Food safety | US | verticals/agriculture-food.md |
| FSMA 21 CFR Part 1 Subpart S (Food Traceability Rule) | FDA FSMA Food Traceability Rule — 21 CFR Part 1 Subpart S | Food safety | US | verticals/agriculture-food.md |
| FSSC 22000 Version 6.0 | Food Safety System Certification 22000 Version 6.0 | Food safety/Quality | Global | verticals/agriculture-food.md |
| FTC Textile and Wool Rules | FTC Rules and Regulations under the Textile Fiber Products Identification Act and Wool Products Labeling Act | Retail/Labelling | US | verticals/retail-ecommerce.md |
| FY2026 NDAA Section 1806 | Fiscal Year 2026 National Defense Authorization Act Section 1806 | Aerospace/Defense | US | verticals/aerospace-defense.md |
| GASB 100 | GASB Statement No. 100 — Accounting Changes and Error Corrections (an amendment of GASB Statement No. 62) | Financial reporting/Public sector | US | verticals/government-publicsector.md |
| GASB Statement No. 103 (April 2024, eff. FY beginning after June 15, 2025) | Financial Reporting Model Improvements | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 16 | Compensated Absences | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 31 | Accounting and Financial Reporting for Certain Investments and for External Investment Pools | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 34 (1999) | Basic Financial Statements — and Management's Discussion and Analysis — for State and Local Governments | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 35 | Basic Financial Statements — and Management's Discussion and Analysis — for Public Colleges and Universities | Financial reporting | US | verticals/education.md |
| GASB Statement No. 54 (2009) | Fund Balance Reporting and Governmental Fund Type Definitions | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 68 (2014) | Accounting and Financial Reporting for Pensions | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 75 (2017) | Accounting and Financial Reporting for Postemployment Benefits Other Than Pensions | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 87 (June 2017, eff. FY beginning after June 15, 2021) | Leases | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 88 (2018) | Certain Disclosures Related to Debt, including Direct Borrowings and Direct Placements | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 94 | Public-Private and Public-Public Partnerships and Availability Payment Arrangements | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 96 | Subscription-Based Information Technology Arrangements | Financial reporting | US | verticals/government-publicsector.md |
| GASB Statement No. 98 (October 2021) | The Hierarchy of Generally Accepted Accounting Principles for State and Local Governments | Financial reporting | US | verticals/government-publicsector.md |
| GDPR (EU 2016/679) | General Data Protection Regulation | Data privacy | EU | core/security.md |
| GDPR Article 9 | General Data Protection Regulation — Processing of Special Categories of Personal Data | Data privacy | EU | core/security.md |
| GHG Protocol | Greenhouse Gas Protocol Corporate Accounting and Reporting Standard | Sustainability / ESG | Global | core/features-core.md |
| GLOBALG.A.P. IFA Version 6.0 | GLOBALG.A.P. Integrated Farm Assurance Standard Version 6.0 | Quality / Food safety | Global | verticals/agriculture-food.md |
| Goods and Services Tax Act 1985 | Goods and Services Tax Act 1985 | Tax / e-invoicing | New Zealand | core/localization-tax.md |
| GS1 EPCIS 2.0 (ISO/IEC 19987:2024) | GS1 Electronic Product Code Information Services 2.0 | Supply chain / traceability | Global | verticals/distribution-logistics.md |
| GS1 SSCC | GS1 Serial Shipping Container Code | Supply chain / traceability | Global | verticals/distribution-logistics.md |
| GS1-128 | GS1-128 Barcode Symbology Standard | Supply chain / traceability | Global | verticals/distribution-logistics.md |
| HCPCS Level II | Healthcare Common Procedure Coding System Level II | Healthcare | US | verticals/healthcare-lifesciences.md |
| HIBCC UDI issuing agency | Health Industry Business Communications Council UDI Issuing Agency | Healthcare / Medical devices | US | verticals/healthcare-lifesciences.md |
| HIPAA Breach Notification Rule | Health Insurance Portability and Accountability Act — Breach Notification Rule (45 CFR Part 164, Subpart D) | Data privacy / Healthcare | US | verticals/healthcare-lifesciences.md |
| HIPAA Security Rule (45 CFR Part 164, Subpart C) | Health Insurance Portability and Accountability Act — Security Rule | Data privacy / Healthcare | US | verticals/healthcare-lifesciences.md |
| HIPAA Security Rule NPRM (HHS-OCR-2023-0015, January 6, 2025) | HIPAA Security Rule Notice of Proposed Rulemaking 2025 | Data privacy / Healthcare | US | verticals/healthcare-lifesciences.md |
| HL7 FHIR R4 (normative, December 2018) | Health Level 7 Fast Healthcare Interoperability Resources Release 4 | Healthcare interoperability | Global | verticals/healthcare-lifesciences.md |
| HL7 FHIR R5 (April 2023) | Health Level 7 Fast Healthcare Interoperability Resources Release 5 | Healthcare interoperability | Global | verticals/healthcare-lifesciences.md |
| HL7 SPL (Structured Product Labeling) | Health Level 7 Structured Product Labeling | Healthcare / Pharmaceuticals | US | verticals/healthcare-lifesciences.md |
| HL7 v2.x (v2.3–v2.8) | Health Level 7 Version 2 Messaging Standard | Healthcare interoperability | Global | verticals/healthcare-lifesciences.md |
| IA9100 (anticipated Q4 2026) | International Aerospace Quality Management System Standard (anticipated) | Quality / Aerospace | Global | verticals/aerospace-defense.md |
| IAS 1 | Presentation of Financial Statements | Financial reporting | Global (IFRS) | core/features-core.md |
| IAS 16 | Property, Plant and Equipment | Financial reporting | Global (IFRS) | core/features-core.md |
| IAS 2 | Inventories | Financial reporting | Global (IFRS) | core/features-core.md |
| IAS 21 | The Effects of Changes in Foreign Exchange Rates | Financial reporting | Global (IFRS) | core/localization-tax.md |
| IAS 37 | Provisions, Contingent Liabilities and Contingent Assets | Financial reporting | Global (IFRS) | core/features-core.md |
| IAS 38 | Intangible Assets | Financial reporting | Global (IFRS) | core/features-core.md |
| IAS 39 | Financial Instruments: Recognition and Measurement | Financial reporting | Global (IFRS) | verticals/financial-services.md |
| IAS 41 | Agriculture | Financial reporting | Global (IFRS) | verticals/agriculture-food.md |
| IAS 7 | Statement of Cash Flows | Financial reporting | Global (IFRS) | core/features-core.md |
| IAS 8 | Accounting Policies, Changes in Accounting Estimates and Errors | Financial reporting | Global (IFRS) | core/features-core.md |
| IAS Regulation 1606/2002 | EU Regulation on the Application of International Accounting Standards | Financial reporting | EU | core/features-core.md |
| IATA DGR 67th Edition (2026) | IATA Dangerous Goods Regulations 67th Edition | Transport / Safety | Global | verticals/distribution-logistics.md |
| IATF 16949:2016 | International Automotive Task Force Quality Management System Standard | Quality / Automotive | Global | verticals/manufacturing.md |
| IBC (International Building Code) | International Building Code | Construction / Safety | US | verticals/construction-realestate.md |
| ICCBBA UDI issuing agency | International Council for Commonality in Blood Banking Automation UDI Issuing Agency | Healthcare / Medical devices | Global | verticals/healthcare-lifesciences.md |
| ICD-10-CM | International Classification of Diseases, 10th Revision, Clinical Modification | Healthcare | US | verticals/healthcare-lifesciences.md |
| ICD-10-PCS | International Classification of Diseases, 10th Revision, Procedure Coding System | Healthcare | US | verticals/healthcare-lifesciences.md |
| ICH E6(R3) (final January 6, 2025) | ICH Guideline for Good Clinical Practice E6(R3) | Healthcare / Clinical trials | Global | verticals/healthcare-lifesciences.md |
| ICH Q10 | ICH Pharmaceutical Quality System Guideline Q10 | Quality / Pharmaceuticals | Global | verticals/healthcare-lifesciences.md |
| ICH Q1A(R2) | ICH Stability Testing of New Drug Substances and Products Q1A(R2) | Quality / Pharmaceuticals | Global | verticals/healthcare-lifesciences.md |
| ICH Q7 | ICH Good Manufacturing Practice Guide for Active Pharmaceutical Ingredients | Quality / Pharmaceuticals | Global | verticals/healthcare-lifesciences.md |
| ICH Q9 Rev 1 (2023) | ICH Quality Risk Management Guideline Q9 Revision 1 | Quality / Pharmaceuticals | Global | verticals/healthcare-lifesciences.md |
| IEC 62264 | Enterprise-Control System Integration | Manufacturing / Automation | Global | verticals/manufacturing.md |
| IEC 62264-2 (B2MML) | Enterprise-Control System Integration — Part 2: Model Object Attributes (Business to Manufacturing Markup Language) | Manufacturing / Automation | Global | verticals/manufacturing.md |
| IEC 62541 series (OPC UA) | OPC Unified Architecture | Manufacturing / Automation | Global | verticals/manufacturing.md |
| IFRIC 23 | Uncertainty over Income Tax Treatments | Financial reporting | Global (IFRS) | core/localization-tax.md |
| IFRS 10 | Consolidated Financial Statements | Financial reporting | Global (IFRS) | core/features-core.md |
| IFRS 13 | Fair Value Measurement | Financial reporting | Global (IFRS) | verticals/financial-services.md |
| IFRS 15 | Revenue from Contracts with Customers | Financial reporting | Global (IFRS) | core/features-core.md |
| IFRS 16 | Leases | Financial reporting | Global (IFRS) | core/features-core.md |
| IFRS 17 | Insurance Contracts | Financial reporting | Global (IFRS) | verticals/financial-services.md |
| IFRS 6 | Exploration for and Evaluation of Mineral Resources | Financial reporting | Global (IFRS) | verticals/oil-gas-energy.md |
| IFRS 8 | Operating Segments | Financial reporting | Global (IFRS) | core/features-core.md |
| IFRS 9 | Financial Instruments | Financial reporting | Global (IFRS) | verticals/financial-services.md |
| IFRS S2 | Climate-related Disclosures | Sustainability / ESG | Global (IFRS) | core/features-core.md |
| IFS Food Version 8 | International Featured Standards Food Version 8 | Quality / Food safety | Global | verticals/agriculture-food.md |
| IMDG Code Amendment 42-24 (IMO MSC.501(108)) | International Maritime Dangerous Goods Code Amendment 42-24 | Transport / Safety | Global | verticals/distribution-logistics.md |
| India DPDP Act 2023 | Digital Personal Data Protection Act 2023 | Data privacy | India | core/localization-tax.md |
| IPSAS 1 | Presentation of Financial Statements | Financial reporting | Global (Public sector) | verticals/government-publicsector.md |
| IPSAS 23 | Revenue from Non-Exchange Transactions | Financial reporting | Global (Public sector) | verticals/government-publicsector.md |
| IPSAS 24 | Presentation of Budget Information in Financial Statements | Financial reporting | Global (Public sector) | verticals/government-publicsector.md |
| IPSAS 33 | First-time Adoption of Accrual Basis International Public Sector Accounting Standards | Financial reporting | Global (Public sector) | verticals/government-publicsector.md |
| IPSAS 39 | Employee Benefits | Financial reporting | Global (Public sector) | verticals/government-publicsector.md |
| IPSAS 43 (eff. January 1, 2025) | Leases | Financial reporting | Global (Public sector) | verticals/government-publicsector.md |
| IPSAS 49 (November 2023) | Retirement Benefit Plans | Financial reporting | Global (Public sector) | verticals/government-publicsector.md |
| IR35 / Off-Payroll Working Rules (UK) | IR35 Off-Payroll Working Rules | Tax / Employment | UK | core/localization-tax.md |
| IRC Section 451(b) | Internal Revenue Code Section 451(b) — Accrual Method Conformity with Financial Accounting | Tax | US | core/localization-tax.md |
| IRC § 148 | Internal Revenue Code Section 148 — Arbitrage Restrictions on Tax-Exempt Bonds | Tax / Public finance | US | verticals/government-publicsector.md |
| IRC §170(f)(8) | Internal Revenue Code Section 170(f)(8) — Substantiation Requirement for Charitable Contributions | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| IRC §4980H | Internal Revenue Code Section 4980H — Employer Shared Responsibility for Health Coverage | Tax / Healthcare | US | core/localization-tax.md |
| IRC §501(c)(3) | Internal Revenue Code Section 501(c)(3) — Tax-exempt charitable organization status | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| IRC §6501 | Internal Revenue Code Section 6501 — Limitations on assessment and collection | Tax | US | core/localization-tax.md |
| IRS Form 1042-S | Foreign Person's U.S. Source Income Subject to Withholding | Tax / Withholding | US | core/localization-tax.md |
| IRS Form 1099-INT | Interest Income information return | Tax / Information reporting | US | core/localization-tax.md |
| IRS Form 1099-MISC | Miscellaneous Information information return | Tax / Information reporting | US | core/localization-tax.md |
| IRS Form 1099-NEC | Nonemployee Compensation information return | Tax / Information reporting | US | core/localization-tax.md |
| IRS Form 990 | Return of Organization Exempt From Income Tax | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| IRS Form 990 Schedule H | Hospitals (supplemental schedule to Form 990) | Tax / Healthcare | US | verticals/healthcare-lifesciences.md |
| IRS Form 990-EZ | Short Form Return of Organization Exempt From Income Tax | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| IRS Form 990-N | Electronic Notice (e-Postcard) for Tax-Exempt Organizations Not Required To File Form 990 | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| IRS Form 990-T | Exempt Organization Business Income Tax Return | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| IRS Publication 1075 | Tax Information Security Guidelines for Federal, State and Local Agencies | Security / Tax | US | core/security.md |
| IRS Publication 1220 | Specifications for Electronic Filing of Forms 1097, 1098, 1099, 3921, 3922, 5498, and W-2G | Tax / Information reporting | US | core/localization-tax.md |
| IRS Publication 15 (Circular E) | Employer's Tax Guide | Tax / Payroll | US | core/localization-tax.md |
| IRS Publication 1771 | Charitable Contributions — Substantiation and Disclosure Requirements | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| IRS Schedule A | Itemized Deductions (supplemental schedule to Form 1040) | Tax | US | core/localization-tax.md |
| IRS Schedule B | Interest and Ordinary Dividends (supplemental schedule to Form 1040) | Tax | US | core/localization-tax.md |
| IRS Schedule D | Capital Gains and Losses (supplemental schedule to Form 1040) | Tax | US | core/localization-tax.md |
| IRS Schedule F (Rev. Dec 2024) | Profit or Loss From Farming | Tax / Agriculture | US | verticals/agriculture-food.md |
| IRS Schedule I | Alternative Minimum Tax — Estates and Trusts (supplemental schedule to Form 1041) | Tax | US | core/localization-tax.md |
| IRS Schedule L | Balance Sheets per Books (supplemental schedule to Form 990 / 1065) | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| IRS Schedule R | Related Organizations and Unrelated Partnerships (supplemental schedule to Form 990) | Tax / Nonprofit | US | verticals/nonprofit-ngo.md |
| ISA/IEC 62443 (62443-1-1, 62443-3-3, 62443-4-x) | Industrial Automation and Control Systems Security series | Security / OT | Global | core/security.md |
| ISO 13485:2016 | Medical devices — Quality management systems — Requirements for regulatory purposes | Quality / Healthcare | Global | verticals/healthcare-lifesciences.md |
| ISO 14001:2015 | Environmental management systems — Requirements with guidance for use | Environmental management | Global | verticals/manufacturing.md |
| ISO 14025 | Environmental labels and declarations — Type III environmental declarations — Principles and procedures | Environmental management | Global | verticals/manufacturing.md |
| ISO 14971:2019 | Medical devices — Application of risk management to medical devices | Risk / Healthcare | Global | verticals/healthcare-lifesciences.md |
| ISO 15022 | Securities — Scheme for messages (Data Field Dictionary) | Financial reporting | Global | verticals/financial-services.md |
| ISO 19005-1 | Document management — Electronic document file format for long-term preservation — Part 1: Use of PDF 1.4 (PDF/A-1) | Records management | Global | core/features-core.md |
| ISO 19005-2 | Document management — Electronic document file format for long-term preservation — Part 2: Use of ISO 32000-1 (PDF/A-2) | Records management | Global | core/features-core.md |
| ISO 19005-3 | Document management — Electronic document file format for long-term preservation — Part 3: Use of ISO 32000-1 (PDF/A-3) | Records management | Global | core/features-core.md |
| ISO 20022 CAMT.053 | Bank-to-Customer Statement message (part of ISO 20022 MX message catalogue) | Financial reporting | Global | verticals/financial-services.md |
| ISO 20022:2013 | Financial services — Universal financial industry message scheme | Financial reporting | Global | verticals/financial-services.md |
| ISO 22000:2018 | Food safety management systems — Requirements for any organization in the food chain | Food safety | Global | verticals/agriculture-food.md |
| ISO 28001:2022 | Security management systems for the supply chain — Best practices for implementing supply chain security, assessments and plans — Requirements and guidance | Security / Supply chain | Global | verticals/distribution-logistics.md |
| ISO 3166 | Codes for the representation of names of countries and their subdivisions | Data standard | Global | core/localization-tax.md |
| ISO 3166-1 alpha-2 | Codes for the representation of names of countries and their subdivisions — Part 1: Country codes (two-letter) | Data standard | Global | core/localization-tax.md |
| ISO 4217 | Currency codes — Codes for the representation of currencies | Data standard | Global | core/localization-tax.md |
| ISO 45001:2018 | Occupational health and safety management systems — Requirements with guidance for use | Health & safety | Global | verticals/manufacturing.md |
| ISO 50001:2018 | Energy management systems — Requirements with guidance for use | Energy management | Global | verticals/oil-gas-energy.md |
| ISO 55001:2024 | Asset management — Management systems — Requirements | Asset management | Global | verticals/oil-gas-energy.md |
| ISO 8601 | Date and time — Representations for information interchange | Data standard | Global | core/features-core.md |
| ISO 9001 FDIS (2026, forthcoming) | Quality management systems — Requirements (Final Draft International Standard, anticipated 2026 revision) | Quality | Global | verticals/manufacturing.md |
| ISO 9001:2015 | Quality management systems — Requirements | Quality | Global | verticals/manufacturing.md |
| ISO 9001:2015 Clause 8.7 | Quality management systems — Control of nonconforming outputs (clause within ISO 9001:2015) | Quality | Global | verticals/manufacturing.md |
| ISO 9001:2015/Amd 1:2024 | Quality management systems — Requirements — Amendment 1: Climate change (amendment to ISO 9001:2015) | Quality | Global | verticals/manufacturing.md |
| ISO/IEC 27001:2022 | Information security, cybersecurity and privacy protection — Information security management systems — Requirements | Security | Global | core/security.md |
| ISO/IEC 27002:2022 | Information security, cybersecurity and privacy protection — Information security controls | Security | Global | core/security.md |
| ISO/IEC 27017:2015 | Code of practice for information security controls based on ISO/IEC 27002 for cloud services | Security | Global | core/security.md |
| ISO/IEC 27018:2019 | Code of practice for protection of personally identifiable information (PII) in public clouds acting as PII processors | Data privacy | Global | core/security.md |
| ISPE GAMP 5, 2nd Edition (July 2022) | Good Automated Manufacturing Practice — A Risk-Based Approach to Compliant GxP Computerized Systems, 2nd Edition | Quality / Healthcare | Global | verticals/healthcare-lifesciences.md |
| ITAR (22 CFR Parts 120–130) | International Traffic in Arms Regulations (22 CFR Parts 120–130) | Trade compliance / Defense | US | verticals/aerospace-defense.md |
| ITU-T E.164 | The international public telecommunication numbering plan | Telecommunications | Global | core/features-core.md |
| JPK_V7K | Jednolity Plik Kontrolny VAT — monthly VAT SAF-T return (quarterly filer variant) | Tax / e-invoicing | Poland | core/localization-tax.md |
| JPK_V7M | Jednolity Plik Kontrolny VAT — monthly VAT SAF-T return (monthly filer variant) | Tax / e-invoicing | Poland | core/localization-tax.md |
| KassenSichV | Kassensicherungsverordnung — Fiscal Cash Register Security Ordinance | Tax / Fiscal | Germany | core/localization-tax.md |
| LEED v5 (USGBC, 2025) | Leadership in Energy and Environmental Design version 5 (U.S. Green Building Council, 2025) | Environmental / Construction | Global | verticals/construction-realestate.md |
| Local Government Finance Act 1988 (UK) — Section 114 | Section 114 of the Local Government Finance Act 1988 — Chief Finance Officer duty to issue a report on unlawful expenditure | Public sector / Financial reporting | UK | verticals/government-publicsector.md |
| LTI 1.3 | Learning Tools Interoperability 1.3 (IMS Global / 1EdTech standard) | Education technology | Global | verticals/education.md |
| MAS TRM Guidelines (2021) | Monetary Authority of Singapore Technology Risk Management Guidelines (2021) | Security / Financial services | Singapore | verticals/financial-services.md |
| MIL-STD-130N w/Change 1 | Identification Marking of U.S. Military Property (Change 1) | Defense / Logistics | US | verticals/aerospace-defense.md |
| MRP II (APICS/Oliver Wight) | Manufacturing Resource Planning II — APICS/Oliver Wight standard for integrated manufacturing planning | Manufacturing | Global | verticals/manufacturing.md |
| MS-DRG | Medicare Severity Diagnosis Related Groups — CMS inpatient hospital payment classification system | Healthcare / Reimbursement | US | verticals/healthcare-lifesciences.md |
| MT940 | SWIFT Customer Statement Message (structured bank account statement format) | Financial reporting | Global | verticals/financial-services.md |
