# ERP Knowledge Library — Master Glossary (Index)

The glossary was split for agent retrieval — a single 432KB file could not be read in one call. Entries now live under **[`glossary/`](glossary/README.md)** as four grepable parts.

- Acronyms & terms: `glossary/acronyms-a-m.md`, `glossary/acronyms-n-z.md`
- Standards & regulations: `glossary/standards-a-m.md`, `glossary/standards-n-z.md`

**Look up a term (grep, don't open whole):**
```
grep -rni "^| ZATCA " glossary/
grep -rni "e-invoicing" glossary/
```

See **[glossary/README.md](glossary/README.md)** for the full index and lookup protocol.
