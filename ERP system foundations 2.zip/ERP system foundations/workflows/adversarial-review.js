// RUNTIME: SCRIPT FOR THE CLAUDE CODE **WORKFLOW TOOL**, not Node.js. Run via
// Workflow({ scriptPath: 'workflows/adversarial-review.js', args }). Do NOT `node` it
// (top-level await/return + workflow globals agent()/pipeline()/parallel()/log()/args). No
// Workflow tool? Execute the same shape by spawning the described subagents by hand.
//
// adversarial-review.js — multi-lens review used for the HARDEN pass (P10) and for
// reviewing the playbook/docs themselves. Each target is reviewed through several
// independent lenses in parallel; findings are collected and (optionally) verified.
//
// Invoke:  Workflow({ scriptPath: 'workflows/adversarial-review.js', args: {
//            projectDir: '/abs/path',
//            targets: ['src/modules/posting', 'src/modules/ap'],   // files/dirs OR doc paths
//            lenses: ['correctness','security','performance','followability','consistency'],
//            mode: 'system'   // 'system' (code) | 'docs' (playbook review)
//          }})
// Returns ranked, deduped findings per target with a blocking flag.

export const meta = {
  name: 'adversarial-review',
  description: 'Multi-lens adversarial review of code or docs, findings deduped and ranked',
  phases: [{ title: 'Review' }, { title: 'Synthesize' }],
}

const A = args || {}
const PROJECT = A.projectDir || '.'
const TARGETS = Array.isArray(A.targets) ? A.targets : []
const MODE = A.mode === 'docs' ? 'docs' : 'system'
const DEFAULT_LENSES = MODE === 'docs'
  ? ['factual', 'followability', 'security-completeness', 'consistency']
  : ['correctness', 'security', 'performance', 'consistency']
const LENSES = Array.isArray(A.lenses) && A.lenses.length ? A.lenses : DEFAULT_LENSES
if (!TARGETS.length) { log('adversarial-review: no targets'); return { findings: [] } }

const FINDINGS = {
  type: 'object', additionalProperties: false,
  required: ['target', 'lens', 'findings'],
  properties: {
    target: { type: 'string' }, lens: { type: 'string' },
    findings: { type: 'array', items: {
      type: 'object', additionalProperties: false,
      required: ['severity', 'summary', 'where', 'blocking'],
      properties: {
        severity: { type: 'string', enum: ['critical', 'high', 'medium', 'low'] },
        summary: { type: 'string' }, where: { type: 'string' },
        failure_scenario: { type: 'string' }, blocking: { type: 'boolean' },
      },
    }},
  },
}

const lensPrompt = (target, lens) => {
  const base = MODE === 'docs'
    ? `You are reviewing a playbook/doctrine document for an ERP build operating system. Target: ${PROJECT}/${target}. `
    : `You are adversarially reviewing built ERP code. Project: ${PROJECT}. Target: ${target}. `
  const lensText = {
    correctness: 'Find bugs, broken invariants, missing edge cases, vacuous tests. Money paths: debit==credit, idempotency, no mutation of posted docs.',
    security: 'Run applicable security scenarios; find IDOR, tenant-isolation bypass, injection, secret exposure, audit-tamper paths, AI-copilot overreach. Defensive framing.',
    performance: 'Find N+1 queries, missing indexes, unbounded scans, hot-path allocations, month-end-close scaling risks. Tie to concrete envelopes.',
    consistency: 'Find internal contradictions, values that disagree across files/modules, drift from locked-decisions.json, dead/orphaned code or docs.',
    factual: 'Check every dated/versioned/numeric claim against a primary source (web). Flag anything unverifiable or wrong with a correction.',
    followability: 'A fresh agent must be able to execute this. Find ambiguity, missing NEXT pointers, undefined terms, steps an agent could not mechanically follow, broken cross-references.',
    'security-completeness': 'Find security gaps the doc omits: missing threat, uncovered attack surface, a control stated but not made enforceable/testable.',
  }[lens] || `Review through the "${lens}" lens.`
  return `${base}${lensText}\n\nReturn ranked findings (severity, one-line summary, file:line or section, concrete failure scenario, blocking?). No false positives — a finding must be real and reproducible/citable. If clean on this lens, return an empty findings array.`
}

// Each target reviewed by all lenses concurrently, then findings collected (barrier per target
// is fine: we want all lenses before synthesizing that target's verdict). Targets pipeline.
const perTarget = await pipeline(
  TARGETS,
  (t) => parallel(LENSES.map(lens => () =>
    agent(lensPrompt(t, lens), {
      label: `${lens}:${t.split('/').pop()}`, phase: 'Review', schema: FINDINGS,
      model: lens === 'security' || lens === 'security-completeness' ? 'opus' : 'sonnet', effort: 'high',
    }).then(r => r || { target: t, lens, findings: [] })
  )).then(lensResults => ({ target: t, lensResults: (lensResults || []).filter(Boolean) })),

  // Synthesize per target: flatten, rank, flag blocking
  (prev) => {
    const all = prev.lensResults.flatMap(lr => (lr.findings || []).map(f => ({ ...f, lens: lr.lens })))
    const order = { critical: 0, high: 1, medium: 2, low: 3 }
    all.sort((a, b) => (order[a.severity] ?? 9) - (order[b.severity] ?? 9))
    return { target: prev.target, count: all.length, blocking: all.some(f => f.blocking), findings: all }
  }
)

const clean = (perTarget || []).filter(Boolean)
return {
  mode: MODE, lenses: LENSES,
  targets: clean,
  total_findings: clean.reduce((n, t) => n + t.count, 0),
  any_blocking: clean.some(t => t.blocking),
  clean: clean.every(t => t.count === 0),
}
