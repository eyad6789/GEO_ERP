// RUNTIME: SCRIPT FOR THE CLAUDE CODE **WORKFLOW TOOL**, not Node.js. Run via
// Workflow({ scriptPath: 'workflows/verify-claims.js', args }). Do NOT `node` it (top-level
// await/return + workflow globals agent()/parallel()/log()/args). No Workflow tool? Execute
// the same shape by spawning the described subagents by hand.
//
// verify-claims.js — the P01 freshness / claim-verification sweep as a re-runnable workflow.
// Fans out one web-verifier per claim cluster; each returns a primary-source-backed verdict.
// Use it to (a) re-check the flagged-claims register in 01-freshness-check.md before a build,
// and (b) verify any date/version/threshold you're about to build compliance logic against.
//
// Invoke:  Workflow({ scriptPath: 'workflows/verify-claims.js', args: {
//            today: '2026-07-06',
//            claims: [ { id: 'sepa-cap', file: 'core/localization-tax.md',
//                        body: 'SEPA Instant cap abolished Oct 5 2025 — verify via europeanpaymentscouncil.eu' } ] }})
// Returns verdicts (CONFIRMED / REFUTED / PARTIALLY_CORRECT / UNVERIFIABLE) + correction text.

export const meta = {
  name: 'verify-claims',
  description: 'Web-verify flagged/compliance claims against primary sources, max fan-out',
  phases: [{ title: 'Verify' }],
}

const A = args || {}
const TODAY = A.today || 'the current date'
const CLAIMS = Array.isArray(A.claims) ? A.claims : []
if (!CLAIMS.length) { log('verify-claims: no claims in args.claims'); return { verdicts: [] } }

const SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['id', 'verdict', 'primary_source_url', 'correction', 'note'],
  properties: {
    id: { type: 'string' },
    verdict: { type: 'string', enum: ['CONFIRMED', 'REFUTED', 'PARTIALLY_CORRECT', 'UNVERIFIABLE'] },
    primary_source_url: { type: 'string' },
    correction: { type: 'string', description: 'exact replacement text if not CONFIRMED, else empty' },
    note: { type: 'string', description: 'reasoning + confidence' },
  },
}

log(`verify-claims: checking ${CLAIMS.length} claim(s) as of ${TODAY}`)

const verdicts = await parallel(CLAIMS.map(c => () => agent(
  `You are a fact-checker with web access. Today is ${TODAY}. Verify this claim against a PRIMARY/authoritative source (regulator, standards body, vendor docs — not SEO blogs unless corroborating). If you cannot find authoritative confirmation, verdict=UNVERIFIABLE (do NOT guess). If the real fact differs, verdict=REFUTED or PARTIALLY_CORRECT with exact corrected replacement text.\n\nClaim id: ${c.id}\n${c.file ? 'Source file: ' + c.file + '\\n' : ''}Claim / what to check:\n${c.body}\n\nUse WebSearch then WebFetch. A claim is CONFIRMED only if a primary source explicitly supports it. Return the structured verdict with id="${c.id}".`,
  { label: `verify:${c.id}`, phase: 'Verify', schema: SCHEMA, model: 'sonnet', effort: 'high' }
)))

const clean = (verdicts || []).filter(Boolean)
const byVerdict = clean.reduce((a, v) => { a[v.verdict] = (a[v.verdict] || 0) + 1; return a }, {})
const needsFix = clean.filter(v => v.verdict !== 'CONFIRMED')

return {
  verdicts: clean,
  tally: byVerdict,
  needs_action: needsFix,          // feed these into a repair pass
  all_confirmed: needsFix.length === 0,
}
