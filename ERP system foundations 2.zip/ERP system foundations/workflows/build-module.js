// ============================================================================
// RUNTIME: This is a SCRIPT FOR THE CLAUDE CODE **WORKFLOW TOOL**, not a Node.js
// program. Do NOT run `node workflows/build-module.js` (it has top-level await/return
// and relies on the workflow runtime's globals: agent(), pipeline(), parallel(), log(),
// args, budget). Run it with:  Workflow({ scriptPath: 'workflows/build-module.js', args })
// If your harness has no Workflow tool, execute the SAME shape by hand: spawn the
// described subagents (Task/Agent tool) in the same order with the same prompts/schemas.
// ============================================================================
//
// build-module.js — the P09 build loop for a BATCH of modules.
// Per module: plan+build → (QA ∥ security) → [bounce to build on blocking findings, ≤3] → verify.
// Modules stream concurrently (cap-limited); each module's own lifecycle is sequential.
//
// GATED BATCHING: call this with modules UP TO AND INCLUDING the next gated module only.
// When it returns a module in `needs_owner_gate`, the orchestrator stops for gate Gk,
// then calls build-module.js again for the remaining modules. Do not pass modules that
// live past an unanswered gate.
//
// Invoke:  Workflow({ scriptPath: 'workflows/build-module.js', args: {
//            projectDir: '/abs/path/to/erp-project',
//            modules: [ { id: 'foundations', spec: '…', gated: false, securityTags: ['auth','tenancy'] },
//                       { id: 'posting-engine', spec: '…', gated: true, securityTags: ['payments','audit'] } ],
//            securityModel: 'multi_tenant', maxBounces: 3 }})

export const meta = {
  name: 'build-module',
  description: 'Run an ERP module batch through plan→build→QA+security→(bounce)→verify',
  phases: [{ title: 'Build' }, { title: 'Review' }, { title: 'Verify' }],
}

const A = args || {}
const PROJECT = A.projectDir || '.'
const MODULES = Array.isArray(A.modules) ? A.modules : []
const TENANCY = A.securityModel || 'single_tenant'
const MAX_BOUNCES = Number.isInteger(A.maxBounces) ? A.maxBounces : 3
if (!MODULES.length) { log('build-module: no modules in args.modules'); return { modules: [] } }

const VERDICT = {
  type: 'object', additionalProperties: false,
  required: ['verdict', 'failing_gates', 'evidence_path', 'summary'],
  properties: {
    verdict: { type: 'string', enum: ['PASS', 'FAIL'] },
    failing_gates: { type: 'array', items: { type: 'string' } },
    evidence_path: { type: 'string' }, summary: { type: 'string' },
  },
}
const FINDINGS = {
  type: 'object', additionalProperties: false,
  required: ['blocking', 'findings'],
  properties: {
    blocking: { type: 'boolean' },
    findings: { type: 'array', items: { type: 'string' } },
  },
}
const secModel = m => (m.securityTags || []).some(t => ['auth', 'payments', 'tenancy'].includes(t)) ? 'opus' : 'sonnet'

// One module's full lifecycle, with the bounce loop.
async function buildModule(m) {
  await agent(
    `You are building ERP module "${m.id}" in project ${PROJECT}.\nFIRST write progress/specs/${m.id}.SPEC.md (purpose; data entities incl. tenant_id+RLS if multi_tenant; API surface with schemas; invariants; the failing acceptance tests that define done; which locked-decisions keys + security scenarios apply). THEN implement to that spec, test-first.\nTenancy: ${TENANCY}. Spec hint: ${m.spec || '(derive from SPEC + locked decisions)'}\nBuilder hard rules: no stubs/empty files; confirm every external API against the installed version before use; exercise every API in a test; honor locked-decisions.json exactly; every write audit-logged. Report files changed, tests, invariants covered, anything incomplete.`,
    { agentType: 'builder', label: `build:${m.id}`, phase: 'Build', model: 'sonnet', effort: 'high' }
  )

  let bounce = 0
  while (true) {
    const arms = [
      () => agent(
        `Adversarial QA review of ERP module "${m.id}" in ${PROJECT}. Read progress/specs/${m.id}.SPEC.md and the module's git diff only. Run the tests; try to break an invariant. Report ranked findings; set blocking=true if any must-fix. Follow the qa-reviewer role.`,
        { agentType: 'qa-reviewer', label: `qa:${m.id}#${bounce}`, phase: 'Review', schema: FINDINGS, model: 'sonnet', effort: 'high' }),
      () => agent(
        `Adversarial security review of ERP module "${m.id}" in ${PROJECT} (tenancy=${TENANCY}). Scenario tags: ${JSON.stringify(m.securityTags || [])}. Run the matching playbook/security/scenarios/* verification steps and try to reproduce each; check fundamentals (server-side per-object authz, RLS+FORCE, injection, secrets, audit integrity, AI-copilot scoping). Report ranked findings; blocking=true if any must-fix. Follow the security-reviewer role.`,
        { agentType: 'security-reviewer', label: `sec:${m.id}#${bounce}`, phase: 'Review', schema: FINDINGS, model: secModel(m), effort: 'high' }),
    ]
    // UI modules gain a THIRD parallel reviewer — the design-QA reviewer that actually
    // looks at the screenshots (playbook/12 + NORTH-STAR: a UI never looked at is not done).
    if (m.ui) arms.push(() => agent(
      `Design-QA review of ERP UI module "${m.id}" in ${PROJECT}. The builder committed screenshots (all four states × light+dark) under the module's test snapshot dir. LOOK at them as images, drive the happy + one error path, and score against the playbook/12-ui-ux-visual-verification.md §6 rubric (≥85 to pass; any category at 0 blocks; evidence must cite concrete pixels). Write progress/reviews/${m.id}-design.md with the numeric verdict. Report findings; blocking=true if score <85 or any required state/theme screenshot is missing. Follow the design-qa-reviewer role.`,
      { agentType: 'design-qa-reviewer', label: `design:${m.id}#${bounce}`, phase: 'Review', schema: FINDINGS, model: 'sonnet', effort: 'high' }))

    const reviews = (await parallel(arms)).filter(Boolean)
    const blockers = reviews.filter(r => r.blocking)
    if (!blockers.length) break
    if (bounce >= MAX_BOUNCES) {
      return { module: m.id, gated: !!m.gated, verdict: 'FAIL',
        failing_gates: ['review'], evidence_path: `progress/reviews/${m.id}.md`,
        summary: `escalate: ${MAX_BOUNCES} bounces exhausted with blocking findings — needs owner/orchestrator attention` }
    }
    bounce++
    const notes = blockers.flatMap(b => b.findings || []).join('\n- ')
    await agent(
      `Fix ERP module "${m.id}" in ${PROJECT}. QA/security review returned BLOCKING findings — fix ALL before re-review:\n- ${notes}\nDo not regress passing tests; add tests covering each fixed finding. Builder hard rules still apply.`,
      { agentType: 'builder', label: `rebuild:${m.id}#${bounce}`, phase: 'Build', model: 'sonnet', effort: 'high' })
    // loop: re-review the fixed code
  }

  const v = await agent(
    `You are the verifier for ERP module "${m.id}" in ${PROJECT}. QA and security reported no blocking findings. Run scripts/verify-phase.sh ${m.id}, read progress/reviews/${m.id}.md, confirm all DoD gates green and no blocking finding remains. VERDICT: PASS only if verify-phase.sh exited 0; else FAIL naming exact gates. Follow the verifier role.`,
    { agentType: 'verifier', label: `verify:${m.id}`, phase: 'Verify', schema: VERDICT, model: 'sonnet', effort: 'high' })
  return { ...(v || { verdict: 'FAIL', failing_gates: ['verify'], evidence_path: '', summary: 'verifier returned nothing' }), module: m.id, gated: !!m.gated }
}

log(`build-module: ${MODULES.length} module(s) in ${PROJECT} (tenancy=${TENANCY}, maxBounces=${MAX_BOUNCES})`)
const results = await pipeline(MODULES, m => buildModule(m))

const clean = (results || []).filter(Boolean)
const passed = clean.filter(r => r.verdict === 'PASS').map(r => r.module)
const failed = clean.filter(r => r.verdict !== 'PASS')
return {
  modules: clean,
  passed,
  failed: failed.map(r => ({ module: r.module, failing_gates: r.failing_gates, summary: r.summary })),
  needs_owner_gate: clean.filter(r => r.verdict === 'PASS' && r.gated).map(r => r.module),
  summary: `${passed.length}/${clean.length} PASS; ${failed.length} failed; ${clean.filter(r => r.gated && r.verdict === 'PASS').length} awaiting owner gate`,
}
