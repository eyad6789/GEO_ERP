---
id: KNOWLEDGE-MAP
stage: any
audience: orchestrator + subagents
read_when: whenever you need a fact from the knowledge library
produces: a targeted grep/section-read (never a full-file read)
---

# knowledge-map.md — How to Pull a Fact Without Bulk-Loading

The knowledge library (`core/*`, `verticals/*`, `glossary/*`) is ~180k words. **Never read a whole file.** Two access patterns only:

1. **Grep for the term**, read ±20 lines around the hit.
   `grep -n -i "posting engine" core/architecture.md` → then read that section.
2. **Jump to a known H2/H3 section** using the tables below. The section names below are **prefixes** — grep them as substrings (`grep -n -i "multi-tenancy" core/architecture.md`), never as exact `^## …$` anchors, since the real headings may carry longer titles.

When *you* (orchestrator) need library knowledge, **dispatch a Sonnet subagent** with the specific file + anchor and ask for the conclusion only — keep the raw text out of your window.

---

## Topic → file § section

### Core architecture (`core/architecture.md`)
| Need | Section |
|---|---|
| Layered architecture, metadata-driven design | `## Layered Architecture`, `## Metadata-Driven Design` |
| Document model (header/lines, JSON schema) | `## The Document Model` |
| Double-entry posting engine, idempotency, outbox | `## The Double-Entry Posting Engine` |
| Chart of accounts, segments, parallel ledgers | `## Chart of Accounts`, `## Parallel Ledgers` |
| Fiscal periods, period close, number ranges | `## Fiscal Calendar`, `## Number Ranges` |
| Costing engines (standard/MAP/WAC/FIFO/actual) | `## Costing Engines` |
| Multi-currency, multi-entity, intercompany | `## Multi-Currency`, `## Multi-Entity` |
| Multi-tenancy models, data residency | `## Multi-Tenancy` |
| Concurrency, locking, idempotency | `## Concurrency` |
| Audit immutability, event sourcing | `## Audit Immutability` |
| Integration & eventing architecture | `## Integration` |

### Features / modules (`core/features-core.md`)
Financial (GL/AP/AR/FA/Cash/Consolidation), HCM, SCM/Procurement/Inventory/WMS, Sales/CRM/CPQ, Manufacturing (BOM/MRP), Projects/EVM, BI, DMS, Workflow, Integration, System Admin. Each module has a **"what breaks without it"** failure-mode note and DDL sketches. Grep the module name (e.g. `grep -n -i "accounts payable" core/features-core.md`).

### Security (`core/security.md`)
| Need | Section |
|---|---|
| RBAC vs ABAC, SoD, least privilege/PAM | `## Access Control Architecture` |
| SSO/SAML/OIDC, MFA, sessions, secrets | `## Authentication and Identity` |
| Encryption at rest/in transit, field-level, HSM/KMS | `## Data Security` |
| Immutable audit logs, SIEM, anomaly detection | `## Audit Trails and Continuous Monitoring` |
| Compliance by region (US/EU/APAC/LatAm/ME) | `## Compliance by Region` |
| Network segmentation, patching, known ERP CVEs | `## Infrastructure Security` |
| Pen-testing ERP, backup/DR/ransomware | `## Penetration Testing ERP Systems`, `## Backup, Disaster Recovery` |
| ERP-specific attack vectors | `## ERP-Specific Attack Vectors` |

> For **building** secure ERP (threat models, multi-tenant isolation patterns, hash-chained audit DDL, AI/LLM threats), use `playbook/06-security-foundations.md` + `playbook/security/scenarios/*` — that is the build doctrine; `core/security.md` is the reference survey.

### Localization & tax (`core/localization-tax.md`)
Indirect tax types, determination engines (Avalara/Vertex/Sovos), withholding, CTC e-invoicing by country (India IRP, Italy SdI, Brazil, Mexico CFDI, Saudi ZATCA, Poland KSeF, France, EU ViDA), SAF-T, Intrastat, ISO 20022 payments, fiscal devices, payroll filings. Grep by country/standard.

### Implementation (`core/implementation.md`)
Methodologies (SAP Activate, OUM, Success by Design, Agile/Hybrid), rollout (big-bang/phased/pilot), data migration, change management, go-live, testing, licensing, team structure, cost/timeline benchmarks by company size.

### Cautions (`core/cautions.md`)
Nine sourced real-world failure cases (Hershey, Nike, Waste Management, Marin County, National Grid, MillerCoors, Lidl, Revlon, Birmingham) + systematic failure modes (scope creep, customisation trap, data quality, vendor lock-in, hidden costs). Read before scope/design decisions.

### Verticals (`verticals/*.md`) — read the ONE that matches the project's industry
`manufacturing` · `distribution-logistics` · `retail-ecommerce` · `healthcare-lifesciences` · `government-publicsector` · `financial-services` · `construction-realestate` · `professional-services` · `education` (higher-ed) · `schools` (K-12 public + private) · `nonprofit-ngo` · `oil-gas-energy` · `agriculture-food` · `aerospace-defense`. Each is self-contained: modules, compliance IDs, data entities (SQL/JSON), integrations, KPIs, vendors, cautions, security depth.

---

## Glossary (grep-only, never open whole)

The glossary is split under `glossary/` with `glossary/README.md` as the index. To define a term:

```
grep -rn -i "^| ZATCA " glossary/          # exact acronym/term lookup
grep -rn -i "e-invoicing" glossary/         # concept search
```

Acronyms table columns: `Term | Expansion | Meaning in ERP context | Primary file(s)`. Standards table: `Identifier | Full name | Domain | Jurisdiction | Primary file(s)`. The "Primary file(s)" column tells you which core/vertical doc has the depth — follow it.

---

## Freshness caveat

Every fact here was verified **2026-07**. Fast-moving items (compliance effective dates, e-invoicing mandates, standard revisions, vendor patch cadences, framework versions) drift. Before relying on a dated claim in a real build, re-verify per `playbook/01-freshness-check.md`. The register of already-checked claims (with primary sources) lives there.

**NEXT:** `playbook/01-freshness-check.md`.
