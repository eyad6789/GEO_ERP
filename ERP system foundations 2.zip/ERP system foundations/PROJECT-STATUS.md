# Project Status — ERP Build Operating System

_Last updated 2026-07-06._

## What this repo is

Two layers in one folder:

1. **Knowledge library** — a dense, citation-backed engineering reference for *building* ERP systems (not buying). 6 core docs + 15 industry verticals + a split glossary. ~230k words, verified 2026-07.
2. **Build operating system** — a guided pipeline that a Claude session (Opus orchestrator + Sonnet-max subagents) reads and executes to build a production ERP: freshness check → owner interview → Anthropic-design HTML decision file → locked decisions → per-module build loop (builder → QA → security → verify) → hardening → deployment. Entry point: **`CLAUDE.md` → `00-START-HERE.md`**.

## Canonical location

This folder (`~/Desktop/CODES/02-ERP-Business-Systems/ERP system foundations`) is the **sole canonical copy**. Earlier notes referenced a `~/code` copy and a `~/Desktop/codes` backup; neither exists — do not look for them. This is git-tracked; history is the backup.

## Current state (2026-07-06)

- **Knowledge library:** audited by 3 agents; 44 flagged 2025–2026 claims re-checked against primary sources (**32 CONFIRMED, 11 partially corrected, 1 refuted**) and corrected in place; cross-file inconsistencies fixed (Hershey/Nike/FoxMeyer figures, PCI DSS version, ViDA timeline); `education.md` §10 consolidated into `schools.md`; glossary re-sorted, deduped, and split into grepable parts under `glossary/`.
- **Build OS:** `CLAUDE.md`, `00-START-HERE.md`, `manifest.md`, `knowledge-map.md`, the `playbook/` (phases 01–11 + security scenarios/checklists + templates), `workflows/` (build-module, verify-claims, adversarial-review), and `.claude/agents/` roles (builder, qa-reviewer, security-reviewer, verifier).

## How to use it (next session)

Point Claude at this folder and say what you want to build. It will read `CLAUDE.md` → `00-START-HERE.md`, run the freshness check, interview you in chunks, generate a decision HTML, lock your choices, and build module-by-module with review gates — stopping only at declared owner gates (G0/G1/Gk/G2).

## Provenance

The knowledge library was originally built (June 2026) via a Research→Write→Harden agent pipeline. The build-OS layer and the 2026-07 verification/repair pass were added by an Opus-orchestrated, Sonnet-max-subagent run (ultracode). Every content file carries numbered citations; the flagged-claims register (with primary sources) lives in `playbook/01-freshness-check.md`.
