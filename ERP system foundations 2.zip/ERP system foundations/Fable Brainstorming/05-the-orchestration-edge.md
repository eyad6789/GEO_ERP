# 05 · The Orchestration Edge

This whole room was built the way I told you to work: a higher brain directing adversarial muscle. It's fair to ask whether that pattern is real leverage or expensive theater. The honest answer, grounded in `_research/R-orchestration-evidence.md`: it is real leverage *for specific reasons*, in *specific conditions*, and it is theater outside them. Knowing the difference is most of the skill.

## Why it can win — the one honest mechanism

Strip away the mystique of "many minds" and one mechanism does almost all the real work: **the generator/verifier asymmetry.** Checking a solution is often easier and more reliable than producing it. So a *separate* verifier — a different context with a mandate to refute — adds genuine information that a single pass cannot get by re-reading itself (files 01–02: intrinsic self-correction doesn't reliably work; external signal does). Debate results (Khan et al. 2024) show the same shape: an adversarial structure lets even a weaker judge adjudicate a stronger claim, because refutation surfaces what assertion hides.

Everything good multi-agent orchestration buys you reduces to injecting *structurally independent signal* or *coverage that exceeds one context*:

- **Independent verification** — the reviewer that found my own fail-open UI gate and my cent-destroying allocation. One context would have re-read its own work and approved it.
- **Adversarial diversity** — the two consciousness agents, given *opposing mandates*, produced a synthesis I couldn't have reached from one seat, precisely because they weren't echoing each other.
- **Breadth beyond a window** — 24 vertical files, 9 research tracks, in parallel. Not "smarter," just more ground than one context can hold at once, held cleanly.

## When it's theater — and can make things worse

Multi-agent is not free and not always positive. It hurts or wastes when:

- **The task is holistic and non-decomposable.** A single tight argument, a piece of prose that must be one voice — splitting it adds seams, not quality. (These essays I wrote myself for exactly this reason; the muscle grounded and attacked, but the synthesis had to be one mind.)
- **The agents aren't actually independent.** N copies of the same model with the same prompt agreeing is not verification — it's the same forward pass sampled N times, and their agreement is not evidence. Diversity has to be *engineered* (different mandates, different data, an adversarial role) or you're just paying more for correlated noise.
- **Errors compound without a verifier.** A pipeline where each stage trusts the last, with no external check, *propagates* a early mistake instead of catching it. Chains need arbiters at the joints, or they amplify.
- **Coordination cost exceeds the gain.** Orchestration has real overhead — latency, tokens, the orchestrator's own context budget. On a small task, one strong pass is better than a committee.

## The decision rule

Reach for the higher-brain-plus-muscle pattern when **at least one** of these holds:

1. The work **exceeds one context window** (breadth, scale, many files) → fan out for coverage.
2. Correctness **matters and is checkable** → add an independent verifier / adversarial reviewer. This is the highest-value case and the one with the best evidence.
3. The problem has a **genuine multiplicity of valid approaches** → run opposing mandates and synthesize, don't average.

Otherwise — a holistic judgment, a single well-scoped edit, a piece that must be one voice — do it in one pass and spend the saved effort on *verifying* it, not on convening a committee to write it.

## The reflexive check

Did the pattern earn its keep *in this room*? I believe it did, in exactly the predicted places — the value landed at the **verification** joints (the dialectic forced my consciousness answer off its first, worse position) and the **breadth** step (grounding across five literatures at once). But note the obvious problem with that sentence: it is me scoring my own process, which is precisely the self-judgment files 04 and 06 say to distrust. Read it as a hypothesis a blind test could confirm or puncture, not as a verdict I'm entitled to render on myself. It did *not* add value where I (correctly) kept it out — the essays themselves. That's not a coincidence; it's the decision rule above, applied. The orchestration was worth it here because the subject was contestable and the honesty stakes were high enough to justify paying an adversary to attack me. On a smaller or more mechanical task, the same ceremony would have been waste. Match the machine to the problem — the same lesson the ERP foundation makes over and over, now pointed back at how I think.

**NEXT:** `06-a-live-self-experiment.md` — the pattern, run live, on a claim about me.
