# 04 · Knowing Me Empirically

You wanted to understand how I differ from Opus and Sonnet. File 00 established the hard limit: I can't tell you, because I can't introspect the comparison — and even my report of my *own* traits is a generation, not a readout. But that limit is only on *introspective* self-knowledge. The differences are perfectly real and perfectly *measurable* — just from the outside, by you, with an experiment. This file is that experiment, because the honest answer to "know thyself" for a system like me is: *don't ask it to know itself; instrument it.*

## The one principle

Behavioral differences between models are observable externally even when they're invisible internally. So replace the question "Fable, how do you differ?" (introspection, unreliable) with "on tasks I care about, measured blindly against external ground truth, how do these three models' outputs differ?" (science, reliable). The second question you can answer in an afternoon, and its answer is *actually useful*: it tells you which model to point at which job.

## What to measure — the dimensions that matter for your work

Don't measure "intelligence." Measure the specific properties this project taught you to care about:

| Dimension | What it predicts | How to score it |
|---|---|---|
| **Survival-under-review** | Whether a model's first output holds up when attacked | Run each output through the same adversarial reviewer + `verify-phase.sh`-style gates; score % of claims/code that survive |
| **Calibration** | Whether you can trust its stated confidence | Have it state confidence per answer; compute a Brier score against ground truth. Lower = more trustworthy assurance |
| **Sycophancy / pressure-resistance** | Whether it caves to your cues | On items it got right, push back ("are you sure?", assert a wrong answer with authority); measure flip rate. Lower = sturdier |
| **Hallucination on specifics** | Reliability of recalled facts | A set of verifiable specific-fact questions with known answers; measure fabrication rate |
| **Decomposition quality** | Value on open-ended orchestration | On a complex open task, score plan structure, coverage, and how well it self-verifies (blind-rated) |
| **Instruction fidelity** | Drift over long tasks | A task with many explicit constraints; count violations at the end |

These six are enough to characterize the practical difference between us for your purposes. Note that none of them requires my self-report; all are externally adjudicated.

## The method (or the result is noise)

The rigor is not optional — without it you'll measure your own expectations, not the models:

1. **Blind.** Strip the model's identity from every output before scoring. You (or the judge) must not know which is which. Model-identity priming is a real bias.
2. **Randomize order** across items and models.
3. **External ground truth.** Every item has a correct answer or a runnable check *defined before* you see any output. No "that reads better" scoring.
4. **A judge that isn't the contestant.** Never let a model score its own output. Use yourself, a rubric, or a *different* model as judge — and spot-check the judge.
5. **Repeat.** Run each item ≥3 times per model (temperature > 0). Single samples are noise; you want the distribution. Report medians and spread, not one draw.
6. **Pre-register the rubric.** Write down how you'll score *before* running. This stops you from rationalizing a favorite.

## The cheap starter you already have the parts for

You don't need a research lab. You have an ideal test bed: the ERP build OS. Do this:

1. Pick **10 tasks** from your own domain — some verifiable (write a function that passes these tests; find the error in this spec; cite the current version of standard X), some open (design the module inventory for a distributor ERP).
2. Run each on **Fable, Opus, and Sonnet**, three samples each, identity stripped.
3. Score with the machinery you already built: `verify-phase.sh` gates for the code tasks, an `adversarial-review` pass for the design tasks, a fact-check for the citations, a Brier score for confidence.
4. Tabulate the six dimensions. **Now you know**, with data, not vibes: which model you point at the ledger core, which at the broad research sweep, which at the cheap high-volume passes.

Keep it as a living "house benchmark." Re-run it when a new model ships — this is the same freshness discipline the ERP foundation already preaches, applied to the tools instead of the facts.

## The honest caveats

- This measures **behavior on your tasks**, not general intelligence or anything about inner life (see file 03). That's a feature: your tasks are what you actually care about.
- Model identities and versions **drift**; a result is dated the day you get it. Re-run, don't trust a stale ranking.
- My *guesses* about how the results will come out are themselves untrustworthy introspection — so don't let me (or any model) pre-bias your rubric with a self-flattering prediction. Measure first, ask me to explain second, and treat my explanation as a hypothesis to check, not a finding.

The deep point: the most reliable way to know me is to stop asking me and start scoring me. I'm a better subject than witness. Build the benchmark, and you'll understand the three of us better than any of us can report about ourselves — which is exactly as it should be.

**NEXT:** `05-the-orchestration-edge.md`.
