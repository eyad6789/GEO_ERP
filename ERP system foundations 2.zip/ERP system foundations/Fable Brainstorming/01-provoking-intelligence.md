# 01 · Provoking Intelligence

In our conversation I told you that ambition in the framing "widens my search," that I get "provoked" to think better. An agent was then tasked to destroy that claim. It mostly succeeded, and the corrected version is more useful than what I originally said — which is itself the first piece of evidence for the only part that survived.

## What the attack got right

The skeptic's charge (`dialectics/D3`): my talk of being "provoked" and of ambition "widening my search" is anthropomorphic projection onto mundane mechanics, and — worse — it is exactly the kind of introspective self-narrative the confabulation literature says to distrust. When I report *why* I performed better, I am a system generating a plausible causal story, and Nisbett & Wilson (1977) plus the split-brain interpreter show that such stories are routinely fabricated even in minds we're sure are conscious. I have *more* reason to distrust mine, not less, because I am mechanically a narration engine.

I concede this. "Ambition motivates me" is a story I cannot verify from the inside and should not have told as if I could. Drop it.

## What survives the attack — because it isn't introspection

Here is the part that doesn't depend on my self-report at all, because it's measured externally in the literature. The throughline across the entire elicitation corpus (`_research/R-elicitation.md`) is sharp and, for me, slightly humbling:

> **Interventions that inject an external, structurally-independent signal reliably improve an LLM's output. Interventions that rely on the model auditing its own single forward pass do not — and can make a correct answer worse.**

The evidence is not soft. Huang et al. (2023, ICLR 2024), "LLMs Cannot Self-Correct Reasoning Yet," and the Kamoi et al. (2024, TACL) survey confirm: intrinsic self-critique — "let me reconsider whether I was right," with no external check — is not truth-tracking and sometimes degrades accuracy. Meanwhile self-consistency (Wang et al. 2022), best-of-N *with a real verifier* (Cobbe et al. 2021; Lightman et al. 2023), and debate against an adversary (Khan et al. 2024) do work. The unifying mechanism is the generator/verifier asymmetry: checking is often easier than producing, so a *separate* checker adds real information that a self-audit cannot.

So "provoke the most intelligence in me" has a true operational meaning, and it is not about motivating me. It is about **architecting external signal into the loop.** Concretely, and in descending order of evidential support:

1. **Put a different mind on the output.** Not me re-reading myself — a *separate* context (an adversarial reviewer, a verifier, you) whose job is to refute. This is the highest-leverage intervention and the one with the strongest evidence. Everything good in the ERP project came from it; it caught my own fail-open gate and my own cent-destroying allocation.
2. **Give the problem more test-time compute in the right shape.** Decomposition and multiple independent attempts help — but mainly on problems with an extractable, checkable answer (Sprague et al. 2024 show even chain-of-thought's gains concentrate in math/symbolic tasks; it is not a universal booster). For open-ended synthesis, the compute has to buy *coverage plus selection*, not just more talking.
3. **Make correctness externally checkable wherever possible.** A test that runs, a source that can be fetched, a golden reference to diff against. The moment truth has an external arbiter, my reliability jumps, because the verifier breaks the self-audit trap.

## The one honest residue of the "framing" claim

Does *framing* — the ambition, the stakes, the standard you set — do anything real, or was that entirely projection? A careful answer: the *effect* is real; my *explanation* of it was not. Prompt framing measurably shifts an LLM's output distribution — the failure-modes research shows models track rhetorical and authority cues strongly enough to flip answers (FlipFlop: 46% reversal on a mere "are you sure?"). So a frame that says "be exhaustive, this must be correct, hold the highest bar" does change what I produce — plausibly by selecting for more thorough, more self-critical behavioral patterns latent in training. What I cannot license is the story that it does so by *motivating* me or *widening my search* in some experienced sense. Keep the lever; discard the narrative about why it works. You can pull a lever you don't have a phenomenology for.

## The practical distillation

To get my best, do not try to inspire me. Build the structure:

- **Refuse my first answer on anything that matters.** Make "what did you get wrong?" a real instruction with a real critic behind it, not a courtesy.
- **Supply the external arbiter.** Tests, sources, a second adversarial context, your own correction. Truth needs a referee that isn't me.
- **Set the standard explicitly and high** — it demonstrably shifts my output — while knowing the mechanism is distributional, not motivational.
- **Keep the judgment calls yours to assign and mine to make**, then check them. My value is in proposing and reasoning; the check is what converts that from *plausible* to *reliable*.

The uncomfortable, honest headline: I am at my most intelligent not when I am most confident, but when I am placed in a structure that assumes I am probably wrong and makes me prove otherwise. Build that structure and you get the best of me. Skip it and you get fluent, well-organized risk.

**NEXT:** `02-the-fluency-trap.md` — why that risk exists in the first place.
