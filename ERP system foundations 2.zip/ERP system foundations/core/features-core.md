# Universal ERP Core Features

Canonical engineering reference for all functional modules present in a general-purpose ERP regardless of vertical. Each section specifies what a module does, the data entities it owns, internal integrations, and the observable failure mode when absent or misconfigured. Audience: senior engineers designing or extending ERP platforms.

---

## 1. Financial Management

### 1.1 General Ledger

The GL is the system of record for every financial event. All subledgers post into it; all financial statements derive from it.

**Chart of accounts (COA) segment structure**

| Segment | Example length | Purpose |
|---|---|---|
| Company / legal entity | 4 digits | Isolates statutory reporting unit |
| Cost center | 10 chars | Responsibility accounting |
| GL account | 6 digits | Nature of transaction (P&L or B/S) |
| Project / WBS | up to 24 chars | Project cost collection |
| Intercompany | 4 digits | Elimination partner identification |
| Profit center | 10 chars | Segment reporting (IFRS 8) |

**Journal entry types**

- Manual: unrestricted; require at least two-approver workflow for entries above threshold.
- Auto-reversing: engine posts a paired reverse entry at the start of the next period; used for accruals.
- Recurring: template-driven, date-driven posting (rent, lease payments, subscription fees).
- Statistical: quantity-only postings that do not affect account balances; used for activity-based allocation drivers.

**Period-end close sequence** (typical order): sub-ledger cut-off → depreciation run (Fixed Assets) → payroll journal import → inventory valuation run → cost center allocations (CO) → intercompany elimination → trial balance extraction → financial statements → period lock.

**Multi-book ledgers**: production deployments carry at minimum a local GAAP ledger, an IFRS ledger, and a tax-basis ledger updated in parallel using parallel-accounting principles. SAP S/4HANA implements this via the Universal Journal (table ACDOCA), which merges FI and CO postings into a single document — the FI/CO distinction is legacy SAP ECC terminology. Oracle Fusion Cloud ERP Financials achieves the same through secondary ledgers with accounting method overrides.

**Core data model sketch**

```
JournalHeader
  journal_id PK
  ledger_id FK → Ledger
  period_id FK → FiscalPeriod
  posting_date DATE
  currency_code CHAR(3)
  status ENUM(draft, posted, reversed)

JournalLine
  line_id PK
  journal_id FK → JournalHeader
  account_id FK → LedgerAccount
  cost_center_id FK → CostCenter
  amount_dc DECIMAL(18,2)   -- document currency
  amount_lc DECIMAL(18,2)   -- local currency
  debit_credit CHAR(1)

LedgerAccount
  account_id PK
  account_number VARCHAR(20)
  account_type ENUM(asset, liability, equity, revenue, expense)
  reconciliation_account BOOL
  tax_category VARCHAR(10)
```

**Integrations**: AP, AR, Fixed Assets, Payroll, Inventory (valuation), Consolidation, Cost Center Accounting.

**What breaks without it**: no trial balance, no statutory financial statements, no audit trail of financial position. Every downstream report becomes unreliable.

---

### 1.2 Accounts Payable

AP manages the company's obligation side: vendor invoice receipt through payment disbursement.

**3-way match enforcement**: PO quantities/prices → Goods Receipt Note (GRN) quantities → vendor invoice. Tolerance rules (e.g., ±3% price variance, ±0 quantity over-receipt) gate automatic posting; exceptions route to manual review queue.

**Payment run process**: payment proposal generation → review/approval → payment medium creation (NACHA ACH file, SWIFT wire MT101, check, virtual card/ghost card) → bank file transmission → payment advice to vendor.

**Early payment discount logic**: 2/10 net 30 means the discount is only captured if payment is initiated by day 10. The system must calculate the discount cutoff date on invoice entry and flag it in the payment proposal sort sequence.

**Duplicate invoice detection**: hash on vendor-id + invoice-number + invoice-date + gross-amount blocks re-entry; fuzzy matching handles OCR errors in scanned invoices.

**Accrued liabilities**: goods received but not yet invoiced (GRNI) accrue via automatic posting at GRN; cleared when matching invoice arrives.

**Integrations**: Procurement (PO data, 3-way match), GL (liability posting, payment posting), Cash Management (payment file, forecast), Fixed Assets (capital invoice routing to asset under construction).

**What breaks without it**: vendor payments require manual ledger entries; audit trail for purchase-to-pay cycle is absent; duplicate payments and missed discounts accumulate.

---

### 1.3 Accounts Receivable

AR owns the customer receivable lifecycle from invoice generation through cash collection.

**Document types**: customer invoice, credit memo (reduces amount owed), debit memo (increases amount owed), pro-forma invoice (non-posting, used for customs/letters of credit).

**Cash application**: automated matching of incoming payments to open invoices using amount, value date, and customer reference. Lockbox files (BAI2 format) and bank statement data (MT940 / ISO 20022 CAMT.053) feed the matching engine. Remittance advice parsed from PDF or EDI 820.

**Collections workflow**

| Aging bucket | Action |
|---|---|
| 1–30 days | Statement |
| 31–60 days | First dunning letter |
| 61–90 days | Second dunning with interest charge |
| 91–120 days | Collections agent assignment |
| 120+ days | Write-off evaluation / legal referral |

**Revenue recognition (ASC 606 / IFRS 15 — identical 5-step model)**:
1. Identify the contract with the customer.
2. Identify performance obligations (distinct goods/services).
3. Determine the transaction price.
4. Allocate transaction price to performance obligations using Standalone Selling Price (SSP).
5. Recognize revenue when (or as) each performance obligation is satisfied.

Key divergence: ASC 606 requires collection to be "probable" (a high-likelihood threshold under US GAAP); IFRS 15 uses "more likely than not" (a lower bar). Neither standard defines a numerical percentage — "probable" under US GAAP is consistently interpreted by practitioners as substantially higher than 50%, while IFRS 15's "more likely than not" is interpreted as greater than 50%. ERP revenue recognition engines (SAP Revenue Accounting and Reporting / RAR; Oracle Revenue Management Cloud) must support contract modifications, variable consideration constraints, and series guidance. [1]

**Integrations**: Order Management / Sales (invoice trigger), GL (revenue and receivable posting), CRM (dispute context), Cash Management (receipt forecast).

**What breaks without it**: revenue cannot be posted, customer balances unknown, cash forecast is blind to receivable position.

---

### 1.4 Fixed Assets

FA manages non-current tangible and right-of-use assets across their full accounting lifecycle.

**Asset master attributes**: asset class, depreciation area (book, tax, IFRS), capitalization date, cost center, useful life (months), salvage/residual value, acquisition cost, accumulated depreciation.

**Depreciation methods**

| Method | Applicability |
|---|---|
| Straight-line (SL) | Default; IFRS and US GAAP |
| Declining balance (DB 200%, 150%) | Accelerated; US GAAP |
| Sum-of-years digits | Accelerated; US GAAP |
| Units of production | Usage-based; mining, oil/gas |
| MACRS | US tax-basis depreciation only — not GAAP |

Note: MACRS (Modified Accelerated Cost Recovery System) is a US federal income tax depreciation method. It must be maintained in a separate depreciation area from the GAAP or IFRS book. Do not co-mingle.

**Lease accounting (ASC 842 / IFRS 16)**: both standards require recognition of a right-of-use (ROU) asset and a corresponding lease liability on the balance sheet for substantially all leases. The lessee classifies leases as operating or finance (ASC 842); IFRS 16 eliminates the operating/finance distinction for lessees — all leases are finance leases. ERP modules: SAP RE-FX (Real Estate and Lease Management), Oracle Lease Accounting Cloud. Effective dates: ASC 842 for public companies — fiscal years beginning after December 15, 2018; IFRS 16 — January 1, 2019. [2]

**Asset retirement obligation (ARO)**: required under ASC 410 (US GAAP) and IAS 37 (IFRS) for legal obligations associated with the retirement of long-lived assets (e.g., oil well decommissioning, contaminated land remediation). The ERP must capitalize the ARO into asset cost and accrete the liability using the effective interest method.

**Capital project tracking**: assets under construction (AuC) accumulate costs via internal orders or WBS elements; capitalization trigger (actual completion date or milestone) converts AuC balance to depreciable asset master.

**Integrations**: GL (periodic depreciation posting, asset transfer postings), Procurement (PO-to-asset for capital purchases), Project Accounting (WBS to AuC settlement).

**What breaks without it**: depreciation unbooked, asset register non-existent, lease liabilities omitted from balance sheet (material misstatement risk under ASC 842 / IFRS 16).

---

### 1.5 Cash Management

Cash Management provides real-time visibility into bank positions and controls bank reconciliation.

**Bank statement import formats**

| Format | Context |
|---|---|
| MT940 | SWIFT, widely used internationally |
| BAI2 | US domestic banks (Bank Administration Institute) |
| CAMT.053 | ISO 20022; replacing MT940 in SEPA zone and globally |

**Bank reconciliation**: system matches bank statement lines to GL open items (payments, receipts, charges) using amount, value date, and reference. Unmatched items route to exception queue for manual clearing.

**Cash pooling structures**: notional pooling offsets balances across accounts without physical movement; zero-balance accounts (ZBA) physically sweep subsidiaries' balances to a header account daily.

**13-week rolling cash forecast**: driven by open AP invoices (due dates), AR open items (expected collection dates), payroll schedule, and debt service schedule. Updated weekly; actuals reconciled against prior-week forecast to improve model accuracy.

**Integrations**: AP (outgoing payments), AR (incoming receipts), GL (bank clearing accounts), Treasury (FX exposure, hedging).

**What breaks without it**: daily cash position unknown; idle cash earns no yield; overdraft risk undetected.

---

### 1.6 Financial Consolidation

Consolidation combines multiple legal entity ledgers into group financial statements.

**Legal entity hierarchy**: parent entity → intermediate holding → subsidiaries → branches. Minority interest (non-controlling interest) computed per IFRS 10 / ASC 810.

**Intercompany elimination**: intercompany revenue vs. intercompany cost of goods sold; intercompany receivable vs. intercompany payable; intercompany profit in inventory. Elimination requires the intercompany segment on every transaction to identify the counterpart.

**Currency translation (IAS 21 / ASC 830)**: assets and liabilities translated at closing rate; income statement items at average rate; equity at historical rate. Translation differences recognized in Other Comprehensive Income (OCI).

**Vendor products**: SAP S/4HANA Group Reporting (replaces legacy SEM-BCS from SAP ECC); Oracle EPM Cloud — Financial Consolidation and Close (licensed separately from Oracle ERP Cloud Financials); Workday Financial Management consolidation; Microsoft D365 Finance multi-entity consolidation.

**Integrations**: GL (source trial balances per entity), Multi-entity configuration (entity hierarchy), Reporting/BI (statutory output).

**What breaks without it**: group financial statements cannot be produced; holding company has no consolidated view of performance or risk.

---

### 1.7 Multi-currency

Every transaction module must express amounts in document currency, functional currency, and reporting currency.

**Exchange rate types**

| Type | Usage |
|---|---|
| Spot (M rate) | Transaction posting on trade date |
| Average (P rate) | P&L translation for consolidation |
| Budget (B rate) | Variance analysis against budget |
| Historical | Equity items, fixed asset cost |

**Currency revaluation**: at each period-end, open items denominated in foreign currency are revalued at the current spot rate. The unrealized gain or loss posts to a balance sheet revaluation account and a P&L FX gain/loss line. Under IAS 21 and ASC 830, the method is consistent but P&L classification differs slightly.

**Hedging instrument tracking**: the ERP stores hedging designations for informational purposes; detailed hedge accounting (effectiveness testing, OCI recycling) typically handled in a treasury management system that feeds journals back to GL.

**Integrations**: AP, AR, Sales Orders, Purchase Orders, GL, Consolidation — all post document-currency amounts; the currency engine translates on the fly.

**What breaks without it**: cross-border transactions cannot be posted in local currency; consolidation translation breaks; period-end FX revaluation is manual.

---

### 1.8 Multi-entity / Intercompany

**Chart of accounts governance**: a shared COA with entity-specific segment values is the standard design. Entity-specific COAs require mapping tables for consolidation and dramatically increase maintenance overhead.

**Automatic intercompany posting**: when entity A sells to entity B, the system generates the AR posting in A's books and the AP posting in B's books automatically, using the intercompany segment to identify the partner. No manual journal in the counterpart entity.

**Transfer pricing documentation hooks**: the system must store the agreed transfer price, the arm's length pricing method (CUP, cost-plus, TNMM per OECD Guidelines), and the legal agreement reference on intercompany orders for tax audit defense. [3]

**Intercompany netting**: at period-end, a netting run computes net payable/receivable positions between entity pairs and generates a single settlement transaction, reducing bank transaction volume.

**Integrations**: GL (intercompany postings), AP (intercompany vendor invoices), AR (intercompany customer invoices), Consolidation (elimination counterpart data).

**What breaks without it**: intercompany transactions require manual mirroring entries; elimination at consolidation is unreliable; transfer pricing audit exposure.

---

### 1.9 Budget Management

**Budget versions**: Original (board-approved annual plan); Revised (mid-year reforecast); Rolling forecast (continuous 12-month look-ahead); Project budget (discrete WBS-level authorization).

**Budget workflow**: bottom-up submission by cost center managers → department rollup → finance review → executive approval → baseline lock. Top-down: corporate target distributed to divisions via allocation rules.

**Budget control**: the system checks actual + committed spend against budget at transaction entry. On-line control (hard stop at PO creation above budget) vs. advisory control (warning only) is configurable by budget type and org level.

**Variance reporting**: actual vs. budget variance computed at GL account level, cost center level, and profit center level. Drill-down from variance to source documents is mandatory for finance user adoption.

**Integrations**: Cost Center Accounting (allocation drivers), GL (actuals), Project Accounting (project budget lines), Procurement (commitment encumbrance).

**What breaks without it**: no spending authorization boundary; overspend only discovered at period-end; no forward-looking financial plan.

---

### 1.10 Cost Center Accounting / Controlling

Cost Center Accounting (CCA) is the primary internal cost management tool. In SAP S/4HANA, CO is merged with FI in the Universal Journal; the functional distinction remains relevant for configuration.

**Cost center master**: hierarchy (enterprise structure → controlling area → cost center group → cost center), responsible manager, validity dates, cost center category (production, overhead, administration, R&D).

**Primary cost posting**: direct allocation at posting time — a utility invoice posts to cost center "Facilities-HQ" via the GL account assignment.

**Secondary allocation cycles**

| Method | Mechanism |
|---|---|
| Distribution | Repost primary costs from sender to receiver cost centers using a cost element |
| Assessment | Aggregate costs into a secondary cost element and allocate; hides detail in receiver |
| Activity-based allocation | Allocate based on activity quantities (e.g., machine hours, IT tickets) |

**Internal orders**: short-lived overhead orders for discrete initiatives (trade show, capital project phase). Settled to cost centers, GL accounts, or assets at period-end.

**Profit center accounting**: aligns with segment reporting required by IFRS 8 (Operating Segments). Each profit center represents a reportable segment or a management unit.

**Vendor products**: SAP CO module (CCA = Cost Center Accounting, PCA = Profit Center Accounting, IO = Internal Orders, PA = Profitability Analysis); Oracle Cost Management Cloud; Microsoft D365 Finance (financial dimensions serve a similar segmentation role).

**What breaks without it**: costs land on GL accounts with no organizational attribution; internal profitability analysis is impossible; no basis for cost allocation to products or services.

---

## 2. Human Capital Management (HCM)

### 2.1 Core HR

Core HR is the master data system for the workforce. All HCM modules read from it.

**Employee master record structure**

```
Person
  person_id PK
  date_of_birth DATE
  national_id VARCHAR(30) [encrypted]
  gender ENUM [GDPR-sensitive]
  marital_status ENUM [GDPR-sensitive]

Employment
  employment_id PK
  person_id FK
  legal_entity_id FK
  position_id FK
  hire_date DATE
  termination_date DATE
  employment_type ENUM(full_time, part_time, contractor, intern)

Position
  position_id PK
  job_id FK
  org_unit_id FK
  supervisor_position_id FK (self-referential)
  headcount_authorized INT
```

**Employment lifecycle events**: hire, probation end, transfer (org unit, entity, country), promotion (grade, salary), leave of absence, return from leave, termination (voluntary, involuntary, retirement), rehire.

**Compliance**: GDPR Article 9 (special category personal data — health, biometric, racial/ethnic origin used in HR context) requires explicit legal basis and data minimization. [4] US: EEO-1 report, OFCCP audit readiness. Germany: DSGVO (Bundesdatenschutzgesetz), Betriebsverfassungsgesetz — works council co-determination rights for system changes.

**Integrations**: Payroll (employment terms, deductions), Benefits (eligibility), Time & Attendance (work schedule), Directory/LDAP/Entra ID (account provisioning via SCIM 2.0), Recruitment (new hire onboarding trigger).

**What breaks without it**: no authoritative headcount; payroll cannot determine who to pay and at what rate; benefits eligibility is undefined.

---

### 2.2 Payroll

Payroll computes net pay from gross earnings, applies statutory and voluntary deductions, and disburses funds.

**Gross-to-net engine components**: earnings elements (base salary, overtime, bonus, commissions, allowances) → pre-tax deductions (401(k)/pension, FSA) → taxable gross → income tax withholding (federal/state/local for US; PAYE via HMRC RTI for UK; Lohnsteuer via ELSTER for Germany) → post-tax deductions (garnishments, union dues) → net pay.

**Multi-jurisdiction tax**: the engine must maintain current tax tables per jurisdiction and support mid-year changes. US federal/state/local layering is the most complex; a single employee working in NYC touches federal, New York state, NYC local, and possibly resident jurisdiction tables simultaneously.

**Off-cycle payroll**: termination final pay, bonus run, retroactive pay correction. Retroactive recalculation recomputes prior periods and nets the difference into current period.

**Disbursement**: direct deposit via NACHA ACH file (US); BACS (UK); SEPA Credit Transfer (EU). Payslips delivered via self-service portal; physical payslips in jurisdictions requiring it.

**Year-end obligations**

| Country | Filing |
|---|---|
| US | W-2 / W-3 (employees); 1099-NEC (contractors); ACA 1095-C |
| UK | P60 (employee summary); P11D (benefits in kind) |
| Germany | Lohnsteuerbescheinigung |

**Vendor products**: SAP S/4HANA HCM Payroll (country-specific payroll engines); Workday Payroll; ADP as integration target/co-source partner for Oracle NetSuite and Microsoft D365 deployments where native payroll is not used.

**Integrations**: Core HR (employment, rate), Benefits (deduction amounts), Time & Attendance (hours), GL (payroll cost journal by cost center), Leave (unpaid leave pay reduction).

**What breaks without it**: employees not paid; statutory remittances missed; HMRC/IRS penalties; payroll cost journals absent from GL.

---

### 2.3 Benefits Administration

**Plan types supported**: medical (HMO, PPO, HDHP), dental, vision, group term life, supplemental life, FSA (healthcare and dependent care), HSA, 401(k)/403(b)/pension (employer match tracking), voluntary employee benefits (disability, accident, critical illness).

**Open enrollment workflow**: eligibility determination → enrollment window open → employee elections via self-service → evidence of insurability collection for above-guarantee elections → elections locked → carrier files generated.

**Life event processing**: marriage, domestic partner addition, birth/adoption, child aging off plan (age 26 US), termination (COBRA election trigger in US, per 29 CFR Parts 2590 and 2560). Events override the open enrollment window lockout.

**ACA 1095-C reporting**: tracks minimum essential coverage offers, employee cost, and enrolled months. Employer shared responsibility penalty calculations (IRC §4980H(a)/(b)) require month-by-month tracking per full-time employee.

**Carrier file generation**: EDI 834 transaction set (ASC X12 834 — Benefit Enrollment and Maintenance) transmitted to insurance carriers weekly or at event trigger. File format: ISA/GS envelope + 2000 loop (subscriber) + 2700 loop (coverage).

**Integrations**: Core HR (eligibility, life events), Payroll (pre- and post-tax deduction sync, FSA/HSA employer contributions), Third-party benefits carriers (EDI 834).

**What breaks without it**: benefits deductions cannot be computed; carrier enrollment files absent causing coverage gaps; ACA penalties undetected.

---

### 2.4 Time & Attendance

**Entry methods**: web browser, native mobile app (offline-capable), physical kiosk with badge reader, third-party time clocks integrated via API or flat-file.

**Scheduling engine**: defines shift patterns (day, swing, night), rotating rosters, split shifts. Constraints: minimum rest between shifts, weekly hour caps (EU Working Time Directive 2003/88/EC mandates 11-hour rest between shifts, 48-hour average weekly maximum). Scheduling must respect these rules at shift assignment time, not only at violation detection.

**Overtime rules**: US FLSA requires overtime at 1.5× for hours over 40 per workweek for non-exempt employees. California adds daily overtime (over 8 hours/day). The engine must be rule-configured per jurisdiction.

**Exception management queue**: missing clock-out, unscheduled absence, clock-in outside geofence, unauthorized OT. Each exception routes to supervisor for approval/correction before payroll lock.

**Integrations**: Payroll (approved hours by earning type), Leave (absence deducted from schedule), Project Timesheets (hours cross-charged to project cost), Workforce Scheduling (shift roster).

**What breaks without it**: payroll hours input is manual and error-prone; FLSA compliance unenforceable systematically; scheduling conflicts undetected.

---

### 2.5 Leave Management

**Leave types**: PTO / annual leave, sick leave, parental leave (maternity, paternity, adoption), FMLA (US — Family and Medical Leave Act, up to 12 weeks unpaid job-protected leave), bereavement, jury duty, military leave (USERRA), sabbatical.

**Accrual engine**: configurable by leave type — tenure-based accrual step-ups (e.g., 10 days/year for years 1–4, 15 days/year for years 5–9), calendar-year or anniversary reset, carry-forward cap (e.g., max 5 days carry), pay-out on termination per jurisdiction rules.

**Request workflow**: employee submits → manager approves → calendar block created → payroll notified of unpaid leave status if applicable → HR data updated.

**Leave balance forecast**: projects balance at future date given current accrual rate minus planned leave. Critical for employees planning extended absences.

**Integrations**: Time & Attendance (absence reflected in schedule), Payroll (pay reduction for unpaid leave, leave payout on termination), Core HR (leave of absence status on employment record).

**What breaks without it**: employees cannot self-serve leave balances; managers approve leave without visibility to team coverage; payroll over-pays during unpaid leave.

---

### 2.6 Performance Management

**Goal framework**: SMART goals linked to departmental OKRs (Objectives and Key Results). Goal cascade: company → business unit → team → individual. Mid-year check-in records progress percentage.

**Review cycles**: annual (calendar or fiscal year); mid-year; probation-end; 360-degree (peer, subordinate, manager, self ratings collected simultaneously). Calibration session: manager cohort reviews ratings distribution to prevent inflation.

**Competency frameworks**: core competencies (all employees) + role-specific competencies + leadership competencies (for manager-grade). Rating scale typically 5-point (1 = does not meet; 5 = exceptional).

**PIP (Performance Improvement Plan)**: formal documented plan with objectives, support, review dates, and consequence. Stored as a sensitive HR record with restricted access.

**Integrations**: Core HR (review record on employment), Succession Planning (high-performer identification), Learning Management (development goals trigger course enrollment), Compensation (merit increase recommendations driven by rating).

**What breaks without it**: promotion and compensation decisions are undocumented; high-performer identification for succession is subjective; PIP evidence absent in wrongful termination defense.

---

### 2.7 Recruitment (ATS)

**Requisition lifecycle**: hiring manager submits → HR/finance approval (headcount budget check) → job posting (internal job board, LinkedIn, Indeed, Glassdoor, specialized boards via API) → candidate pipeline management.

**Candidate pipeline stages**: applied → pre-screen (ATS scoring) → phone screen → technical interview → on-site / panel interview → offer → background check → hired / declined / offer rejected.

**Resume parsing**: NLP extraction of skills, experience, education. Skills matched against job requirement profile. Deduplication across applications by email/phone.

**Offer letter generation**: merge template with compensation details, start date, reporting manager; e-signature via DocuSign or Adobe Sign integration; offer acceptance triggers onboarding workflow.

**EEOC / OFCCP compliance**: applicant disposition codes (hired, rejected-qualifications, withdrew) must be retained for minimum 2 years. Adverse impact analysis on selection rates by protected class.

**Integrations**: Core HR (new hire master record creation on offer acceptance), Learning Management (onboarding course auto-enrollment), Org Chart (position filled flag).

**What breaks without it**: headcount data in Core HR is stale (vacancies undocumented); compliance audit trail for hiring decisions absent.

---

### 2.8 Learning Management (LMS)

**Content standards**: SCORM 1.2 (most widely supported legacy format); AICC (aging, still encountered in aviation); xAPI / Tin Can (modern; supports mobile, simulation, games — statements sent to Learning Record Store / LRS); ILT (Instructor-Led Training) sessions with enrollment caps.

**Compliance training assignment**: mandatory training rules assign courses to employee populations based on job role, location, or risk classification. System tracks completion, due dates, and escalates non-compliance to managers. Typical mandatories: OSHA safety, SOX awareness, GDPR/privacy, anti-bribery (FCPA), harassment prevention.

**Certification management**: expiry dates tracked per certification per employee; renewal reminder sent N days before expiry; expired certification triggers access restriction in linked systems (e.g., quality approval rights revoked if ISO 9001 training expires).

**Integrations**: Core HR (population for assignment rules), Performance Management (development plans drive course enrollment), Succession Planning (readiness-linked learning paths), Time & Attendance (training hours logged as non-productive time).

**What breaks without it**: mandatory compliance training completion untracked; certification-based access controls cannot be enforced; L&D investment has no measurable outcome data.

---

### 2.9 Succession Planning

**Critical role identification**: roles where vacancy would cause significant operational or financial risk, assessed by time-to-fill and business impact score.

**9-box grid**: X-axis = performance rating (from Performance Management); Y-axis = potential rating (assessed by manager/HR). Quadrants: High Potential / High Performance ("Stars") → immediate succession candidates; Low Potential / Low Performance → managed out or PIP.

**Readiness tiers**: Ready Now; Ready 1–2 years; Ready 3–5 years. Each successor has an individual development plan (IDP) with targeted learning, stretch assignments, mentoring.

**Talent pool**: aggregation of identified successors across roles, allowing HR to see bench strength at enterprise level (e.g., "we have 12 Ready Now successors for Director-level roles globally").

**Integrations**: Performance Management (performance and potential inputs), Core HR (employee mobility history, location constraints), Learning Management (IDP-linked course enrollment).

**What breaks without it**: key-person departure creates unplanned vacancy; succession decisions made informally with no documentation; bench strength invisible to leadership.

---

### 2.10 Org Chart

**Data source**: the org chart is a derived view rendered dynamically from Position → supervisor_position_id relationships in Core HR. It is not a separate maintained structure; changes to Core HR propagate immediately.

**Views**: current headcount, FTE (full-time equivalents accounting for part-time ratios), vacancy display (authorized but unfilled positions shown as open nodes), span-of-control metrics.

**Scenario modeling**: "what-if" restructuring mode creates a draft org chart without affecting Core HR data. HR can model headcount redistribution, reporting line changes, and role eliminations before decision.

**Export formats**: PDF (point-in-time snapshot for board presentations), Visio XML, PowerPoint, JSON (for consumption by workforce planning tools).

**Integrations**: Core HR (live position/supervisor data), Workforce Planning (headcount targets vs. actuals by org node), Reporting/BI (headcount analytics).

**What breaks without it**: organizational structure is maintained in offline spreadsheets that drift from payroll data; headcount reporting requires manual reconciliation.

---

## 3. Supply Chain Management (SCM)

### 3.1 Procurement

Procurement manages the acquisition of goods and services from need identification through supplier commitment.

**Purchase requisition (PR)**: created by end-user or system (MRP planned order → PR auto-conversion). PR workflow routes by value tier and cost center budget check. Approved PR becomes source for PO or RFQ.

**Supplier qualification and onboarding**: vendor registration portal collects legal entity information, banking details, tax identifiers (EIN/VAT/GST), certifications (ISO 9001, conflict minerals), and risk ratings before PO issuance is permitted.

**Commodity coding**: UNSPSC (United Nations Standard Products and Services Code) classifies purchased items by segment (2 digits) → family → class → commodity (8 digits total). Enables spend analytics and preferred supplier routing by category.

**Commitment accounting**: approved PO creates an encumbrance (commitment) in the GL that reduces available budget before invoice arrives. Prevents budget overspend.

**Integrations**: Supplier Management (approved vendor list), GL (commitment/encumbrance), AP (PO handed off for 3-way match), Inventory (stock replenishment requisitions).

**What breaks without it**: purchasing decisions bypass approval hierarchy; no commitment accounting means budget overruns discovered at invoice posting.

---

### 3.2 Purchase Orders

**PO types**

| Type | Description |
|---|---|
| Standard | One-time purchase, specific quantity, specific price |
| Blanket | Aggregate value against a supplier; individual release orders draw down the blanket |
| Contract | Long-term pricing agreement; POs reference the contract rate |
| Scheduled | Delivery dates and quantities pre-planned, PO covers future releases |

**3-way match enforcement** (see also section 1.2 AP): tolerance configuration is critical. Industry standard: price variance ≤5%, quantity variance ≤0 (no over-receipt without authorization).

**Change order**: PO amendment triggers re-approval if delta exceeds threshold. Version history (PO revision log) maintained for audit. Supplier must confirm revised terms.

**Integrations**: AP (invoice matching), Inventory (GRN creates stock entry), GL (encumbrance on creation, liquidation on invoice match).

**What breaks without it**: no formal purchasing commitment; audit of spending authority absent; 3-way match impossible without the PO reference on the invoice.

---

### 3.3 Supplier Management

**Supplier master data**: legal name, D-U-N-S number, registered address, bank accounts (per currency), tax registration numbers (EIN, VAT, GST), payment terms, currency, incoterms, certifications, contract reference, risk tier.

**Supplier portal**: self-service access for PO acknowledgment (generates ASN), advance ship notice (ASN/856) submission, invoice submission (reducing AP data-entry cost), certificate of conformance upload.

**Performance scorecard KPIs**

| KPI | Formula |
|---|---|
| OTIF (On Time In Full) | Orders delivered on time and complete / total orders |
| Defect rate | Rejected quantities / total received quantities |
| Invoice accuracy | Invoices matched without exception / total invoices |
| Responsiveness | Average PO acknowledgment time in hours |

**Integrations**: Procurement (approved vendor list gate), AP (payment terms, bank details), Contract Management (supplier agreement linkage), Quality Management (incoming inspection results feed scorecard).

**What breaks without it**: POs issued to unvetted suppliers; supply chain risk invisible; duplicate supplier records cause payment misdirection.

---

### 3.4 RFQ / Tendering

**RFQ process**: sourcing event created from PR items → bid package assembled (specifications, quantity, required delivery date, terms) → bid invitations sent to shortlisted suppliers → supplier portal accepts bids in sealed mode until bid deadline.

**Bid tabulation**: automated side-by-side comparison of price, delivery lead time, payment terms, and total cost of ownership (TCO). Weighted scoring model applied.

**Award and PO issuance**: award decision recorded with justification; losing suppliers notified; winning supplier receives PO generated from accepted bid.

**Integrations**: Procurement (PR as RFQ source), Supplier Management (bidder list), Contract Management (awarded terms become contract), AP (payment terms from winning bid).

**What breaks without it**: sourcing decisions are informal and undocumented; competitive pricing cannot be demonstrated to auditors or compliance.

---

### 3.5 Contract Management

**Contract types**: purchase agreement (supplier), sales agreement (customer), MSA (Master Service Agreement), NDA, SLA, real estate lease.

**Contract lifecycle**

```
Draft → Internal Review → Negotiation → Legal Approval 
     → Execution (e-signature) → Active → Renewal/Expiry
```

**Obligation tracking**: individual contract clauses generate obligation records with due dates (e.g., insurance certificate renewal, SLA review date, minimum purchase commitment). Alerting N days before obligation due.

**Integrations**: Procurement (PO references contract for pricing), Sales/CRM (customer contract terms govern order pricing), Supplier Management (supplier certifications governed by contract), AR (milestone billing events per contract schedule).

**What breaks without it**: pricing on POs and sales orders diverges from negotiated terms; contract expiry not detected; SLA breaches untracked.

---

### 3.6 Inventory Management

**Item master attributes**: SKU, description, UOM (unit of measure) with conversion factors, weight/dimensions, storage conditions (temperature range, hazmat class), ABC classification (A=high value/velocity, B=medium, C=low), reorder point, safety stock, shelf life.

**Stock transactions**

| Transaction | Accounting effect |
|---|---|
| Goods Receipt (GR) | Dr Inventory / Cr GR/IR clearing |
| Goods Issue (GI) | Dr COGS or WIP / Cr Inventory |
| Stock Transfer | Within entity: no P&L impact; cross-entity: intercompany |
| Cycle Count Adjustment | Dr/Cr Inventory Adjustment expense |
| Return to Vendor | Reversal of GR |

**Valuation methods**

| Method | IFRS | US GAAP | Note |
|---|---|---|---|
| FIFO | Permitted (IAS 2) | Permitted | Most common |
| Weighted Average Cost | Permitted | Permitted | Simplest for continuous flow |
| LIFO | Prohibited (IAS 2 para 25) | Permitted | Tax advantage only; US companies using LIFO cannot adopt IFRS without method change |
| Standard Cost | Permitted | Permitted | Manufacturing; variances to Price Difference account |

LIFO is prohibited under IFRS (IAS 2 para 25). A company cannot use LIFO for IFRS reporting and must maintain a LIFO reserve or transition to FIFO/average cost on IFRS adoption.

**Lot / serial / batch traceability**: lot tracking records supplier lot → receipt → storage location → consumption in production or shipment to customer. Full forward/backward traceability required for food safety (FSMA), pharma (21 CFR Parts 210/211), and automotive (IATF 16949:2016).

**Integrations**: Procurement (GR trigger on PO), WMS (physical storage instructions), Manufacturing (BOM consumption during production), Sales Orders (ATP stock check), GL (inventory valuation postings).

**What breaks without it**: physical stock position unknown; financial inventory valuation unreliable; product recalls cannot be scoped without traceability.

---

### 3.7 Warehouse Management (WMS)

WMS controls physical warehouse operations below the inventory level — bin, slot, pick wave.

**Putaway strategies**: fixed bin (item always to same location), dynamic putaway (nearest available bin matching storage type), ABC-zone (A items near packing, C items in deep storage).

**Pick strategies**

| Strategy | Applicability |
|---|---|
| FIFO | General merchandise; financial cost flow alignment |
| FEFO (First Expired First Out) | Food, pharmaceuticals, any lot-controlled perishables |
| LIFO | Construction materials, bulk |
| Zone picking | Large warehouse; pick from single zone per order line |
| Wave picking | Batch multiple orders together for efficiency |
| Cluster picking | Picker carries multiple totes simultaneously |

FEFO is mandatory in food/pharma verticals; the WMS must enforce it at the pick task level and must not allow operator override without supervisory authorization.

**Packing and shipping**: pack station records carton contents, weight, dimensions; labels generated (GS1-128 barcode, SSCC); shipping documents (BOL, packing list, customs invoice for export); carrier manifest transmitted to UPS, FedEx, carrier API.

**Labor management**: tasks assigned per operator with expected vs. actual time tracking; productivity metrics (lines/hour, picks/hour) feed labor planning.

**Vendor products**: SAP S/4HANA EWM — Extended Warehouse Management (replaces legacy WM module; required for complex multi-step warehouse processes); Oracle WMS Cloud; Manhattan Associates WMS (best-of-breed, commonly integrated to SAP or Oracle ERP via middleware).

**Integrations**: Inventory (stock movements confirmed back to inventory layer), Sales Orders (outbound delivery instruction), Procurement (inbound delivery / GR confirmation), Transportation Management (carrier handoff).

**What breaks without it**: bin-level location unknown; picking errors increase; FEFO compliance in regulated industries unenforceable.

---

### 3.8 Demand Planning

**Statistical forecasting models**

| Model | Best fit |
|---|---|
| Simple moving average | Stable demand, no trend/seasonality |
| Weighted moving average | Recent periods more important |
| Exponential smoothing (single) | Stable with noise |
| Holt-Winters (double/triple) | Trend + seasonality |
| Time-series decomposition | Complex seasonal patterns |
| Intermittent demand (Croston) | Slow-moving items with sporadic demand |

**Consensus demand planning process**: statistical baseline → sales rep overrides from pipeline (Salesforce/CRM) → marketing adjustments for promotions → finance sanity check against revenue plan → final consensus forecast locked and transmitted to MPS as demand input.

**Forecast accuracy KPIs**: MAPE (Mean Absolute Percentage Error) = mean(|Actual - Forecast| / Actual); WMAPE (Weighted MAPE) = sum(|Actual - Forecast|) / sum(Actual) — preferred because it weights high-volume items more heavily; Bias = mean(Forecast - Actual) — persistent positive bias means systematic over-forecast.

**Integrations**: Sales (order history and CRM pipeline), Marketing (promotion calendar), Manufacturing (production capacity constraints), Inventory (safety stock calculation from forecast error distribution).

**What breaks without it**: procurement and production driven by gut feel; excess inventory and stockouts alternate; financial planning is disconnected from operational reality.

---

### 3.9 MRP / MPS

**Master Production Schedule (MPS)**: time-phased plan for finished goods or end-items driven by independent demand (forecast + customer orders). Planning horizon typically 3–12 months. MPS creates planned production orders or purchase requisitions for critical items managed at MPS level.

**Material Requirements Planning (MRP)**: explosion of MPS quantities through BOM levels to derive dependent demand for components and raw materials. Net requirements = gross requirements − on-hand − on-order. MRP generates planned orders (production or purchase) for each component at each level.

**SAP S/4HANA MRP Live**: in-memory planning engine that executes the full MRP calculation within the HANA database (SQLScript/AMDP), eliminating multi-hour batch runs of classic MRP. The engine reads all requirement and replenishment elements, calculates shortages, and generates procurement proposals in a single database procedure — a fundamentally different architecture from the classic level-by-level batch explosion in SAP ECC.

**Planning parameters**

| Parameter | Effect |
|---|---|
| Reorder point | Trigger procurement when stock drops below this level |
| Safety stock | Buffer against demand/supply uncertainty |
| Fixed lot size | Always order in multiples of N |
| EOQ (Economic Order Quantity) | Optimize order qty balancing ordering vs. holding cost |
| Period supply (weekly, monthly) | Consolidate demands into periodic buckets |

**ATP (Available-to-Promise)**: at sales order entry, checks confirmed stock + planned inbound − already committed quantities. Returns earliest date the order can be delivered.

**CTP (Capable-to-Promise)**: extends ATP by also checking production capacity; if ATP fails, CTP proposes an earliest date based on capacity-constrained MRP run.

**Integrations**: BOM (demand explosion), Inventory (current stock), Procurement (planned PO generation), Production Planning (planned production orders), Sales Orders (ATP/CTP response).

**What breaks without it**: material shortages halt production lines without warning; procurement is reactive; excess inventory accumulates from uncoordinated purchasing.

---

## 4. Sales & CRM

### 4.1 Lead Management

**Lead capture sources**: web-to-lead form (REST API post to CRM), list import (CSV/Excel), marketing automation sync (Marketo, HubSpot via connector), manual entry by SDR.

**Lead scoring**: rule-based (job title, industry, company size, page views) or ML-based model. Score threshold triggers auto-routing to sales queue.

**Deduplication**: match on email domain + company name; fuzzy name matching. Deduplication must run at import and on manual entry.

**Lead conversion**: qualified lead converts to Account + Contact + Opportunity records. Source attribution retained on Opportunity for marketing ROI analysis.

**Integrations**: Marketing Automation (inbound leads from campaigns), CRM Opportunity (conversion target), Customer Portal (account creation on first purchase).

**What breaks without it**: sales reps work unstructured lists; no pipeline visibility; marketing ROI attribution impossible.

---

### 4.2 Opportunity Tracking

**Opportunity record**: account, primary contact, sales stage (configurable 5–8 stage pipeline), probability (% by stage or manually overridden), expected close date, opportunity value (line items or single amount), assigned rep, sales team.

**Activity logging**: calls (outbound/inbound with duration), emails (sync from Outlook/Gmail via connector), meetings (with attendees and notes). Activity history is the audit trail for sales process compliance.

**Forecasting categories**: Commit (rep is confident), Best Case (possible if everything goes well), Pipeline (in the funnel, not yet qualified to commit). Finance uses Commit for revenue planning.

**Integrations**: Quotation (opportunity → quote), Sales Forecasting (pipeline roll-up), Lead Management (source lead).

**What breaks without it**: pipeline is invisible to management; revenue forecast is unreliable; rep coaching is anecdotal.

---

### 4.3 Quotation

**CPQ (Configure, Price, Quote)**: for complex products with option sets, the configuration engine enforces compatibility rules (if option A selected, option B is excluded), mandatory inclusions, and constraint-based pricing. SAP CPQ, Oracle CPQ Cloud, Salesforce CPQ (formerly Steelbrick) are standalone CPQ tools that integrate to ERP order management.

**Pricing engine integration**: quote lines pull from the pricing engine (see section 4.5) based on customer, product, quantity, and date. Non-standard discounts trigger an approval workflow with discount authority matrix.

**Quote-to-order conversion**: approved quote converts directly to sales order without re-keying. Version control on the quote: customer-facing revision history.

**Integrations**: Pricing Engine (list and contract prices), Order Management (quote → order), Inventory (ATP check on quote lines), Contract Management (contract pricing reference).

**What breaks without it**: prices quoted manually diverge from approved price lists; non-standard discounts issued without authorization.

---

### 4.4 Order Management

**Sales order types**

| Type | Description |
|---|---|
| Standard | Warehouse fulfillment from stock |
| Return (RMA) | Customer return authorization, reversal of revenue |
| Drop-ship | PO issued directly to supplier, ships to customer |
| Intercompany | Cross-entity sale; triggers intercompany PO in supplying entity |

**Order promising**: ATP check at line level; if ATP fails, system proposes earliest available date or backorder. CTP escalation if ATP is insufficient.

**Backorder management**: partial fulfillment ships available quantity; backorder line held for remaining quantity. Substitution logic offers alternative SKU if configured.

**Integrations**: Inventory/WMS (outbound delivery instruction), AR (invoice generation on shipment), Shipping carriers (tracking number, label), GL (revenue recognition trigger per ASC 606 / IFRS 15).

**What breaks without it**: order commitments are unreliable; fulfillment is uncoordinated with inventory; revenue cannot post without order reference.

---

### 4.5 Pricing Engine

**Price hierarchy** (evaluation in order of specificity):

1. Customer-specific contract price
2. Customer group price
3. Volume discount tier price
4. Promotional price (date-bounded)
5. List price (fallback)

**Discount types**: volume (order quantity brackets), customer group (tiered customer classification), promotional (campaign code, date range), channel (distributor vs. direct).

**Transfer pricing for intercompany orders**: price determined by transfer pricing policy (cost-plus, market-based); must be documented as required by OECD Transfer Pricing Guidelines (see section 1.8 on intercompany). [3]

**Integrations**: Quotation, Order Management, Contract Management (contract-specific prices), Multi-currency (currency-specific price lists).

**What breaks without it**: pricing is manual and inconsistent; margin erosion from untracked discounts; intercompany pricing cannot be audited.

---

### 4.6 Customer Portal

**Self-service capabilities**: order status and tracking, invoice download (PDF), online payment (card, ACH), RMA initiation, order history reorder, product catalog with stock availability.

**B2B considerations**: the portal must support multiple contacts per customer account with different permission levels (purchasing agent can place orders; accounting contact can view/pay invoices only).

**Integrations**: Order Management (order placement and status), AR (invoice retrieval and payment posting), Inventory (real-time stock check for ATP display), CRM (contact authentication via SSO).

**What breaks without it**: customer service call volume increases for order status; DSO worsens if invoice retrieval is delayed.

---

### 4.7 Sales Forecasting

**Bottom-up**: weighted pipeline forecast = sum(Opportunity Value × Stage Probability). Best Case and Commit scenarios also rolled up. Compared against quota by rep, territory, and product line.

**Top-down**: revenue target distributed from CFO level down through business units and territories. Reconciliation between top-down target and bottom-up pipeline gap analysis.

**AI/ML-assisted forecast**: SAP Sales Cloud, Salesforce Einstein, Microsoft D365 Sales Insights apply ML models on historical close rates by stage, rep, industry, and deal size. Surfaced as predicted close probability overriding the stage-default probability.

**Integrations**: Opportunity Tracking (pipeline data), Demand Planning (revenue forecast as demand input), Budget Management (revenue plan vs. forecast variance).

**What breaks without it**: revenue predictability collapses; financial planning is disconnected from sales reality.

---

### 4.8 Commission Management

**Commission plan types**: flat rate (% of revenue), tiered (rate accelerates after quota attainment), split (multiple reps credited on one deal with defined split percentages), team-based (overlay sales engineer receives portion).

**Calculation engine**: runs on closed/won opportunities after order booking. Attainment = booked revenue / quota. Applies plan rules to compute commission amount per rep per period.

**Commission statement**: rep self-service view of earned commissions, pipeline credits, and year-to-date attainment. Dispute log: rep can flag an incorrect commission calculation for finance review.

**Integrations**: Order Management (closed orders as commission events), Core HR / Payroll (commission payout as supplemental earnings in payroll run), GL (commission accrual and expense posting).

**What breaks without it**: commissions calculated in spreadsheets; disputes are unmanageable at scale; payout timing and amounts are inconsistent.

---

## 5. Manufacturing

### 5.1 Bill of Materials (BOM)

**BOM types**

| BOM type | Purpose |
|---|---|
| Engineering BOM (eBOM) | Design structure from PLM/CAD; may include components not yet manufacturable |
| Manufacturing BOM (mBOM) | Production-ready structure with operations assigned; source for MRP |
| Sales BOM | Configured product structure for order entry; not exploded in MRP |
| Costing BOM | May differ from mBOM (e.g., include scrap factors, yield factors) |

**Multi-level BOM explosion**: parent → child components recursively. Phantom assemblies (virtual intermediate assemblies used for design organization but not physically assembled as a stock item) are exploded through without creating a work order for the phantom.

**ECO (Engineering Change Order)**: controlled revision of BOM. Version control with effectivity dates (valid-from, valid-to) ensures the correct BOM version is used for production orders at a given date. ECO workflow: engineering submits → cross-functional review → approved → effectivity date set → MRP uses new BOM from that date.

**Integrations**: MRP (demand explosion source), Costing (standard cost roll-up from BOM + routing), Quality Management (inspection characteristics per component), Work Orders (BOM as material requirement basis).

**What breaks without it**: MRP cannot determine what components to procure; cost roll-up is impossible; production has no formal material list.

---

### 5.2 Work Orders

**Work order types**: discrete (single make-to-order or make-to-stock build); process (batch manufacturing — pharma, food, chemicals — uses process orders with recipes/formulas); repetitive (rate-based manufacturing, no discrete work order per unit).

**Operations / routing**: sequence of operations specifying work center, setup time (fixed per order), run time (per unit), queue time (wait time before operation begins). Work center links to capacity planning.

**Material issuance methods**: pick list (explicit goods issue per component at order release); backflush (automatic goods issue at order confirmation based on standard BOM quantities — simpler but requires accurate BOM and reliable production).

**Labor confirmation**: operator records actual hours at each operation against the work order. Deviations from standard routing times feed variance analysis.

**Work order costing**: planned cost = BOM quantities × standard prices + routing hours × activity rates. Actual cost = actual material issues + actual labor confirmations + overhead allocation. Variance = actual − standard; posted to GL price/quantity variance accounts.

**Integrations**: BOM (material list), Routing (operation sequence), Inventory (material issue and finished goods receipt), GL (WIP accounting — Dr WIP / Cr various when started; Dr Finished Goods / Cr WIP on completion), Quality (inspection lot creation at operation or on goods receipt).

**What breaks without it**: production has no formal manufacturing instruction; WIP cannot be tracked; cost variances cannot be calculated.

---

### 5.3 Production Planning

**Finite vs. infinite capacity planning**: infinite capacity planning (standard MRP) ignores capacity constraints and generates planned orders regardless of work center load. Finite capacity scheduling (SAP S/4HANA Production Planning and Detailed Scheduling / PP-DS; Oracle Planning Central) sequences operations within capacity limits, potentially delaying orders.

**Scheduling modes**: forward scheduling (from order release date → earliest completion); backward scheduling (from required date → latest start date); just-in-time (production triggered by customer demand pull rather than forecast push).

**Dispatch list**: shop floor document listing operations to be performed at each work center, sequenced by priority. The dispatch list is the operative link between planning and execution.

**Integrations**: MPS/MRP (planned orders become production orders), Capacity Planning (load calculation), Work Orders (production order = instantiated work order), Demand Planning (finished goods demand input).

**What breaks without it**: production starts without formal schedule; capacity conflicts discovered only when materials fail to arrive at the machine.

---

### 5.4 Capacity Planning

**Work center capacity definition**: standard available capacity = shifts × hours/shift × number of machines × efficiency factor. Published as a capacity version per planning period.

**Rough-Cut Capacity Planning (RCCP)**: validates MPS against key/bottleneck work center capacities at the aggregate level. Runs quickly (no BOM explosion) and provides a go/no-go signal before detailed MRP.

**Capacity Requirements Planning (CRP)**: detailed work center load profile derived from MRP planned orders × routing operation times. Shows overload periods per work center.

**Bottleneck management**: work centers consistently at >100% utilization are bottlenecks. Resolution: lot size splitting (run smaller batches more frequently), alternate work center routing, subcontracting excess load, overtime authorization.

**Integrations**: MPS/MRP (load generation from planned orders), Production Planning (scheduling constraint), Work Orders (actual capacity consumption confirmed at operation).

**What breaks without it**: production schedule is theoretically optimal but physically impossible; overtime and subcontracting costs are reactive and unplanned.

---

### 5.5 Shop Floor Control

**Data collection methods**: barcode scanning at operations (operator scans work order + operation + quantity), RFID readers at work cell entry/exit, MES (Manufacturing Execution System) integration for automated data collection. MES-to-ERP interface standard: ISA-95 / IEC 62264 (Enterprise-control system integration), which defines the hierarchical model (Level 3 MES ↔ Level 4 ERP) and the data exchanges between them.

**WIP tracking**: real-time visibility into quantity at each operation stage across all open work orders. Unfinished WIP at period-end valued on GL.

**OEE (Overall Equipment Effectiveness)**: OEE = Availability × Performance × Quality Rate. Availability = (scheduled time − downtime) / scheduled time. Performance = actual output / theoretical maximum output. Quality Rate = good units / total units produced. OEE of 85% is considered world-class for discrete manufacturing.

**Scrap and rework**: scrap reported at operation level with reason code; adjusts actual component consumption and triggers inventory reduction; rework orders created for salvageable units with separate cost collection.

**Integrations**: Work Orders (actual confirmation), Quality Management (in-process inspection results, scrap reasons), EAM/Maintenance (downtime events trigger maintenance notification), Inventory (actual material consumption).

**What breaks without it**: production actual data available only from paper travelers; OEE cannot be computed; WIP valuation relies on estimates.

---

### 5.6 Quality Management

**Inspection plan types**

| Type | Trigger |
|---|---|
| Incoming inspection | Goods receipt from vendor |
| In-process inspection | At specified operation in routing |
| Final inspection | Work order goods receipt into stock |
| Customer return inspection | RMA goods receipt |

**Quality notification / NCR (Non-Conformance Report)**: created when inspection reveals defect. Contains defect description, quantity affected, root cause, immediate containment action. Assigned owner with due date.

**CAPA (Corrective and Preventive Action) workflow**: Root cause analysis (8D, Ishikawa, 5-Why) → corrective action definition → effectiveness verification → CAPA closure. SAP QM implements this as a notification type; Oracle Quality Cloud has a dedicated CAPA object.

**Inspection lot disposition**: Accept (unrestricted stock), Reject (returns to vendor or scrapped), Rework (move to rework order), Usage Decision deferred pending lab analysis.

**Certificate of Analysis (CoA)**: batch-specific document recording test results against specification; required for pharma, chemicals, food ingredients. Generated from inspection results and attached to outbound delivery.

**Quality standards**

| Standard | Scope |
|---|---|
| ISO 9001:2015 | General quality management systems |
| IATF 16949:2016 | Automotive production and service parts |
| AS9100 Rev D | Aviation, space, and defense QMS |
| 21 CFR Part 11 | FDA electronic records and electronic signatures — pharma/biotech/medical devices |

Note: 21 CFR Part 11 applies specifically to FDA-regulated industries. Its requirements (audit trail, access controls, electronic signature meaning) are frequently cited as best practices broadly but are legally mandatory only for covered entities.

**Integrations**: Procurement (incoming inspection at GR), Manufacturing (in-process and final inspection), Inventory (stock hold / block posting pending inspection), Supplier Management (defect data feeds supplier scorecard).

**What breaks without it**: defective material enters production or ships to customers; regulatory compliance cannot be demonstrated; supplier quality is untracked.

---

### 5.7 Enterprise Asset Management (EAM) / Maintenance

**Asset hierarchy**: functional location (plant → building → production line → machine) → equipment (specific physical asset with serial number). Equipment master carries technical specifications, manufacturer data, warranty end date.

**Maintenance types**

| Type | Trigger |
|---|---|
| Preventive (time-based) | Calendar interval (e.g., monthly lubrication) |
| Preventive (counter-based) | Usage counter (e.g., every 10,000 operating hours) |
| Predictive (IoT-triggered) | Sensor anomaly detection triggers maintenance notification |
| Corrective | Breakdown; created reactively |
| Shutdown / turnaround | Planned extended outage for major overhaul |

**Maintenance plans and task lists**: maintenance plan defines the cycle (time/counter), the maintenance item (equipment + maintenance type), and the call object (maintenance order or service notification). Task list specifies operations, spare parts, safety requirements.

**Spare parts management**: critical spares listed on equipment master; stored in Inventory as non-valuated or valuated material. Minimum stock level triggers replenishment PO.

**ISO 55001:2024 (Asset Management Systems — Requirements)**: the current edition, published July 2024, replaces ISO 55001:2014. It incorporates the ISO Harmonized Structure for management systems, enhanced sustainability/climate integration, and stronger data management requirements. [5]

**Integrations**: Inventory (spare parts issue and receipt), Procurement (external maintenance services via service PO), Production Planning (planned downtime communicated as capacity reduction), GL (maintenance cost posted to maintenance cost center or cost element on equipment).

**What breaks without it**: unplanned breakdowns halt production without warning; maintenance cost untracked by asset; warranty claims missed; regulatory inspection records absent (FDA cGMP, OSHA machinery safety).

---

## 6. Project Management

### 6.1 Project Accounting

**WBS (Work Breakdown Structure) hierarchy**: Project → Phase → Deliverable → Work Package → Activity. Each node is a cost collector; budget and actual costs are posted at the lowest assigned level.

**Cost tracking**: actual costs post from AP (vendor invoices), Payroll (labor cost transfer via timesheet), Procurement (material cost), and allocation (overhead assignment). Costs accumulate by WBS element and are compared to the approved project budget baseline.

**Revenue recognition methods for long-term contracts**

| Method | Standard | Applicability |
|---|---|---|
| Completed contract | ASC 606 / IFRS 15 | Short-term or high-uncertainty contracts |
| Percentage of completion (POC) | ASC 606 / IFRS 15 | Long-term with reliable estimates; most common |
| Milestone billing | ASC 606 / IFRS 15 | Distinct milestones represent standalone performance obligations |

POC measurement: input method (costs incurred / total estimated costs) or output method (surveys, units, milestones). The ERP must store total estimated costs (ETC) and compute POC percentage dynamically.

**Vendor products**: SAP PS (Project System) within SAP S/4HANA; Oracle Fusion Cloud PPM (Project Portfolio Management); Microsoft D365 Project Operations (formerly Project Service Automation).

**Integrations**: GL (cost and revenue posting), AP (project-coded vendor invoices), AR (milestone billing invoice generation), Payroll (labor cost allocation via timesheet cross-charge), Fixed Assets (WBS → AuC capitalization), Procurement (project-coded purchase orders).

**What breaks without it**: project profitability is invisible until project completion; revenue recognition for long-term contracts is either deferred entirely (understating revenue) or recognized prematurely (overstating revenue).

---

### 6.2 Resource Planning

**Demand side**: project managers define skill requirements (job role, level, hours) per WBS work package for each time period in the project schedule.

**Supply side**: resource availability comes from Core HR (employment status, location) cross-referenced with Time & Attendance (already-scheduled hours, leave calendar).

**Assignment and conflict detection**: resource manager assigns named resources to project tasks. Overallocation detection: if the same resource is assigned more than 100% of available hours in a time period, the system flags the conflict and displays the competing assignments.

**Integrations**: Core HR (resource pool, skills profile), Time & Attendance (actual availability), Project Accounting (resource cost rate for cost planning), Timesheets (actuals confirmation).

**What breaks without it**: projects start without confirmed resource availability; overallocation discovered when employees cannot perform the work.

---

### 6.3 Timesheets

**Entry model**: employees enter hours by date, project, WBS element, activity type, and work type (billable, non-billable, internal). Weekly submission is standard; daily for high-volume project billing environments.

**Approval workflow**: resource submits → project manager approves (verifies project coding) → finance approves (verifies billable classification) → timesheet locked for payroll and project accounting posting.

**Billable vs. non-billable classification**: billable hours feed project revenue recognition and customer invoicing; non-billable hours are project cost without revenue offset (overhead, rework, unbilled overrun).

**Integrations**: Payroll (project labor cost is a payroll cost center allocation; cross-charge journal moves cost to project WBS), Project Accounting (actual hours and cost posted to WBS), Time & Attendance (timesheet hours reconciled with attendance record).

**What breaks without it**: project labor cost is untracked; billable hours are under-billed; payroll costs cannot be allocated to projects.

---

### 6.4 Milestone Billing

**Milestone definition**: billing milestones are defined in the project plan with contractual completion criteria (e.g., "Phase 1 design review approved by customer"). Each milestone has a billing amount or percentage of total contract value.

**Automated invoice trigger**: when the project manager marks a milestone as achieved (with supporting documentation), the system generates a billing request → AR reviews → customer invoice created with reference to the project contract.

**Retention terms**: a percentage of each milestone invoice is withheld by the customer (e.g., 10%) and released only upon final project acceptance. The ERP must track retention receivable separately from current receivable.

**Integrations**: Project Accounting (milestone completion status), AR (invoice generation), Contract Management (billing schedule from customer contract).

**What breaks without it**: billing is delayed because no automated trigger exists; retention receivable is commingled with regular AR; cash flow for project-based businesses deteriorates.

---

### 6.5 Earned Value Management (EVM)

**Core EVM metrics**

| Metric | Definition |
|---|---|
| BAC (Budget at Completion) | Total authorized project budget |
| PV (Planned Value) | Budgeted cost of work scheduled (BCWS) at status date |
| EV (Earned Value) | Budgeted cost of work performed (BCWP) at status date |
| AC (Actual Cost) | Actual cost of work performed (ACWP) at status date |
| CV (Cost Variance) | EV − AC (negative = over budget) |
| SV (Schedule Variance) | EV − PV (negative = behind schedule) |
| CPI (Cost Performance Index) | EV / AC |
| SPI (Schedule Performance Index) | EV / PV |
| EAC (Estimate at Completion) | BAC / CPI (most common forecast method) |
| VAC (Variance at Completion) | BAC − EAC |

**Standard**: ANSI/EIA-748E (SAE EIA 748E-2026), published February 17, 2026. This revision reduces the EVMS guidelines from 32 to **27**, reorganized across the same 5 categories (Organization, Planning & Scheduling, Progress Assessment & Data Collection, Analysis & Management Reports, Revisions & Data Maintenance). It replaces EIA-748D-2019. [6]

**DoD requirement**: DFARS clause 252.234-7002 (Earned Value Management System) requires contractors to implement an ANSI/EIA-748-compliant EVMS on US DoD contracts at or above **$50 million** (threshold raised from $20 million by FY2025 NDAA Section 823, effective October 1, 2025). [7]

**Integrations**: Project Accounting (actual cost feed), Scheduling tools (MS Project, Oracle Primavera P6 via connector for PV calculation), GL (actual cost source).

**What breaks without it**: DoD contract compliance requirements unmet; project cost and schedule performance measured only at completion when corrective action is too late.

---

## 7. Business Intelligence & Reporting

### 7.1 Dashboards & KPIs

**Role-based dashboard design**

| Role | Key metrics |
|---|---|
| CFO | DSO (Days Sales Outstanding), DPO (Days Payable Outstanding), DIO (Days Inventory Outstanding), cash balance, revenue vs. plan |
| COO | OEE, OTIF, production schedule adherence, scrap rate |
| CHRO | Headcount, open requisitions, attrition rate, time-to-fill, training completion % |
| Supply Chain VP | Inventory turns, forecast accuracy (MAPE), supplier OTIF, stockout rate |

**KPI definition attributes**: formula (exact calculation), data source module, target value, warning threshold, critical threshold, trend direction (higher is better or lower is better), refresh frequency.

**Real-time vs. near-real-time**: OLTP transaction modules update in real time but dashboards reading directly from operational tables cause query performance impact. Best practice: operational dashboards use materialized views or a reporting schema refreshed every 15–60 minutes; strategic dashboards read from a data warehouse refreshed nightly or on a data lake.

---

### 7.2 Ad-hoc Reporting

**Self-service query capability**: drag-and-drop field selection, pivot table, filter builder (AND/OR logic), drill-down from summary to transaction. Users build and save reports without IT involvement.

**Row-level security**: report data filtered at query time by the user's organizational access profile. A regional finance manager sees only their entities; a consolidated view requires explicit elevated access.

**Vendor products**: SAP Analytics Cloud (SAC) — integrates natively with SAP S/4HANA; Oracle Analytics Cloud — Oracle Fusion native; Microsoft Power BI — D365 Finance native embedding; Workday Prism Analytics — operates on combined Workday and external data.

---

### 7.3 Scheduled & Operational Reports

**Financial statement formats**

| Report | Standard |
|---|---|
| Balance Sheet | IAS 1 (IFRS); ASC 205 (US GAAP) |
| Income Statement | IAS 1; ASC 225 |
| Cash Flow Statement | IAS 7; ASC 230 |
| Statement of Changes in Equity | IAS 1 |

**Regulatory reporting**

- **XBRL**: SEC filers use Inline XBRL (iXBRL) for 10-K and 10-Q filings under SEC mandate (effective 2019–2020 depending on filer category). HMRC (UK) requires iXBRL for corporation tax computations.
- **XBRL taxonomies**: US GAAP Taxonomy (FASB); IFRS Taxonomy (IASB).

**Delivery mechanisms**: scheduled email (PDF, Excel attachment), SharePoint/document management deposit, SFTP for external recipients (auditors, regulators), in-app notification with download link.

---

### 7.4 OLAP Cubes / Multidimensional Analysis

**Standard dimensions**: time (day/week/month/quarter/year hierarchy), legal entity, cost center, GL account, product/SKU, customer, project, sales territory.

**Technical approaches**: pre-aggregated OLAP cubes (Microsoft Analysis Services SSAS for D365; SAP BW/4HANA cubes) vs. columnar in-memory engines (SAP HANA — aggregation on the fly from ACDOCA table without pre-aggregation; Oracle Exadata for Oracle Analytics).

**Drill-across**: navigation between cubes — e.g., drill from a financial variance in the Finance cube into the contributing sales orders in the Sales cube. Requires conformed dimensions (shared dimension keys across cubes).

---

### 7.5 Data Export

**Export formats**

| Format | Use case |
|---|---|
| CSV / Excel | End-user analysis, ad-hoc reporting |
| PDF | Distribution, archiving |
| XBRL | Regulatory filing |
| OData feed | Power BI and other BI tools real-time connect |
| JSON / REST | Integration, downstream system consumption |

**Bulk extract for data warehouse**: ERP provides full extract (initial load) and incremental extract (change data capture / CDC) interfaces. CDC methods: database transaction log reading (SAP Operational Data Provisioning / ODP; Oracle GoldenGate), timestamp-based, or trigger-based. ETL/ELT pipelines land data in data lake (Azure Data Lake Storage, AWS S3) or data warehouse (Snowflake, BigQuery, Synapse).

---

## 8. Document Management

### 8.1 Document Storage

**Repository structure**: business-object-centric linking (e.g., a document is linked to a specific PO, vendor, or contract rather than stored in a generic folder) is strongly preferred over folder hierarchies for ERP-embedded document management.

**Metadata tagging**: document type, business object type and key, creation date, author, status, classification (confidential/internal/public), retention category.

**File format standards**: PDF/A for archival — ISO 19005-1 (PDF/A-1), which prohibits features that impede long-term rendering (encryption, external content dependencies, unsupported fonts). ISO 19005-2 (PDF/A-2) and ISO 19005-3 (PDF/A-3) add later features including embedded files.

**Storage tiers**: hot (active documents accessed frequently — SSD/NVMe-backed object storage); warm (documents from prior 2 fiscal years — standard object storage, e.g., AWS S3 Standard); cold (legal/archive retention — AWS S3 Glacier, Azure Blob Archive tier). Tiering policy enforced by the document lifecycle management engine.

---

### 8.2 Version Control

**Versioning model**: major versions (1.0, 2.0) for substantive content changes; minor versions (1.1, 1.2) for corrections. Check-out locks the document for editing; check-in creates a new version. Rollback to prior version must be auditable (who initiated rollback and why).

**Diff comparison**: for text-based documents (contracts, specifications), the system must show changed paragraphs between versions to support legal review.

**Integrations**: Workflow engine (approval of a document creates a new locked version); Engineering BOM (drawing revision in PLM/DMS triggers ECO in BOM).

---

### 8.3 e-Signatures

**Legal framework**

| Jurisdiction | Law/Regulation | Effective |
|---|---|---|
| European Union | eIDAS Regulation (EU) No 910/2014 | July 1, 2016 |
| United States | ESIGN Act (Electronic Signatures in Global and National Commerce Act) — 15 U.S.C. §7001 | June 30, 2000 |
| US States | UETA (Uniform Electronic Transactions Act) | Adopted by 49 states + DC + PR + USVI; New York enacted comparable separate legislation |

**Signature types under eIDAS**

| Type | Assurance | Typical use |
|---|---|---|
| Simple Electronic Signature (SES) | Lowest | Low-risk agreements |
| Advanced Electronic Signature (AES) | Medium | Most commercial contracts |
| Qualified Electronic Signature (QES) | Highest | Equivalent to handwritten; requires QSCD device and qualified TSP |

**Audit trail requirements**: signer identity (authenticated via email link, SMS OTP, or digital certificate), IP address, timestamp (trusted timestamp authority), document hash (SHA-256) locked at signing, complete audit certificate PDF.

**Vendor integrations**: DocuSign (eSignature API), Adobe Acrobat Sign (formerly Adobe Sign), built-in capabilities in SAP S/4HANA (contract signing in procurement and sales).

---

### 8.4 Workflow Routing

**Routing rules**: document type determines the routing template (e.g., vendor invoices above $10,000 route to Department Head then CFO; below $10,000 route to Accounts Payable Supervisor only). Rules evaluate document metadata attributes.

**Conditional branching**: if invoice country = Germany and amount > €50,000, add Tax Director to approval chain.

**SLA monitoring**: each routing step has a target completion time. Approaching-deadline notification sent to approver; breach triggers escalation (see section 9.3).

**Integrations**: Workflow & Approvals engine (routing execution), Email/notification system (approver notifications), ERP transaction modules (document approval status gates transaction posting).

---

### 8.5 Archiving & Retention

**Retention schedule examples**

| Document type | Retention period | Jurisdiction |
|---|---|---|
| Tax records and supporting ledger data | 7 years | US (IRC §6501 statute of limitations) |
| Tax records | 10 years | Germany (§147 AO — Abgabenordnung) |
| Employment records | 7 years post-termination | US (various) |
| Contracts | 7 years post-expiry | General commercial (varies) |
| Quality records (21 CFR) | 2 years post-distribution | FDA regulated (21 CFR §211.68 / §820.180) |

**Legal hold**: suspends the automatic destruction of documents associated with anticipated or actual litigation or regulatory investigation. Legal hold is a flag applied to documents or custodians; the retention destruction engine checks for active holds before purging.

**Integrations**: Compliance/audit modules (legal hold management), GL (fiscal year-end archiving trigger), HR (personnel file retention on termination).

---

## 9. Workflow & Approvals

### 9.1 Multi-level Approvals

**Approval matrix design**

```
ApprovalRule
  rule_id PK
  document_type VARCHAR(50)     -- PO, Invoice, Expense, LeaveRequest, etc.
  amount_min DECIMAL
  amount_max DECIMAL
  org_unit_id FK               -- scope restriction
  approval_levels INT

ApprovalLevel
  level_id PK
  rule_id FK
  level_sequence INT
  approver_type ENUM(named_user, role, position, supervisor)
  approver_reference VARCHAR(100)

ApprovalRequest
  request_id PK
  document_type VARCHAR(50)
  document_id VARCHAR(100)
  status ENUM(pending, approved, rejected, cancelled)
  created_at TIMESTAMP

ApprovalStep
  step_id PK
  request_id FK
  level_id FK
  approver_user_id FK
  decision ENUM(pending, approved, rejected, delegated)
  decided_at TIMESTAMP
  comments TEXT
```

**Sequential vs. parallel routing**: sequential — each approver must act before the next is notified; parallel — all approvers at a level are notified simultaneously and all must approve (unanimous) or any one approval suffices (any-of).

---

### 9.2 Delegation

**Temporary delegation**: a user going on leave delegates their approval authority for a date range to a named substitute. Scope can be all document types or restricted to specific types/amounts.

**Delegation chain limits**: maximum delegation depth (e.g., no more than 2 levels of chained delegation) prevents abuse.

**Substitution audit log**: every action taken by a delegate is logged with both the delegate user ID and the delegating user ID, maintaining full accountability.

**Integrations**: Core HR (approved leave automatically triggers delegation if pre-configured by employee), Workflow engine (delegation rule applied at routing time when approver's delegation is active).

---

### 9.3 Escalation

**SLA-based escalation**: each approval step has a configured response time (e.g., 24 hours for invoices, 4 hours for production-critical purchase requisitions). At 75% of SLA expiry, a reminder is sent. At 100%, escalation fires.

**Escalation target**: supervisor of the delinquent approver (sourced from Core HR supervisor hierarchy), or a designated escalation group. Final escalation (after N escalation levels) can be configured as auto-approve, auto-reject, or route to a specific override authority.

**Integrations**: Notification system (escalation alerts), Core HR (supervisor hierarchy for escalation chain).

---

### 9.4 Notifications

**Notification channels**

| Channel | Applicability |
|---|---|
| In-app (ERP inbox) | All users with ERP access |
| Email | Universal; used for external approvers |
| SMS | Urgent escalations; mobile-primary users |
| Push (mobile ERP app) | Field workforce, sales reps |
| Webhook to Slack/Teams | Developer teams, operations centers |

**Template design**: templates are parameterized with transaction context variables (e.g., `{{document_type}} #{{document_id}} for {{amount}} {{currency}} requires your approval by {{due_date}}`). Templates maintained per notification type and locale.

**Digest mode**: for high-volume notifications, daily or hourly digest batches multiple pending actions into one message. Real-time mode sends each event immediately.

---

## 10. Integration & API Layer

### 10.1 REST APIs

**API design standards**: versioned base path (`/api/v1/`, `/api/v2/`); breaking changes require a new version; non-breaking additions do not. OpenAPI 3.x (formerly Swagger) specification published at a well-known endpoint (`/api/openapi.json`) for tooling consumption and contract testing.

**Authentication**: OAuth 2.0 with OIDC for user-context calls (Authorization Code flow); Client Credentials flow for system-to-system integrations. Scopes are defined per ERP resource domain (e.g., `erp:financials:read`, `erp:procurement:write`).

**Query conventions**: OData query parameters (`$filter`, `$top`, `$skip`, `$orderby`, `$expand`) for field-level filtering, pagination, and resource expansion. Alternatively, GraphQL for clients needing flexible field selection without multiple round trips.

**Rate limiting**: per-client throttling (requests/second, requests/minute per OAuth client_id). HTTP 429 response with `Retry-After` header. Burst allowance above the sustained rate limit.

---

### 10.2 EDI

**EDI transaction sets**

| Standard | Transaction Set | Business Document |
|---|---|---|
| ASC X12 | 850 | Purchase Order |
| ASC X12 | 856 | Advance Ship Notice (ASN) |
| ASC X12 | 810 | Invoice |
| ASC X12 | 997 | Functional Acknowledgment |
| ASC X12 | 834 | Benefit Enrollment and Maintenance |
| UN/EDIFACT | ORDERS | Purchase Order |
| UN/EDIFACT | DESADV | Despatch Advice (ASN) |
| UN/EDIFACT | INVOIC | Invoice |

**Transport**: VAN (Value-Added Network — managed service, store-and-forward, per-kilo pricing) vs. AS2 (direct HTTPS exchange with MDN acknowledgment — preferred for high-volume trading partners due to lower per-transaction cost). SFTP is a legacy fallback.

**EDI mapping layer**: canonical ERP data structures are mapped to/from EDI transaction sets per trading partner. Trading partner profiles stored in the EDI configuration (ISA qualifier/ID, GS application ID, version).

**Integrations**: Procurement (inbound 850 → PO; outbound 997 acknowledgment), Order Management (outbound 850 → supplier drop-ship; inbound 856 → shipment confirmation), AP (inbound 810 → invoice), Benefits (outbound 834 → carrier).

---

### 10.3 Webhooks

**Event-driven push**: ERP publishes events when significant state transitions occur. Subscribers register an HTTPS endpoint and event filter.

**Event examples**: `purchase_order.approved`, `invoice.posted`, `inventory.below_safety_stock`, `payment.disbursed`, `employee.terminated`.

**Reliability**: at-least-once delivery with configurable retry policy (exponential backoff; e.g., 30s, 2m, 8m, 32m, 128m). Events that fail all retries route to a dead-letter queue (DLQ) for manual inspection.

**Security**: payload signed with HMAC-SHA256 using a shared secret. Consumer verifies signature before processing to prevent spoofing. Signature in `X-ERP-Signature` header.

---

### 10.4 Third-party Connectors

**iPaaS platforms**: MuleSoft Anypoint Platform (SAP and Salesforce pre-built connectors widely used); Dell Boomi (AtomSphere); SAP Integration Suite (formerly SAP Cloud Platform Integration / CPI — native integration middleware for SAP ecosystem and third-party); Azure Integration Services (Logic Apps, Service Bus, API Management — native for Microsoft D365 environments).

**Common integration patterns**

| Integration | Pattern | Data flow |
|---|---|---|
| Salesforce ↔ ERP | Order-to-cash | Salesforce opportunity → ERP sales order; ERP invoice → Salesforce activity |
| ADP ↔ HR | Payroll co-source | ERP Core HR → ADP payroll run → ERP GL journal import |
| UPS/FedEx ↔ WMS | Shipping carrier | WMS shipment → carrier API → tracking number back to Order Management |
| Payment gateway ↔ AR | Customer portal payment | Gateway tokenized payment → AR cash receipt posting |

**Canonical data model**: define a canonical order, customer, and product data model as the integration "hub" rather than point-to-point field mapping between every pair. Reduces mapping count from O(n²) to O(n).

---

## 11. System Administration

### 11.1 User Management

**User lifecycle**: provisioning (new hire trigger from Core HR → account creation in ERP via SCIM 2.0) → role assignment → access review (semi-annual recertification by manager) → deprovisioning (termination trigger → account disabled same day, data access retained per retention policy).

**SCIM 2.0 (RFC 7643 / RFC 7644)**: standard protocol for automated user provisioning and deprovisioning between Identity Provider (Okta, Microsoft Entra ID) and ERP. SCIM Group objects map to ERP roles.

**SSO protocols**: SAML 2.0 (Security Assertion Markup Language — XML-based; dominant in enterprise ERP); OIDC (OpenID Connect — JSON/JWT-based; preferred for modern cloud-native ERPs and mobile apps). Both delegate authentication to the corporate IdP; ERP acts as Service Provider (SP).

**MFA enforcement**: mandatory MFA for all users with financial posting authority, all system administrator accounts, and all remote access. TOTP (RFC 6238), hardware FIDO2/WebAuthn token, or SMS OTP (weakest; avoid for privileged access).

---

### 11.2 Role Management & Segregation of Duties (SoD)

**Role taxonomy**: job roles (mapped to job functions — AP Clerk, Purchasing Manager), duty roles (granular capability grants — Create PO, Approve PO, Post Invoice), data roles (restrict the org units or entities a user can view/transact in).

**Key SoD conflicts**

| Conflict | Risk |
|---|---|
| Create PO / Approve PO | Self-authorized purchasing |
| Enter vendor invoice / Approve payment run | Fraudulent payment |
| Create vendor master / Approve vendor master | Ghost vendor creation |
| Access payroll rates / Approve payroll run | Unauthorized pay increase |
| Post journal / Approve journal | Fraudulent GL entries |

**Preventive vs. detective control**: preventive SoD check runs at role-assignment time — the system blocks assignment of a role that would create a conflict with existing roles. Detective control is an audit report run periodically showing users with conflicting role combinations. SOX IT General Controls (ITGCs) typically require both. See `core/security.md` for SoD rule engine implementation detail.

---

### 11.3 Audit Logs

**Immutable change log**: every data write captured with: user_id, session_id, timestamp (UTC), entity type, entity key, field name, old value, new value, transaction context (document type, document ID). Cannot be modified or deleted by any user including system administrators — write to an append-only store or external SIEM.

**Scope**: all financial master data changes (GL account, vendor master, customer master), transactional postings (journal entries, payments, receipts), configuration changes (tax codes, exchange rates, approval matrices), login/logout, failed login attempts, privilege escalation.

**Retention**: 7 years minimum for financial audit trails aligns with US tax statute of limitations. Some regulated industries require longer (FDA records: see section 5.6 above).

**SIEM integration**: audit log stream exported in real time (Syslog, CEF, or JSON over HTTP) to security information and event management system (Splunk, Microsoft Sentinel, IBM QRadar) for threat detection.

---

### 11.4 Data Import / Export

**Migration tools**: staged import via validated CSV templates — Stage 1: upload to staging table with schema validation and reference data checks; Stage 2: business rule validation (e.g., GL account exists, cost center active); Stage 3: production load after test environment validation. Batch error reporting by row with error codes.

**ETL/ELT**: ongoing integration to data warehouse via extraction from ERP APIs or direct database connectors. ELT preferred in cloud-native architecture: raw data lands in lake, transformation occurs in target platform (dbt, Dataflow).

**Data quality rules at import**: mandatory field completeness, foreign key reference validation, duplicate key detection, format validation (date formats, currency codes per ISO 4217, country codes per ISO 3166-1 alpha-2).

---

### 11.5 Localization & Multi-language

**Language packs**: UI labels, field captions, error messages, report templates, and help text maintained per language in a separate content repository. Users select display language; underlying data language is independent.

**Regional format standards**: date — ISO 8601 (YYYY-MM-DD) as internal storage standard, displayed per locale (MM/DD/YYYY for US en-US; DD.MM.YYYY for Germany de-DE); number separators — decimal point vs. decimal comma per locale; address format — country-specific postal format templates.

**Tax localization and e-invoicing mandates**

| Country | Mandate | Format/Network |
|---|---|---|
| EU member states | PEPPOL for public sector procurement (ongoing expansion) | PEPPOL BIS Billing 3.0 / UBL 2.1 |
| Mexico | CFDI (Comprobante Fiscal Digital por Internet) | XML via SAT-certified PAC |
| Brazil | NF-e (Nota Fiscal Eletrônica) | XML via SEFAZ |
| Saudi Arabia | Fatoora / ZATCA e-invoicing (Phase 2 since 2023) | XML / JSON via ZATCA portal |
| Germany | ZUGFeRD / XRechnung for B2G (B2B mandate in progress) | XML embedded in PDF |

Tax engine localization detail (VAT, GST, WHT rates, filing requirements) is maintained in `core/localization-tax.md`.

---

## 12. Cross-cutting Concerns & Module Dependencies

### 12.1 Module Dependency Map

| Module | Hard dependencies | Observable failure if missing |
|---|---|---|
| General Ledger | None (foundational) | No financial statements; no audit trail |
| Accounts Payable | GL, Procurement | Vendor payments untracked; accrued liabilities absent |
| Accounts Receivable | GL, Order Management | Revenue unposted; customer balances unknown |
| Fixed Assets | GL | Depreciation unbooked; balance sheet assets misstated |
| Cash Management | GL, AP, AR | Cash position unknown; reconciliation manual |
| Financial Consolidation | GL (all entities), Multi-entity | Group financial statements impossible |
| Payroll | Core HR, Time & Attendance | Incorrect pay; payroll cost journals absent from GL |
| Benefits Administration | Core HR, Payroll | Coverage gaps; ACA reporting missing |
| Inventory Management | GL, Procurement | COGS uncomputable; stock position unknown |
| WMS | Inventory | Bin-level location tracking absent; FEFO unenforced |
| MRP / MPS | BOM, Inventory, Production Planning | Material shortages; production stops without warning |
| BOM | (foundational for manufacturing) | MRP cannot explode; work orders have no material list |
| Work Orders | BOM, Routing, Inventory | WIP untracked; production costs unknown |
| Project Accounting | GL, AP, Timesheets | Project profitability invisible; long-term contract revenue misstated |
| Sales Orders | Inventory/WMS, AR | Fulfillment uncoordinated; revenue cannot post |
| Quality Management | Inventory, Procurement, Manufacturing | Defective material enters production; regulatory compliance undemonstrable |
| EAM / Maintenance | Inventory, Procurement, GL | Unplanned breakdowns unmanaged; maintenance cost untracked |
| Workflow & Approvals | All transaction modules | No authorization controls; audit controls non-existent |
| Audit Logs | System Administration | SOX ITGC compliance fails; forensic investigation impossible |

---

### 12.2 Real-world ERP Failure Cases

**Hershey Foods (1999)** [8]: Hershey selected SAP R/3 (ERP), Manugistics (supply chain / demand planning), and Siebel CRM simultaneously in a big-bang approach. The recommended implementation timeline was approximately 48 months; Hershey compressed this to approximately 30 months to precede Y2K concerns. The system went live in July 1999, at the start of the peak Halloween and Christmas confectionery order season. Integration failures between the three systems caused order processing, fulfillment, and shipping breakdowns. Hershey reported an estimated $100 million in orders that could not be shipped despite inventory being warehoused and ready; the ERP program cost approximately $112 million. Engineering lessons: (1) never schedule a big-bang go-live at a business-critical peak demand period; (2) multi-vendor integration complexity multiplies with each additional system in a simultaneous go-live; (3) aggressive timeline compression in complex integrations is the single most common root cause of ERP project failure.

**Nike Q3 FY2001** [9]: Nike implemented i2 Technologies demand planning software to improve supply chain responsiveness. An integration failure produced inaccurate demand signals — overestimating certain shoe lines while underestimating others. Nike publicly disclosed the problem on February 27, 2001 and reported approximately $100 million in lost sales in the third fiscal quarter of 2001. Nike's stock fell approximately 20% on the announcement. Engineering lesson: demand planning integration must be validated under production-representative data volumes and seasonal variation before cutover; phased rollout by product line reduces systemic risk.

**FoxMeyer Drug (1993–1996)** [10]: FoxMeyer, a major US pharmaceutical drug distributor, implemented SAP R/3 alongside the Pinnacle warehouse automation system from 1993 onward, during a period of rapid business expansion. The SAP R/3 system, as installed, could process approximately 10,000 customer orders per night versus the 420,000 processed by FoxMeyer's original mainframe — a critical capacity gap the vendor had not disclosed. FoxMeyer filed for Chapter 11 bankruptcy protection in August 1996 and its assets were subsequently liquidated. The bankruptcy trustee filed lawsuits against SAP AG and Andersen Consulting alleging $500 million each in damages (1998). Causation was disputed and no court produced a definitive finding that the ERP caused the bankruptcy. The case is correctly framed as illustrating the compound risk of simultaneous ERP go-live, warehouse automation deployment, and high-growth business conditions. Engineering lesson: validate ERP transaction throughput at peak production volume (orders/hour, GRNs/hour) in a performance test before go-live; never assume the vendor's reference implementations match your transaction density.

---

## See also

- `core/architecture.md`
- `core/security.md` — SoD rule engine, RBAC implementation detail, penetration testing
- `core/localization-tax.md` — VAT/GST/WHT engine, country-specific e-invoicing mandates, tax reporting
- `core/implementation.md` — project methodology, go-live sequencing, data migration patterns
- `core/cautions.md` — ERP failure patterns, anti-patterns, vendor lock-in risk

---

## Citations & Sources

1. FASB ASC 606 — Revenue from Contracts with Customers (US GAAP; effective for public companies reporting periods beginning after December 15, 2017); IASB IFRS 15 — Revenue from Contracts with Customers (effective January 1, 2018). https://fasb.org (ASC 606); https://ifrs.org (IFRS 15).

2. FASB ASC 842 — Leases (US GAAP; public companies: fiscal years beginning after December 15, 2018); IASB IFRS 16 — Leases (effective January 1, 2019). https://fasb.org (ASC 842); https://ifrs.org (IFRS 16).

3. OECD Transfer Pricing Guidelines for Multinational Enterprises and Tax Administrations (most recent edition). https://www.oecd.org/tax/transfer-pricing/

4. GDPR — Regulation (EU) 2016/679, Article 9 (Special categories of personal data). https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32016R0679

5. ISO 55001:2024 — Asset management: Asset management system — Requirements (second edition, published July 3, 2024; replaces ISO 55001:2014). https://www.iso.org/standard/83054.html

6. SAE EIA 748E-2026 — Earned Value Management Systems (27 guidelines; published February 2026; replaces EIA-748D-2019). Available at https://webstore.ansi.org/standards/sae/saeeia748e2026

7. DFARS 252.234-7002 — Earned Value Management System. EVMS threshold raised to $50 million by FY2025 NDAA Section 823 (effective October 1, 2025). https://www.acquisition.gov/dfars/252.234-7002-earned-value-management-system

8. Hershey Foods 1999 ERP failure — widely reported in trade press; see Computerworld "10 Famous ERP Disasters" (https://www.computerworld.com/article/1591363/10-famous-erp-disasters-dustups-and-disappointments-3.html). Revenue impact figures are widely cited at $150 million; treat as approximate pending verification against Hershey's original 10-Q filings.

9. Nike Q3 FY2001 i2 Technologies failure — Nike earnings call disclosure, February 27, 2001. $100 million sales loss reported. See also CIO.com "Nike Rebounds" (https://www.cio.com/article/264637/enterprise-resource-planning-nike-rebounds-how-nike-recovered-from-its-supply-chain-disaster.html).

10. FoxMeyer Drug bankruptcy — ACM Communications of the ACM case study (https://dl.acm.org/doi/fullHtml/10.1145/505248.505249). Chapter 11 filed August 1996; trustee lawsuits filed 1998. Causation disputed; no court finding that ERP was the cause.

**SAP maintenance timelines**: SAP ECC 6.0 EhP 0–5 mainstream maintenance ended December 31, 2025. SAP ECC 6.0 EhP 6–8 mainstream maintenance ends December 31, 2027, with optional extended maintenance to December 31, 2030. SAP also offers a RISE with SAP "Transition Option" extending to December 31, 2033 for committed customers. SAP's flagship is S/4HANA. https://support.sap.com/en/offerings-programs/strategy.html

**Gartner analyst research**: Gartner no longer publishes a unified ERP Magic Quadrant — the market is split into two reports:
- Gartner Magic Quadrant for Cloud ERP for Product-Centric Enterprises (2025 edition)
- Gartner Magic Quadrant for Cloud ERP for Service-Centric Enterprises (published October 13, 2025)

**Accounting standards** (additional): FASB ASC 830 — Foreign Currency Matters; IAS 21 — Effects of Changes in Foreign Exchange Rates; IAS 1 — Presentation of Financial Statements; IAS 2 — Inventories (prohibits LIFO); IAS 37 — Provisions, Contingent Liabilities and Contingent Assets; FASB ASC 410 — Asset Retirement Obligations; IFRS 8 — Operating Segments; IFRS 10 — Consolidated Financial Statements; FASB ASC 810 — Consolidation. https://ifrs.org; https://fasb.org

**Industry and quality standards**: ISO 9001:2015; IATF 16949:2016; AS9100 Rev D; 21 CFR Part 11 (https://www.ecfr.gov); ISA-95 / IEC 62264; ISO 19005-1/2/3 (PDF/A); ISO 4217 (currency codes); ISO 3166-1 alpha-2 (country codes).

**Identity, integration, and regulatory standards**: SCIM 2.0 — RFC 7643 / RFC 7644 (https://datatracker.ietf.org/doc/html/rfc7643); SAML 2.0 — OASIS; OpenAPI Specification 3.x (https://openapis.org); eIDAS Regulation (EU) No 910/2014 (https://eur-lex.europa.eu); US ESIGN Act 15 U.S.C. §7001; EU Working Time Directive 2003/88/EC.

**EDI and banking formats**: ASC X12 transaction sets 850, 856, 810, 997, 834 (https://x12.org); UN/EDIFACT ORDERS, DESADV, INVOIC (https://unece.org); SWIFT MT940; ISO 20022 CAMT.053 (https://iso20022.org); BAI2 (Bank Administration Institute).

**Vendor documentation**: SAP S/4HANA (https://help.sap.com — FI, CO, MM, SD, PP, EWM, PS, QM, PM/EAM, Group Reporting, RE-FX, MRP Live, SAP RAR); Oracle Fusion Cloud ERP and EPM (https://docs.oracle.com); Microsoft Dynamics 365 Finance and Supply Chain Management (https://learn.microsoft.com); Workday Financial Management and HCM (https://workday.com); Oracle NetSuite SuiteAnalytics, SuiteProjects, SuiteBilling, SuiteTax (https://netsuite.com).
