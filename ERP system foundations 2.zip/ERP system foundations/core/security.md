# ERP Security, Compliance & Access Control

ERP systems concentrate an organisation's most sensitive operational, financial, and personal data into a single integrated platform. That concentration makes them the highest-value target in the enterprise threat landscape and the primary scope item in virtually every compliance audit. This file is an engineering reference for architects and engineers designing, building, or hardening ERP systems. It covers access control design, identity, data security, audit infrastructure, regional compliance obligations, infrastructure hardening, vendor risk, penetration testing methodology, and backup resilience.

---

## Access Control Architecture

### RBAC vs ABAC

**Role-Based Access Control (RBAC)** maps job functions to permission sets via role assignments. It is the native access model in every major ERP:

| ERP Platform | RBAC Implementation |
|---|---|
| SAP S/4HANA | Authorization objects → Profiles → Roles; transaction SU01 for user maintenance, PFCG for role maintenance |
| Oracle Fusion Cloud ERP | Job roles + data roles + duty roles; role hierarchy managed in OIM/Oracle Access Governance |
| Microsoft Dynamics 365 Finance & Supply Chain Management | Security roles → Duties → Privileges → Permissions; configured in System Administration |
| Workday Financial Management / HCM | Security groups (role-based, user-based, intersection, aggregation groups) |
| NetSuite | Roles with permission levels per record type; SuiteAnalytics permissions managed separately |

RBAC is simpler to administer and audit. Its weakness in multi-entity, multi-country ERP deployments is that roles cannot natively express data-row-level restrictions (e.g., "this role may access only ledger entries for legal entity DE01").

**Attribute-Based Access Control (ABAC)** evaluates policies against subject attributes (department, clearance level, employment status), object attributes (data classification, legal entity, profit centre), and environment attributes (time of day, source IP, device posture). NIST SP 800-162 is the canonical definition guide. NIST SP 800-53 Rev. 5 control AC-3(14) addresses ABAC; AC-3(7) addresses RBAC. [1]

**Hybrid model (recommended for large ERPs):** Use RBAC as the coarse-grained base layer that determines which transactions a user may execute, and ABAC for fine-grained data-row filtering. Oracle Fusion Cloud ERP implements this natively via RBAC job roles combined with data security policies that filter row access by business unit, legal entity, or ledger. SAP S/4HANA implements it via authorization fields within authorization objects (e.g., `BUKRS` restricts access to specific company codes within a transaction-level role).

| Dimension | RBAC | ABAC |
|---|---|---|
| Administrative complexity | Low — finite role catalog | High — policy authoring requires expertise |
| Scalability with entities/countries | Poor — role explosion across legal entities | Strong — policy references entity attribute |
| ERP native support | Universal | Oracle Fusion Cloud ERP, SAP S/4HANA (partial) |
| Audit legibility | High — role assignments are readable | Lower — policy evaluation requires tooling |
| Fine-grained data filtering | Requires additional controls | Native |
| Primary standards reference | NIST SP 800-53 Rev. 5 AC-3(7) | NIST SP 800-53 Rev. 5 AC-3(14); NIST SP 800-162 |
| Best fit | Standard enterprise ERP | Multi-entity, multi-country, regulated industries |

### Segregation of Duties (SoD)

SoD requires that no single user can initiate and approve the same transaction. ERPs are uniquely high-risk because end-to-end business processes — procure-to-pay (P2P), order-to-cash (O2C), record-to-report (R2R) — live within one system. A single over-privileged user account can execute an entire fraudulent cycle without crossing system boundaries.

**Critical SoD conflict matrix:**

| Conflicting Permissions | Process | Fraud Vector |
|---|---|---|
| Create vendor master + Approve vendor payment | P2P | Create fictitious vendor, pay to controlled account |
| Post journal entry + Approve journal entry | R2R | Falsify financial statements without second reviewer |
| Create purchase order + Approve purchase order | Procurement | Self-approve fraudulent purchases |
| Receive goods (goods receipt) + Process vendor invoice | P2P | Three-way-match bypass; pay for undelivered goods |
| Create customer master + Process customer refund | O2C | Issue refunds to fictitious customers |
| Modify payroll master data + Approve payroll run | HCM/Payroll | Add ghost employees or inflate salary |
| Change bank account on vendor record + Initiate payment run | P2P | Redirect vendor payments to attacker-controlled account |
| Request user access + Approve user access | Identity | Grant self-elevated permissions |
| Maintain GL chart of accounts + Post financial documents | R2R | Create concealment accounts |

**SoD ruleset frameworks and tooling:**

- **SAP GRC Access Control** (Access Risk Analysis / ARA module): automated SoD conflict detection at provisioning time and on-demand; transaction SU53 provides authorisation trace for failed checks; Emergency Access Management (EAM) module controls time-boxed firefighter access with full session logging; Business Role Management for role design governance.
- **Oracle Risk Management Cloud (RMC) + Oracle Access Governance Cloud Service**: Access Guardrails within Oracle Access Governance provide real-time SoD enforcement at the point of access request, without requiring a full RMC deployment. RMC adds continuous monitoring and incident management for detected conflicts.
- **Pathlock** (formed from the merger of Greenlight Technologies and Fastpath): cross-application SoD analysis spanning SAP, Oracle EBS/Fusion, Workday, Salesforce, Microsoft Dynamics 365, Sage, and NetSuite within a single conflict ruleset; AI-driven role remediation suggestions; continuous controls monitoring (CCM) capability.
- **Fastpath Assure** (now integrated into Pathlock): historically focused on Microsoft Dynamics 365, Sage, and NetSuite SoD detection; unified with the Pathlock platform.

**Compensating controls** when SoD cannot be enforced (e.g., small teams): enhanced transaction monitoring with alerting on conflicting-permission usage; dual-approval workflow enforced at application layer; detective controls via audit log review on a defined cycle; periodic management review of exception report.

**Access certification (user access review):** Quarterly recertification cycles are recommended for privileged and financially sensitive roles. SAP GRC Access Control includes a User Access Review workflow. Oracle Access Governance automates review campaigns with manager attestation. Unreviewed access should auto-revoke on certification deadline.

### Least Privilege and Privileged Access Management

**Least privilege provisioning:** Grant only permissions required for the documented job function. Implement role request and approval workflow so every granted role has a documented business justification. Set automatic expiry on temporary access grants.

**Privileged access anti-patterns:**

- `SAP_ALL` profile: grants all authorizations across all modules; should exist on zero production user accounts; its assignment must trigger an immediate alert.
- Shared administrative accounts: violate non-repudiation; every administrator must have an individual named account.
- Standing privileged access: production DBA or Basis administrator accounts with permanent broad access should be replaced with just-in-time (JIT) access via a PAM platform.

**PAM tooling for ERP:**

| Tool | Capability |
|---|---|
| CyberArk Privileged Access Manager | Session recording for SAP GUI/Oracle Forms sessions; JIT access with approval workflow; credential vaulting |
| BeyondTrust Password Safe | Privileged password management; session monitoring; SAP and Oracle ERP credential rotation |
| Delinea Secret Server | Secrets vault for ERP service accounts; automated credential rotation; SIEM integration |

**SAP Emergency Access Management (EAM):** Provides time-boxed "firefighter" access (SAP term) for Basis administrators and emergency production fixes. Every firefighter session is logged to a dedicated log owner role; sessions are reviewed post-use; inappropriate use triggers an access violation record in SAP GRC.

**Service and technical accounts:** Non-human identities (batch job users, RFC technical users, API integration users) must have dedicated accounts with no interactive login capability, credentials stored in a secrets vault (HashiCorp Vault, AWS Secrets Manager, Azure Key Vault), and automated rotation schedules. Never store ERP API keys or RFC passwords in configuration files, source code, or build pipelines.

---

## Authentication and Identity

### SSO, SAML, and OIDC

**SAML 2.0** (Security Assertion Markup Language) is the dominant SSO protocol in enterprise ERP:

- **SAP S/4HANA**: integrates with enterprise IdP (Okta, Microsoft Entra ID, Ping Identity) via SAP Cloud Identity Services — Identity Authentication Service (IAS). IAS acts as a proxy IdP, normalising claims before forwarding to S/4HANA.
- **Oracle Fusion Cloud ERP**: uses Oracle Identity Cloud Service (IDCS) as its IdP proxy; supports SAML 2.0 federation with Okta, Entra ID, or on-premises ADFS.
- **Microsoft Dynamics 365 Finance & Supply Chain Management**: natively uses Microsoft Entra ID (formerly Azure Active Directory); SAML federation is handled at the Entra ID layer.

**OIDC (OpenID Connect 1.0)**: modern token-based protocol preferred for web and mobile clients. Workday, NetSuite, and Acumatica use OIDC for SSO. OIDC access tokens (JWT) carry claims including roles and group memberships; map carefully to ERP role assignments during implementation.

**Federated identity engineering considerations:**
- Synchronise session lifetime between IdP and ERP application layer.
- Attribute/claim mapping (e.g., department code to business unit) must be tested for all user population segments.
- Logout propagation (single logout / SLO) must terminate both the IdP session and the ERP application session.

### MFA Enforcement

MFA is mandatory in any regulated ERP environment. PCI DSS v4.0.1 (v3.2.1 retired December 31, 2024; all 64 future-dated requirements became mandatory March 31, 2025) mandates MFA for all accounts accessing the cardholder data environment (Requirement 8.4.2). [2] NIST SP 800-63B Digital Identity Guidelines defines assurance levels and explicitly deprecates SMS OTP as a second factor. [3]

**MFA factor taxonomy:**

| Factor Type | Implementation | Notes |
|---|---|---|
| TOTP | RFC 6238 (Time-Based OTP); Google Authenticator, Microsoft Authenticator | Widely supported; phishable via real-time AiTM proxy |
| FIDO2/WebAuthn | W3C Web Authentication hardware tokens (YubiKey, Titan); passkeys | Phishing-resistant; recommended for all privileged accounts |
| Push-based | Duo Security, Microsoft Authenticator push | Vulnerable to MFA fatigue attacks; configure number matching |
| SMS OTP | Deprecated per NIST SP 800-63B | Do not implement for new systems |

**ERP MFA enforcement points:**

- **SAP Cloud IAS**: conditional MFA policies based on user group, risk score, network location, and device type.
- **Oracle IDCS**: adaptive MFA evaluates risk signals (device fingerprint, geolocation, behaviour); can require step-up authentication for high-risk transactions.
- **Microsoft Dynamics 365**: enforced via Entra ID Conditional Access policies; can require compliant device + MFA for ERP access; supports phishing-resistant FIDO2 policies for privileged roles.

### Session Management

- **Idle timeout**: 15-minute inactivity timeout is the standard baseline for ERP financial modules; PCI DSS v4.0.1 Requirement 8.2.8 mandates a 15-minute timeout for idle sessions with access to the CDE.
- **Absolute session maximum**: force re-authentication after a defined absolute duration (e.g., 8 hours) regardless of activity.
- **Token revocation**: on explicit logout, invalidate server-side session tokens and revoke OAuth access tokens via the IdP revocation endpoint. Client-side token deletion alone is insufficient.
- **API sessions**: OAuth 2.0 access tokens (short-lived, 15–60 minutes) plus refresh tokens with rotation; never issue non-expiring API tokens.
- **CSRF protection**: apply CSRF tokens to all state-changing ERP web requests; verify `Origin` and `Referer` headers at the application layer.
- **Concurrent session control**: limit concurrent sessions per user; flag simultaneous sessions from geographically separated IPs as anomalous.

### API Key and Secrets Management

ERP platforms expose extensive REST and OData APIs. Managing those credentials is a critical security control:

- **SAP S/4HANA / SAP Integration Suite**: OAuth 2.0 client credentials for system-to-system integration; certificates for RFC and iDoc channels; manage via SAP BTP service instances.
- **Oracle Fusion Cloud ERP**: REST APIs use OAuth 2.0; client IDs and secrets registered in Oracle IDCS; certificate-based authentication for on-premise integration middleware.
- **Microsoft Dynamics 365**: Azure Active Directory app registrations with client secrets or certificates; certificates are preferred over secrets (no unexpected expiry).

Rotation schedule: client secrets should rotate at least annually (90-day rotation for high-sensitivity integrations). Automated rotation via HashiCorp Vault dynamic secrets or Azure Key Vault rotation policies eliminates manual processes. Every secret access event must produce an audit log entry.

---

## Data Security

### Encryption at Rest and in Transit

**At rest minimum standard: AES-256.**

| ERP / Database | Encryption-at-Rest Implementation |
|---|---|
| SAP S/4HANA on SAP HANA | SAP HANA Native Storage Extension (NSE) encryption; data volume encryption at page level; key management via SAP HANA Secure Store |
| Oracle Fusion Cloud / Oracle Autonomous DB | Oracle Transparent Data Encryption (TDE); customer-managed keys option via Oracle Key Vault |
| Microsoft Dynamics 365 / SQL Server | SQL Server TDE; Azure Disk Encryption for IaaS; keys managed in Azure Key Vault |
| Workday Financial Management | Workday-managed encryption on proprietary cloud infrastructure; verify current customer-managed key availability against Workday Trust documentation |

**In transit: TLS 1.2 minimum; TLS 1.3 preferred.** NIST SP 800-52 Rev. 2 (Guidelines for TLS Implementations) mandates TLS 1.2 minimum and deprecates TLS 1.0/1.1 for US government systems; the same baseline is standard enterprise practice. Disable SSL 2.0/3.0 and TLS 1.0/1.1 at load balancer, web dispatcher, and database listener layers. Implement certificate pinning for ERP mobile clients to prevent MITM via rogue CA.

**Database-level vs filesystem/volume-level encryption trade-off:** Database-level TDE (Oracle, SQL Server) encrypts data pages on disk and protects against storage theft but does not protect against a compromised privileged database user who queries data in plaintext. Filesystem/volume encryption (dm-crypt, AWS EBS encryption, Azure Disk Encryption) adds protection for the storage layer but is transparent to the database. For maximum protection, deploy both layers plus application-layer field encryption for the most sensitive columns.

### Field-Level Encryption and Data Masking

**Field-level encryption** encrypts specific columns (Social Security Numbers, bank account numbers, tax IDs, passport numbers) with a key hierarchy separate from the database master key:

- **SAP Data Custodian**: field-level encryption for SAP S/4HANA Cloud; allows customer-controlled field encryption keys independent of SAP infrastructure keys.
- **Oracle Database Vault**: column-level access controls that restrict even privileged DBA accounts from accessing specific sensitive columns.
- **Custom ABAP / PL/SQL**: implementing field-level encryption in custom ERP code requires a carefully designed key management architecture; do not build home-grown key derivation or storage.

**Data masking:**

| Type | Use Case | Tools |
|---|---|---|
| Static masking | Non-production environments (dev/test/UAT); permanently replace real values with realistic synthetic data | Oracle Data Masking and Subsetting, Delphix, Informatica Test Data Management |
| Dynamic masking | Production read access; mask at query time based on role; authorised roles see plaintext | Informatica Dynamic Data Masking, Oracle Database Vault |

Static masking for non-production is a compliance requirement under GDPR Article 5 (data minimisation) and PCI DSS v4.0.1 Requirement 3 (protect stored cardholder data). Never copy production ERP data to non-production environments without masking.

**Tokenisation** replaces sensitive values with format-preserving tokens (same length and character set, no mathematical relationship to the original). Critical for PCI DSS compliance when cardholder PANs flow through ERP order management and billing modules. The tokenisation vault holds the mapping; the ERP stores only tokens.

### Key Management and HSM

**Key hierarchy:**
```
Master Key (stored in HSM)
  └── Key Encryption Key (KEK)  ← wraps DEKs; rotated annually
        └── Data Encryption Key (DEK)  ← encrypts actual data; rotated per policy
```

**Hardware Security Modules (HSM):** For regulated environments, keys must be generated and stored in validated HSMs. FIPS PUB 140-3 (Security Requirements for Cryptographic Modules, current version) supersedes FIPS 140-2 for new submissions as of April 1, 2022; FIPS 140-2 certificates move to the Historical List on September 21, 2026. Specify FIPS 140-3 Level 3 for new HSM procurement. Options: AWS CloudHSM, Azure Dedicated HSM, Thales Luna Network HSM. HSMs provide tamper-evident key storage, enforced dual-control for key ceremonies, and hardware-accelerated cryptographic operations.

**Bring Your Own Key (BYOK):** Allows the customer to hold the master key in their own HSM or key management service while the ERP cloud provider encrypts data with keys derived from that master:

- SAP Cloud: BYOK via SAP Data Custodian with customer HSM integration.
- Oracle Autonomous Database: Customer-Managed Encryption Keys using Oracle Key Vault.
- Microsoft Azure (Dynamics 365): Customer-Managed Keys (CMK) via Azure Key Vault Managed HSM; customer revocation of key immediately renders data inaccessible.

**Key management procedures:** Implement dual control (two authorised key custodians required for key ceremonies) and split knowledge (no single person knows the complete key material). Document key rotation schedules; automate rotation where HSM and KMS APIs support it. Maintain a key inventory with associated data assets, rotation dates, and custodian assignments.

---

## Audit Trails and Continuous Monitoring

### Immutable Audit Logs

Every financial data change must produce a log record capturing: who (authenticated user identity), what (table name, field name, old value, new value), when (timestamp with timezone, server-authoritative), and from-where (source IP, terminal, session ID). These records must be tamper-evident and retained for the compliance-mandated period.

**ERP native audit capabilities:**

| Platform | Audit Mechanism |
|---|---|
| SAP S/4HANA | Table Change Log (transaction SCU3 / SCDO for configuration); Document Change Log for FI/CO documents; SAP Audit Management for audit program management |
| Oracle Fusion Cloud ERP | Audit Trail configuration per business object in Security Console; Oracle Audit Vault and Database Firewall (AVDF) for database-layer capture |
| Microsoft Dynamics 365 Finance & Supply Chain Management | Microsoft Purview Audit (Standard and Premium tiers); field-level change tracking per entity; Database Logging for specific table changes |

**Immutability:** Write audit logs to append-only storage. AWS S3 Object Lock (WORM mode with governance or compliance lock), Azure Immutable Blob Storage (time-based retention or legal hold), and NetApp SnapLock provide write-once semantics. Never allow ERP application service accounts write or delete permission on the audit log bucket/container.

**Retention requirements:**

- **SOX (Sarbanes-Oxley Act of 2002)**: 7-year retention for financial records and audit documentation. [4]
- **UK Companies Act 2006, Section 388**: 6 years for public company accounting records; 3 years for private companies.
- **GDPR Article 5(1)(e)**: storage limitation — retain only as long as necessary for the processing purpose; reconcile with SOX/audit retention by applying purpose-specific retention buckets.
- **PCI DSS v4.0.1 Requirement 10.5.1**: retain audit logs for at least 12 months, with at least 3 months immediately available for analysis. [2]

### SIEM Integration and Alerting

**Log source taxonomy for ERP SIEM integration:**

1. ERP application audit logs (financial change logs, access logs, failed transaction logs)
2. Database audit logs (Oracle AVDF, SQL Server Audit, HANA Audit Policy)
3. Identity provider logs (Entra ID sign-in logs, SAP IAS audit logs)
4. OS and infrastructure logs (host syslog, hypervisor events)
5. Network logs (WAF events, load balancer access logs, VPC flow logs)

**SIEM platforms with ERP connectors:**

| SIEM | ERP Connector |
|---|---|
| Splunk | Splunk Add-on for SAP (SAP application layer, ABAP, Java, HANA DB logs) |
| Microsoft Sentinel | Native Dynamics 365 connector; Microsoft Sentinel Solution for SAP (SAP-certified connector) |
| IBM QRadar | SAP connector via IBM QRadar SAP DSM; Oracle AVDF forwarding |
| Google Chronicle | Ingestion via log forwarder; ERP-specific parsers available |
| Securonix | SAP S/4HANA UEBA connector with pre-built threat models |

**Alerting priorities:**

- Assignment of `SAP_ALL` or equivalent super-profile: immediate P1 alert.
- SoD conflict execution attempt: alert when a user executes a transaction that conflicts with another permission already held; SAP GRC ARA can feed real-time SoD violation events to SIEM.
- Mass data export from ERP (SE16N, SQVI, large OData responses): alert on volume threshold.
- Off-hours access to financial transaction codes.
- Failed login threshold breach: account lockout trigger + SIEM alert.

**Continuous Controls Monitoring (CCM):** Automated testing of controls at high frequency (daily or near-real-time) rather than point-in-time audit. Tools: Pathlock CCM, AuditBoard, Diligent (formerly Galvanize HighBond). CCM closes the gap between annual auditor testing and the actual control state.

### Login Anomaly Detection

**UEBA (User and Entity Behaviour Analytics)** establishes a baseline of normal user behaviour and alerts on deviations. Priority detection scenarios for ERP:

- Login from a geolocation not previously seen for that user account.
- Off-hours access to high-sensitivity financial transactions.
- Mass data download (high record count export, large OData response body).
- Privilege escalation immediately after a role change event.
- Use of a shared/service account for interactive login.
- Multiple failed logins followed by successful login (credential stuffing pattern).

Tools with SAP/ERP-specific models: Securonix with SAP S/4HANA connector; Splunk UBA; Microsoft Sentinel UEBA (native for Dynamics 365 / Entra ID signals). Lock accounts after a configurable threshold of failed authentications (5–10 attempts); alert on account lockouts in aggregate (lockout storm = credential stuffing).

---

## Compliance by Region

### United States

**SOX (Sarbanes-Oxley Act of 2002):** [4]

- **Section 302**: CEO and CFO must personally certify the accuracy of financial statements and the effectiveness of disclosure controls.
- **Section 404**: Management's annual assessment of Internal Controls over Financial Reporting (ICFR); external auditor attestation required for accelerated filers per PCAOB AS 2201 (formerly AS No. 5, An Audit of Internal Control Over Financial Reporting That Is Integrated with an Audit of Financial Statements).
- **IT General Controls (ITGCs)**: a sub-category of ICFR covering logical access controls, change management, computer operations, and SDLC. ERP access control logs, SoD evidence, and change management audit trails are primary evidence categories in ITGC testing.
- **7-year record retention** applies to audit documentation.

**HIPAA (Health Insurance Portability and Accountability Act of 1996):**

- **Security Rule (45 CFR Part 164, Subpart C)**: administrative, physical, and technical safeguards for electronically Protected Health Information (ePHI). Relevant to ERP HR and payroll modules that hold employee health benefit data, and to healthcare vertical ERP implementations (see `verticals/healthcare-lifesciences.md`).
- **Breach Notification Rule**: covered entities must notify affected individuals, HHS, and (in some cases) media within 60 days of breach discovery.

**FedRAMP (Federal Risk and Authorization Management Program):**

- Authority: OMB M-24-15 (2024); control baselines derived from NIST SP 800-53 Rev. 5. [1]
- Impact levels: Low, Moderate, High. Most ERP cloud deployments targeting US federal agencies require Moderate authorisation.
- ERP cloud providers serving federal customers must achieve an Authority to Operate (ATO) from a sponsoring agency and appear in the FedRAMP Marketplace. Microsoft Dynamics 365 Government Cloud (GCC/GCC High) and SAP NS2 maintain FedRAMP authorisations.

**ITAR / EAR:**

- **ITAR (22 CFR Parts 120–130)**: controls export of US Munitions List (USML) items; ERP must enforce data residency (ITAR-controlled data must not transit or be stored outside the US without authorisation) and nationality-based access controls (non-US persons may not access ITAR-controlled technical data).
- **EAR (15 CFR Parts 730–774)**: Export Administration Regulations covering dual-use goods and technologies; ERP order management must screen transactions against denied/debarred parties lists. Tools: SAP Global Trade Services (GTS), Oracle Global Trade Management.

**CCPA / CPRA:**

- California Consumer Privacy Act (effective January 1, 2020) / California Privacy Rights Act (effective January 1, 2023, enforced by the California Privacy Protection Agency / CPPA): data subject rights including right to know, right to delete, right to portability, and right to opt out of sale/sharing. ERP must support data subject request workflows, data inventory/mapping, and consent flags.

**PCI DSS v4.0.1:** [2]

- Published by the PCI Security Standards Council (PCI SSC). v4.0.1 is a limited revision released June 2024 that clarifies intent without changing requirements. v3.2.1 retired December 31, 2024; the 51 future-dated requirements of v4.x became mandatory March 31, 2025.
- Key requirements impacting ERP: Requirement 4 (encrypt cardholder data in transit), Requirement 7 (restrict access by business need to know), Requirement 8 (MFA mandatory for all CDE access — Req 8.4.2), Requirement 10 (logging and monitoring — Req 10.5.1 for log retention), Requirement 11 (vulnerability scans and penetration testing — Req 11.3).

### European Union and United Kingdom

**GDPR (Regulation (EU) 2016/679, effective May 25, 2018):** [5]

| Article | Engineering Implication |
|---|---|
| Art. 5 | Lawfulness, purpose limitation, data minimisation, accuracy, storage limitation, integrity/confidentiality, accountability — every ERP data field must have a documented processing purpose and retention rule |
| Art. 25 | Data Protection by Design and by Default — encryption, pseudonymisation, and access minimisation must be architectural defaults, not retrofits |
| Art. 28 | Data Processing Agreement (DPA) required for all processors and subprocessors, including ERP SaaS vendors, cloud infrastructure providers, and analytics platform vendors |
| Art. 30 | Records of Processing Activities (RoPA) — maintain a data map of all ERP processing activities, purpose, legal basis, categories of data, recipients, and retention periods |
| Art. 32 | Appropriate technical and organisational measures including encryption and pseudonymisation; EDPB and national DPAs (e.g., CNIL) expect state-of-the-art encryption |
| Art. 33/34 | 72-hour breach notification to supervisory authority; notification to data subjects if high risk |
| Arts. 44–49 | Cross-border transfer mechanisms: Standard Contractual Clauses (SCCs), Binding Corporate Rules (BCRs), adequacy decisions; ERP data replication to offshore support centres or analytics clouds must comply |

**NIS2 Directive (Directive (EU) 2022/2555):** [6]

Transposition deadline was October 17, 2024; EU member states were required to apply transposed provisions from October 18, 2024. In practice, only a handful of member states (Belgium, Croatia, Hungary, Italy, Latvia, Lithuania) met the deadline; major economies including France and Germany were still completing transposition as of early 2025. Replaces NIS1; expands scope to essential and important entities across additional sectors. Directly relevant for ERP because ERP systems are core operational infrastructure for essential entities. Requirements: MFA for ERP administrative access, supply chain security (ERP vendor and integrator vetting), incident reporting within 24 hours (early warning) / 72 hours (notification) / 1 month (final report).

**DORA (Regulation (EU) 2022/2554, in application January 17, 2025):** [7]

Applies to EU financial entities (banks, insurers, investment firms, payment processors). Mandates: ICT risk management framework; ICT incident classification and reporting; Digital Operational Resilience Testing (DORT), including Threat-Led Penetration Testing (TLPT); ICT third-party risk management with a Register of Information (initial submission deadline April 30, 2025 for competent authorities, with some national supervisors setting earlier dates). ERP systems used by in-scope financial entities are directly regulated. Penalties: up to EUR 10 million or 5% of total annual worldwide turnover (whichever is higher). See `verticals/financial-services.md` for DORA detail.

**UK GDPR + Data Protection Act 2018:** Retained EU law post-Brexit; functionally equivalent to EU GDPR; enforced by the ICO (Information Commissioner's Office). UK SCCs (International Data Transfer Agreements / IDTAs) govern transfers from the UK.

**UK Companies Act 2006, Section 388:** Requires accounting records to be retained for 6 years for public companies; 3 years for private companies. ERP change logs and financial document history must support this retention.

### Asia-Pacific

**Singapore PDPA (Personal Data Protection Act 2012, significantly amended 2020/2021):**
Mandatory breach notification within 3 business days to the PDPC (Personal Data Protection Commission) if the breach is likely to result in significant harm. Mandatory Data Protection Officer (DPO). Financial penalties up to SGD 1 million or 10% of annual Singapore turnover, whichever is higher (post-2021 amendment).

**Thailand PDPA (Personal Data Protection Act B.E. 2562/2019, enforcement from June 1, 2022):**
GDPR-aligned consent requirements; DPO mandatory for certain categories of data controller; cross-border transfer restrictions require adequate protection or explicit consent.

**Australia Privacy Act 1988:**
The Privacy and Other Legislation Amendment Act 2024 (Cth) was passed November 29, 2024 and took effect December 11, 2024. Maximum civil penalty for serious interference with privacy: AUD 50 million, or 3x the value of any benefit obtained, or 30% of adjusted annual turnover — whichever is highest. [8] Australian Privacy Principles (APP) 11 requires reasonable security safeguards. Mandatory Notifiable Data Breaches (NDB) scheme (Part IIIC): notify the OAIC and affected individuals if a breach is likely to result in serious harm.

**China PIPL (Personal Information Protection Law, enacted August 20, 2021, effective November 1, 2021):**
Comprehensive law with extraterritorial effect. Cross-border data transfer requires one of: Standard Contract (CAC Standard Contract, effective June 1, 2023), a security assessment approved by the CAC (Cyberspace Administration of China), or PIPC certification. Critical Information Infrastructure Operators (CIIOs) must store personal information within China. DPO required for certain processors. Enforced by the CAC. ERP cloud deployments for China operations require China-specific data residency architecture.

**South Korea PIPA (Personal Information Protection Act, originally 2011, significantly amended effective September 15, 2023):** [9]
2023 amendment modernised cross-border transfer rules to GDPR-equivalent adequacy pathways. Maximum administrative fines: up to 3% of total revenue (amended from "violation-related revenue" to "total revenue" minus unrelated portions). Mandatory breach notification. Enforced by the PIPC (Personal Information Protection Commission).

### Latin America

**Brazil LGPD (Lei Geral de Proteção de Dados Pessoais, Law No. 13.709/2018, in effect September 18, 2020):**
10 legal bases for processing (including consent, legitimate interest, contractual necessity). Data subject rights: access, correction, deletion, data portability, revocation of consent. Enforced by ANPD (Autoridade Nacional de Proteção de Dados). Administrative sanctions: warnings, fines up to 2% of revenue in Brazil capped at BRL 50 million per infraction. ERP must support data subject request workflows, consent management records, and breach notification processes.

**Colombia Habeas Data Law (Statutory Law 1581 of 2012 + Decree 1377 of 2013):**
Regulates treatment of personal data; rights of access, update, correction, and deletion; prior authorisation (consent) required; data quality principles; cross-border transfer restrictions. Enforced by the SIC (Superintendencia de Industria y Comercio). Verify current penalty schedule against SIC enforcement guidance; do not cite secondary-source figures.

### Middle East

**Saudi Arabia PDPL (Personal Data Protection Law, Royal Decree M/19, effective September 14, 2023, full enforcement September 14, 2024):**
Overseen by SDAIA (Saudi Data and Artificial Intelligence Authority). Consent-based processing; data minimisation principle; sensitive data categories (health, financial, biometric) require explicit consent; cross-border transfer requires SDAIA approval. Fines up to SAR 5 million (approximately USD 1.3 million at publication exchange rate), doubled for repeat violations; criminal imprisonment for intentional unauthorised disclosure.

**UAE Federal Decree-Law No. 45 of 2021 on Personal Data Protection (effective January 2, 2022; executive regulations issued 2023):**
First comprehensive federal UAE data privacy law. Extraterritorial effect for controllers/processors handling UAE residents' data. Mandatory DPO, breach notification, and appropriate technical/organisational measures. Importantly, **excludes** DIFC (Dubai International Financial Centre) and ADGM (Abu Dhabi Global Market) free zones — each has its own data protection regime broadly equivalent to GDPR: DIFC Data Protection Law 2020 and ADGM Data Protection Regulations 2021, each regulated by their respective data protection commissioners.

---

## Infrastructure Security

### Network Segmentation and Perimeter

**ERP tier isolation:** Separate the presentation tier (web/Fiori), application tier (ABAP/Java stack, Oracle AppServer), and database tier (HANA, Oracle DB, SQL Server) into distinct network segments with explicit allow-list firewall rules between tiers. No direct client-to-database connectivity. In cloud deployments, implement micro-segmentation:

- **AWS**: Security Groups and Network ACLs per tier; VPC peering with route control.
- **Azure**: Network Security Groups (NSGs) per subnet; Azure Private Link for database access without public IP exposure.
- **GCP**: VPC firewall rules with service account-based identity; Private Service Connect.

**WAF (Web Application Firewall):** Protect ERP web front-ends (SAP Fiori Launchpad, Oracle Fusion UI, Dynamics 365 web client) against OWASP Top 10 (injection, broken auth, IDOR, XSS, etc.). Specific to SAP: deploy SAP Web Dispatcher in a DMZ with a WAF in front; the Web Dispatcher performs URL filtering and load balancing before traffic reaches the ABAP application server. Options: ModSecurity (open-source), AWS WAF, Azure Front Door WAF, Cloudflare WAF.

**DDoS protection:** ERP login portals and API endpoints are attractive DDoS targets during financial close. AWS Shield Advanced, Azure DDoS Protection, and Cloudflare Magic Transit provide volumetric and protocol-layer protection. Rate-limit API endpoints at the gateway layer.

### Vulnerability Management and Patch Cadence

**SAP Security Notes:**
Published on the second Tuesday of each month (SAP Patch Day). Notes are categorised by CVSS v3.1 score:

| Priority | CVSS Range | Action |
|---|---|---|
| HotNews | ≥ 9.0 | Emergency patch; target SLA 72 hours |
| High | 7.0–8.9 | Patch within current monthly cycle |
| Medium | 4.0–6.9 | Patch within 90 days |
| Low | < 4.0 | Patch in next scheduled maintenance window |

**Oracle Critical Patch Updates (CPU) and Critical Security Patch Updates (CSPU):**
Oracle published quarterly CPUs (January, April, July, October). Beginning May 28, 2026, Oracle transitioned to monthly Critical Security Patch Updates (CSPUs), published on the third Tuesday of each month for the intervening months (February, March, May, June, August, September, November, December). Quarterly CPUs remain on the existing schedule for January, April, July, and October. Verify current schedule at https://www.oracle.com/security-alerts/ [10]

**Microsoft Dynamics 365 Finance & Supply Chain Management:** Security updates aligned to Microsoft Patch Tuesday (second Tuesday of each month). Platform service updates are monthly.

**ERP-specific vulnerability scanners:**
- **Onapsis Platform**: authenticated vulnerability scanning for SAP and Oracle ERP application layer (not just OS/network); provides business context for vulnerabilities.
- **SecurityBridge**: SAP security monitoring, vulnerability detection, and runtime protection.
- **CISA KEV (Known Exploited Vulnerabilities) catalog**: monitor for ERP product CVEs listed in KEV; federal agencies must remediate KEV entries per CISA BOD 22-01; enterprises should treat KEV as a priority queue.

### Notable ERP CVEs

**SAP RECON (CVE-2020-6287):** CVSS 10.0. Unauthenticated remote code execution in the SAP NetWeaver AS Java LM Configuration Wizard component. Affected every SAP Java stack with the default LM Configuration Wizard enabled. Patched July 14, 2020 (SAP Security Note 2934135). Onapsis (discoverer) estimated 40,000+ SAP systems globally were potentially vulnerable, with approximately 2,500 directly exposed to the internet. [11] Exploit code appeared in the wild within 72 hours of patch release. CISA issued an emergency advisory. This CVE remains the canonical reference case for the operational risk of unpatched internet-exposed SAP Java systems.

**SAP ICMAD (CVE-2022-22536, CVE-2022-22532, CVE-2022-22533):** Patched February 8, 2022. CVE-2022-22536 (CVSS 10.0): MPI (Memory Pipes) memory desynchronisation vulnerability exploitable via a single specially crafted HTTP request without any authentication. Affects SAP Web Dispatcher, SAP Content Server, and SAP NetWeaver / ABAP Platform. An unauthenticated attacker can fully compromise the SAP system, accessing or modifying all business data. CVE-2022-22532 (CVSS 8.1) and CVE-2022-22533 (CVSS 7.5) are related. CISA issued an advisory. Discovered by Onapsis. [12]

**CVE-2025-31324 (SAP NetWeaver Visual Composer):** CVSS 10.0. Unauthenticated file upload vulnerability in the NetWeaver Visual Composer Metadata Uploader (`/developmentserver/metadatauploader` endpoint), enabling JSP webshell upload and remote code execution without authentication. Active exploitation was reported by ReliaQuest on April 22, 2025, two days before SAP's official disclosure (SAP Security Note 3594142, disclosed April 24, 2025). [13] Forescout Vedere Labs documented a campaign attributed to the Chinese threat actor group Chaya_004 that had compromised 581 SAP NetWeaver instances visible in an openly accessible directory on attacker-controlled infrastructure. [14] Ransomware groups BianLian and RansomEXX also exploited unpatched systems. Immediate remediation: apply SAP Security Note 3594142 and disable the deprecated Visual Composer module.

**CVE-2025-42957 (SAP S/4HANA):** CVSS 9.9. Critical ABAP code injection vulnerability; exploitation requires a valid user account with access to a vulnerable RFC module and S_DMIS authorization with activity 02 (low privilege threshold). Successful exploitation achieves full SAP system compromise including operating system access. Reported as actively exploited in the wild in 2025. [15]

---

## Third-Party and Vendor Risk

### SaaS ERP Security Assessments

The shared responsibility model for SaaS ERP: the cloud vendor secures physical infrastructure, hypervisor, network, and platform software; the customer secures configuration, access control, customisations, data classification, and integration security.

**Security attestation checklist for ERP SaaS vendors:**

| Attestation | Scope |
|---|---|
| SOC 2 Type II (AICPA/CIMA Trust Services Criteria) | Security, availability, processing integrity, confidentiality, privacy; must be Type II (operating effectiveness over period, not just design) |
| SOC 1 Type II (SSAE 18 / ISAE 3402) | Internal controls over financial reporting (ICFR); required for ERP vendors whose processing affects customer financial statements |
| ISO/IEC 27001:2022 | Information Security Management System; third edition published October 25, 2022, replacing the 2013 edition; controls reorganised from 114 to 93 across 4 themes (Organizational, People, Physical, Technological); ISO 27001:2013 certification transition deadline was October 31, 2025 — all current certifications must be to the 2022 revision |
| ISO/IEC 27017:2015 | Cloud-specific security controls; supplement to ISO 27001 for cloud service providers |
| ISO/IEC 27018:2019 | Protection of PII in public cloud; addresses GDPR Article 28 processor obligations |
| Penetration test report | Annual third-party pentest; scope must include ERP application layer, not just infrastructure |
| Bug bounty / VDP | Demonstrates maturity in vulnerability disclosure |

**Due diligence questionnaires:** Shared Assessments SIG (Standardized Information Gathering questionnaire) and CAIQ (Consensus Assessments Initiative Questionnaire from the Cloud Security Alliance / CSA) provide structured vendor risk assessment frameworks.

### Data Processing Agreements and Subprocessor Chains

**GDPR Article 28 DPA mandatory clauses:**
- Processing only on documented controller instructions.
- Confidentiality obligations binding on all personnel with access.
- Appropriate technical and organisational security measures (Article 32).
- Subprocessor restrictions: ERP vendor must obtain prior written authorisation before engaging additional subprocessors; customer must receive notification of subprocessor changes with opportunity to object.
- Assistance with data subject rights, breach notification, DPIAs.
- Data return or deletion on termination.
- Audit rights: customer or designated auditor may audit vendor compliance; most enterprise SaaS vendors satisfy audit rights via sharing SOC 2/ISO 27001 reports.

**Subprocessor chains in SaaS ERP:** A typical SaaS ERP vendor subcontracts to cloud infrastructure (AWS, Azure, GCP), monitoring and observability platforms, support ticketing systems, and analytics services. Customers are entitled to the current list of subprocessors and advance notice of changes. Review subprocessor lists at contract renewal and when material changes are notified.

---

## Penetration Testing ERP Systems

### ERP-Specific Testing Methodology

Standard infrastructure penetration testing commonly excludes ERP application layers. This is an error: the highest-impact vulnerabilities in ERP environments are application- and business-logic-layer issues, not OS or network vulnerabilities.

**Priority attack surfaces:**

| Attack Surface | Specific Techniques |
|---|---|
| **Business logic abuse** | Bypass approval workflows via direct API call; exploit price fields in O2C; submit negative-quantity orders; manipulate discount calculation logic |
| **SoD conflict exploitation** | Identify users with conflicting permissions; attempt end-to-end P2P fraud cycle in a test environment |
| **SAP RFC/BAPI exposure** | Test RFC gateway exposure (SMGW/SICF configuration); unauthenticated BAPI calls; RFC_READ_TABLE for full table extraction; trusted RFC trust relationships (SM59) for privilege escalation |
| **SAP ABAP injection** | Custom report programs lacking `AUTHORITY-CHECK`; ABAP injection via dynamic SQL construction in custom code |
| **OData / REST API abuse** | Service discovery via `$metadata` endpoint enumeration; missing field-level authorisation on OData entity sets; bulk extraction via absent pagination controls; rate limiting bypass |
| **Oracle EBS** | PL/SQL injection in custom packages; OAF (Oracle Application Framework) parameter manipulation; E-Business Suite function security bypass via direct URL construction |
| **NetWeaver Visual Composer endpoint** | Test for `/developmentserver/metadatauploader` exposure (CVE-2025-31324 class); disable if Visual Composer is not in use |
| **Default user accounts** | Test for unlocked SAP* (verify default password status against current S/4HANA hardening guide), DDIC, EARLYWATCH; Oracle EBS defaults: SYSADMIN, GUEST, OPERATIONS |
| **Hardcoded credentials** | RFC destination passwords (SM59), background job service account passwords embedded in ABAP programs |
| **SAP Message Server** | Port 3600 exposure; Message Server access allows registration of rogue application servers |

**Tools:**
- Onapsis Security Platform: automated SAP and Oracle ERP vulnerability scanning with business risk context.
- SecurityBridge: SAP runtime security monitoring and penetration testing support.
- Metasploit: includes SAP-specific modules for RFC enumeration, authentication testing, and exploitation.
- Custom scripts: Python with `pyrfc` library for SAP RFC interface testing.

### Penetration Testing Scope and Frequency

- **Annual third-party penetration test** as baseline requirement (SOX ITGC evidence, PCI DSS v4.0.1 Requirement 11.3, ISO/IEC 27001:2022 Annex A control A.8.8).
- **ERP must be explicitly in scope**: negotiate with pentest provider to include SAP application layer, Oracle ERP instance, or Dynamics 365 application. These are routinely excluded from standard infrastructure pentests and must be mandated in the statement of work.
- **DORA TLPT**: financial entities in scope under DORA must conduct Threat-Led Penetration Testing per DORA's own RTS on TLPT (Regulatory Technical Standard, informed by the TIBER-EU methodology); tests must cover production-equivalent systems and use real threat intelligence to design scenarios. ICT systems critical to financial operations — including ERP — are primary TLPT scope candidates. [7]

---

## Backup, Disaster Recovery, and Ransomware Resilience

### RTO/RPO Targets and Backup Architecture

Define Recovery Time Objective (RTO) and Recovery Point Objective (RPO) for ERP as part of the Business Impact Analysis (BIA). Representative enterprise ERP Tier-1 targets (financial close critical):

| Tier | RTO | RPO | Justification |
|---|---|---|---|
| Tier 1 (financial close, payroll) | 4–8 hours | 1–4 hours | Revenue and regulatory impact |
| Tier 2 (operational ERP: procurement, inventory) | 8–24 hours | 4–8 hours | Supply chain and operational disruption |
| Tier 3 (analytics, reporting) | 24–72 hours | 24 hours | Manageable delay |

These are illustrative targets; the organisation's BIA must define RTO/RPO based on documented business impact of outage.

**Backup types and cadence:**

- **Full backup**: weekly, with retention per compliance policy.
- **Incremental backup**: daily, capturing changes since last full or incremental.
- **Transaction log backup** (for RDBMS supporting point-in-time recovery): every 15–60 minutes; enables PITR recovery within the RPO window.
- **SAP HANA**: native HANA backup to Backint API-compatible storage targets (AWS, Azure, GCP storage connectors); HANA System Replication (HSR) for synchronous or asynchronous real-time replication to a secondary site.

**Geographic redundancy:** Active-passive or active-active cross-region ERP deployment:
- SAP S/4HANA on AWS/Azure/GCP: deploy HANA System Replication across availability zones or regions; application server failover via Pacemaker/RHEL HA cluster.
- Oracle Fusion Cloud ERP: Oracle operates multi-AZ infrastructure within each data region; customer selects home region; Oracle manages cross-AZ redundancy.

**Backup verification:** Automated restore tests at least quarterly. DR drills annually: simulate a complete ERP failure and restore from backup; time the recovery and validate against RTO/RPO targets. An untested backup cannot be trusted.

### Immutable Backups and Ransomware Resilience

Ransomware targeting ERP databases is a primary threat vector — encrypting the SAP HANA or Oracle database halts all business operations. Attackers increasingly target SAP and Oracle ERP specifically because of the operational leverage against the victim organisation.

**Immutable backup storage:**

| Platform | Immutability Mechanism |
|---|---|
| AWS S3 | Object Lock with WORM (governance or compliance mode); compliance mode is truly immutable — no override by any user including root |
| Azure Blob Storage | Immutable Blob Storage with time-based retention policies or legal hold; once set to locked state, cannot be modified or deleted by anyone including Microsoft |
| NetApp SnapLock | On-premises WORM storage for HANA data centre deployments |
| Veeam | Immutable backup repositories to Linux hardened repository or cloud object storage with Object Lock |

**Air-gapped backups:** Maintain at least one offline copy (tape or isolated cloud vault) disconnected from all production network paths. An air gap ensures ransomware that compromises all production credentials cannot reach the backup copy.

**Backup access control segregation:**
- Use separate credentials (stored in PAM vault) for backup systems; production ERP administrator accounts must not have access to backup storage.
- No single administrator should hold write access to both the production ERP system and the backup storage.
- Review backup access controls quarterly.

---

## ERP-Specific Attack Vectors

### Privilege Escalation via Role Assignment

- **Self-service role escalation**: attacker compromises an HR or IT administrator account; uses SU01/SU10 (SAP) or equivalent to grant `SAP_ALL` or a super-user role to a controlled account. Monitor all role assignment transactions in real time.
- **Profile parameter manipulation**: SAP `login/no_automatic_user_sapstar` controls whether the built-in SAP* recovery account is active. If misconfigured, SAP* with its static default password can be used to log in even after the database record is deleted. Verify this parameter on every SAP system as part of the hardening checklist.
- **Role import from transport**: malicious or misconfigured transports that introduce over-privileged roles into production; validate role content before importing transports from development to production.

### Data Exfiltration Patterns

- **Report-to-export (SE16N / SQVI)**: SAP standard tools allow any user with access to download table-level data to spreadsheet. Standard DLP controls do not intercept ERP-native downloads. Alert on high-volume exports; restrict SE16N in production to a named authorised group; log all SE16N executions.
- **OData bulk extraction**: SAP Gateway OData services expose entity sets that return large datasets if pagination (`$top`/`$skip`) is not enforced and field-level authorisation is absent. Rate-limit OData services at the SAP Web Dispatcher layer; implement entity-level authorisation checks.
- **RFC_READ_TABLE exploitation**: SAP function module `RFC_READ_TABLE` allows retrieval of any database table content over a trusted RFC connection. Any system with a trusted RFC connection (SM59 trust level = 1) to a production SAP system can read arbitrary tables without standard authorisation. Audit and restrict trusted RFC relationships; replace RFC_READ_TABLE-dependent integrations with authorisation-aware APIs.
- **BI/analytics secondary systems**: SAP BW/4HANA, Oracle Analytics Cloud, and Microsoft Fabric replicate ERP data into analytics environments that frequently have weaker access controls than the source ERP. Enforce consistent data classification and access controls on all replication targets.

### Default Credentials and Weak Customisation

- **Default SAP users**: SAP*, DDIC, and EARLYWATCH must be locked or have passwords changed immediately post-installation per the SAP Security Guide for the specific release. Do not rely on historical default password documentation — verify against current SAP S/4HANA Security Guide.
- **Default Oracle EBS users**: SYSADMIN, GUEST, OPERATIONS must be locked. Verify the complete list against the Oracle E-Business Suite Security Guide for the deployed release.
- **Customisation security debt**: customer-developed ABAP reports and function modules that call sensitive APIs without `AUTHORITY-CHECK` statements bypass the entire SAP authorisation framework. Include custom code security review (static analysis with ABAP Test Cockpit / Code Inspector) in the SDLC for all custom development. Third-party SAP add-ons with their own user management introduce additional attack surface; assess as part of vendor due diligence.

---

## See Also

- `core/architecture.md` — ERP system architecture, multi-tenancy, cloud deployment models referenced in infrastructure security design
- `core/features-core.md` — core ERP functional modules whose data requires the protection controls described here
- `core/localization-tax.md` — country-specific data residency requirements that intersect with GDPR Chapter V, China PIPL, and ITAR compliance
- `verticals/healthcare-lifesciences.md` — HIPAA ePHI technical safeguards detail and healthcare ERP security architecture
- `verticals/financial-services.md` — DORA operational resilience requirements, PCI DSS cardholder data controls, and Basel III operational risk capital intersections

---

## Citations & Sources

1. NIST SP 800-53 Rev. 5 — Security and Privacy Controls for Information Systems and Organizations (NIST, 2020): https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final; NIST SP 800-162 — Guide to Attribute Based Access Control (ABAC): https://csrc.nist.gov/publications/detail/sp/800-162/final
2. PCI Security Standards Council — PCI DSS v4.0.1 (PCI SSC, June 2024): https://www.pcisecuritystandards.org/document_library/
3. NIST SP 800-63B — Digital Identity Guidelines: Authentication and Lifecycle Management (NIST, 2017, updated 2020): https://pages.nist.gov/800-63-3/sp800-63b.html
4. Sarbanes-Oxley Act of 2002 (US Public Law 107-204); PCAOB AS 2201 — An Audit of Internal Control Over Financial Reporting That Is Integrated with an Audit of Financial Statements: https://pcaobus.org/Standards/Auditing/Pages/AS2201.aspx
5. GDPR — Regulation (EU) 2016/679 (Official Journal of the European Union, 2016): https://eur-lex.europa.eu/eli/reg/2016/679
6. NIS2 Directive — Directive (EU) 2022/2555 (Official Journal of the European Union, 2022): https://eur-lex.europa.eu/eli/dir/2022/2555
7. DORA — Regulation (EU) 2022/2554 (Official Journal of the European Union, 2022): https://eur-lex.europa.eu/eli/reg/2022/2554
8. Privacy and Other Legislation Amendment Act 2024 (Cth) (Australian Parliament, November 29, 2024); OAIC — Office of the Australian Information Commissioner: https://www.oaic.gov.au
9. South Korea Personal Information Protection Act (PIPA), as amended effective September 15, 2023; PIPC — Personal Information Protection Commission: https://www.pipc.go.kr
10. Oracle Security Alerts — Critical Patch Updates and CSPUs: https://www.oracle.com/security-alerts/; Oracle blog post "Update: Monthly Critical Security Patch Updates (CSPUs) Begin May 28, 2026": https://blogs.oracle.com/security/update-monthly-critical-security-patch-updates-cspus-begin-may-28-2026
11. Onapsis Research Labs — SAP RECON (CVE-2020-6287) advisory and blog: https://onapsis.com/threat-research/recon/
12. Onapsis Research Labs — ICMAD (CVE-2022-22536, CVE-2022-22532, CVE-2022-22533) advisory: https://onapsis.com/icmad-vulnerabilities/
13. SAP Security Note 3594142 (CVE-2025-31324); ReliaQuest threat intelligence report, April 2025; Onapsis blog — Active Exploitation of CVE-2025-31324: https://onapsis.com/blog/active-exploitation-of-sap-vulnerability-cve-2025-31324/
14. Forescout Vedere Labs — Threat Analysis: SAP Vulnerability Exploited in the Wild by Chinese Threat Actor (Chaya_004): https://www.forescout.com/blog/threat-analysis-sap-vulnerability-exploited-in-the-wild-by-chinese-threat-actor/
15. SecurityBridge — CVE-2025-42957 Critical SAP S/4HANA Code Injection Vulnerability: https://securitybridge.com/blog/critical-sap-s-4hana-code-injection-vulnerability-cve-2025-42957/; Security Affairs report on active exploitation: https://securityaffairs.com/181930/hacking/critical-sap-s-4hana-flaw-cve-2025-42957-under-active-exploitation.html
16. NIST SP 800-52 Rev. 2 — Guidelines for TLS Implementations (NIST, 2019): https://csrc.nist.gov/publications/detail/sp/800-52/rev-2/final
17. ISO/IEC 27001:2022 — Information Security Management Systems (ISO, October 2022): https://www.iso.org/standard/27001; ISO/IEC 27002:2022 — Information Security Controls: https://www.iso.org/standard/75652.html; ISO/IEC 27017:2015: https://www.iso.org/standard/43757.html; ISO/IEC 27018:2019: https://www.iso.org/standard/76559.html
18. SAP Security Notes portal — SAP Patch Day: https://support.sap.com/en/my-support/knowledge-base/security-notes-news.html
19. SAP GRC Access Control documentation — SAP Help Portal: https://help.sap.com/docs/SAP_ACCESS_CONTROL
20. Pathlock SoD and CCM platform: https://pathlock.com
21. Onapsis Security Platform: https://onapsis.com/products/
22. SecurityBridge SAP Security Platform: https://securitybridge.com
23. AICPA/CIMA — SOC 2 Trust Services Criteria: https://www.aicpa-cima.com/resources/landing/system-and-organization-controls-soc-suite-of-services
24. FedRAMP — OMB M-24-15 and Marketplace: https://www.fedramp.gov
25. China PIPL — Cyberspace Administration of China: http://www.cac.gov.cn
26. Brazil LGPD — Law No. 13.709/2018; ANPD (Autoridade Nacional de Proteção de Dados): https://www.gov.br/anpd/
27. Saudi Arabia PDPL — SDAIA: https://sdaia.gov.sa
28. FIPS PUB 140-3 — Security Requirements for Cryptographic Modules (NIST, 2019): https://csrc.nist.gov/publications/detail/fips/140/3/final
29. CISA BOD 22-01 — Known Exploited Vulnerabilities catalog: https://www.cisa.gov/known-exploited-vulnerabilities-catalog
