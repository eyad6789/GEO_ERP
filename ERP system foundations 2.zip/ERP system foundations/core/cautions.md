# ERP Cautions, Pitfalls & Failure Modes

---

## 1. Scale of the Problem: Failure Rates and Attribution

### 1.1 Quantitative Context

ERP project failure statistics circulate widely but require careful attribution. The table below maps commonly cited sources to what they actually measure.

| Source | What it measures | Commonly cited finding | Confidence / Caveats |
|---|---|---|---|
| Panorama Consulting Group — Annual ERP Report (panorama-consulting.com) | Self-reported survey data from ERP practitioners; year-over-year tracking | 55–75% of projects exceed original budget or timeline; benefit realization gaps common | Moderate: self-selection bias; survey cohort varies year to year; methodology not peer-reviewed |
| Standish Group CHAOS Report | Broad IT project outcomes (not ERP-specific); resolution categories: Successful, Challenged, Failed | Large share of IT projects are "Challenged" (over budget, over time, under scope); "Failed" is a minority but significant | Low–Moderate for ERP specifically: CHAOS data covers all software projects; applying it directly to ERP overstates certainty |
| Gartner advisory notes | Analyst advisory; based on client inquiry data | A figure often cited as "70% of ERP implementations fail" and attributed to Gartner is widely recycled but is difficult to trace to a specific Gartner publication with a verifiable date — treat as a commonly repeated industry estimate, not a sourced Gartner statistic | Low: do not assert as authoritative Gartner data |
| Deloitte / KPMG / Accenture consulting whitepapers | Internal client data and industry surveys | Consistent with Panorama in describing majority of implementations as over budget or behind schedule | Low–Moderate: self-serving source; methodology rarely disclosed |

**Important attribution discipline.** "ERP project failure" conflates at least three distinct outcomes:

1. **Full abandonment** — project terminated before go-live (Lidl eLWIS 2018; MillerCoors 2016). Rare but catastrophic.
2. **Go-live with severe defects** — system launches but creates operational crises requiring expensive remediation (National Grid 2012; Revlon 2018; Birmingham City Council 2022). [1][2][3]
3. **On-time/on-budget but benefit-realization gap** — system goes live without operational crisis, but projected ROI, cost savings, or productivity gains are not achieved. This is the most common and least visible failure mode.

Engineering teams designing and building ERP systems must distinguish these because the design responses differ. A system that goes live cleanly but misses ROI targets has an adoption and configuration problem; a system that creates operational chaos has a testing, integration, or data-quality problem.

### 1.2 Pattern Without Fabricated Numbers

Across the documented survey literature, several patterns hold regardless of the precise percentage:

- **On-time, on-budget delivery remains rare.** Even best-in-class implementations typically experience scope growth after contract signature.
- **Post-implementation benefit realization gap is pervasive.** Systems go live but the ROI case — headcount reduction, inventory reduction, cycle-time improvement — is not achieved, often because shadow systems persist or because the process redesign work did not happen.
- **Most cited budget overruns are underestimates of the underestimate.** The initial budget is often constructed before full scoping; the overrun is measured against an already-optimistic baseline.

---

## 2. Canonical Real-World Failure Cases

### 2.1 Hershey Foods 1999 — The Big-Bang Go-Live Trap

Hershey undertook simultaneous implementation of SAP R/3 (financials and logistics), Siebel CRM, and Manugistics SCM — three enterprise systems from three vendors — at a combined software investment of approximately $112 million. [4] The recommended timeline was approximately 48 months; it was compressed to roughly 30 months to achieve cutover before Y2K remediation windows closed. Go-live was July 1999, which coincided with the peak Halloween and holiday order fulfillment season.

The result: approximately $100 million in candy orders could not be shipped due to system failures. [4] Hershey reported a 19% decline in Q3 quarterly profit; the stock fell more than 8% on the day the problems were disclosed. [4] The root causes are now textbook:

- **Big-bang scope**: maximum surface area of failure at go-live
- **Timeline compression**: insufficient time for testing, training, and data validation
- **Wrong timing**: go-live at peak business load, when the system had zero tolerance budget for defects
- **Multi-vendor integration**: three systems from three vendors, each requiring interface testing, all untested in combination under load

### 2.2 Nike 2000–2001 — Demand Planning Software Integration Failure

Nike's case is frequently cited as an ERP failure but requires precision: the failing component was i2 Technologies' demand planning system, not an ERP core. i2 was being integrated with Nike's legacy systems as part of a broader supply-chain technology program (total investment approximately $400 million), making it an ERP-ecosystem integration failure rather than an ERP core system failure. [5]

The system went live in June 2000. i2 had warned Nike to limit customization to 10–15% of the standard configuration; Nike did not comply, modifying the software to accommodate its own data structures. [5] Two root causes compounded: (1) a data format and business-rule mismatch between the i2 demand planner and Nike's legacy systems caused orders not to translate cleanly between systems; (2) i2's demand planner had a bug that caused order data to be deleted approximately 6–8 weeks after entry, creating a planning blindness window. The combined effect: excess inventory of unpopular product lines and stockouts of high-demand lines including Air Jordan.

Nike disclosed the problem on February 27, 2001. The company reported approximately $100 million in lost sales in Q3 fiscal 2001; the stock dropped approximately 20%. [5] The i2 demand planner was replaced by SAP modules for short- and medium-range planning in spring 2001.

**Engineering lesson:** System-of-record ambiguity, undocumented data deletion schedules between integrated systems, and customization beyond vendor-tested bounds are individually dangerous; in combination they are lethal.

### 2.3 Waste Management vs. SAP 2008–2010

Waste Management filed suit against SAP in March 2008, alleging that SAP misrepresented the capabilities of its ERP products during the sales process — including the use of a "fake" software demonstration — and that the delivered system could not perform as demonstrated. Waste Management sought over $1 billion in damages, including more than $100 million spent on the project itself and over $350 million in unrealized benefits. [6] The case settled in 2010 with SAP making a cash payment of $80 million to Waste Management. [6] SAP subsequently filed suit against its insurer Swiss Re International, seeking its share of the $80 million settlement; that secondary suit's outcome is not confirmed in publicly available sources.

The pattern — vendor demo-to-delivery gap and over-customization of a system that could not meet business requirements — is the central engineering lesson, independent of the legal outcome.

### 2.4 Marin County vs. Deloitte/SAP 2006–2013

The County of Marin, California engaged Deloitte as system integrator for an SAP implementation beginning in 2005. Release 1 went live in July 2006 and immediately produced cash reconciliation failures. Release 2 was pushed live in January 2007 despite Release 1 being unresolved. Marin County alleged that Deloitte staff lacked basic SAP product competency and that Deloitte concealed problems due to conflicts of interest. The county filed suit seeking $35 million and alleging RICO (Racketeer Influenced and Corrupt Organizations Act) violations, which would have trebled damages; a judge dismissed the racketeering claims. The case settled in January 2013: Deloitte paid Marin County $3.9 million, reimbursed from Deloitte's fees; all claims against SAP were dismissed. [7]

**Engineering lesson:** SI capability assessment is not a procurement formality. A technically sound ERP product deployed by an incompetent integrator fails as completely as a defective product. Reference checks on integrator staff credentials and prior implementations in the same product/version are essential, not optional.

### 2.5 National Grid SAP 2012 — Go-Live Into a Hurricane

National Grid's US operations undertook SAP consolidation beginning in mid-2009 with Deloitte as original SI and an approved budget of $290 million (approved by the utility rate commission). [8] In 2010, Deloitte's role was superseded by a consortium in which Wipro took on system integration responsibilities and EY provided project oversight — a change motivated by cost reduction. By the time of go-live, the final sanctioned project estimate had risen to approximately $383 million. [8]

The target go-live date migrated from December 2011 to July 2012, then October 2012, then November 5, 2012. Hurricane Sandy made landfall on October 29, 2012. National Grid's US operations were in active emergency response mode — exactly the scenario that had not been included in testing. Rather than delay (which would have cost an estimated additional $50 million), management proceeded with the November 5 go-live. [8]

The consequences:

- Financial books-close time: 4 days pre-go-live → 43 days post-go-live [8]
- 15,000+ vendor invoices rendered unprocessable
- Payroll errors affecting thousands of employees; approximately $8 million in overpayments; approximately $12 million in settlement for employees who were short-paid [8]
- National Grid's own internal estimates put total project and remediation spend above $1 billion against the original $290 million budget [8]
- In December 2017, National Grid filed suit against Wipro for $140 million; in August 2018, the case settled for $75 million [8]

An audit noted that Wipro had "virtually no experience" implementing SAP in the US. [8] The proximate amplifier of the damage was "happy-path testing" — test scripts covered normal business operations only. Emergency-response operating modes, disaster scenarios, and high-concurrency edge cases were never simulated; the system performed exactly as tested.

### 2.6 MillerCoors vs. HCL/SAP ~2014–2017

MillerCoors contracted HCL Technologies for SAP implementation at approximately $53 million, with a subsequent change order of approximately $9 million. At the first phase go-live, more than 50 known defects existed in the system. After go-live, thousands of additional defects were discovered. The project was scrapped in June 2016. In March 2017, MillerCoors filed a $100 million lawsuit against HCL, alleging inadequate staffing, failure to follow HCL's own stated methodology, and inadequate QA processes. [9] HCL filed a countersuit in June 2017, alleging MillerCoors management did not understand its own business requirements and used "bullying" tactics. [9] The case eventually settled in an Illinois federal court; terms were not publicly disclosed and no settlement payment amount should be inferred.

### 2.7 Lidl eLWIS SAP Abandonment 2018

Lidl's internal project, nicknamed eLWIS (Elektronisches Lidl Warenwirtschafts- und Informations-System — Electronic Lidl Merchandise Management and Information System), ran for approximately seven years. Originally estimated at approximately €201 million, costs had ballooned to approximately €500 million by 2018. [10] SAP recognized Lidl as a top customer in April 2017 — one year before the project was terminated.

The fundamental incompatibility was architectural: Lidl's stock management system recorded inventory at **purchase prices** (cost-based valuation). SAP's standard retail functionality manages inventory at **retail prices** (selling-price-based valuation). These are not equivalent data models; they drive different accounting, margin calculations, and replenishment logic. Adapting SAP to Lidl's purchase-price model required massive, continuous customization involving hundreds of consultants working over years. The customization compounded itself: each SAP release required re-implementation of the custom logic.

CEO Jesper Højer terminated the project in July 2018. [10] This is the canonical case of the **customization trap** applied at scale: a fundamental business process incompatibility that was not surfaced in fit-gap analysis was papered over with custom code for seven years until the cost became indefensible.

### 2.8 Revlon SAP S/4HANA 2018

Revlon's acquisition of Elizabeth Arden created a dual-ERP landscape: Revlon on Microsoft Dynamics AX, Elizabeth Arden on Oracle Fusion Cloud ERP. The decision was made to consolidate onto SAP S/4HANA, beginning with Revlon's North Carolina manufacturing facility. Go-live was February 2018.

The immediate impact: approximately $64 million in net sales could not be shipped to major US retail customers due to service-level disruptions affecting production and distribution capabilities. [11] Incremental remediation charges totaled approximately $53.6 million. Q4 2018 net loss was $70.3 million. [11] The 2018 annual report was delayed due to a material weakness finding in internal controls. The stock fell approximately 6.9% on the day of disclosure; shareholder class-action lawsuits alleged Revlon had failed to disclose the implementation risk adequately. [11] CFO Victoria Dolan resigned in March 2019.

### 2.9 Birmingham City Council Oracle Fusion Cloud 2022

Birmingham City Council — Europe's largest local authority by population — migrated from SAP (in service since 1997) to Oracle Fusion Cloud ERP, targeting go-live in December 2020, then April 2022. The system went live in April 2022. The original project estimate was approximately £19 million. [12]

Costs escalated: £38 million, then in June 2023 an additional £46.5 million remediation budget was approved. An August 2024 Audit Reform Lab report put the total financial impact at approximately £216.5 million by 2026 — a figure that combines direct program costs with approximately £69 million of anticipated 2023/24 savings written off as undeliverable, rather than representing direct program spend alone. [12] Subsequent reporting (The Register, January 2026) placed the direct program cost figure lower, at approximately £144.4 million forecast to financial year 2027/28. [13] The two figures are measuring different things — total financial impact versus direct program cost — but both confirm a tenfold-plus overrun from the original estimate.

In September 2023, Birmingham City Council issued a Section 114 notice under the Local Government Finance Act 1988 — the statutory mechanism by which UK local authorities declare effective insolvency, prohibiting new expenditure except for statutory obligations. The Oracle project was a significant contributing factor alongside a separate equal pay liability crisis. [12]

Technical consequences:

- Audit trail for fraud detection not activated for more than 18 months post-go-live, leaving the council unable to determine if financial fraud had occurred [12][13]
- Approximately £2 billion in transactions posted to the wrong fiscal year [12]
- Inability to file auditable accounts

This case illustrates the public-sector-specific amplification of ERP failure: statutory insolvency mechanisms, unauditable accounts, and public accountability obligations that private-sector failures do not trigger.

---

## 2.10 Failure Case Summary Table

| Case | Year | Systems | Vendor/SI | Loss / Cost | Primary failure mode |
|---|---|---|---|---|---|
| Hershey Foods | 1999 | SAP R/3 + Siebel CRM + Manugistics SCM | SAP, Siebel, Manugistics | ~$100M orders unshipped; 19% quarterly profit drop; 8%+ stock fall | Big-bang go-live at peak season; timeline compression |
| Nike | 2000–2001 | i2 Technologies demand planner | i2 Technologies | ~$100M lost sales Q3 2001 | Data integration failure; over-customization; silent data deletion bug |
| Waste Management | 2008–2010 | SAP ERP | SAP | $80M settlement | Demo fraud alleged; system could not meet stated requirements |
| Marin County | 2006–2013 | SAP | Deloitte | $3.9M settlement to county | Incompetent SI; concurrent release failures |
| National Grid US | 2012–2018 | SAP | Deloitte → Wipro + EY | >$1B total spend vs. $290M budget; $75M settlement | Happy-path testing only; go-live during Hurricane Sandy |
| MillerCoors | 2014–2017 | SAP | HCL Technologies | ~$100M suit (settlement undisclosed) | Defect-laden go-live; inadequate QA |
| Lidl eLWIS | 2011–2018 | SAP (retail) | SAP + large consulting teams | ~€500M (~$580M) written off | Fundamental data-model incompatibility; customization trap |
| Revlon | 2018 | SAP S/4HANA | SAP | $64M lost sales; $53.6M remediation; $70.3M Q4 net loss | Go-live without operational readiness |
| Birmingham City Council | 2022–ongoing | Oracle Fusion Cloud ERP | Oracle | £144–216M total vs. £19M estimate | Testing failure; audit controls disabled; fiscal year posting error |

---

## 3. Top Reasons ERP Projects Fail

### 3.1 Scope Creep

ERP scope expands continuously as each department discovers that its edge cases were not included in the original fit-gap analysis. A finance department adds multi-currency revaluation requirements not in scope; a logistics team adds carrier-specific EDI format requirements; a manufacturing site adds shop floor scheduling not in the original blueprint. Each addition is individually reasonable; collectively they extend timeline, consume budget, and increase testing surface area.

Prevention mechanisms:

- **Scope freeze gate**: formal milestone after which scope additions require a change control board (CCB) decision with explicit cost and schedule impact assessment
- **Fit-gap analysis locked pre-contract**: documented before SI contract execution, not after
- **Configuration-not-customization rule**: any scope item that cannot be met by standard configuration is a mandatory CCB item, not a silent addition to development backlog

See `core/implementation.md` for phased scope management approach.

### 3.2 The Customization Trap and Upgrade-Path Destruction

Custom code written against ERP internals — SAP ABAP user exits and enhancements, Oracle PL/SQL database triggers, Dynamics 365 Finance & SCM X++ modifications to standard objects — creates technical debt that compounds on every major version upgrade.

**SAP Clean Core Principle (S/4HANA era):** SAP's architectural guidance since S/4HANA is that modifications to SAP-delivered repository objects are prohibited in the ABAP Cloud development model. Extensions must use approved extension points via SAP BTP (Business Technology Platform), following the side-by-side extension pattern, or use released APIs. The ABAP Cloud development model enforces this restriction at the language level, blocking access to SAP-internal APIs. This represents a hard break from SAP ECC customization practice.

**Oracle Fusion Cloud approach:** Oracle Fusion Cloud ERP recommends zero customization to core delivered objects. Extensions use Oracle Integration Cloud (OIC) for integrations and process extensions, and Oracle APEX for low-code UI extensions. Oracle enforces this via cloud delivery: core code is not customer-accessible.

**SAP ECC maintenance timeline:**

| ECC version | Mainstream maintenance end | Extended maintenance | Notes |
|---|---|---|---|
| SAP ECC 6.0 EHP 0–5 | December 31, 2025 | None offered | No path to extended maintenance; transition to Customer Specific Maintenance only |
| SAP ECC 6.0 EHP 6–8 / SAP Business Suite 7 | December 31, 2027 | Available to December 31, 2030 at ~9%+ additional license surcharge | Only for EHP 6–8 customers; not available for EHP 0–5 |

Organizations that have heavily customized SAP ECC face years of custom-code remediation — re-implementation of each modification against ABAP Cloud-compliant extension patterns — before they can reach S/4HANA. The Lidl case is an extreme example; many organizations carry customization debt at smaller scale that still runs to millions of euros in upgrade remediation. [10]

| Customization tier | Upgrade impact | Recommended pattern |
|---|---|---|
| Standard configuration (IMG settings, org structure, master data) | None — survives all upgrades | Always preferred |
| Approved extension points (BAdIs, enhancement spots, released APIs) | Low — SAP maintains backward compatibility for released APIs | Use for all business-logic extensions |
| Side-by-side extension on SAP BTP | None to core — extension is decoupled | Use for complex business logic, UI extensions, integrations |
| ABAP modification of SAP-delivered objects (pre-ABAP Cloud) | High — must be re-applied to each patch/upgrade; regression-tested per release | Legacy pattern only; not permitted in ABAP Cloud |
| Core data model changes (custom fields via ABAP Dictionary, non-BTP) | Very high — upgrade may overwrite; S/4HANA migration requires remediation | Avoid; use Extension Fields via SAP Fiori extensibility |

### 3.3 Data Quality Underestimation

A widely observed implementation-community pattern (not formally attributed to a single study) is that data migration appears as approximately 20% of effort in project estimates and consumes 40–60% of actual effort. The migration work exposes data quality problems that were invisible while data lived in legacy systems.

Critical data quality failure patterns:

- **Duplicate vendor masters** causing double-payment on AP after go-live
- **Item master unit-of-measure (UoM) mismatches** — a component measured in "each" in legacy mapped to "box" in ERP causing 12x over-ordering or 1/12x under-ordering
- **GL account mapping errors** producing incorrect financial statements (Birmingham City Council: approximately £2 billion posted to wrong fiscal year [12])
- **Customer master address/tax classification errors** producing incorrect sales tax calculation post-go-live
- **Open-item reconciliation failures** — open purchase orders, open sales orders, open AP/AR items imported without matching to correct counterparty records

Pre-migration data profiling is not optional:

- Row count and null rate by field for every migrated entity
- Duplicate key analysis (vendor number, material number, customer number)
- Referential integrity checks across related entities
- Financial reconciliation: sum of all open-item balances must match GL control account balance
- Spot-check audit sample: random N records compared field-by-field between legacy and ERP staging

See `core/implementation.md` for migration phase detail.

### 3.4 Change-Management Failure

Technical go-live is not organizational go-live. A system that functions correctly but is not adopted by users has failed in every business outcome metric.

**Shadow system escalation path:**

1. ERP goes live; users cannot produce a required report in the required format
2. Team creates an Excel extract and formats it manually — initially as a temporary workaround
3. Excel becomes the team's authoritative view of data; ERP is updated reluctantly or sporadically
4. A second team's report is built on the first team's Excel (second-order shadow system)
5. ERP data becomes stale; reports from ERP and from the Excel shadow diverge
6. Management decisions are made on shadow-system data that is not subject to ERP controls, audit trails, or period-close disciplines

Key indicators of OCM (Organizational Change Management) failure at 90 days post-go-live:

- System adoption rate (transactions-per-user per day) significantly below baseline target
- Help desk volume remains high and is not declining week-over-week
- Manual workarounds being formally documented and approved rather than eliminated
- Report requests being fulfilled outside ERP (BI tool, spreadsheet) for data that should come from ERP

The Prosci ADKAR model (Awareness, Desire, Knowledge, Ability, Reinforcement) is widely used in ERP OCM programs as a structured framework for identifying which stage of adoption resistance is occurring for which user population. It is not a guarantee; it is a diagnostic framework.

Audit risk: decisions made on unaudited shadow-system data create SOX Section 404 internal control exposure and internal audit findings. When the ERP is the system of record for financial reporting and a shadow spreadsheet is the system of decision, the audit trail is broken.

See `core/implementation.md` for OCM program design.

### 3.5 Going Live Too Fast and Hypercare Shortfalls

**Hypercare** is the period immediately post-go-live during which the implementation team provides elevated support — typically 30 to 90 days. Compressed timelines reduce the pre-go-live testing budget, increase defect density at go-live, and simultaneously create pressure to reduce hypercare duration to free up consultant billing.

Testing debt patterns:

- **Happy-path testing only** (National Grid 2012 [8]): test scripts cover normal business operations and nothing else. Exception paths, emergency operating modes, period-end batch jobs under full load, and concurrent-user spikes are not tested.
- **UAT script compliance vs. real scenario coverage**: users sign off on pre-written test scripts that do not reflect their actual day-to-day edge cases; the sign-off is treated as business acceptance.
- **Performance testing skipped or deferred**: period-end batch jobs (depreciation runs, inventory valuation, MRP/DRP explosion, aged-receivables calculation) are not run under production data volumes. Degradation discovered after go-live when it cannot be deferred.
- **Integration end-to-end testing** between ERP and legacy retained systems omitted: only tested in isolation.

Timeline compression case: Hershey's 48-month recommended timeline was compressed to approximately 30 months. [4] The missing 18 months represented testing, data validation, training, and change management work — not padding.

### 3.6 Integration Complexity

Legacy systems are rarely retired at ERP go-live. A typical large enterprise ERP cutover retires 20–30% of legacy systems in the first year and maintains interfaces to the remaining 70–80% for months or years. Each interface is a failure surface.

Interface failure patterns:

- **Flat-file drops replaced by API calls without fallback**: a legacy EDI flat-file process replaced by REST API integration; when the API endpoint is unavailable, there is no queue, no retry, and no alert — transactions are silently lost
- **Character-encoding mismatches**: legacy system uses Latin-1 encoding; ERP uses UTF-8; special characters in supplier names, addresses, or item descriptions are corrupted or truncated
- **Timezone and calendar misalignments**: a fiscal calendar in legacy (4-4-5 weeks) does not map cleanly to ERP calendar periods; date-shifted postings appear in wrong periods
- **Batch latency creating stale master data**: customer master updates propagated to ERP via nightly batch; orders placed during the day use stale pricing or credit limits
- **Bidirectional sync without system-of-record designation**: two systems each believe they are authoritative for a shared data entity; updates in both systems produce data divergence that is not detected until reconciliation

The most dangerous integration failure mode is the one that fails silently. A failed interface that produces an error and stops is recoverable; an interface that continues processing with corrupted or missing data is discovered weeks later during reconciliation, by which point the blast radius is large.

See `core/architecture.md` for integration architecture patterns including circuit-breaker and system-of-record designation.

### 3.7 Vendor Lock-In and Licensing Traps

**SAP Indirect / Digital Access.** Third-party systems that read from or write to SAP data create licensing exposure under SAP's access model. In February 2017, the UK High Court ruled in favor of SAP against Diageo Great Britain Limited (SAP UK Limited v Diageo Great Britain Limited [2017]), establishing that third-party systems accessing SAP data via SAP interfaces require licensing; SAP had claimed approximately £55 million in underpaid license fees. [14] This ruling, combined with a separately filed SAP arbitration against AB InBev (SAP America Inc. v. Anheuser-Busch Companies LLC, filed February 2017 in AAA arbitration, settled June 2017 with undisclosed terms — SAP's claimed exposure had been approximately $600 million but the actual settlement amount was not publicly disclosed), [15] motivated SAP to formalize the **Digital Access** licensing model in 2018, introducing document-based pricing: each digital document created in SAP (sales order, purchase order, goods receipt, production order, etc.) by a non-SAP system interface counts against a document license pool.

SAP launched the **DAAP (Digital Access Adoption Program)** in May 2019, offering two transition options: (Option A) license 115% of current indirect document volume but pay only for the 15% growth portion (~85% effective discount); or (Option B) license 100% of current volume at a 90% discount. [16] SAP extended DAAP through December 31, 2022; its current status must be verified against sap.com licensing documentation.

**Oracle License Management Services (LMS).** Oracle's LMS audit program is aggressive and well-documented. Virtualization technologies (VMware, Hyper-V) and cloud deployments on non-Oracle Cloud infrastructure create complex license counting scenarios. Oracle's position on virtualization has historically been restrictive: in many VMware configurations, Oracle counts all physical cores in the cluster as licensed regardless of actual VM placement. AWS and Azure deployments have specific Oracle license terms that differ from on-premises.

**SaaS contract terms for data portability.** Negotiating data export rights before signing a SaaS ERP contract is essential. Key terms:

- Data export format (open formats vs. proprietary; complete relational export vs. flat-file summary)
- API rate limits for bulk data extraction (can make migration take months at low rate limits)
- Data retention post-termination (some vendors delete data within 30–90 days of contract end)
- Audit log and transaction history export (not always included in standard export)

**Migration cost as de facto lock-in.** Even with contractually clean data portability, the cost of ERP migration — data migration, integration rebuild, retraining, parallel-run operations, regression testing — creates switching costs that function as lock-in regardless of contract terms. Organizations that recognize this dynamic only at contract renewal are at a severe negotiating disadvantage.

### 3.8 Hidden Costs

| Cost category | Typical pattern | Notes |
|---|---|---|
| Implementation partner / SI fees | Commonly cited as 2–5× the software license cost (widely cited by Gartner and implementation firms as an industry estimate, not a precisely sourced statistic) | Varies by scope, geography, and SI tier; increases with customization volume |
| Training and adoption | Consistently underbudgeted; actual costs include backfill for staff in training, LMS, and training environment infrastructure | Training is the first budget cut when projects are over budget, which amplifies adoption failure |
| Custom development and bolt-ons | Open-ended; tracked during project but underestimated; ongoing maintenance cost often not budgeted | Custom code requires maintenance through every upgrade |
| Integration middleware | MuleSoft, Dell Boomi, SAP Integration Suite, Azure Integration Services; annual license plus implementation and maintenance | Often added mid-project when point-to-point integration complexity becomes unmanageable |
| Ongoing support / AMS | Application Managed Services; typically 15–20% of implementation cost annually | Often underestimated in Year 1 due to hypercare coverage; cost becomes visible in Year 2 |
| Annual license true-up / software audit exposure | SAP, Oracle, Microsoft audit programs; indirect/digital access exposure; user count growth | Can exceed annual software budget; often treated as a Year 3+ surprise |
| Infrastructure (on-premises or private cloud) | Hardware refresh, storage growth (especially LOB attachment storage), backup, DR | Storage growth from document attachments in ERP is frequently underestimated |
| Change management / OCM consulting | Often a separate workstream with dedicated OCM firm or consulting team | Cut when over budget; amplifies adoption failure risk |
| Data migration and cleansing | Expands from estimated 20% to actual 40–60% of effort in many implementations | Requires dedicated data team plus business SME time for validation |
| Hypercare extended support | Hypercare extensions past 90 days are billed at high consulting rates | Budget for 90 days minimum; 180 for large, complex go-lives |

---

## 4. Domain-Specific Traps

### 4.1 SMB Traps

Small and mid-size businesses face a specific failure mode: purchasing ERP capability far beyond their organizational capacity to implement and operate it. SAP S/4HANA and Oracle Fusion Cloud ERP are enterprise-grade products with correspondingly complex implementation requirements, support demands, and annual licensing costs. An SMB with 50 employees, a 3-person IT team, and no dedicated ERP administrator buying into SAP S/4HANA is almost certain to fail — not because the product is defective but because the organizational infrastructure to operate it does not exist.

Appropriate mid-market alternatives by segment:

| Segment | Products |
|---|---|
| General mid-market | Oracle NetSuite (SuiteBilling, SuiteTax, SuiteCommerce); Acumatica |
| Manufacturing-focused | Epicor Kinetic (formerly Epicor ERP) |
| Financial management focus | Sage Intacct |
| SMB open-source | Odoo; ERPNext |
| Industry-specific mid-market | Infor CloudSuite (vertical-specific); Infor LN (manufacturing); Infor M3 (distribution/fashion) |
| Multi-subsidiary SMB/mid-market | NetSuite OneWorld (consumption-based Acumatica is favorable for seasonal transaction spikes) |

Specific SMB risk patterns:

- **Wrong vendor tier**: tier-1 enterprise product selected but implemented by a tier-3 local SI partner with two certified consultants; neither the product nor the SI is sized for the engagement
- **No dedicated internal project ownership**: no full-time internal project manager; no business process owners assigned to each module area; ERP is treated as an IT project rather than a business transformation
- **Pre-configured template overconfidence**: vendor-provided industry templates still require significant configuration work, master data loading, and user training; "pre-configured" does not mean "ready to use"

### 4.2 Government and Public Sector Traps

Public sector ERP implementations encounter failure modes that do not exist in private-sector projects:

- **Political change mid-project**: election cycles can replace the administration that approved the ERP project; a new administration may have different priorities, a different preferred vendor, or may use the project as a cost-cutting target
- **Procurement timeline extension**: public tender requirements — mandatory waiting periods, challenge periods, Freedom of Information (FOI) obligations — routinely extend the pre-implementation phase by 12–24 months beyond private-sector timelines; scope and technology landscape change during this period
- **Mid-project compliance change**: legislative or regulatory changes during implementation force scope additions that were not in the approved business case
- **Fixed-price contract misalignment**: public procurement typically favors fixed-price contracts; ERP complexity makes fixed-price adversarial because the SI's risk response is to minimize scope, challenge every change, and reduce quality in execution
- **Audit and accountability amplification**: public-sector failures are subject to FOI requests, parliamentary/legislative scrutiny, and public audit bodies; failures that would be managed quietly in private sector become public record

Birmingham City Council is the defining current exemplar: a migration from SAP to Oracle Fusion Cloud ERP; an original estimate of approximately £19 million escalating to a projected £144–216 million; a Section 114 notice under the Local Government Finance Act 1988; fraud detection controls disabled for over 18 months post-go-live; and approximately £2 billion posted to the wrong fiscal year. [12][13]

See `verticals/government-publicsector.md` for public sector ERP design detail.

### 4.3 Cloud ERP Cautions

SaaS ERP delivery introduces failure modes that on-premises or private-cloud deployments do not have:

**Forced upgrade schedules.** SAP S/4HANA Cloud Public Edition pushes quarterly or semi-annual releases; customers cannot defer or opt out. Workday Financial Management and Workday HCM release twice annually. Oracle Fusion Cloud ERP releases quarterly. The customer's obligation is to regression-test all customizations, extensions, and integrations against each new release on the vendor's timeline — typically with 4–8 weeks of preview access before production. Organizations with large integration estates face significant ongoing regression testing costs that are not included in license fees.

**Integration breakage on forced upgrades.** External systems integrated via API face deprecation risk: vendors deprecate API versions on their own timeline; customers learn of deprecation through release notes and must adapt integrations before the deprecation date. Missing a deprecation date causes production integration failures.

**Shared-infrastructure risk.** Multi-tenant SaaS architecture means performance during other tenants' peak loads is a theoretical risk; major vendors implement tenant isolation to mitigate this, but performance guarantees in SaaS SLAs typically define uptime (availability), not transaction throughput or response time under load. SLA uptime numbers (e.g., 99.9%) do not cover performance degradation that falls short of complete outage.

**SaaS contract terms requiring review:**

| Term | Risk if not negotiated |
|---|---|
| Data ownership clause | Ambiguity over who owns transaction data and master data in the vendor's system |
| Audit rights | Customer may not have a contractual right to audit its own data and access logs |
| SLA definition | "Outage" vs. degraded performance definitions; what credits apply and how they are calculated |
| Data deletion post-termination | Standard terms may delete customer data 30–90 days after contract end |
| Data export format and completeness | Exported data may not include audit history, system logs, or attachments |

**Egress and migration cost.** Extracting data from a SaaS ERP at end of contract is not always free, fast, or complete. API rate limits on bulk data extraction can limit throughput to tens of thousands of records per day; a large ERP with tens of millions of transaction records may take months to extract at standard API rate limits. Negotiating enhanced extraction rights — bulk export, higher rate limits, extended post-termination access window — before contract signature is significantly easier than after.

### 4.4 Performance at Scale

ERP performance degrades predictably as transaction volume grows; engineering for growth requires anticipating the failure modes:

- **Period-end batch degradation**: financial close (GL balance calculation, foreign currency revaluation, intercompany elimination), MRP/DRP material requirements explosion, AP/AR aging calculation, and fixed-asset depreciation runs all compete for compute resources. At small data volumes these run in minutes; at large enterprise scale they can run for hours and block other operations.
- **SAP HANA in-memory architecture** substantially reduces period-end batch times compared to traditional disk-based RDBMS for standard SAP-delivered reports and batch programs. However, custom-written reports using non-optimized SQL, full table scans, or non-CDS (Core Data Services) views can still cause significant performance issues and lock contention even on HANA. The architecture does not compensate for poor query design.
- **Batch job scheduling conflicts**: concurrent depreciation, inventory valuation, AP/AR aging, and GR/IR clearing jobs during period-end create resource contention. Batch job scheduling is an operational engineering problem that requires planning as transaction volumes grow.
- **Database growth from LOB (large object) attachments**: PDFs, scanned documents, and binary attachments stored directly in the ERP database can dominate storage. A purchase order with a scanned invoice attachment adds kilobytes to megabytes per transaction; at millions of transactions per year, this is significant. Architecture decision: store attachments in a content management system (SAP Document Management, SharePoint, S3) with ERP storing only the reference.
- **Query plan regression**: as statistics on large tables drift over time, query optimizer plans can regress; execution plans should be monitored and pinned where critical performance is required.

---

## 5. Post-Go-Live Failure Modes

### 5.1 Shadow Systems and Parallel Usage

Shadow systems are the most common long-term outcome of ERP adoption failure. They develop when the ERP cannot produce a required report in the required format, when ERP data latency is too high for operational decisions, or when user training was insufficient and the path of least resistance is a spreadsheet.

Escalation path:

1. **Excel extract** — user exports ERP data to Excel for formatting/analysis; initially ad hoc
2. **Maintained spreadsheet** — team maintains a running spreadsheet updated manually; becomes the team's source of truth
3. **Access database / SharePoint list** — spreadsheet becomes unmanageable; migrated to local database or SharePoint; other teams begin consuming it
4. **Unauthorized BI tool against production database** — power user discovers they can connect Power BI or Tableau directly to the ERP database; builds dashboards that bypass ERP reporting controls
5. **Parallel authoritative system** — the shadow system is now used for business decisions; ERP data is treated as a backup or as the input to the shadow system, not as the authoritative record

Audit and control consequences:

- SOX Section 404 internal control findings if financial decisions are made on unaudited shadow data
- Reconciliation burden: when ERP and shadow diverge, resolving which is correct requires reconstructing the history
- Personnel dependency: shadow systems are typically owned by one person; when they leave, the shadow system becomes unmaintainable

Remediation approach: ERP reporting gap analysis — identify each shadow system, document the business requirement it serves, determine whether the ERP can meet it natively or via embedded analytics (SAP Analytics Cloud, Oracle Analytics for Fusion, Power BI connector against ERP data via certified integration). Invest in closing reporting gaps rather than tolerating shadow proliferation.

### 5.2 Post-Go-Live Abandonment

**Partial abandonment** is more common than full abandonment and harder to detect. A module goes live; certain high-complexity features are disabled with the stated intention of enabling them "in the next phase." The next phase never comes. The disabled features represent undelivered ROI from the business case — the justification for the investment — that is quietly forgotten.

**Full abandonment** (Lidl eLWIS after 7 years and approximately €500 million [10]; MillerCoors after go-live defects became unmanageable [9]) follows a recognizable pattern:

1. Accumulated defects reach a volume where prioritization becomes impossible
2. Remediation cost estimate exceeds the perceived value of completing
3. Decision-makers who championed the project resist reassessment (escalation of commitment; sunk-cost reasoning)
4. An external trigger — new leadership, an operational crisis, an audit finding — forces explicit reassessment
5. Abandonment is announced; the organization begins another ERP selection cycle

The sunk-cost dynamic is the most dangerous because it delays the reassessment conversation. Engineering teams building these systems should build structured go/no-go reassessment gates into the project governance framework; a project that cannot pass a gate should surface the abandonment decision explicitly rather than allowing drift until the costs become impossible to ignore.

---

## 6. Implementation Anti-Patterns Summary

| Anti-pattern | Description | Real-world example | Mitigation |
|---|---|---|---|
| Big-bang go-live | All modules, all sites, all users on one date | Hershey 1999 (SAP R/3 + Siebel + Manugistics simultaneous) | Phased or pilot rollout; module-by-module or site-by-site |
| Wrong timing | Go-live during peak business load or crisis | Hershey 1999 (Halloween order peak); National Grid 2012 (Hurricane Sandy) | Enforce go-live blackout periods; align cutover to business trough |
| Compressed timeline | Schedule accelerated to meet external deadline | Hershey 1999 (48 months → ~30 months) | Buffer schedules; treat timeline compression as scope reduction requiring explicit trade-off |
| Happy-path testing only | Test scripts cover normal operations; no exception, emergency, or load scenarios | National Grid 2012 | Stress testing; exception scenario library; disaster/emergency mode test plan |
| Customization overrun | Core system modified to match legacy process rather than adapting process to system | Lidl eLWIS (purchase-price vs. retail-price data model) | Fit-gap analysis pre-contract; clean core; process change required |
| SI capability gap | Integrator lacks proven competency in the specific product/version | Marin County (Deloitte staff alleged to lack basic SAP competency); National Grid (Wipro's "virtually no experience" with SAP in the US) | Reference checks; require CVs and prior implementations for named staff; right-to-audit SI quality |
| Data migration underestimation | Dirty legacy data migrated without profiling or cleansing | Birmingham City Council (£2B to wrong fiscal year) | Pre-migration data profiling and cleansing as separate workstream |
| Scope freeze failure | Scope expands continuously after project start | Universal ERP pattern | CCB with mandatory cost/schedule impact; fit-gap locked pre-contract |
| OCM neglect | No formal user adoption program; training treated as a one-day event | Universal ERP pattern | Dedicated OCM stream; Prosci ADKAR framework; adoption metrics at 30/60/90 days |
| Shadow system acceptance | Management tolerates Excel parallel tracking post-go-live | Universal post-go-live pattern | Reporting gap analysis; embedded analytics investment; shadow system retirement roadmap |
| Wrong vendor tier | Enterprise product for SMB or vice versa | Generic SMB trap | Vendor selection based on organizational capacity, not feature checklist |
| SI changed mid-project | Integrator replaced mid-implementation to cut cost | National Grid (Deloitte → EY/Wipro 2010) | Evaluate SI transition cost and knowledge loss risk before replacing; knowledge transfer gate if unavoidable |

---

## 7. Engineering Design Responses

### 7.1 Designing for Upgradability

- **Separate configuration from customization in repository structure.** Configuration (IMG settings, number ranges, output types, pricing procedures) survives upgrades. Custom code does not upgrade automatically.
- **Use approved extension frameworks exclusively.** SAP: SAP BTP / ABAP Cloud released APIs and extension points. Oracle Fusion Cloud ERP: OIC and Oracle APEX. Microsoft Dynamics 365 Finance & Supply Chain Management: Power Platform (Power Apps, Power Automate). Workday Financial Management: Workday Extend.
- **Maintain a customization register.** Every deviation from standard — configuration decision, RICEFW object, interface, output form, workflow — documented with business justification, functional owner, technical owner, and test case reference. The register is the input to upgrade impact assessment.
- **Regression test suite as living artifact.** A test suite covering all custom objects, executed against each vendor release in a sandbox environment before production upgrade. Without this, forced upgrades in SaaS ERP are regressions waiting to be discovered in production.

### 7.2 Designing for Data Quality

**Pre-migration:**

- Data profiling: row count, null rate, duplicate key analysis, referential integrity checks for every entity in migration scope
- Data cleansing workstream with business SME ownership (not IT ownership — IT cannot determine which of two duplicate vendor records is authoritative)
- Cleansed data locked and frozen before migration; changes to source system after freeze are tracked and applied separately

**Migration validation:**

- Record count reconciliation: source count = staging count = target count per entity
- Financial total reconciliation: sum of open AP items, open AR items, GL balances must match
- Spot-check audit: random sample compared field-by-field between source and target

**Ongoing master data governance:**

- Duplicate detection rules on vendor master, customer master, material master
- MDM layer for large enterprises: SAP Master Data Governance (MDG), Oracle MDM, Stibo STEP
- Workflow-enforced creation/change process: no direct table edits to master data in production

### 7.3 Designing for Graceful Failure at Integration Points

Every ERP integration interface is a potential failure point in a system that cannot tolerate silent failures. Engineering responses:

- **Circuit-breaker pattern** on all integration interfaces: when downstream system is unavailable, the circuit opens; messages queue or are rejected cleanly rather than being lost or silently corrupted
- **System-of-record designation** documented in the integration contract for every shared data entity: exactly one system is authoritative for each attribute; conflicting updates in non-authoritative systems are rejected or queued for review
- **Fallback / manual override path** for critical business processes when the ERP interface fails: financial close, payroll, and order fulfillment must have documented manual procedures executable without system access
- **Dead letter queue** for all async integration: messages that cannot be processed are captured, not dropped, and are visible to operations teams for manual resolution
- **Interface monitoring**: latency, error rate, and throughput per interface; alerting on degradation before it becomes an outage

See `core/architecture.md` for integration architecture patterns.

### 7.4 Designing for Exit and Portability

Lock-in management is an engineering discipline, not only a procurement concern:

- **Contract:** Negotiate data export rights, formats (open relational format or structured CSV, not proprietary), volume limits, and timeline before signature. Include post-termination access period of at least 90 days.
- **Architecture:** Avoid storing unique business logic only in vendor-proprietary scripting environments (SAP ABAP, Oracle PL/SQL in cloud-managed schemas, Workday Calculated Fields). Document all business rules in a vendor-neutral specification so they can be re-implemented on a successor platform.
- **Data:** Maintain scheduled canonical data exports — master data, open transactions, financial balances — on a vendor-independent storage layer, independent of vendor-provided export tools. This also provides a disaster recovery option independent of the vendor's backup SLA.
- **Integration:** Abstraction layer between ERP and external systems; external systems should integrate against a canonical data model or API gateway, not directly against ERP-specific API structures. This reduces the re-integration cost if the ERP is replaced.

---

## See also

- `core/implementation.md`
- `core/architecture.md`
- `core/security.md`
- `verticals/government-publicsector.md`
- `glossary.md`

---

## Citations & Sources

1. Henrico Dolfing — "Case Study 3: How a Screwed-Up SAP Implementation Almost Brought Down National Grid": henricodolfing.com (detailed case analysis with sourced financials for National Grid)
2. The Register — "Birmingham City Council goes under after Oracle disaster" (September 5, 2023): theregister.com/2023/09/05/birmingham_city_council_oracle/
3. Data Center Dynamics — "Total cost of Birmingham City's Oracle system failure to reach £216.5m by 2026" (2023): datacenterdynamics.com
4. Pemeco — "Why ERP Implementations Fail: Lessons from Hershey's" / CIO.com — "Supply Chain: Hershey's Bittersweet Lesson": $112M system cost, $100M orders unshipped, 19% quarterly profit decline, 8%+ stock drop confirmed across multiple contemporaneous sources
5. Henrico Dolfing — "Case Study 16: Nike's 100 Million Dollar Supply Chain 'Speed bump'": henricodolfing.ch; CIO.com — "Nike Rebounds" (Nike $400M supply chain investment, $100M lost sales Q3 2001, 20% stock drop, i2 replaced by SAP spring 2001)
6. Computerworld — "SAP, Waste Management settle lawsuit" (2010); Network World — "SAP sues insurer over Waste Management lawsuit settlement": $80M settlement confirmed; SAP lawsuit against Swiss Re confirmed; Swiss Re secondary suit outcome unconfirmed
7. Computerworld — "Marin County settles legal claims against Deloitte, SAP over software project" (January 11, 2013): $3.9M settlement from Deloitte; SAP claims dismissed; RICO claims dismissed by judge
8. Henrico Dolfing — "Case Study 3: How a Screwed-Up SAP Implementation Almost Brought Down National Grid": henricodolfing.com; UpperEdge — "Wipro Responds to National Grid's SAP Implementation Billion Dollar Lawsuit": upperedge.com; The Register — "Wipro hands $75m to National Grid US after botched SAP upgrade" (August 6, 2018): theregister.com/2018/08/06/botched_sap_implementation_national_grid_wipro_settlement_75m/; Infoworld/Computerworld — "Price tag for troubled SAP project will skyrocket to nearly $1 billion, audit says"
9. UpperEdge — "MillerCoors Files $100M Suit Against HCL for Flawed SAP Implementation": upperedge.com; TechTarget — "MillerCoors ERP lawsuit begins harshly, ends softly"
10. Henrico Dolfing — "Case Study 12: Lidl's €500 Million SAP Debacle": henricodolfing.ch; Panorama Consulting — "The Lidl SAP ERP System Project Failure Case Study": panorama-consulting.com; Consultancy.uk — "Lidl cancels SAP introduction having sunk €500 million into it" (2018): consultancy.uk
11. Henrico Dolfing — "Case Study 6: How Revlon Got Sued by Its Own Shareholders Because of a Failed SAP Implementation": henricodolfing.ch; Panorama Consulting — "Revlon ERP SAP Implementation Failure Case Study": panorama-consulting.com; Computer Weekly — "SAP disruption leads to Revlon class action lawsuit"
12. The Register — "Birmingham City Council goes under after Oracle disaster" (September 2023); Computer Weekly — "Birmingham City Council's Oracle implementation explained: What went wrong?"; Data Center Dynamics — "Total cost of Birmingham City's Oracle system failure to reach £216.5m by 2026"
13. The Register — "Birmingham Oracle ERP fiasco now £144M and still not working" (January 29, 2026): theregister.com/2026/01/29/birmingham_oracle_latest/ (most recent total forecast cost £144.4M to 2027/28)
14. Computer Weekly — "High Court rules for SAP, against Diageo in indirect licensing case" (February 2017); Mondaq — "The Scope of 'Indirect Access' to Software: SAP UK Limited v Diageo Great Britain Limited": SAP claimed ~£55M; ruling favored SAP
15. Computer Weekly — "AB InBev settles out of court in $600m SAP licensing dispute" / Computerworld — "SAP settles licensing dispute with AB InBev": SAP claimed ~$600M; actual settlement amount not publicly disclosed; settled June 30, 2017
16. SAP — "Digital Access Adoption Program Overview" (May 2019, public document): news.sap.com; SAP — "DAAP External" (April 2020 update): news.sap.com; DAAP offered 90% discount (Option B) or ~85% discount with growth headroom (Option A); program extended through December 31, 2022
17. Panorama Consulting Group — Annual ERP Report: panorama-consulting.com (annual survey; methodology described in each report)
18. Standish Group — CHAOS Report: standishgroup.com (broad IT project outcomes; not ERP-specific)
19. Prosci — ADKAR Model: prosci.com (Awareness, Desire, Knowledge, Ability, Reinforcement — change management framework for ERP OCM programs)
20. SAP — Support Strategy page / SAP Community — "Maintenance Timelines for SAP ERP 6.0": support.sap.com; Rimini Street — "No Extension to SAP ECC 6 and Business Suite 7 Mainstream Maintenance End Dates in 2025 and 2027": riministreet.com (EHP 0–5 mainstream end Dec 31 2025; EHP 6–8 mainstream end Dec 31 2027; extended maintenance to Dec 31 2030 for EHP 6–8 only)
21. UK Local Government Finance Act 1988 — Section 114 notice mechanism: legislation.gov.uk
22. Gartner Magic Quadrant for Cloud ERP for Product-Centric Enterprises and Cloud ERP for Service-Centric Enterprises: gartner.com (note: Gartner no longer publishes a single "ERP Magic Quadrant"; the market is evaluated as two separate quadrants)
23. Oracle — License Management Services: oracle.com/corporate/license-management-services
24. Oracle — Fusion Cloud ERP extensibility documentation: docs.oracle.com/en/cloud/saas/erp
25. SAP — Clean Core and ABAP Cloud development model: help.sap.com (S/4HANA extensibility guide; ABAP Cloud documentation)
26. SAP — BTP (Business Technology Platform): discovery.sap.com/btp
