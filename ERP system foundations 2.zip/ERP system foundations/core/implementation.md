# ERP Implementation Methodology & Best Practices

ERP implementations are high-risk, capital-intensive programs that transform core business operations. This file covers the full lifecycle from methodology selection through post-go-live value realization, written for engineers designing and building ERP systems or integration infrastructure around them.

---

## 1. Implementation Methodology Frameworks

### 1.1 Waterfall

Sequential phases execute to completion before the next begins: Requirements → Design → Build → Test → Deploy. Scope is locked at requirements freeze; change requests require formal impact assessment and schedule revision.

**Tradeoffs:**

| Attribute | Assessment |
|---|---|
| Scope control | Strong: gate reviews enforce deliverable completeness before proceeding |
| Adaptability | Poor: late-stage discoveries require expensive rework or scope deferral |
| Governance overhead | High: heavyweight documentation at each phase gate |
| Vendor alignment | Agnostic: works with any ERP product |
| Best fit | Fixed-scope greenfield with stable, well-documented business requirements |

Waterfall suits organizations with mature process documentation, regulatory environments requiring full traceability (e.g., 21 CFR Part 11 validation in life sciences), or fixed-price SI contracts where scope must be frozen to control commercial exposure.

### 1.2 Agile / Scrum in ERP Context

Sprint-based delivery of configured modules, typically two-week iterations. Each sprint targets a demonstrable process slice ("fit-to-standard" demo of Purchase-to-Pay flow, for example). The product backlog maps to configuration items, interface builds, and custom extensions rather than software features.

**ERP-specific challenges:**

- Module interdependency: procurement (MM) posts to Financial Accounting (FI); a defect in account determination breaks the entire procure-to-pay flow. True sprint independence is difficult when downstream modules depend on upstream configuration.
- Master data: sprint demos require realistic master data in the sprint environment, adding setup overhead.
- Integration: interfaces to external systems cannot be independently tested until both sides are configured.

Works best when combined with iterative configuration and phased rollout, with Agile governing the build workstream inside a waterfall governance frame for budget and milestone accountability.

### 1.3 SAP Activate

SAP's proprietary methodology for S/4HANA implementations, system conversions (brownfield), and selective data transitions. Built around three pillars: SAP Best Practice content activation, fit-to-standard analysis (not fit-gap), and Agile delivery inside the Realize phase. [1]

**Six phases:**

| Phase | Purpose |
|---|---|
| Discover | Opportunity assessment; access to trial systems; activate SAP Best Practices |
| Prepare | Project setup, environment provisioning, team onboarding, standards definition |
| Explore | Fit-to-standard workshops; delta design for gaps; confirm scope |
| Realize | Iterative configuration sprints; unit test; integration test; data migration mock |
| Deploy | Cutover preparation; UAT sign-off; go-live execution |
| Run | Hypercare; steady-state operations; continuous improvement |

SAP Roadmap Viewer (roadmap.sap.com) delivers workstream-specific task content per deployment scenario (new implementation vs. system conversion vs. selective data transition). Fit-to-standard in Explore is deliberate: the methodology discourages gap analysis that drives customization, instead pushing process change to close gaps against SAP standard.

### 1.4 Oracle Unified Method (OUM)

OUM replaced Oracle Application Implementation Method (AIM), which was retired January 31, 2011. [2] AIM had six phases (Definition, Operation Analysis, Solution Design, Build, Transition, Production) and approximately 10–12 processes depending on version; OUM has five phases (Inception, Elaboration, Construction, Transition, Production) and 14 processes, structured to be adaptive across Oracle Fusion Cloud ERP, integrations, custom development, and BI workstreams simultaneously.

OUM also shifts the delivery model from AIM's waterfall approach to an iterative, spiral model—each phase may cycle through multiple iterations before completion. Broadly applicable across Oracle Fusion Cloud ERP (Financials, Procurement, Project Portfolio Management, SCM, Manufacturing) and Oracle E-Business Suite (EBS) legacy programs.

### 1.5 Microsoft Success by Design

Microsoft Sure Step was introduced circa 2007 for Dynamics NAV, AX, and CRM implementations. While still used by some partners for on-premises deployments, Microsoft has not actively maintained it. Success by Design replaced it as the prescriptive governance framework for Dynamics 365 cloud implementations; unlike Sure Step, it is not a rigid project management methodology but a lifecycle governance overlay that sits atop the team's chosen Agile or Waterfall approach. [3]

**Phases (verify current naming against Microsoft Learn documentation, as Microsoft updates guidance periodically):** Initiate → Implement → Prepare → Operate.

FastTrack for Dynamics 365 overlays review checkpoints at key milestones—Solution Blueprint Review, Gap Solution Design Review, Mock Go-Live Review—where Microsoft engineers assess implementation health and flag risk before go-live. Engagement with FastTrack is typically included above certain contract thresholds.

### 1.6 Hybrid Approaches

Large enterprise programs commonly combine waterfall governance frames with Agile delivery inside build phases. The program steering committee operates on waterfall gates (phase entry/exit criteria, budget approval, go/no-go decisions); delivery squads within the build phase use Scrum sprints.

**Risk:** Methodological mismatch between SI partner and client organization. If the client PMO operates on monthly waterfall reporting and the SI team runs two-week sprints, velocity, scope completion, and risk signals translate poorly between frameworks. Align reporting cadence explicitly.

### 1.7 Methodology Comparison Table

| Methodology | Vendor | Flexibility | Governance Overhead | Best Deployment Type |
|---|---|---|---|---|
| Waterfall | Agnostic | Low | High | Fixed-scope greenfield |
| Agile / Scrum | Agnostic | High | Medium | Iterative module rollout |
| SAP Activate | SAP | Medium-High | Medium | SAP S/4HANA (all scenarios) |
| OUM | Oracle | Medium | Medium | Oracle Fusion Cloud ERP |
| Success by Design | Microsoft | Medium | Medium | Dynamics 365 Cloud |
| Hybrid | Agnostic | High | High | Enterprise multi-phase programs |

---

## 2. Rollout Strategy

### 2.1 Big Bang

All modules, all sites, and all users cut over on a single date. Legacy systems are decommissioned immediately post-cutover.

**Risk profile:** Maximum. A single defect in a core financial posting path can halt all operations simultaneously. Parallel-run costs are minimized because there is no overlap period.

**Historical failure cases:**

- **Hershey Foods, 1999 [4]:** SAP R/3 + Siebel CRM + Manugistics SCM big-bang go-live in July 1999. The $112M program's timeline was compressed from the recommended 48 months to 30 months to beat Y2K deadlines, with critical testing phases abbreviated or skipped. Go-live coincided with the peak Halloween and Christmas confectionery season. Approximately $100M in orders could not be shipped; quarterly profits fell 19% year-over-year in Q3 1999; stock fell approximately 8% on the day the CEO announced the problems. Root causes: compressed timeline, insufficient testing, inadequate risk mitigation for seasonal volume.
- **FoxMeyer Drug, 1993–1996 [5]:** A $5B pharmaceutical distributor began the Delta III SAP R/3 + Pinnacle automated warehouse project in 1993 with Andersen Consulting as SI. The legacy system processed approximately 420,000 orders per night; at go-live, the ERP managed only around 10,000 orders per night (from academic case studies—treat as reported approximations). The company simultaneously signed a large University HealthSystem Consortium contract that exacerbated volume mismatch. FoxMeyer was driven to bankruptcy in 1996. In 1998, the bankruptcy trustee sued both SAP AG and Andersen Consulting for $500M each; both defendants denied the allegations, blaming FoxMeyer for mismanagement.

**When appropriate:** Single-site organizations, limited integrations, small user populations with high technical maturity, strong executive mandate, and a short legacy decommission window.

### 2.2 Phased Rollout

Sequential module or geographic deployment. Finance (FI/CO) typically deploys first—it is the integration backbone; downstream modules (Procurement/MM, Manufacturing/PP, Distribution/SD, Warehouse/EWM) follow in subsequent phases.

**Pattern:** Finance → Procurement → Manufacturing → Distribution → Warehouse Management.

Earlier phases stabilize before the next begins. Lessons learned (data migration failures, interface defects, adoption issues) are incorporated. The blast radius of a go-live failure is limited to one module or region. Requires long-lived data bridges between old and new systems during the transition period, which adds integration complexity and cost.

### 2.3 Pilot / Parallel Run

- **Pilot:** One business unit or geography goes live first as a controlled test. Scale-out to remaining sites follows after stabilization. Common in global rollouts with a "template" model: pilot establishes the template; country rollouts deploy the template with local configuration (currency, tax, language, chart of accounts localization).
- **Parallel run:** Legacy and new systems operate concurrently for a defined reconciliation period. Both systems receive identical transactions; outputs are compared to validate ERP correctness before legacy decommission. Expensive: requires dual data entry or automated posting to both systems, and dual reconciliation at period close. Appropriate for highly regulated environments or complex GL migration where opening balance accuracy is critical.

### 2.4 Rollout Strategy Decision Framework

| Strategy | Timeline Risk | Cost | Data Risk | Recommended When |
|---|---|---|---|---|
| Big Bang | Highest | Lowest long-term | Highest | Single site, small scope, high org maturity |
| Phased | Medium | Medium | Medium | Multi-site, complex integrations |
| Pilot + Rollout | Lower | Higher (dual-run overhead) | Lower | Global rollouts, high compliance burden |
| Parallel Run | Lowest | Highest | Lowest | Regulated industries, complex GL migration |

---

## 3. Pre-Implementation

### 3.1 Business Process Mapping

Document current-state (As-Is) processes using swimlane diagrams in BPMN 2.0 (Business Process Model and Notation) notation. BPMN 2.0 (OMG specification, published 2011) provides standardized syntax for tasks, gateways, events, and pools/lanes that maps directly to ERP transaction flows. [6]

Tools: SAP Signavio (process modeling + process mining), Celonis (process mining on live system data), ARIS (IDS Scheer), Microsoft Visio.

To-Be process design should target ERP standard processes to minimize customization. The delta between As-Is and To-Be defines the change management scope; the delta between To-Be and ERP standard defines the technical gap register.

### 3.2 Gap/Fit Analysis

Under the SAP clean-core principle and similar fit-to-standard philosophies, fit-gap analysis is replaced by fit-to-standard workshops: demonstrate the standard system, then identify gaps against it rather than gaps against the current process. Gaps are resolved through one of three paths:

1. **Configuration:** Activate standard functionality via settings (no code change).
2. **Extension:** Build on approved extensibility frameworks (SAP BTP / Oracle Extensibility Framework / Power Platform) without modifying core.
3. **Process change:** Adapt the business process to the ERP standard.

Maintain a gap register: gap ID, description, owner, resolution type, effort estimate, priority, and sign-off status. The gap register is a living document through the Realize phase.

### 3.3 Vendor Selection Criteria

| Criterion | Engineering Considerations |
|---|---|
| Functional coverage | Module depth per vertical; reference customers in same industry and revenue range |
| TCO (5-year) | License/subscription + implementation + annual maintenance + infrastructure |
| Upgrade path | SaaS quarterly vs. on-prem major releases; ECC to S/4HANA migration cost |
| Partner ecosystem | SI availability in geography; certified partner count per product |
| API maturity | REST/OData coverage, event publishing (SAP Event Mesh), batch interface options |
| Integration connectors | Pre-built connectors to your existing landscape (CRM, WMS, e-commerce) |
| Security certifications | SOC 2 Type II, ISO/IEC 27001:2022 attestation for cloud products |
| Localization depth | Country-specific tax, statutory reporting, language support (see `core/localization-tax.md`) |

Gartner no longer publishes a single ERP Magic Quadrant. As of 2025, analysis is split across three reports: Magic Quadrant for Cloud ERP for Product-Centric Enterprises (2025 edition), Magic Quadrant for Cloud ERP for Service-Centric Enterprises (published October 2025), and Magic Quadrant for Cloud ERP Finance (published 2025). Reference all three when the organization spans manufacturing, services, and finance-led deployments.

### 3.4 RFP Structure

A well-structured RFP reduces vendor evaluation subjectivity:

- **Functional requirements matrix:** Mandatory vs. desirable; weighted scoring; reference to specific business scenarios (not generic module names).
- **Technical requirements:** Cloud hosting model, SLA tiers, security certifications (SOC 2 Type II, ISO/IEC 27001:2022), data residency, API capabilities.
- **Vendor financial stability:** Revenue, customer retention, product roadmap commitment, acquisition risk.
- **Demo scenario scripts:** Scripted walkthroughs of actual business processes (not vendor-directed product tours).
- **Pricing request:** List price, discount rationale, multi-year commitment terms, costs for sandbox/test tenants, premium support tier pricing.
- **Reference check protocol:** Minimum three references in same industry and size; direct conversations with reference implementation teams.

### 3.5 TCO Calculation Components

| Cost Category | Notes |
|---|---|
| Software licensing / subscription | Year 1 and 5-year NPV; includes named users, modules, add-ons |
| Implementation labor (SI fees) | Typically the largest single cost item in mid-market and enterprise |
| Internal staff backfill and opportunity cost | Business SMEs pulled from operations; frequently underbudgeted |
| Infrastructure | Cloud hosting (compute, storage, network egress); on-prem hardware/data center |
| Data migration | ETL tooling, cleansing effort, external data quality services |
| Integration development | Custom connectors, middleware licensing, API management |
| Training and change management | Content development, delivery, travel, change management consulting |
| Annual support and maintenance | Typically 18–22% of license for on-prem; bundled in SaaS subscription |
| Upgrade cycles | Major upgrades, regression testing, consultant re-engagement |

Industry benchmark: total ERP program costs are often equivalent to 3–6% of annual revenue for mid-market and enterprise programs. Software licensing typically represents 20–30% of total program cost; implementation services represent the majority.

### 3.6 ROI Modeling

**Hard savings (quantifiable):** Headcount reduction through automation, error rate reduction (duplicate payments, inventory adjustments), audit cost reduction, inventory carrying cost reduction.

**Soft/strategic benefits (directionally quantifiable):** Real-time financial visibility, faster period-end close, regulatory compliance posture improvement, improved supplier/customer data quality.

**Modeling approach:**
- Establish baseline metrics before go-live (current DSO, current close duration, current error rates).
- Payback period benchmarks: 3–5 years for mid-market; 5–7 years for enterprise programs.
- Calculate IRR and NPV over a 7–10-year horizon to account for upgrade cycles.
- Document assumptions explicitly; ROI model credibility depends on defensible baseline data.

---

## 4. Data Migration

Data migration is consistently underestimated. Cleansing effort alone typically represents 60–80% of the total migration budget.

### 4.1 Data Audit and Profiling

Inventory all source systems. Assign data owners per domain:

- Customer master (CRM, billing systems)
- Vendor/supplier master (procurement systems, spreadsheets)
- Chart of accounts and cost center hierarchy
- Open items (AR open invoices, AP open purchase orders)
- Inventory master (item master, lot/serial records, on-hand balances)
- Fixed asset register
- Employee master (if HCM in scope)

Profile data quality per domain: completeness, duplicates, referential integrity violations, format non-conformance. Classify criticality:

- **Tier 1:** Required at go-live (open AR/AP, customer master, vendor master, inventory balances).
- **Tier 2:** Load post-go-live (historical transactions, closed purchase orders).
- **Tier 3:** Archive-only (data retained for compliance; not migrated to ERP).

### 4.2 Data Cleansing

Deduplication of business partners, material/item masters, and fixed asset records must be completed before migration. Standardize reference data:

- Country codes: ISO 3166 (two-letter alpha codes; e.g., DE, US, JP). [7]
- Currency codes: ISO 4217 (three-letter codes; e.g., EUR, USD, JPY). [8]
- Units of measure: align to ERP UoM master before load.

**Critical governance point:** Data cleansing is a business responsibility, not IT. IT can provide tooling and profiling reports; business data owners must validate and approve the cleansed records. Projects that treat cleansing as purely a technical workstream consistently fail reconciliation at go-live.

### 4.3 ETL Tooling

| Platform | Tooling |
|---|---|
| SAP S/4HANA | "Migrate Your Data" Fiori app (replaced LTMC, which was deprecated with S/4HANA 2021; LTMC projects created before deprecation remain read-only from S/4HANA 2021 onward); LTMOM (Legacy Transfer Migration Object Modeler) for custom migration objects [9] |
| Oracle Fusion Cloud ERP | Oracle Data Integrator (ODI); Oracle Data Management Platform; FBDI (File-Based Data Import) for bulk loads |
| Microsoft Dynamics 365 | Data Migration Framework (DMF); Azure Data Factory for complex transformations |
| Third-party / agnostic | Syniti (SAP-focused); Informatica IDMC (Intelligent Data Management Cloud); Talend Data Integration; AWS Glue; Boomi ETL |

**Migration pattern:**

```
Source System Extract
        ↓
Staging Schema (source-format tables, no transformation)
        ↓
Data Validation (completeness, referential integrity, business rules)
        ↓
Transformation (map to ERP data model, apply defaults, enrich)
        ↓
Load to ERP (via migration tool / API / file import)
        ↓
Reconciliation (row counts, financial totals, spot validation by business)
```

### 4.4 Cutover Strategy

- **Mock cutovers:** Execute at least two full dress rehearsals (in a production-equivalent environment) before the actual cutover. Measure elapsed time per runbook step; identify bottlenecks; validate that the cutover window is achievable.
- **Cutover runbook:** Sequenced task list with owner, estimated duration, dependency on prior tasks, go/no-go checkpoint. Every task must have a named responsible person, not a team.
- **Data freeze:** Source systems enter a defined data freeze period before final migration load. No new master data creation, no open item changes without change control approval.
- **Delta migration:** Capture changes between the freeze point and go-live using CDC (Change Data Capture) or manual delta scripts. Delta scope must be defined and bounded at cutover planning.

### 4.5 Parallel Running and Reconciliation

Compare ERP opening balances to legacy trial balance at the point of cutover. Define reconciliation tolerance thresholds per account class (e.g., GL balance variance < 0.01% of period total before sign-off). Dual-posting parallel run periods typically run 1–3 months for financial modules in regulated or high-risk environments.

### 4.6 Common Migration Failure Points

- Underestimating data cleansing scope and timeline (typically 2–3x the initial estimate).
- Not involving business users in data sign-off; IT signs off on technical completeness, not business accuracy.
- Missing legacy system extracts: retired systems with no active access, offline departmental spreadsheets, legacy AS/400 or mainframe systems with undocumented schemas.
- Insufficient mock cutover rehearsals; first dress rehearsal commonly reveals the runbook is 40–60% longer than estimated.
- No rollback plan defined before go-live. If cutover fails mid-run after irreversible financial transactions post, rollback becomes impossible.

---

## 5. Change Management

### 5.1 Stakeholder Alignment

Map stakeholders using a power/interest grid: high power/high interest (manage closely), high power/low interest (keep satisfied), low power/high interest (keep informed), low power/low interest (monitor). Identify champions, blockers, and neutrals per workstream.

**Executive sponsorship** is the most consistently cited failure factor when absent. The sponsor must have budget authority, decision-making power over scope trade-offs, and visible commitment to the program—attending steering committees, communicating organizational priority, and removing organizational blockers.

### 5.2 ADKAR Model (Prosci)

Developed by Jeff Hiatt (Prosci founder) after studying more than 700 organizations undergoing change. [10] The ADKAR model identifies five building blocks of individual change:

| Element | Question |
|---|---|
| **A**wareness | Do stakeholders understand why the change is necessary? |
| **D**esire | Do they want to participate and support the change? |
| **K**nowledge | Do they know how to change (skills, process knowledge)? |
| **A**bility | Can they demonstrate the required behaviors and skills? |
| **R**einforcement | Are mechanisms in place to sustain the change post-go-live? |

Diagnostic application: assess ADKAR state per stakeholder group; the weakest element is the barrier point. Target interventions at the barrier point, not at all elements equally.

**Change management plan components:** Sponsor Plan (sponsor activities and communications), People Manager Plan (manager-specific guidance), Training Plan (role-based curriculum), Communications Plan (cadenced messaging).

### 5.3 Kotter's 8-Step Change Model

John Kotter (Harvard Business School) describes eight stages for large-scale organizational transformation: [11]

1. Create urgency
2. Build a guiding coalition
3. Form a strategic vision
4. Communicate the vision
5. Enable action by removing blockers
6. Generate short-term wins
7. Sustain acceleration
8. Institute the change

Applicable to enterprise ERP programs where the technology deployment is a vector for broader cultural or operational transformation. The model complements ADKAR: Kotter addresses organizational change sequencing; ADKAR addresses individual change readiness.

### 5.4 End-User Training Program

Role-based curriculum is mandatory. Generic "system overview" training does not translate to operational proficiency. Training must address what each role does in the system, not what the system can do.

| Training Element | Design Requirement |
|---|---|
| Role-based curriculum | Map training content to job roles and transaction codes / Fiori apps |
| Training environment | Dedicated tenant/client refreshed with realistic master data and transaction scenarios |
| Delivery channels | Instructor-led (ILT) for complex flows; eLearning for standard transactions |
| Authoring tools | SAP Enable Now (SAP); Oracle Guided Learning (Oracle); Articulate / Camtasia (generic) |
| Super user program | One or more per department; receives advanced training; provides floor support post-go-live |
| Job aids | Quick reference cards for high-frequency transactions; available at go-live |

### 5.5 Resistance Handling

Identify resistance early via pulse surveys and structured stakeholder interviews during Prepare and Explore phases, not at UAT when it is too late to address substantively. Root causes of resistance:

- Fear of job elimination from automation.
- Loss of valued workarounds (Excel-based processes, offline tracking).
- Perceived loss of control or status.
- Unfamiliarity with new process flows.

Middle management engagement is critical: they either enable or block adoption at the operational level. Neutral or resistant middle managers consistently undermine go-live effectiveness even when senior leadership is supportive.

### 5.6 Communication Plan

| Communication Type | Cadence | Audience |
|---|---|---|
| Program newsletter | Monthly | All affected staff |
| Steering committee update | Monthly (weekly during critical phases) | Executives, sponsors |
| Department briefings | Per major milestone | Department managers and teams |
| Town halls | Pre-go-live (2–3 events) | All users |
| Feedback mechanisms | Ongoing | All users |

Avoid over-communicating detailed system information before the Realize phase. Premature communication about system specifics creates change fatigue and generates questions that cannot yet be answered, eroding confidence.

---

## 6. Go-Live Strategy

### 6.1 Cutover Checklist

**Technical:**
- System access: all user accounts provisioned, roles assigned, SoD conflicts resolved (see `core/security.md`).
- Interfaces: all integration points activated, tested end-to-end with production credentials.
- Batch jobs: scheduled and sequenced in production; monitoring alerts configured.
- Printers, output devices, email routing configured for production.
- SSL certificates, load balancer configuration, DNS entries validated.

**Data:**
- Opening balances loaded and reconciled to source trial balance within defined tolerance.
- Master data validated: customer, vendor, material/item, cost center, profit center hierarchies.
- Document number ranges configured and tested in production.
- Inventory balances physically counted and reconciled before load.

**Business:**
- Approval hierarchies configured and workflow rules tested end-to-end.
- Month-end calendar aligned; first close date confirmed.
- Purchase order/sales order cutoff procedures documented and communicated.
- Signature authorities confirmed in system.

**Support:**
- Hypercare team staffed; contact roster published.
- Helpdesk routing configured; production issue queue distinct from project queue.
- Escalation path documented: helpdesk → super user → functional consultant → vendor support.

### 6.2 Command Center

A physical or virtual war room operated during the cutover window and the first weeks post-go-live. All workstream leads, SI consultants, and vendor support are on standby or available with defined SLAs.

Issue triage process: classify every reported issue by severity:

| Severity | Definition | Response |
|---|---|---|
| SEV-1 | Go-live blocker; financial posting failure; core process non-functional | Immediate; all hands |
| SEV-2 | Significant workaround required; affects majority of a business unit | Same-day resolution |
| SEV-3 | Minor defect; workaround available; cosmetic | Scheduled in backlog |

Real-time issue dashboard: open vs. resolved by workstream, SEV-1 aging, new issues per hour during cutover.

### 6.3 Hypercare Period

Defined duration of elevated support, typically 4–8 weeks post-go-live. Functional consultants remain on-site or on-call. Issue resolution SLAs are stricter than steady-state operations.

The first month-end close within the hypercare period requires additional reconciliation checks and consultant presence. This is the highest-risk financial event post-go-live: incorrect period-end accruals, asset depreciation runs, and intercompany eliminations surface configuration defects not visible in testing.

### 6.4 Rollback Planning

Rollback decision criteria must be defined and agreed before go-live. Common trigger conditions:

- SEV-1 financial posting failures that cannot be resolved within the cutover window.
- Month-end close cannot proceed (if go-live occurs at period end).
- Data integrity failures in inventory or AR balances exceed tolerance thresholds.

**Technical rollback:** Database restore procedure documented and tested; interface deactivation runbook; reverse DNS changes. **Business rollback:** Legacy system reactivation procedure; dual-entry reversal process; communication script for staff.

**Rollback window:** Practically limited to the first 24–72 hours after go-live. Once significant business transactions accumulate in the ERP (customer invoices posted, payments cleared, goods receipts confirmed), rollback creates unrecoverable reconciliation complexity.

---

## 7. Integration Architecture

See `core/architecture.md` for the canonical data model and API layer design.

### 7.1 ERP as System of Record

ERP owns the golden record for Finance (GL, AR, AP, fixed assets), Procurement (PO, vendor master), and Inventory (item master, on-hand balances, lot/serial tracking). External systems are consumers. Direct database reads from external systems to ERP tables violate system-of-record boundaries and create upgrade risk.

### 7.2 Middleware Patterns

| Pattern | Technology Examples | Characteristics |
|---|---|---|
| ESB (Enterprise Service Bus) | MuleSoft (on-prem runtime), IBM App Connect | Centralized transformation and routing; suited to on-prem legacy landscapes |
| iPaaS | MuleSoft Anypoint Cloud, Dell Boomi, Azure Integration Services, SAP Integration Suite | Cloud-native; managed infrastructure; preferred for modern ERP landscapes |
| Point-to-Point | Direct API calls | Simple for 2–3 systems; connection count scales as n(n-1)/2; unmaintainable at scale |
| Hub-and-Spoke | Single integration hub | Reduces connection count; introduces single point of failure; requires high hub availability |

SAP Integration Suite (part of SAP BTP) bundles API Management, Cloud Integration (CI), Event Mesh, and Integration Advisor. It is the preferred integration platform for SAP S/4HANA Cloud and hybrid landscapes.

### 7.3 API Patterns in ERP Integration

- **Synchronous REST/OData:** Real-time queries (inventory availability check, price determination, customer credit check). SAP exposes standard OData APIs via SAP Gateway; Oracle Fusion exposes REST APIs.
- **Asynchronous messaging (AMQP, Apache Kafka, Azure Service Bus):** High-volume event streams where the sender should not block on consumer acknowledgment (order created, shipment confirmed, invoice posted).
- **Batch file-based:** Still prevalent for legacy financial system feeds: GL journal imports, bank statement files (MT940, BAI2 formats), EDI (ANSI X12, EDIFACT).
- **SAP API taxonomy:** BAPIs (legacy ABAP function modules, still widely used), IDocs (intermediate documents for EDI/batch), OData services via SAP Gateway (S/4HANA standard APIs), SOAP/REST via SAP Integration Suite.

### 7.4 Event-Driven Integration

Publish domain events on ERP state changes: `OrderConfirmed`, `InvoicePosted`, `PaymentCleared`, `GoodsReceiptPosted`, `AssetCapitalized`. Consumers (CRM, WMS, eCommerce platform, BI data lake) subscribe without the ERP needing to know the consumer list. Ensures loose coupling and enables consumer addition without ERP changes. SAP Event Mesh (part of BTP) supports this pattern for S/4HANA Cloud.

---

## 8. Customization vs. Configuration

### 8.1 Configuration

Activating standard ERP functionality through settings: organizational structure definition, chart of accounts, document types, tax codes, approval workflow thresholds. Zero code changes; configuration survives standard upgrades without regression risk.

Examples: SAP customizing via IMG (Implementation Guide) transaction SPRO; Oracle Fusion value sets, profile options, and business rule configurations; Dynamics 365 parameterization via the client.

### 8.2 Extension (Approved Extensibility)

Build additional functionality on top of the ERP without modifying vendor source code, using published extension points:

- **SAP:** SAP BTP (Business Technology Platform) using released APIs and ABAP Cloud development model. The clean-core principle defines five pillars: Processes, Extensibility, Data, Integrations, Operations. ABAP Cloud restricts access to released APIs only, preventing hidden dependencies on internal SAP code.
- **Oracle:** Oracle Extensibility Framework, Sandbox configurations, PaaS extensions on Oracle Cloud Infrastructure.
- **Microsoft Dynamics 365:** Power Platform (Power Apps, Power Automate, Power BI) layered on D365; AL language extensions deployed via AppSource or per-environment.

Extensions survive upgrades because they depend only on released, versioned APIs that SAP/Oracle/Microsoft commit to maintaining.

### 8.3 Customization (Core Modification)

Direct modification of vendor source code. In SAP: ABAP user exits, BAdIs, and enhancement spots are the preferred extensibility mechanisms (prefer to full source modifications); older programs may still use implicit enhancements or source code copies. In Oracle EBS: custom PL/SQL packages replacing standard APIs.

**Technical debt consequences:**
- Each vendor upgrade requires regression testing of all modified objects.
- Custom code blocks automatic upgrade paths; SAP ECC to S/4HANA migrations frequently fail custom code compatibility checks.
- Maintenance requires ABAP/Oracle developers with vendor-specific skills; increases vendor lock-in.

Maintain a custom code register: object ID, business justification, technical owner, business owner, last regression test date, technical debt score.

### 8.4 Decision Framework

```
Requirement received
        ↓
Does standard config + process change resolve it?
    YES → Configure; document decision
        ↓
    NO → Is it solvable via approved extensibility (BTP/Power Platform)?
        YES → Extend; document released APIs used
            ↓
        NO → Is it a regulatory mandate with no other resolution path?
            YES → Modify core; document in custom code register; accept upgrade risk
            NO  → Challenge the requirement; revisit process change
```

---

## 9. Testing

### 9.1 Test Types and Sequence

| Test Type | Scope | Owner |
|---|---|---|
| Unit | Individual configuration object or custom code function | SI consultant / developer |
| Integration | End-to-end process flow across modules and external interfaces | SI + business leads |
| UAT (User Acceptance Testing) | Business validation against acceptance criteria | Business users (coordinated by BA) |
| Performance / Volume | Peak transaction loads; production-scale data volumes | Technical team + SI |
| Regression | Validate previously passing scenarios after any configuration change | SI + automated tooling |
| Cutover testing | Full rehearsal of migration runbook and go-live procedure | Migration team + SI |

### 9.2 ERP-Specific Testing Challenges

- **Process interdependencies:** A procure-to-pay flow spans MM (purchase requisition, PO), FI (GR/IR clearing, vendor invoice posting), CO (cost center assignment). A defect in account determination blocks the entire downstream chain.
- **Master data dependency:** Test scripts fail without correct master data in the test environment. Environment refresh cycles must include master data loads.
- **Authorization testing:** Segregation of Duties (SoD) conflicts surface late if security testing is deferred to UAT. See `core/security.md` for role design and SoD analysis detail.
- **Interface volume:** Performance of batch interfaces only becomes visible at realistic data volumes; unit-scale testing misses throughput bottlenecks.
- **Environment management:** DEV → QA → UAT → PROD pipeline requires disciplined transport management. Environment refresh cycles (particularly for UAT) must be planned to avoid stale configuration contaminating test results.

### 9.3 Test Automation

| Platform | Tooling |
|---|---|
| SAP | Tricentis Tosca (official SAP partner); SAP Cloud ALM (test management and automation for cloud); SAP Solution Manager Test Suite (on-premises); CBTA (Component-Based Test Automation, embedded in Solution Manager) |
| Oracle Fusion | Oracle Application Testing Suite (OATS); Selenium-based custom frameworks |
| Microsoft Dynamics 365 | RSAT (Regression Suite Automation Tool); Power Automate test flows |

ROI of test automation is justified when the regression suite exceeds approximately 200 scripts, or when the ERP is on a SaaS quarterly release cycle where each release requires full regression without automation being impractical. Continuous testing pipelines are mandatory for SaaS ERP operations.

### 9.4 Performance Testing Benchmarks

Define peak concurrent user counts and peak document volume (sales orders per hour, journal lines per day, goods receipts per shift) before test design. For SAP S/4HANA: use SAP QuickSizer for initial hardware sizing; HANA memory sizing must account for columnar store compression ratios. Test environments should match production specification tier; cloud environments should use the same instance size as production for performance test validity.

---

## 10. Cloud vs. On-Premise vs. Hybrid

### 10.1 Deployment Model Comparison

| Model | Examples | Upgrade Cadence | Notable Costs | Control Level |
|---|---|---|---|---|
| SaaS / Public Cloud | SAP S/4HANA Cloud Public Edition (GROW with SAP), Oracle Fusion Cloud ERP, Dynamics 365 F&SCM, NetSuite | Quarterly (mandatory; customer cannot defer) | API re-testing per release; integration regression; sandbox tenant fees | Low |
| Private Cloud | SAP Cloud ERP Private (formerly RISE with SAP S/4HANA Cloud Private Edition, rebranded 2025), Oracle Cloud@Customer | Semi-annual | Infrastructure bundle included; per-FUE fees; 2025 packaging unbundled AI/Joule from base | Medium |
| On-Premises | SAP ECC (ERP 6.0), Oracle E-Business Suite (EBS) | Customer-controlled | Hardware refresh cycles; DBA and Basis staffing; data center costs; see ECC maintenance note below | High |
| Hybrid | S/4HANA on-prem core + BTP cloud extensions | Mixed | Complexity of hybrid integration layer; dual environment management | Medium-High |

**SAP ECC maintenance note [12]:** Mainstream maintenance end dates depend on enhancement package (EHP) level. ECC 6.0 EHP 0–5: mainstream maintenance ended December 31, 2025 (no extended maintenance option; only Customer-Specific Maintenance thereafter, which provides no new security patches). ECC 6.0 EHP 6–8: mainstream maintenance ends December 31, 2027; optional extended maintenance available until December 31, 2030 at approximately +2 percentage points additional maintenance fee. These deadlines are the primary migration driver for the global SAP installed base; SAP leadership has confirmed these dates will not be extended.

**Third-party support note:** Rimini Street offers SAP and Oracle extended support services claimed to extend past vendor end-of-maintenance dates. This is a third-party commercial claim, not a commitment from SAP or Oracle. Organizations considering third-party support must evaluate vendor contract terms and implications for future vendor-led upgrades.

### 10.2 Licensing Models

| Model | Structure |
|---|---|
| Named user / concurrent user | On-prem; per-seat charges by user type; audit exposure for under-licensing |
| SAP Cloud ERP Private (formerly RISE with SAP) | Subscription bundle (S/4HANA Cloud Private + BTP credits + infrastructure); priced per FUE (Full-Use Equivalent); typically 3–5 year contracts; 2025 rebranding unbundled AI/Joule from base package [13] |
| GROW with SAP | Subscription targeting mid-market (net-new customers, ~100 employees to 2,000); S/4HANA Cloud Public Edition; standardized pricing tiers with optional premium package for more complex financial requirements |
| Oracle Fusion Cloud ERP | Subscription per PUPM (per user per module per month) for most modules; resource-based for some compute-intensive workloads; highly negotiable at volume |
| Dynamics 365 F&SCM | Named user subscription; base license plus attach licenses for cross-application use (e.g., F&SCM base + Commerce attach) |
| Consumption-based | SAP BTP services; Azure PaaS integration services; AI workloads; pay-per-use |

**Hidden costs to model:** Sandbox and development tenant fees, test system charges, premium support tier uplift (SAP Enterprise Support, Oracle Platinum Services), localization pack fees for additional countries, and integration middleware licensing.

Precise current pricing figures for SAP Cloud ERP Private, Oracle Fusion, and Dynamics 365 vary significantly by volume, geography, negotiation, and contract vintage. The structures above reflect market patterns; actual figures require vendor engagement.

### 10.3 Two-Tier ERP

| Tier | Role | Typical Products |
|---|---|---|
| Tier 1 (HQ) | Group financials, consolidation, group statutory reporting, intercompany | SAP S/4HANA (Group Reporting, Material Ledger), Oracle Fusion Cloud ERP (Financials, Consolidation) |
| Tier 2 (Subsidiary) | Local operational ERP; faster deployment; lower per-unit cost | NetSuite, Dynamics 365 Business Central, Acumatica, Odoo, ERPNext |

Integration pattern: Tier 2 posts financial summaries (journal entries, intercompany balances) to Tier 1 GL. Operational detail (individual sales orders, purchase orders, inventory transactions) remains in Tier 2. The integration is the critical engineering challenge: frequency, reconciliation, currency translation, and intercompany elimination must all be designed explicitly.

Use case: global enterprise with subsidiary diversity in size, industry, or geography; post-acquisition integration where a full Tier 1 deployment to the acquired entity is disproportionate to its size.

### 10.4 Upgrade Cadence Implications

- **SaaS ERP:** Implement once, then manage continuous change. Each quarterly release may introduce behavioral changes to APIs, UI, or business logic. Test automation and a quarterly release readiness process (impact assessment → regression testing → acceptance sign-off) are operational requirements, not optional.
- **On-prem:** Major upgrades every 3–5 years; each upgrade carries re-implementation risk for custom code. SAP ECC to S/4HANA migration is widely treated as a new implementation given the architectural differences (HANA-only database, simplified data model, Fiori UX, Universal Journal in FI).

---

## 11. Post-Go-Live

### 11.1 Continuous Improvement

Scope cut at go-live generates a deferred backlog. Prioritize and schedule post-go-live enhancement sprints with the same governance rigor as the original implementation. Process mining tools (Celonis, SAP Signavio Process Intelligence) identify process deviations and inefficiencies in the live system by analyzing event logs from the ERP database—providing empirical rather than anecdotal evidence of process quality.

**Center of Excellence (CoE):** Internal team governing configuration change management, master data quality, enhancement backlog prioritization, and ERP adoption. The CoE becomes the internal ERP center of gravity after SI disengagement. Without a CoE, ERP quality degrades over time as undocumented configuration changes accumulate.

### 11.2 Release and Upgrade Management

- **Change control board (CCB):** Approves all configuration changes in production. Prevents ungoverned changes from destabilizing the live system.
- **Transport management:** SAP uses CTS/TMS (Change and Transport System / Transport Management System) to move configuration changes from DEV → QA → UAT → PROD. Oracle uses migration processes in Lifecycle Manager. Microsoft Dynamics 365 uses Lifecycle Services (LCS) and environment-to-environment data packages.
- **Cloud ERP quarterly release process:** Impact assessment (review release notes for changes affecting configured functionality) → regression testing (execute automated test suite against updated sandbox tenant) → acceptance sign-off → production update. Continuous testing pipeline is operationally necessary.

### 11.3 User Adoption Monitoring

Measure adoption quantitatively:

| Metric | Interpretation |
|---|---|
| Login rates by role | Low rates indicate training failure or workaround persistence |
| Transaction error rates | High rates indicate insufficient training or UX issues |
| Manual workarounds | Identified via process mining; indicate unresolved gaps or resistance |
| % of POs raised in system | Purchasing compliance; off-system POs bypass controls |
| On-time period close rate | Finance efficiency; delays indicate process or system issues |

Super user feedback loops: monthly super user forums surface adoption issues before they become embedded workarounds.

### 11.4 KPI Tracking and Business Value Realization

Establish baseline values before go-live. Measure at 3, 6, and 12 months post-go-live. Common ERP KPIs:

| KPI | Domain |
|---|---|
| Days Sales Outstanding (DSO) | AR / Cash |
| Inventory turnover | Inventory management |
| On-Time Delivery (OTD) | Fulfillment |
| Days Payable Outstanding (DPO) | AP / Cash |
| Time-to-close (financial period close duration) | Finance |
| Procurement cycle time | Procurement |
| First-pass yield / quality cost | Manufacturing |

Publish a value realization report to the steering committee at 6 and 12 months post-go-live. Tie measured outcomes to the original ROI model. This closes the loop on the business case and informs prioritization of the continuous improvement backlog.

---

## 12. Team Structure

### 12.1 Core Program Roles

| Role | Responsibilities |
|---|---|
| Executive Sponsor | Budget authority; organizational mandate; escalation point; visible commitment |
| Steering Committee | Strategic decisions; scope arbitration; phase go/no-go; risk acceptance |
| Program Manager (PM) | Plan, schedule, budget, RAID log, stakeholder reporting, SI coordination |
| Functional Consultants (SI) | Module configuration, process design, test script authoring, UAT support |
| Technical Consultants (SI) | Custom development, integration builds, performance testing, Basis/infrastructure |
| Business Analysts (BA) | Requirements documentation, gap analysis, UAT coordination, acceptance criteria |
| Super Users | SME per business area; UAT execution; post-go-live floor support; CoE seed team |
| Change Manager | ADKAR/Kotter plan execution; training program; communications; resistance management |
| Data Migration Lead | Data audit, cleansing coordination, ETL execution, reconciliation sign-off |
| Integration Architect | Middleware design, interface inventory, API governance, event schema ownership |
| Security / Auth Consultant | Role design, SoD analysis, authorization testing (see `core/security.md`) |

### 12.2 RACI Template

RACI (Responsible, Accountable, Consulted, Informed) assignment per deliverable. Every deliverable has exactly one Accountable party; multiple parties may be Responsible.

Key decisions requiring explicit RACI:

- Phase go/no-go approval
- Scope change approval (scope increase or deferral)
- Data quality sign-off before migration load
- Production system access grants
- Rollback decision authority

### 12.3 Governance Bodies

| Body | Cadence | Purpose |
|---|---|---|
| Steering Committee | Monthly (weekly during critical phases) | Strategic decisions, risk acceptance, budget arbitration |
| PMO Status Meeting | Weekly | RAID log review, schedule status, dependency management |
| Technical Architecture Board | As needed / bi-weekly | Design decision authority, interface standards, custom code review |
| Change Control Board (CCB) | Weekly (pre/post go-live) | Configuration and code change approvals in UAT/Prod |

---

## 13. Timeline and Cost Benchmarks by Company Size

These ranges reflect market patterns from multiple consultancy and analyst sources (Panorama Consulting annual ERP Report, Gartner, internal SI benchmarks). They are approximate ranges for planning purposes, not guaranteed outcomes.

### 13.1 SMB (< $50M revenue, < 200 employees)

| Attribute | Typical Range |
|---|---|
| ERP products | NetSuite (SuiteBilling, SuiteTax, SuiteAnalytics), Dynamics 365 Business Central, Acumatica, Sage Intacct, Odoo, ERPNext |
| Timeline | 3–6 months |
| Total first-year cost (software + implementation) | Approximately $60K–$300K |
| Implementation-to-license ratio | Often 1:1 to 2:1 (implementation cost equal to or twice license) |
| Typical team | 1–2 functional consultants, 1 PM, internal super users |

### 13.2 Mid-Market ($50M–$500M revenue, 200–2,000 employees)

| Attribute | Typical Range |
|---|---|
| ERP products | SAP S/4HANA via GROW with SAP, Oracle Fusion Cloud ERP, Dynamics 365 F&SCM, NetSuite (upper mid-market), Epicor Kinetic, Infor LN / M3 / CloudSuite |
| Timeline | 9–18 months |
| Total cost (software + implementation) | Approximately $500K–$3M |
| Program cost as % of revenue | 3–6% of annual revenue as benchmark |
| Typical team | 4–10 functional consultants, 2–3 technical consultants, PM, change manager |

### 13.3 Enterprise (> $500M revenue, 2,000+ employees)

| Attribute | Typical Range |
|---|---|
| ERP products | SAP S/4HANA (FI/CO, MM, SD, PP, EWM, TM, Group Reporting, Material Ledger), Oracle Fusion Cloud ERP (Financials, Procurement, PPM, SCM, Manufacturing), Dynamics 365 F&SCM, Infor CloudSuite (industry-specific), Workday Financial Management |
| Timeline | 18–36+ months; global multi-phase programs: 3–5 years |
| Total cost (software + implementation + infrastructure + internal) | Approximately $5M–$100M+ |
| SI engagement (Big 4 / tier-1 SI) | Approximately $10M–$50M for global programs |
| Typical team | 20–100+ consultants; full PMO; dedicated change management workstream |

### 13.4 Failure Rate Context

Qualitative consensus across analyst firms and consultancy surveys is that a significant majority of ERP projects experience cost overruns, schedule slippage, or fail to deliver projected benefits within the original program scope. Precise percentages vary widely across studies based on the definition of "failure" and the survey population; cite specific reports directly rather than repeating generalized figures.

Common cited root causes, consistent across studies:

- Insufficient or disengaged executive sponsorship
- Inadequate data migration preparation (cleansing scope underestimated)
- Scope creep without corresponding budget/timeline adjustment
- Underestimating the change management effort relative to technical delivery
- Compressed implementation timelines (the Hershey and FoxMeyer cases are canonical illustrations)

**AI in ERP (current trend):** Gartner forecasts that approximately 62% of ERP application spending will be on solutions with embedded AI by 2027, up from approximately 14% in 2024. [14] A separate Gartner prediction (February 2026) holds that finance organizations using cloud ERP with embedded AI assistants will achieve a 30% faster financial close by 2028. These trends affect implementation methodology: AI feature configuration, training data quality, and model governance are becoming distinct ERP implementation workstreams.

---

## See also

- `core/architecture.md` — data model design, API layer, multi-tenancy patterns
- `core/features-core.md` — module functional reference (FI/CO, MM, SD, PP, HR, etc.)
- `core/security.md` — role design, SoD analysis, authorization testing, access control
- `core/cautions.md` — known failure patterns, vendor pitfalls, anti-patterns
- `glossary.md` — terminology reference for acronyms and ERP-specific terms

---

## Citations & Sources

1. SAP Activate Methodology — official roadmap, phase guides, and Roadmap Viewer: https://www.sap.com/activate
2. Oracle blog: "Oracle AIM, Oracle ABF, and Siebel Results Roadmap Officially Retired as of January 31, 2011" — Oracle Unified Method Blog: https://blogs.oracle.com/oum/oracle-aim,-oracle-abf,-and-siebel-results-roadmap-officially-retired-as-of-january-31,-2011
3. Microsoft Success by Design framework — Microsoft Learn: https://learn.microsoft.com/en-us/dynamics365/guidance/implementation-guide/implementation-strategy-choose-methodology
4. Hershey Foods 1999 ERP failure — multiple secondary sources including CIO.com ("Supply Chain: Hershey's Bittersweet Lesson") and Panorama Consulting case study. Primary financial data from Hershey Foods Q3 1999 earnings announcement and contemporaneous Wall Street Journal coverage. $112M project cost figure widely cited across academic case studies.
5. FoxMeyer Drug bankruptcy — Scott, J.E. (1999). "The FoxMeyer Drugs' Bankruptcy: Was it a Failure of ERP?" AMCIS 1999 Proceedings: https://aisel.aisnet.org/cgi/viewcontent.cgi?article=1437&context=amcis1999
6. BPMN 2.0 Specification — Object Management Group (OMG): https://www.omg.org/spec/BPMN/2.0/
7. ISO 3166 Country Codes: https://www.iso.org/iso-3166-country-codes.html
8. ISO 4217 Currency Codes: https://www.iso.org/iso-4217-currency-codes.html
9. SAP Knowledge Base Article 2988692 — SAP S/4HANA Migration Cockpit information and LTMC deprecation: https://userapps.support.sap.com/sap/support/knowledge/en/2988692
10. Prosci ADKAR Model — Jeff Hiatt, Prosci founder. Hiatt, J.M. (2006). *ADKAR: A Model for Change in Business, Government and Our Community*. Prosci Learning Center Publications: https://www.prosci.com/methodology/adkar
11. Kotter, J.P. (1996). *Leading Change*. Harvard Business Review Press.
12. SAP ECC and Business Suite 7 end-of-support calendar — SAP Support Portal: https://support.sap.com/en/product-support/end-of-support-calendar.html
13. RISE with SAP / SAP Cloud ERP Private 2025 packaging changes — SAP licensing experts and Rimini Street analysis: https://saplicensingexperts.com/sap-private-cloud-bundle-and-tier-changes-in-2025/
14. Gartner Press Release, February 24, 2026: "Gartner Predicts Embedded AI in Cloud ERP Applications will Drive a 30% Faster Financial Close by 2028" — includes the 62%/14% AI spending forecast: https://www.gartner.com/en/newsroom/press-releases/2026-02-24-gartner-predicts-embedded-ai-in-cloud-erp-applications-will-drive-a-30-percent-faster-financial-close-by-2028
15. Gartner Magic Quadrant for Cloud ERP for Product-Centric Enterprises (2025): https://www.gartner.com/en/documents/7058198
16. Gartner Magic Quadrant for Cloud ERP for Service-Centric Enterprises (2025): https://www.gartner.com/en/documents/7047499
17. Gartner Magic Quadrant for Cloud ERP Finance (2025): https://www.gartner.com/en/documents/7109030
18. Panorama Consulting Group ERP Report — annual benchmarks on implementation timelines, costs, and outcomes: https://www.panorama-consulting.com/resource-center/
19. Standish Group CHAOS Report — annual IT project success and failure rate tracking
20. ISO/IEC 27001:2022 Information Security Management: https://www.iso.org/standard/27001
21. SOC 2 (AICPA Trust Services Criteria): https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2
22. Microsoft FastTrack for Dynamics 365: https://learn.microsoft.com/en-us/dynamics365/fasttrack/
