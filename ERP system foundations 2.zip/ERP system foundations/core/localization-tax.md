# Global Localization, Tax & e-Invoicing

## 1. Indirect Tax Fundamentals

### 1.1 Tax Type Taxonomy

**VAT (Value Added Tax)** is a destination-principle, multi-stage consumption tax with a credit mechanism: each supplier collects output tax from the buyer and deducts input tax paid to its own suppliers, remitting only the net to the tax authority. The EU root authority is Council Directive 2006/112/EC (the "Principal VAT Directive"), amended most recently by the ViDA package (Council adopted March 11 2025; entered into force April 14 2025 — see §3.2). [1] Standard rates: Germany 19%, France 20%, UK 20%, Sweden 25%. Reduced rates apply to food, pharmaceuticals, and culture in most jurisdictions.

**GST (Goods and Services Tax)** is functionally equivalent to VAT; name differs by country:

| Country | GST Rate(s) | Notes |
|---|---|---|
| Australia | 10% | Single federal rate; A New Tax System (Goods and Services Tax) Act 1999 |
| Canada | 5% federal (GST) | Provinces add HST (combined 13–15%) or PST separately |
| India | Dual GST: Central (CGST) + State (SGST) | 4 main slabs: 5%, 12%, 18%, 28%; compensation cess on sin goods; integrated IGST for interstate |
| New Zealand | 15% | Single rate; Goods and Services Tax Act 1985; one of the broadest-base GST systems globally |
| Singapore | 9% (from January 1 2024) [2] | Rose from 8%; rate confirmed by IRAS; further increases must be verified at iras.gov.sg |

**US Sales & Use Tax** has no federal equivalent. Forty-five states plus the District of Columbia levy sales tax, administered through thousands of distinct local jurisdictions — county, city, and special taxing districts. There is no national uniform base: what is taxable in one state is exempt in another (e.g., clothing in New York vs. California).

*South Dakota v. Wayfair, Inc.*, 585 U.S. 162 (decided June 21 2018) [3] overturned the physical-presence nexus rule from *Quill Corp. v. North Dakota* (1992). The Supreme Court held that "substantial nexus" can be satisfied by economic presence alone. Every state thereafter enacted economic nexus laws; the most common threshold is $100,000 in annual revenue *or* 200 individual transactions into the state — many states are now dropping the transaction-count prong. No two state statutes are identical. ERP tax determination must evaluate nexus per state per seller entity continuously.

**Consumption tax** variants: Japan's JCT (Japan Consumption Tax) at 10% standard (reduced 8% on food/newspapers); Taiwan's 5% VAT; South Korea's VAT at 10%.

**Excise taxes** apply to specific goods: fuel, tobacco, alcohol, gambling receipts. They are *ad valorem* (percentage of value) or *per unit* (e.g., US federal excise on beer per barrel). Excise determination is separate from VAT/GST and uses commodity-code-based lookup tables.

### 1.2 Data Model — Tax Line

```json
{
  "tax_line": {
    "jurisdiction_code": "US-CA-LA",
    "tax_type": "SALES",
    "tax_code": "CA_STATE_9.5",
    "taxable_amount": 1000.00,
    "tax_amount": 95.00,
    "rate": 0.095,
    "reverse_charge": false,
    "place_of_supply": "destination",
    "exemption_cert_id": null,
    "reporting_period": "2025-Q1"
  }
}
```

Key fields: `jurisdiction_code` uses a hierarchical scheme (country → state → county/city); `reverse_charge` triggers buyer self-assessment; `place_of_supply` determines which country's rate applies for cross-border services; `exemption_cert_id` links to the stored certificate record with its own validity dates.

---

## 2. Tax Determination Engines

### 2.1 Jurisdiction Resolution Architecture

US sales tax jurisdiction mapping is more complex than a ZIP code lookup: ZIP codes routinely cross county and city tax boundaries. Rooftop-level geocoding (latitude/longitude matched against jurisdiction polygons) is significantly more accurate than ZIP-to-jurisdiction tables, which can be wrong near jurisdiction boundaries. Avalara uses rooftop-level GIS data covering 12,000+ US jurisdictions. [4]

Resolution hierarchy: **country → state/province → county → city → special taxing district** (e.g., transportation district, stadium district). Each level may impose its own rate on its own tax base; stacking rules vary.

Transaction attributes fed into the determination engine:

- **Ship-from address**: determines origin-sourcing states (Texas; Illinois prior to its 2019 shift toward destination sourcing)
- **Ship-to address**: used in 30+ destination-sourcing states
- **Bill-to address**: relevant for services in some jurisdictions
- **Supply type**: tangible personal property, digital goods, SaaS, professional services — taxability varies enormously per category
- **Buyer type**: B2B (resale certificate?), B2C, government entity (often exempt)
- **Product tax category**: UNSPSC code or vendor-proprietary taxability code maps to rate/exemption rules per jurisdiction

**EU Place-of-Supply Rules (B2C digital services):** Since January 1 2015, electronically supplied services to EU consumers are taxed in the *buyer's* member state. The One-Stop Shop (OSS) scheme (mandatory from July 1 2021) eliminates multi-country VAT registration below thresholds — suppliers register once in one EU member state and file a single OSS return for all EU B2C sales.

### 2.2 Tax Codes, Reverse Charge & Exemption Certificates

**Tax codes** map the combination of (transaction type, jurisdiction, effective date) → rate and behavior flags. They must carry version history with effective-date ranges; a rate change in January must not recalculate closed prior-period documents.

**Reverse charge mechanism** requires the buyer to self-assess output VAT and claim the corresponding input VAT simultaneously — net cash-flow neutral, but mandatory for audit compliance. Key EU applications:
- Cross-border B2B supply: Article 196, Council Directive 2006/112/EC
- Construction sector domestic reverse charge: Article 199, Council Directive 2006/112/EC

ERP implementation: the supplier's invoice shows "Reverse Charge — VAT Amount 0; customer to account for VAT under Article 196 2006/112/EC." The buyer's ERP posts both output and input tax lines from the same AP document.

**Exemption certificates** (US) include resale certificates, direct-pay permits, and exempt-use certificates. ERP requirements:
- Store certificate number, issuing state, buyer's tax ID, valid-from/valid-to dates, eligible goods category
- Block certificate expiry from being used on new transactions without renewal
- Support bulk exempt-customer validation via external certificate management services (Avalara CertCapture, Vertex Certificate Center)

EU equivalent: verified VAT registration numbers of buyer serve as proof of B2B status, allowing zero-rated intra-community supply. ERP must validate VATINs against VIES (VAT Information Exchange System) at transaction time.

### 2.3 Third-Party Tax Engine Integration

| Vendor | Product | Primary Strength | Integration Method |
|---|---|---|---|
| Avalara | AvaTax | Mid-market and enterprise; 12,000+ US jurisdictions; cloud-native | REST/OAuth 2.0; connectors for SAP, NetSuite, D365, Salesforce |
| Vertex | O Series Cloud / Tax Links | Enterprise; complex product taxability matrices; real-time + batch modes | OAuth 2.0 (VERX IDP); SOAP and REST API |
| Thomson Reuters | ONESOURCE Indirect Tax | Large multinationals; 185+ countries; deep audit trail; strong VAT | REST / WS-Security; SAP and Oracle certified connectors |
| Sovos | Sovos Tax Determination + CTC suite | Global; especially strong LATAM + EU CTC/e-invoicing mandate coverage | REST API; covers clearance + reporting obligations |
| SAP native | FI-TX tax codes + condition technique; SAP Tax Compliance | Embedded; condition pricing (SD pricing + MM purchasing); BAPI_TAX_CALC for external | Internal; optional Vertex/Avalara OCC connector |
| Oracle native | Oracle Fusion Cloud Tax (within Oracle Financials Cloud) | Rules-based; regime/rate model; party qualification; product fiscal classification | Internal engine; optional Vertex connector |
| Microsoft native | D365 Finance Tax Calculation Service (Global Tax Engine) | Rule-designer introduced ~2019; China/India complexity; extensible conditions | Internal; Avalara ISV via AppSource |
| NetSuite | SuiteTax (native engine) | Country SuiteApps per locale; included at no extra cost | Internal; Avalara/Vertex via SuiteApp Marketplace |

**Integration pattern:** ERP triggers a synchronous REST call to the external engine at document-save time, passing a transaction context object. The engine returns one or more tax lines. ERP stores these lines and includes them in the accounting entry. No re-calculation occurs at payment time for most indirect taxes. See §12 for architecture details including circuit-breaker patterns for engine failures.

### 2.4 Withholding Tax

#### Vendor WHT — General

Withholding tax on vendor payments applies to interest, royalties, dividends, and in many countries to service fees paid to non-residents (and sometimes residents). ERP stores WHT codes per vendor-income type combination, with treaty override fields per country pair.

SAP S/4HANA offers two WHT procedures:
- **Classic Withholding Tax**: calculated at invoice posting time; suitable for countries where tax withheld on accrual basis
- **Extended Withholding Tax**: calculated at payment time; required for US 1099/1042-S and most payroll-adjacent scenarios; supports partial payments, down-payments, and clearing

#### US 1099 & 1042-S

| Form | Applies To | Key Threshold | Filing Deadline |
|---|---|---|---|
| 1099-NEC | Nonemployee compensation (US persons) | ≥ $600 per payee per year | January 31 to IRS and payee |
| 1099-MISC | Rents, prizes, royalties, medical payments | ≥ $600 (varies by box) | January 31 |
| 1099-INT | Interest income paid | ≥ $10 | January 31 |
| 1042-S | US-source income to foreign persons | All amounts reportable | March 15 to IRS; March 15 to recipient |

ERP requirements for 1099/1042-S:
- Vendor master flag: US person vs. foreign person; W-9 / W-8BEN received flag
- ITIN or EIN field on vendor master; storage of treaty country code and income type code (1042-S has 52+ income codes)
- Year-end accumulation of reportable payments across AP, Payroll, and treasury modules
- IRS electronic filing via FIRE (Filing Information Returns Electronically) system or approved substitute
- SAP Extended Withholding Tax: report **RFIDYYWT** generates 1099 data; DMEE (Data Medium Exchange Engine) formats the IRS Publication 1220 e-file record — verify report name against current release notes

---

## 3. e-Invoicing & Continuous Transaction Controls (CTC) by Country

### 3.1 CTC Model Classification

| Model | Description | Examples |
|---|---|---|
| Post-audit | Seller issues invoice freely; tax authority audits periodically | Traditional; most of the world prior to 2010 |
| Clearance | Invoice submitted to tax authority before delivery to buyer; authority validates and returns stamped invoice | India, Brazil (NF-e), Mexico (CFDI), Saudi Arabia (Phase 2), Turkey (e-Fatura) |
| Near-real-time reporting | Structured data sent to authority shortly after issuance | Italy (SdI), Saudi Arabia (simplified B2C within 24 hours) |
| Decentralized / DRR | Structured transaction data reported periodically, not per-invoice clearance | Germany (transitional), EU ViDA DRR (July 1 2030 target) |

### 3.2 Country-by-Country e-Invoicing Reference

#### India — GST e-Invoice & e-Way Bill

India's clearance model operates through the **Invoice Registration Portal (IRP)** network, governed by GSTN (Goods and Services Tax Network). The supplier submits an invoice JSON payload to one of the authorized IRPs, which validates it, generates an **IRN (Invoice Reference Number)** — a 64-character hash — and embeds a signed **QR code**. The stamped payload is returned to the supplier.

The mandate has stepped down through successive Annual Aggregate Turnover (AATO) thresholds:

| Effective Date | AATO Threshold |
|---|---|
| October 1 2020 | ₹500 crore |
| January 1 2021 | ₹100 crore |
| April 1 2021 | ₹50 crore |
| April 1 2022 | ₹20 crore |
| October 1 2022 | ₹10 crore |
| August 1 2023 | ₹5 crore (current mandatory threshold) |

From **April 1 2025**, taxpayers with AATO ≥ ₹10 crore cannot report IRNs for documents older than 30 days — real-time discipline is enforced at the IRP level, with rejected IRNs invalid for Input Tax Credit (ITC) purposes. [5]

The **e-Way Bill (EWB)** is a separate system on the NIC portal for movement of goods worth ≥ ₹50,000. It generates an EWB number that must be linked to the IRN for road transport.

ERP integration: REST API call to IRP (six government-operated IRPs plus private accredited IRPs); response embeds IRN and QR code data URI into the printed invoice output. IRN must be archived for 8 years per GST rules.

#### Italy — SdI / FatturaPA

Italy was the **first EU country to mandate B2B e-invoicing** via the *Sistema di Interscambio* (SdI), operated by *Agenzia delle Entrate* (AdE):

- B2G mandate: June 6 2014
- B2B and B2C mandate: January 1 2019
- Remaining small taxpayers below €25,000 annual turnover: phased from July 2022; effectively all since January 1 2024

Format: **FatturaPA XML**, aligned with EN 16931:2017+A1:2019, digitally signed using **XAdES-BES**. Invoice is transmitted to SdI (not directly to the buyer); SdI validates, stamps with a receipt, and forwards to the buyer's fiscal code or PEC (certified email). Rejection returned within 5 days.

EU derogation: **Decision (EU) 2024/3150** (OJ L, December 19 2024) [6] extends Italy's SdI mandate derogation from Articles 218 and 232 of Directive 2006/112/EC to **December 31 2027**, confirming Italy's mandate pre-dates and co-exists alongside the ViDA framework.

**Telematic Cash Registers (RT):** Mandatory for retail and B2C sales:
- July 1 2019: large businesses (annual revenue > €400,000)
- July 1 2020: all businesses (some extensions; effectively all by January 1 2021)

The RT device (hardware or **RT Server** software option for multi-lane retail) transmits daily fiscal totals as XML to AdE via HTTPS. Customers receive a non-fiscal *documento commerciale*. RT certification authority: MEF (*Ministero dell'Economia e delle Finanze*) in regulatory text; operational oversight delegated to AdE — verify current authority at AdE documentation. [7]

#### Brazil — NF-e, NFS-e, and SPED

Brazil operates one of the earliest and most comprehensive CTC ecosystems, administered by SEFAZ (Secretaria da Fazenda) at state level:

| Document | Scope | Portal |
|---|---|---|
| NF-e (Nota Fiscal Eletrônica) | Physical goods | State SEFAZ; federal authorization via SEFAZ Nacional; DANFE printed representation |
| NFS-e | Services | National NFS-e mandatory January 1 2026 under Constitutional Amendment 132/2023 tax reform (Complementary Law PLP 68/2023) [8] |
| CT-e | Transportation | SEFAZ; electronic transport document |
| NF3e | Electricity supply | SEFAZ |
| NFCom | Telecommunications | Mandatory November 1 2025 |
| NFC-e | Consumer fiscal receipt (retail) | Mandatory digital fiscal receipts from 2026 per tax reform |

**SPED (Sistema Público de Escrituração Digital):** digital bookkeeping system with sub-components:
- **ECD** (Escrituração Contábil Digital): electronic accounting books
- **ECF** (Escrituração Contábil Fiscal): corporate income tax
- **EFD-ICMS/IPI**: state ICMS and federal IPI indirect tax ledgers
- **EFD-Contribuições**: federal PIS/COFINS contributions

Archiving requirement: minimum **132 months (11 years)** in digital format from May 1 2025 for NF-e, NFC-e, CT-e, CT-e OS, MDF-e, BP-e, NF3e, GTV-e, DC-e, and NFCom. [8]

#### Mexico — CFDI 4.0

Mexico's clearance model uses the **CFDI (Comprobante Fiscal Digital por Internet)** standard, validated by SAT-authorized **PAC (Proveedor Autorizado de Certificación)** intermediaries:

1. Supplier creates XML invoice signed with its **CSD (Certificado de Sello Digital)**
2. Supplier submits to a PAC; PAC validates schema, RFC codes, and stamps a **UUID (folio fiscal)** — the legal document identifier
3. Stamped CFDI transmitted to SAT (Servicio de Administración Tributaria) in real time; recipient must receive within 3 calendar days

**CFDI 4.0** became mandatory from **April 1 2023** (CFDI 3.3 permitted January–March 2023, sunset March 31 2023). [9] Key changes in 4.0: mandatory receiver legal name and RFC; mandatory `RégimenFiscalReceptor` and `DomicilioFiscalReceptor` (postal code) validated against SAT catalogs; global invoice (*comprobante global*) for B2C cash transactions below reporting threshold; new export complement.

Key **Complementos** (supplemental XML schemas):
- **Complemento de Nómina 1.2**: payroll
- **Complemento de Pagos 2.0**: payment receipts for installment transactions
- **Complemento de Comercio Exterior**: foreign trade

Penalties: MXN 19,700 to MXN 112,650 per incident for non-compliance.

#### Saudi Arabia — ZATCA Fatoorah

The **Zakat, Tax and Customs Authority (ZATCA)** operates the Fatoorah platform in two phases:

- **Phase 1 — Generation** (December 4 2021): All VAT-registered businesses must generate compliant structured e-invoices. B2B: XML with QR code and digital signature. B2C: simplified invoice with QR code (PDF/A-3).
- **Phase 2 — Integration/Clearance** (from January 1 2023, wave-based rollout): B2B invoices cleared via ZATCA in real time before delivery to buyer. B2C simplified invoices reported within 24 hours.

Wave rollout by annual turnover threshold (sample waves): [10]

| Wave | Target Date | Turnover Threshold (2022–2024 revenue) |
|---|---|---|
| Wave 1 | January 1 2023 | > SAR 3 billion |
| Wave 2 | July 1 2023 | > SAR 500 million |
| Wave 22 | December 31 2025 | SAR 1 million – SAR 1.25 million |
| Wave 23 | March 31 2026 | SAR 750,000 – SAR 1 million |
| Wave 24 | June 30 2026 | SAR 375,000 – SAR 750,000 |

Technical specifications: **XML UBL 2.1**-based schema; **XAdES** digital signature; QR code encoding per ZATCA specification; CSID (Cryptographic Stamp Identifier) onboarding required before Phase 2 integration.

#### EU — ViDA (VAT in the Digital Age)

The ViDA legislative package was adopted by the EU Council on **March 11 2025** (following European Parliament vote February 12 2025 and ECOFIN political agreement November 5 2024), published in the Official Journal March 25 2025, and entered into force **April 14 2025**. [1] It amends Council Directive 2006/112/EC across three pillars:

1. **Digital Reporting Requirements (DRR)** and mandatory e-invoicing
2. **Platform Economy** deemed-supplier VAT treatment
3. **Single VAT Registration** (OSS expansion)

Implementation timeline:

| Date | Obligation |
|---|---|
| April 14 2025 | Entry into force; Member States may introduce mandatory domestic e-invoicing without prior EU derogation; IOSS improvements |
| January 1 2027 | OSS/IOSS legislative clarifications; Single VAT Registration improvements begin |
| July 1 2028 | Platform economy deemed-supplier rules for short-term accommodation and passenger transport; expanded OSS; mandatory reverse charge for certain cross-border supplies |
| **July 1 2030** | **Mandatory cross-border B2B e-invoicing (EN 16931-compliant) + real-time DRR go-live** [11] |
| January 1 2035 | All Member State domestic e-invoicing systems must align with EU standards |

Cross-border intra-EU B2B e-invoices under ViDA DRR must be issued within 10 days of the chargeable event and reported to the national tax authority within the same window. Pre-2030, Member States may legislate national schemes without prior EU approval (Germany, France, Poland, Italy have already done so).

#### Poland — KSeF

**KSeF (Krajowy System e-Faktur)** is Poland's national clearance platform: [12]

- **Format**: FA_VAT structured XML (verify exact schema version at Ministerstwo Finansów)
- **Mandatory timeline**:
  - **February 1 2026**: taxpayers whose prior-year sales (including VAT) exceeded PLN 200 million
  - **April 1 2026**: all other VAT-registered businesses
  - **January 1 2027**: micro-entrepreneurs with monthly sales under PLN 10,000 (extended adaptation period)
- Invoices receive a **KSeF reference number** upon clearance; stored in KSeF for 10 years
- From February 2026 all entities in scope must be capable of both issuing **and** receiving through KSeF

ERP must support: XML generation per FA_VAT schema, KSeF API integration for submission, reference number storage on the invoice record, and status polling.

#### France — PDP / Factur-X

France's B2B mandate uses certified private intermediaries called **PDP (Plateformes de Dématérialisation Partenaires)** accredited by DGFiP (*Direction Générale des Finances Publiques*); Chorus Pro remains B2G only. The PDP network connects to the public **PPF (Portail Public de Facturation)** and to other PDPs. The approved PDP list is evolving — flag accreditation status in implementation planning. [13]

**Accepted formats**: **Factur-X** (hybrid PDF/A-3 + embedded CII XML, EN 16931-compliant), **UBL 2.1**, and **UN/CEFACT CII (Cross Industry Invoice) 3.0**.

**Mandatory B2B timeline**: [13]
- **September 1 2026**: large enterprises (> 250 employees and > €50M turnover, or > €43M balance sheet) must issue and receive compliant e-invoices
- **September 1 2027**: SMEs and micro-enterprises

**e-Reporting obligation**: B2C transactions and cross-border transactions must have transaction data reported to DGFiP.

#### Germany — XRechnung / ZUGFeRD

Germany's B2B e-invoice mandate was enacted under the **Wachstumschancengesetz** (Growth Opportunities Act, enacted March 22 2024): [14]

| Date | Obligation |
|---|---|
| **January 1 2025** | All businesses must be capable of **receiving** structured e-invoices |
| **January 1 2027** | Businesses with prior-year turnover > €800,000 must **issue** structured e-invoices (domestic B2B) |
| **January 1 2028** | **All businesses** must issue structured e-invoices regardless of size |

**Formats**:
- **XRechnung**: DE-specific pure XML profile of EN 16931:2017+A1:2019; required for B2G via PEPPOL or Leitweg-ID routing
- **ZUGFeRD 2.x** (version 2.3 or higher recommended): hybrid PDF/A-3 + embedded CII XML, EN 16931-compliant; functionally equivalent to French Factur-X; cross-compatible
- Both formats acceptable for B2B domestic mandate

Non-compliance penalty: up to €5,000 per offense. Transmission: via **PEPPOL network** (4-corner model with certified access points) or bilateral agreement.

#### Turkey — e-Fatura / e-Arşiv / e-İrsaliye

Turkey's mandates are administered by **GİB (Gelir İdaresi Başkanlığı)**: [15]

- **e-Fatura**: mandatory B2B e-invoice for businesses with annual gross sales revenue exceeding TRY 3 million; lower TRY 500,000 threshold for e-commerce platforms, real estate, and motor vehicle dealers; zero-threshold for accommodation/hotel sector; routed via GİB platform or certified intermediary; format: **UBL-TR** (UBL 2.1 Turkey profile); signed with **XAdES**; 10-year digital archiving requirement
- **e-Arşiv**: B2C invoices or invoices to non-e-Fatura-registered counterparts; above the same turnover thresholds; includes QR code; threshold for unregistered buyers: TRY 3,000 (updated 2025)
- **e-İrsaliye**: electronic dispatch note (waybill) for goods movement; mandatory for same threshold businesses

#### Latin America — Chile, Peru, Colombia

**Chile**: DTE (Documento Tributario Electrónico) mandatory since 2018 for all taxpayers. Clearance model via SII (*Servicio de Impuestos Internos*); format: **XML_DTE** with digital signature; 6-year archiving requirement.

**Colombia**: Factura electrónica via DIAN (*Dirección de Impuestos y Aduanas Nacionales*) clearance model. Mandatory for all large taxpayers from November 2020; technical specification version 1.9 compliance required from February 1 2024; electronic POS receipts mandatory for large taxpayers from February 3 2024 and remaining income-tax filers from March 1 2024. [16] DIAN validates and issues CUFE (Unique Electronic Invoice Code). Resolution 000119/2024 introduced significant modifications.

**Peru**: e-invoicing via SUNAT using the **OSE (Operadores de Servicios Electrónicos)** operator model — third-party OSE providers validate invoices before transmitting to SUNAT. Document types: *factura* (B2B), *boleta de venta* (B2C), *nota de crédito/débito*. Precise 2024+ mandatory extension dates by taxpayer tier should be verified against current SUNAT resolutions.

---

## 4. SAF-T and Tax Audit Files

### 4.1 OECD SAF-T Standard

The OECD SAF-T (Standard Audit File for Tax) framework defines XML-based exports of accounting and tax data for use by tax authorities during audits or as periodic statutory submissions. Core data modules: General Ledger, Accounts Receivable, Accounts Payable, Fixed Assets, Inventory, Payroll. National implementations diverge significantly in schema, scope, submission frequency, and whether submission is mandatory or audit-triggered.

### 4.2 Country SAF-T Variants

| Country | Local Name | Submission Trigger | Scope |
|---|---|---|---|
| Portugal | SAF-T (PT) | Monthly (invoicing) + annual accounting | GL, invoicing; mandatory since 2008; SAFT-PT schema |
| Norway | SAF-T Financial | On-demand (tax authority audit request) | GL, AR/AP, fixed assets; mandatory capability from January 1 2020 |
| Poland | JPK (Jednolity Plik Kontrolny) | Monthly VAT (JPK_V7M/JPK_V7K); on-demand for other modules | VAT registers, GL journal, invoices, bank statements |
| France | FEC (Fichier des Écritures Comptables) | On-demand (audit); must be producible on D+1 | GL journal entries in fixed flat-file format; mandatory since 2014 |
| Luxembourg | SAF-T (LU) | On-demand | GL |
| Lithuania | SAF-T (LT) | On-demand | GL, AR/AP |
| Austria | SAF-T (AT) | On-demand (relaunched ~2024) | GL |
| Romania | SAF-T (D406) | Monthly (large); quarterly (medium); annual (small) | GL, AR/AP, fixed assets, stock; phased from 2022 |
| Bulgaria | SAF-T | Phased from 2026 | GL |

Poland's JPK is the most extensive in scope and the only one with a monthly mandatory submission cadence for VAT (JPK_V7M for monthly filers, JPK_V7K for quarterly). ERP must generate per-schema, per-period exports via a dedicated report or localization module.

---

## 5. EU Statistical & Summary Reporting

### 5.1 Intrastat

Intrastat is the EU statistical system for measuring cross-border goods flows between member states, operational since January 1 1993. It is a statistical obligation, not a tax obligation — but tax authorities frequently cross-reference it against EC Sales Lists and VAT returns.

- **Submission**: monthly to the national statistics body (e.g., INSEE in France, Destatis in Germany)
- **Threshold**: triggered only when intra-EU arrivals or dispatches exceed country-specific annual thresholds; verify per member state annually as thresholds are revised
- **Data elements**: CN 8-digit commodity code, partner member state (ISO 3166-1 alpha-2), nature of transaction code (two-digit), net mass (kg), supplementary quantity where required, statistical value
- ERP must assign CN codes to products, capture ship-from/ship-to country per delivery, and aggregate for the Intrastat declaration

### 5.2 EC Sales List (Recapitulative Statement / ESL)

The EC Sales List (Recapitulative Statement under Articles 262–271 of Directive 2006/112/EC) summarizes zero-rated intra-community supplies of goods and services to VAT-registered buyers in other member states:

- Filed monthly (or quarterly if value below threshold)
- Triggered from the first intra-community supply, regardless of value
- Data: buyer VATIN, net supply value, indicator for goods/services/triangular transactions

ViDA DRR (effective July 1 2030) will supplement or replace the ESL with per-transaction digital reporting, shifting from periodic summary to near-real-time transaction-level data. [11]

---

## 6. Statutory & Legal Reporting

### 6.1 Local GAAP vs. IFRS

ERP parallel ledger architecture must cleanly separate IFRS and local GAAP accounting entries:

| Framework | Applicability | ERP Implementation |
|---|---|---|
| IFRS (as adopted by EU) | Mandatory for consolidated statements of EU-listed companies under IAS Regulation 1606/2002 | SAP: Non-Leading Ledger or Extension Ledger; Oracle: Secondary Ledger; D365: posting layer (Current/Operations/Tax) |
| US GAAP (FASB ASC Codification) | US public companies; most large US private companies | Standard US chart of accounts; parallel ledger for IFRS reconciliation where needed |
| French PCG / ANC norms | French statutory subsidiary reporting | Class 1–8 account numbering; see §6.2 |
| German HGB | German statutory (Handelsgesetzbuch) | SKR03/SKR04 chart variants; HGB closing entries differ from IFRS |
| Spanish PGC | Spanish statutory under RD 1514/2007 | 7-group system |
| Italian OIC standards | Italian statutory; based on Codice Civile | No single mandated account numbering |
| Dutch GAAP / Burgerlijk Wetboek Book 2 | Netherlands statutory | Per company — chart varies |

SAP S/4HANA Finance uses the **Universal Journal (ACDOCA table)** to store all accounting entries; parallel accounting achieved via ledger assignment at document entry (RLDNR field).

### 6.2 Statutory Charts of Accounts

| Country | Chart / Authority | Structure |
|---|---|---|
| France | PCG (Plan Comptable Général) — authority: ANC (Autorité des Normes Comptables) | Decimal 8-class: 1=Capital, 2=Fixed Assets, 3=Inventories, 4=Third-Party Accounts, 5=Financial Accounts, 6=Expenses, 7=Revenue, 8=Special Accounts |
| Spain | PGC (Plan General de Cuentas) under RD 1514/2007 | 7-group system; more IFRS-aligned than French PCG; revised 2007 aligning with IAS/IFRS concepts |
| Germany | SKR03 / SKR04 (DATEV standard charts; basis: HGB) | Two common variants differing in account sequence; de facto standard — not legally mandated numbering, but universally adopted in German practice |
| Austria | ÖKR (Österreichischer Kontenrahmen) | Aligned with German approach; basis: UGB (Unternehmensgesetzbuch) |
| Italy | No single mandated numbering; based on Codice Civile + OIC standards | Chart typically 4–5 digits; varies by industry and size |
| Belgium | PMCN (Plan Comptable Minimum Normalisé) | Mandatory minimum chart; companies may expand |

---

## 7. ERP Localization Packs

### 7.1 SAP S/4HANA Country Versions

SAP delivers country-specific legal requirements as part of its standard release cycle. SAP ECC 6 EHP 6–8 mainstream maintenance ends December 31 2027, with extended maintenance through December 31 2030 (at additional cost); SAP S/4HANA is the current strategic flagship. [17]

- **Tax**: condition technique (SD pricing procedure + MM purchasing schema); FI-TX tax codes with validity periods; BAPI_TAX_CALC for external engine integration
- **Extended Withholding Tax** (FI-AP/AR): country-specific WHT types and codes; report **RFIDYYWT** for US 1099 generation; DMEE (Data Medium Exchange Engine) for IRS e-file Publication 1220 format
- **e-Invoicing**: **SAP Document and Reporting Compliance (SAP DRC)** module covers India GST e-invoice (IRP integration), Saudi Arabia ZATCA Fatoorah, Italy FatturaPA, Mexico CFDI 4.0, Poland KSeF, France PDP, Germany XRechnung/ZUGFeRD, and others; expanding per quarterly release
- **Legal reporting**: SAP Localization Hub + regulatory change management lifecycle; structured delivery of regulatory updates per release
- **Parallel accounting**: Universal Journal (ACDOCA) with ledger-level posting; Extension Ledgers for additive parallel values
- **Payroll**: SAP HCM and SAP SuccessFactors Employee Central Payroll; country payroll engines using PCR (Personnel Calculation Rules) + calculation schemas for 50+ countries

### 7.2 Oracle Fusion Cloud ERP Localizations

- **Oracle Fusion Cloud Tax** (within Oracle Financials Cloud): rules-based engine using a **regime/rate model**; configuration elements include: tax regimes, taxes, tax statuses, tax rates, tax rules (party qualification, product fiscal classification, place of supply derivation)
- Country-specific localizations maintained per quarterly release; Oracle Help Center Localizations section is the authoritative reference
- **e-Invoicing**: Oracle Fiscal Document Capture + Document Compliance for Brazil NF-e, Mexico CFDI, India GST e-invoice
- **Withholding tax**: Oracle Payables Withholding Tax module; 1099 reporting via year-end close process; Oracle Cloud HCM Payroll localized for 30+ countries using the Fast Formula engine

### 7.3 Microsoft Dynamics 365 Finance & Supply Chain Management

- **Tax Calculation Service** (Global Tax Engine): extensible rule-based tax designer introduced ~2019 to handle China Golden Tax complexity; supports custom conditions via configuration rather than code
- **Electronic Reporting (ER) framework**: declarative data model + format mapping; country localization features delivered through **Feature Management** as separate toggleable features per release
- **Electronic Invoicing Service**: cloud service supporting CFDI (Mexico), ZATCA (Saudi Arabia), FatturaPA (Italy), OIOUBL (Denmark), and others; expanding per update cycle
- **Regulatory updates**: Microsoft publishes Regulatory Alerts and Localization scope guides per country per release cycle; accessible in Lifecycle Services (LCS) and Microsoft admin portal

### 7.4 NetSuite SuiteTax

- **SuiteTax**: native tax engine replacing the legacy "Tax Groups" module; included at no extra cost; uses nexus objects, tax code groups, and tax types
- Country-specific SuiteApps required for local regulatory compliance beyond basic tax calculation:
  - Brazil: Brazil Localization SuiteApp (NF-e generation, SPED)
  - India: India GST SuiteApp (e-invoice IRP integration)
  - Chile: Chile Localization SuiteApp (DTE)
  - UK: VAT100 return, MTD (Making Tax Digital) integration
- **Tax Reporting Framework** + country SuiteApp generates localized VAT return formats

### 7.5 Other ERP Systems

- **Odoo**: fiscal positions map product and account tax codes per customer/supplier location; country modules follow naming convention `l10n_[cc]` (e.g., `l10n_br` for Brazil NF-e, `l10n_in` for India GST e-invoice — verify module names against current Odoo 17/18 module registry as naming may shift between major versions)
- **ERPNext**: regional fiscal compliance via apps and community modules; India GST module covers e-invoicing and e-Way Bill; other countries vary in maturity
- **Sage Intacct**: US-centric design; Avalara AvaTax integration for US sales tax; limited native international VAT/GST capability
- **Infor LN / M3 / CloudSuite**: localization coverage varies by product line; LN has stronger manufacturing-sector localization in Western Europe

---

## 8. Internationalization (i18n) & Localization Engineering

### 8.1 Unicode & Character Sets

All ERP text fields must use **Unicode** — UTF-8 for storage and interchange (web APIs, file formats); UTF-16 in some internal runtimes (Java, .NET). Avoid ISO 8859-x encodings in new development; treat them as conversion concerns for legacy data migration only.

**Collation**: database collation must match the target locale for correct sorting. Notable exceptions to ASCII sort order:
- Swedish: `ä`, `å`, `ö` sort *after* z
- Turkish: dotted `İ`/`i` and dotless `I`/`ı` are distinct letters; naive case-folding causes bugs in string comparison
- German: `ß` sorts as `ss` in most contexts

Use the **ICU (International Components for Unicode)** library for locale-aware string operations: collation, case mapping, date/number formatting.

### 8.2 RTL Languages

Arabic, Hebrew, Persian (Farsi), and Urdu are right-to-left scripts. UI framework requirements:
- **BiDi (bidirectional) text support** at the rendering level (Unicode BiDi algorithm)
- CSS `direction: rtl; unicode-bidi: embed` on container elements; layout mirroring (navigation on right, back button on left)
- Number rendering: **Arabic-Indic digits** (٠١٢٣٤٥٦٧٨٩) in Arabic-speaking markets vs. Eastern Arabic-Indic (used in Persian/Urdu); specify digit form explicitly rather than relying on font fallback
- Input validation: do not assume LTR in address parsing, string length computations, or PDF generation

### 8.3 Date, Number & Address Formats

- **Date storage**: **ISO 8601** (YYYY-MM-DD) mandatory for all internal storage and API contracts. Display layer applies locale format:
  - UK/EU: DD/MM/YYYY
  - US: MM/DD/YYYY
  - Japan: YYYY年MM月DD日; Japanese imperial era calendar (Reiwa, 令和, from May 1 2019)
  - Thailand: Buddhist calendar (BE = CE + 543)
- **Numbers**: decimal separator is period in US/UK; comma in continental Europe; thousands separator inverted accordingly. Currency symbol position, spacing, and directionality vary
- **Address structure**: field order, postal code position, administrative subdivision terminology, and required vs. optional fields differ per country. Use **OASIS xAL (eXtensible Address Language)** for standardized address data model; do not hard-code "State / Zip / Country" field labels
- **Telephone**: store in **ITU-T E.164** format (`+[country code][national number]`); display per locale-specific formatting rules

### 8.4 Language Packs

- UI strings must be externalized from code into resource bundles: Java `.properties` files, `.po`/`.pot` (gettext), or **XLIFF 1.2 / XLIFF 2.0** (XML Localisation Interchange File Format — OASIS standard) for translation exchange with LSPs
- Fallback chain: `locale (e.g., fr-CA)` → `language (fr)` → `default (en)` — never hard-fail on missing translation
- Pluralization: English has two plural forms (1 vs. many); Russian has four; Arabic has six. Use **Unicode CLDR (Common Locale Data Repository)** plural rules per language — do not hard-code `if (count == 1) ... else ...`

---

## 9. Banking & Payment Formats

### 9.1 ISO 20022

**ISO 20022:2013** (Financial Services — Universal Financial Industry Message Scheme) uses XML within the namespace `urn:iso:std:iso:20022:tech:xsd`. Key message families relevant to ERP:

| Message | Code | Replaces | Use |
|---|---|---|---|
| Customer Credit Transfer Initiation | pain.001.001.0x | MT103 | AP payment file to bank |
| Payment Status Report | pain.002.001.0x | MT199 | Bank acknowledgement/rejection |
| Payment Reversal | pain.007.001.0x | — | Recall/reversal request |
| Customer Direct Debit Initiation | pain.008.001.0x | MT104 | AR direct debit collection |
| Bank Account Report (intraday) | camt.052.001.0x | MT942 | Intraday liquidity monitoring |
| Bank Statement | camt.053.001.0x | MT940 | End-of-day reconciliation |
| Debit/Credit Notification | camt.054.001.0x | MT900/MT910 | Individual transaction notification |

**SWIFT MT sunset**: SWIFT ended cross-border MT payment message support on **November 22 2025** — the coexistence period between FIN MT and FINPlus ISO 20022 MX messaging (which began March 2023) closed on that date. [18] ERP payment format libraries must support ISO 20022 pain/camt natively. A SWIFT contingency service converts remaining MT submissions to MX at additional cost; treat MT generation as a legacy compatibility layer only.

### 9.2 SEPA Formats (EU)

Governed by EPC (European Payments Council) SEPA Rulebooks, updated annually:

| Scheme | Schema | Settlement | Notes |
|---|---|---|---|
| SEPA Credit Transfer (SCT) | pain.001.001.09 | D+1 business days | Standard euro credit transfer |
| SEPA Instant Credit Transfer (SCT Inst) | pain.001 | ≤10 seconds | Individual transaction amount cap abolished October 5 2025 (raised to €999,999,999.99 per EPC 2025 Rulebook) [19] |
| SEPA Direct Debit Core (SDD Core) | pain.008 | D+5/D+2; pre-notification 14 days default (or 1 day with debtor approval) | Consumer mandate; refund right |
| SEPA Direct Debit B2B (SDD B2B) | pain.008 | D+1 | Mandate held at debtor bank; no refund right |

### 9.3 US — ACH / NACHA

NACHA Operating Rules (updated annually) govern ACH transactions. Key **SEC (Standard Entry Class) codes**:

| SEC Code | Use |
|---|---|
| PPD | Prearranged Payment and Deposit — consumer |
| CCD | Corporate Credit or Debit — B2B payments |
| CTX | Corporate Trade Exchange — CCD with addenda records for EDI remittance (820 transaction set) |
| WEB | Internet-initiated consumer debit |
| TEL | Telephone-initiated |

NACHA published ISO 20022 mapping guides in 2023: pain.001 → ACH CTX, pain.008 → ACH debit, pain.002 → NOC/return file. ERP generates NACHA flat files in the 94-character fixed-width record format; bank-specific addenda length and routing conventions exist.

### 9.4 UK — BACS, Faster Payments & CHAPS

| System | Settlement | Standard | Notes |
|---|---|---|---|
| BACS | 3 business days | Standard 18 (BACSTEL-IP) | Payroll and utility direct debits; Bacs Payment Schemes Ltd |
| Faster Payments (FPS) | Near-real-time (seconds) | ISO 20022 migration via Pay.UK NPA programme | Limit now £1 million per transaction for many banks |
| CHAPS | Same-day (high value) | ISO 20022 (migrated June 19 2023) [20] | Bank of England-operated; for high-value and property settlements |

### 9.5 Payment Factories & EBICS

A **payment factory** centralizes payment execution on behalf of group entities, using POBO (Payment-On-Behalf-Of) or ROBO (Receive-On-Behalf-Of) structures with an in-house bank overlay.

ERP requirements:
- Multi-bank connectivity: SWIFT Service Bureau, **EBICS**, host-to-host SFTP per bank
- Payment format library covering all required national formats
- Bank account master with signatory rules and approval workflows
- Payment status reconciliation via camt.054 matching to original pain.001 end-to-end reference
- FX dealing integration for multi-currency payment approval

**EBICS (Electronic Banking Internet Communication Standard)**: **EBICS 3.0 (2017)** is the current version; uses ISO 20022 message formats throughout. Widely adopted in Germany, Austria, Switzerland, and France (DACH + France) for corporate-to-bank communication. Adoption beyond these geographies is limited — verify against local bank documentation.

---

## 10. Fiscal Devices & Certified Cash Registers

### 10.1 France — NF525

**Article 286 bis CGI** (Code Général des Impôts): from January 1 2018, VAT-registered businesses using POS or accounting/management software to record customer payments must use software meeting anti-fraud requirements. Software must be certified against **NF525**, published by INFOCERT (accredited by COFRAC — Comité Français d'Accréditation). [21]

Mandatory external certification by an accredited body (INFOCERT or LNE): self-certifications remain valid until **September 1 2026** only if the certification process started by August 31 2025; from September 1 2026, all systems must carry formal third-party certification.

**INCA properties** required:
- **I**naltérabilité: audit trail records cannot be modified or deleted
- **N**on-réutilisabilité: no reuse of transaction IDs or sequence gaps
- **C**lôture: mandatory daily fiscal closing with hash chaining
- **A**rchivage: 6-year digital archive, exportable on request

### 10.2 Italy — Registratore Telematico (RT)

Mandatory since:
- July 1 2019: large businesses (annual revenue > €400,000)
- July 1 2020: all businesses (some extensions granted; effectively all by January 1 2021)

The RT device (hardware or **RT Server** software option for retail chains) transmits daily fiscal totals as XML to AdE via HTTPS. Customers receive a non-fiscal *documento commerciale* (formerly *scontrino fiscale*). RT certification authority: MEF in regulatory text, operational oversight involves AdE — verify current authority at MEF/AdE documentation. [7]

### 10.3 Other Countries

| Country | System | Key Requirement |
|---|---|---|
| Germany | KassenSichV (Kassensicherungsverordnung) | **TSE (Technische Sicherheitseinrichtung)** — tamper-proof hardware security module mandatory in all POS systems from September 30 2020 (extended to January 1 2021 for late installations); technical specification: **BSI TR-03153** [22] |
| Austria | Registrierkassenpflicht (since 2016) | DEP (Datenerfassungsprotokoll) — every receipt chained with cryptographic signature via HSM; annual DEP export to USB for tax audit |
| Sweden | Skatteverket certified cash register | Control unit (*kontrollenhet*) obligation since 2010; control unit records all sales, stores journal for 3 years |
| Russia | OFD (Online Fiscal Data) system | KKT (online cash registers) connected to certified OFD (fiscal data operators) who forward transaction data to FNS (Federal Tax Service) in real time |

---

## 11. Payroll Localization & Statutory Filings

### 11.1 Payroll Complexity Dimensions

Payroll localization is among the most complex ERP domains — rules change annually and vary at the sub-national level:

- **Income tax withholding**: progressive tax tables per jurisdiction, updated annually; supplemental wage rates (US flat 22% federal for bonus withholding); year-end reconciliation to Form W-2 (US), P60 (UK), Lohnsteuerbescheinigung (DE)
- **Social insurance contributions**:
  - US FICA: employee + employer each contribute 6.2% for Social Security up to the annual wage base ($176,100 for 2025; $184,500 for 2026 [23] — verify annually with IRS Publication 15); Medicare 1.45% uncapped; Additional Medicare 0.9% on employee wages above $200,000
  - EU countries: employer + employee split varies; Germany: approximately 20% each side total across pension, health, unemployment, and long-term care
- **Statutory filings**:
  - UK: **RTI (Real Time Information)** — HMRC PAYE; FPS (Full Payment Submission) on or before pay date
  - Germany: monthly **Lohnsteueranmeldung** (payroll tax declaration to Finanzamt) + **DEÜV** (social insurance reporting) + annual **Lohnsteuerbescheinigung** per employee
  - France: **DSN (Déclaration Sociale Nominative)** — monthly unified statutory reporting replacing ~24 prior declarations; filed by 5th or 15th of following month
  - Australia: **STP Phase 2 (Single Touch Payroll Phase 2)** — mandatory from January 1 2022 for most employers (some provider deferrals); disaggregated income type reporting per payroll event to ATO [24]

### 11.2 ERP Payroll Localization Coverage

| Vendor | Product | Native Countries | Extension |
|---|---|---|---|
| SAP | SuccessFactors Employee Central Payroll / SAP HCM | 50+ via PCR (Personnel Calculation Rules) + calculation schemas | Country-specific PCR schemas maintained per release |
| Oracle | Oracle Cloud HCM Payroll | 30+ | Fast Formula engine for country rules |
| Workday | Workday HCM Payroll | US, Canada, UK, France, Germany, Netherlands, Australia, New Zealand natively | Partner payroll for other countries |
| ADP | GlobalView / Celergo | 140+ countries via managed payroll service | REST API integration with SAP/Workday HCM for HR master data |

---

## 12. Cross-Cutting ERP Architecture Considerations

### 12.1 Tax Engine Integration Pattern

```
ERP Document (SO / PO / AR Invoice / AP Invoice)
        │
        ▼  [at document save or before posting]
 Tax Determination Request
        │  (ship-from, ship-to, product codes, buyer type, date, amounts)
        ▼
 [External Tax Engine API — synchronous REST call, ~100–300ms SLA]
        │
        ▼  Tax Lines Response
        │  (jurisdiction_code, tax_code, rate, taxable_amount, tax_amount, reverse_charge flag)
        ▼
 ERP stores tax lines on document
        │
        ▼  [Accounting entry]
 Debit: Expense / Receivable    Credit: Revenue / Payable
 Debit: Input Tax Account       Credit: Output Tax Account (on sales)
```

**Failure mode handling**:
- Implement **circuit-breaker pattern**: after N consecutive timeouts, open circuit and either block transaction or fall back to estimated tax (allowed in some jurisdictions, not others)
- Tax line tombstoning: re-call tax engine if transaction date, amount, or address changes after initial determination
- **Caching**: jurisdiction/rate data can be cached with TTL (e.g., 24 hours); invalidate on tax content updates from vendor

### 12.2 Legal Entity & Multi-Book Architecture

Each legal entity maps to: one country of registration, one set of applicable tax rules, one primary chart of accounts (local GAAP), and optionally a secondary IFRS ledger. See `core/architecture.md` for entity hierarchy patterns.

Parallel ledger implementations by ERP:
- **SAP S/4HANA**: Leading Ledger (0L, typically IFRS) + Non-Leading Ledger (local GAAP) or Extension Ledger for additive deltas; ACDOCA stores all via `RLDNR` (ledger) field
- **Oracle Fusion Cloud**: Primary Ledger + Secondary Ledger; Ledger Sets for shared chart of accounts across legal entities
- **D365 Finance**: Legal entity chart of accounts + Financial Reporting dimension sets; posting layer concept (Current / Operations / Tax) for parallel values

### 12.3 CTC Integration Architecture Patterns

| Clearance Model | Synchronous? | ERP Pattern | Error Handling |
|---|---|---|---|
| Mexico CFDI (PAC clearance) | Yes (blocking) | AR invoice saved → XML generated → PAC API called → UUID received → invoice finalized | PAC rejection → document in error status → finance review → correct and resubmit; PAC downtime → SAT Direct Channel Fallback |
| Saudi ZATCA Phase 2 | Yes (B2B clearance) | Blocking pattern; CSID-based device authentication per invoice batch | ZATCA rejection returns error code → blocked from delivery; network failure → retry queue with exponential backoff |
| India IRP (e-invoice) | Yes (blocking) | REST to IRP → IRN + QR code returned → embedded on invoice PDF | IRP rejection → error code + description → correction workflow; IRN cancellation within 24 hours of generation possible |
| Italy SdI | No (async) | Invoice XML posted to SdI delivery channel → status polled or webhook callback; delivery confirmation within 5 days | SdI rejection (scarto) → must void and reissue; technical error → re-transmission |
| Poland KSeF | Yes (clearance from Feb 2026) | XML submitted → KSeF reference number returned → reference mandatory on invoice | KSeF unavailability: temporary manual paper-invoice fallback permitted under regulation |
| France PDP | No (near-real-time) | Invoice routed via PDP → forwarded to counterpart's PDP or PPF → e-reporting data sent to DGFiP | PDP rejection → correction and resubmission; PDP accreditation status must be monitored |

---

## See also

- `core/features-core.md` — AR/AP, GL, and financial close features that host tax postings
- `core/architecture.md` — legal entity hierarchy, multi-ledger architecture, and integration patterns
- `core/security.md` — data residency, audit log integrity (relevant for e-invoice non-repudiation), and SoD controls on tax code maintenance
- `verticals/retail-ecommerce.md` — POS fiscal device integration, sales tax nexus for digital commerce
- `verticals/financial-services.md` — withholding tax on financial instruments, regulatory reporting overlap

---

## Citations & Sources

1. EU Council Directive 2006/112/EC (Principal VAT Directive) and ViDA amending package — adopted March 11 2025, OJ published March 25 2025, in force April 14 2025: EUR-Lex — https://eur-lex.europa.eu
2. IRAS Singapore — GST rate change January 1 2024 (8% → 9%): https://www.iras.gov.sg/taxes/goods-services-tax-(gst)/gst-rate-change
3. *South Dakota v. Wayfair, Inc.*, 585 U.S. 162 (2018): U.S. Supreme Court opinion — https://www.supremecourt.gov
4. Avalara AvaTax — rooftop-level geocoding and US jurisdiction coverage: https://www.avalara.com
5. India GSTN — e-invoice IRP mandate thresholds and 30-day reporting rule (from April 1 2025): https://einvoice6.gst.gov.in/content/einvoice-mandate/
6. Decision (EU) 2024/3150 — Italy SdI derogation from Articles 218 and 232 of Directive 2006/112/EC to December 31 2027 (OJ L, December 19 2024): EUR-Lex — https://eur-lex.europa.eu
7. Agenzia delle Entrate (AdE) — Registratore Telematico (RT) and Telematic Cash Register specifications: https://www.agenziaentrate.gov.it
8. SEFAZ / Receita Federal Brazil — e-invoicing documents (NF-e, NFS-e national mandate January 1 2026 under PLP 68/2023; 132-month archiving from May 1 2025): https://www.nfe.fazenda.gov.br
9. SAT Mexico — CFDI 4.0 mandatory from April 1 2023; PAC certification requirements: https://www.sat.gob.mx
10. ZATCA Saudi Arabia — Fatoorah Phase 2 wave rollout schedule and technical specifications: https://zatca.gov.sa
11. EU Commission / EUR-Lex — ViDA DRR timeline (July 1 2030 cross-border B2B e-invoicing + DRR go-live; January 1 2035 domestic alignment): https://taxation-customs.ec.europa.eu/taxation/vat/vat-digital-age-vida_en
12. Ministerstwo Finansów Poland — KSeF mandatory timeline (February 1 2026 for PLN 200M+ taxpayers; April 1 2026 others; January 1 2027 micro-entrepreneurs): https://www.gov.pl/web/finanse/ksef
13. DGFiP France — B2B e-invoicing mandate (September 1 2026 large/mid; September 1 2027 SMEs); PDP accreditation framework: https://www.impots.gouv.fr
14. BMF Germany — Wachstumschancengesetz (March 22 2024) B2B e-invoice mandate (receive: January 1 2025; issue for >€800K: January 1 2027; all: January 1 2028): https://www.bundesfinanzministerium.de
15. GİB Turkey — e-Fatura, e-Arşiv, e-İrsaliye mandate thresholds and UBL-TR specifications: https://www.gib.gov.tr
16. DIAN Colombia — Resolution 000119/2024 updating electronic invoicing system; technical specification v1.9 mandatory from February 1 2024: https://www.dian.gov.co
17. SAP — ECC 6 EHP 6–8 mainstream maintenance end December 31 2027; extended maintenance through December 31 2030: https://support.sap.com/en/my-support/product-support/end-of-support-overview.html
18. SWIFT — ISO 20022 migration coexistence period ended November 22 2025; MT payment message retirement: https://www.swift.com/standards/iso-20022
19. EPC — 2025 SEPA Instant Credit Transfer Rulebook (effective October 5 2025; cap raised to €999,999,999.99): https://www.europeanpaymentscouncil.eu
20. Bank of England — CHAPS migrated to ISO 20022 June 19 2023 (RTGS Renewal Programme): https://www.bankofengland.co.uk/payment-and-settlement/rtgs-renewal-programme
21. DGFiP / COFRAC / INFOCERT — NF525 certification for French POS software (self-certification valid to September 1 2026 if process started by August 31 2025): https://infocert.org/en/nf525/
22. BSI TR-03153 — Technical guideline for POS TSE (Technische Sicherheitseinrichtung): Bundesamt für Sicherheit in der Informationstechnik — https://www.bsi.bund.de
23. IRS Publication 15 (Circular E) — FICA Social Security wage base ($176,100 for 2025; $184,500 for 2026): https://www.irs.gov/publications/p15
24. ATO Australia — Single Touch Payroll Phase 2 mandatory from January 1 2022 (disaggregated income type reporting): https://www.ato.gov.au/businesses-and-organisations/hiring-and-paying-your-workers/single-touch-payroll
25. OECD SAF-T guidelines — Standard Audit File for Tax: https://www.oecd.org/tax/forum-on-tax-administration/publications-and-products/standard-audit-file-for-tax.htm
26. EN 16931:2017+A1:2019 — European Standard for Electronic Invoicing: CEN — https://www.cen.eu
27. NACHA Operating Rules and ISO 20022 mapping guides: https://www.nacha.org
28. SAP Document and Reporting Compliance (SAP DRC): SAP Help Portal — https://help.sap.com
29. Oracle Fusion Cloud Tax documentation: Oracle Help Center — https://docs.oracle.com/en/cloud/saas/financials
30. Microsoft D365 Finance Regulatory Updates and Electronic Invoicing Service: Microsoft Learn — https://learn.microsoft.com/en-us/dynamics365/finance/localizations
31. EBICS 3.0 specification: EBICS SCRL — https://www.ebics.org
32. Unicode CLDR (Common Locale Data Repository): https://cldr.unicode.org
33. IAS Regulation 1606/2002 — IFRS mandatory for EU-listed consolidated statements: EUR-Lex — https://eur-lex.europa.eu
