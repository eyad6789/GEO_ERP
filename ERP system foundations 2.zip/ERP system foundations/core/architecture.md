# ERP Engineering Architecture & Internals

## Layered Architecture

Enterprise resource planning systems are organized into four canonical layers: **Presentation**, **Application**, **Domain**, and **Persistence**. Understanding these layers is prerequisite to reasoning about coupling, testability, upgrade safety, and integration surface.

| Layer | Responsibility | Typical Artifacts |
|---|---|---|
| Presentation | Renders UI, handles HTTP/WebSocket, serializes to JSON/XML/OData | Fiori Launchpad apps, Oracle Fusion OTBI dashboards, Dynamics 365 model-driven apps, REST controllers |
| Application | Orchestrates use cases, manages transactions, enforces security, translates between domain and presentation | Application services, SAGAs, command handlers, workflow engines |
| Domain | Owns business rules, invariants, and state transitions; no infrastructure dependency | Entities, aggregates, domain services, policy objects (e.g., posting rules, tax determination) |
| Persistence | O/R mapping, connection pooling, caching, query optimization | JPA/Hibernate mappings, ABAP Open SQL, ACDOCA table, Flyway migrations |

### Why ERPs Are Metadata-Driven

The defining architectural characteristic of mature ERP systems is that **behavior is stored as data, not as code**. Field labels, validation rules, workflow steps, approval matrices, account determination rules, and output formats are rows in configuration tables rather than compiled logic. This enables:

- Behavior changes through configuration screens without redeployment
- Customer-specific rule variations without forking the codebase
- A/B testing of workflow variants by toggling configuration

In SAP, this manifests as Customizing (transaction SPRO), condition techniques (pricing, output, account determination), and the Field Selection mechanism that controls which fields appear and whether they are required, optional, display-only, or hidden — all driven by table entries, not source code. Oracle Fusion uses setups stored in the Functional Setup Manager (FSM), which deploys configuration as data through an ordered task list. Microsoft Dynamics 365 Finance stores posting profile logic, number sequence rules, and workflow approvals in SQL tables read at runtime.

The engineering consequence is that the domain layer must be designed to **read its own rules at runtime**. Policy tables, condition records, and workflow definitions are first-class domain objects. Caching strategies must account for rule invalidation — rule changes must flush cached policy objects.

### Monolith vs Modular ERP

| Dimension | Classic Monolith (SAP ECC, Oracle E-Business Suite) | Modular / Composable (SAP S/4HANA + BTP, Oracle Fusion Cloud, modern SaaS) |
|---|---|---|
| Deployment unit | Single ABAP stack or Oracle Forms/Reports binary | Core SaaS + independently deployable extensions |
| Schema ownership | Shared schema, thousands of interrelated tables | Domain-bounded schemas; cross-domain via API |
| Upgrade path | Full system upgrade; extensive regression testing | Rolling upgrades per service; stable API contract |
| Extension mechanism | In-line code modifications (overlayering) | Side-by-side extensions via stable released APIs |
| Inter-module communication | Direct in-process function calls / BAPIs | REST/OData/event bus |
| Coupling risk | High: module A can corrupt module B's data | Lower: domain boundaries enforced by API contracts |
| Operational cost | Lower (one system) | Higher (more moving parts to operate) |

SAP ECC (ERP Central Component) with Enhancement Packages 6–8 reaches end of mainstream maintenance on December 31, 2027, with optional paid extended maintenance through December 31, 2030. EHP 0–5 mainstream maintenance ended December 31, 2025 [1]. SAP S/4HANA is the designated successor.

---

## Master Data vs Transactional Data

**Master data** are slow-changing reference objects that describe the entities participating in business processes: customers (debtor accounts), vendors (creditor accounts), materials/products (item master), GL accounts, employees, cost centers, profit centers, plants, and business partners. They are created once, rarely change, and are consumed by many transactions over their lifecycle.

**Transactional data** are time-stamped events that consume, reference, or produce master data: sales orders, purchase orders, goods movements, journal entries, invoices, and payments. They accumulate continuously; once posted they are immutable (see Audit Immutability section).

### Canonical Data Model

The foundational entity relationships that appear in every ERP:

```
BusinessPartner (1) ─── (N) SalesOrder
SalesOrder (1) ─── (N) SalesOrderLine
SalesOrderLine (N) ─── (1) Material
SalesOrderLine (N) ─── (1) Plant
Material (N) ─── (1) MaterialType
CompanyCode (1) ─── (N) GLAccount
CompanyCode (N) ─── (1) ControllingArea
JournalEntry (1) ─── (N) JournalEntryLine
JournalEntryLine (N) ─── (1) GLAccount
JournalEntryLine (N) ─── (1) CostCenter
JournalEntryLine (N) ─── (1) ProfitCenter
```

Foreign-key conventions in production ERP databases typically use natural keys (material number, company code, GL account) rather than surrogate integers for master data, because these natural keys appear in legal documents and must be readable in regulatory submissions.

### Master Data Management & Governance

**MDM** establishes a single system of record (golden record) for each master data domain. The engineering challenges are:

- **Deduplication**: Identifying that "Acme Corp", "Acme Corporation", and "ACME CORP INC" are the same legal entity. Two algorithm families:
  - **Deterministic matching**: Exact or normalized match on a registered identifier (DUNS, VAT registration number, EIN). Zero false positives, misses records without the identifier.
  - **Probabilistic matching**: Weighted scoring across name, address, phone, email fields. Tunable threshold; requires manual review queue for mid-range scores.
- **Golden record construction**: When multiple source systems contribute conflicting data (different phone numbers for the same customer), survivorship rules determine which source wins per field.
- **Merge/unmerge workflows**: Merge links duplicate records under one golden record; unmerge capability is required for when a merge was incorrect.
- **Data stewardship roles**: Create → pending approval → active → deactivate → archive. Role separation enforced at system level — a data entry clerk cannot approve their own master data record.

Cross-system MDM hubs: **SAP Master Data Governance (MDG)** provides central governance with workflow-based approval for business partner, material, and GL account data in SAP landscapes. **Oracle Product Hub** (part of Oracle Fusion SCM) governs product master data. **Informatica MDM** and **Reltio** serve as vendor-neutral MDM platforms for heterogeneous ERP landscapes.

---

## The Document Model — Everything Is a Document

Every business event in an ERP is captured as a **versioned, header/lines document**. This is not metaphorical — the same data structure pattern governs purchase orders, sales orders, journal entries, goods receipts, and payments.

### Document Structure

**Header fields** (one per document):
- Document type (distinguishes PO from GR from invoice; drives account determination)
- Document number (sequenced by number range object; see Number Ranges section)
- Company code / legal entity
- Fiscal year
- Posting date (determines which fiscal period the document lands in)
- Document date (the external date on the vendor invoice or customer order)
- Currency and exchange rate
- Reference number (vendor invoice reference, customer PO number)
- Status (Draft / Open / Partially Processed / Completed / Cancelled)

**Line item fields** (one-to-many per header):
- Line number
- GL account (or material, or asset)
- Debit/credit indicator and amount
- Cost center, profit center, project (controlling dimensions)
- Material, quantity, unit of measure
- Tax code
- Assignment field (free-form reference, appears on bank statement reconciliation)

### Document Flow

**Procurement cycle** (materials management):
```
Purchase Requisition → Purchase Order → Goods Receipt → Invoice Receipt (MIRO) → Payment Run
```
Each document references the preceding one. The goods receipt posts a material document (inventory + consumption) and an FI document (GR/IR clearing account + inventory account). The invoice receipt clears the GR/IR account and creates a vendor liability. Payment clears the liability.

**Order-to-cash cycle** (sales):
```
Sales Inquiry → Quotation → Sales Order → Delivery → Transfer Order (WM/EWM)
→ Goods Issue → Billing Document → Incoming Payment
```

Goods issue reverses the inventory movement from the delivery and posts COGS. The billing document creates the customer receivable and posts revenue. In SAP SD, the billing document is the trigger for FI posting; the SD document flow is maintained in the VBFA (document flow) table.

### Document Schema Sketch

```json
{
  "documentHeader": {
    "documentNumber": "5100001234",
    "documentType": "RE",
    "companyCode": "1000",
    "fiscalYear": 2026,
    "postingDate": "2026-06-14",
    "documentDate": "2026-06-10",
    "currency": "USD",
    "exchangeRate": 1.0,
    "referenceDocument": "VINV-2026-0087",
    "status": "OPEN",
    "createdBy": "MM_PROC_USER",
    "createdAt": "2026-06-14T09:22:00Z",
    "idempotencyKey": "a3f8d1c2-44e9-4b7a-9f1d-8c3b2a0e5f19"
  },
  "lineItems": [
    {
      "lineNumber": 1,
      "glAccount": "160000",
      "debitCredit": "D",
      "amount": 15000.00,
      "costCenter": "COST-1001",
      "profitCenter": "PC-EU-WEST",
      "taxCode": "V1",
      "assignment": "PO-4500001122-10"
    },
    {
      "lineNumber": 2,
      "glAccount": "175000",
      "debitCredit": "C",
      "amount": 15000.00,
      "assignment": "PO-4500001122-10"
    }
  ]
}
```

### Status Lifecycle and Cancellation

Status transitions: **Draft → Open → Partially Processed → Completed** (or **Cancelled**).

A fundamental invariant: **posted documents are never updated or deleted**. Errors are corrected by **reversal documents** (storno). In SAP FI, transaction FB08 creates a reversal that posts the mirror-image entries with the same document header data; the original document is flagged as reversed and both documents remain in the database. This applies to goods receipts (movement type 102), billing documents (credit memos), and journal entries. The audit trail is always complete.

---

## The Double-Entry Posting Engine

Every financial event in an ERP resolves to one or more journal entries where **sum(debits) = sum(credits)** for each entry. This invariant must be enforced at the database transaction level, not just application level — the posting engine rolls back the entire transaction if it cannot construct a balanced entry.

### Journal Entry Anatomy

```json
{
  "journalId": "JE-2026-0091234",
  "source": "FI-MM",
  "postingDate": "2026-06-14",
  "postingPeriod": "2026-06",
  "ledger": "0L",
  "idempotencyKey": "b7c2e5f8-1a3d-4e9b-8f0c-2d5a7e1b3c9f",
  "lines": [
    { "line": 1, "account": "140000", "debitCredit": "D", "amount": 15000.00, "currency": "USD", "costCenter": "COST-1001" },
    { "line": 2, "account": "160000", "debitCredit": "C", "amount": 15000.00, "currency": "USD" }
  ]
}
```

Assertion: `SUM(amount WHERE debitCredit='D') == SUM(amount WHERE debitCredit='C')` must hold. Any posting engine that allows an imbalanced entry to persist is architecturally broken.

### Sub-Ledgers vs General Ledger

The general ledger (GL) is the master financial record. **Sub-ledgers** are detailed transaction records for specific domains: Accounts Receivable (AR), Accounts Payable (AP), Asset Accounting (AA), Cost Accounting (CO), Inventory Accounting (ML/Material Ledger), and Payroll (PY). Each sub-ledger posts summarized totals to **control accounts** in the GL.

The control account mechanism: when a vendor invoice is posted in AP, the vendor line item is written to the AP sub-ledger (BSIK/BSAK in SAP ECC, or the ACDOCA vendor line in S/4HANA) and simultaneously the vendor reconciliation GL account (e.g., 210000 Accounts Payable — Trade) is updated in the GL. Direct manual posting to control accounts is blocked — all entries must flow through the sub-ledger to maintain reconciliation.

**Sub-Ledger Accounting (SLA)** is the rules engine that derives GL account assignments from document attributes at posting time, rather than hardcoding account numbers in application code. In SAP, this is FI-SLA; in Oracle Fusion, it is Subledger Accounting (SLA) with Journal Entry Rule Sets (JERS) and Account Derivation Rules [2]. Rules are configured in customizing, not in code. For example: if the transaction is an invoice receipt for a raw material in plant Hamburg, post the debit to account 300010 (Raw Materials Inventory — EU); if the plant is in Texas, post to 300020 (Raw Materials Inventory — US).

### SAP S/4HANA Universal Journal

Introduced with SAP S/4HANA Finance 1503 (released March 2015), the Universal Journal consolidates FI-GL, CO, AA (Asset Accounting), and ML (Material Ledger) into a single database table: **ACDOCA** (Universal Journal Entry Line Items), which carries 500+ fields in current S/4HANA releases [3]. This eliminates the periodic reconciliation batch jobs that were necessary in SAP ECC where financial accounting and controlling were separate schemas that drifted apart. Every posting writes one ACDOCA row that carries GL, cost object, asset, and material valuation dimensions simultaneously. Reporting queries hit ACDOCA directly rather than joining multiple aggregation tables. ACDOCA is implemented as a column store table on SAP HANA.

### Reversal / Storno and Accruals

**Reversal** (storno): posting the exact mirror of the original document. Two approaches:
1. **Sign-flip (negative posting)**: posts the same debit/credit sides but with negative amounts — balance-neutral but distorts period transaction counts; used in some European accounting traditions.
2. **Mirror posting**: swaps debit and credit signs — the more common approach in SAP and Oracle.

**Accruals**: automated accrual engines allow posting of estimated expenses in the period they are incurred, with scheduled automatic reversal in the following period. SAP uses Accrual Engine (FBS1 recurring entries); Oracle Fusion uses Accrual Accounting in the Period Close module. Accrual objects carry the posting rule, amount, GL accounts, and reversal date.

### Idempotent Posting

Distributed systems fail and retry. An invoice posting triggered twice must not create two journal entries. The solution:

1. **Client generates an idempotency key** (UUIDv4) before the first attempt.
2. **Server stores key + result** in an idempotency table within the same database transaction as the posting.
3. **Duplicate requests** are detected by key lookup and return the cached result without re-executing the posting.
4. **Outbox pattern**: the posting to the business tables and the outbox event record are written atomically in one DB transaction. A relay process (often Debezium reading the WAL, or a polling job) publishes the event to Apache Kafka or Azure Service Bus. Downstream consumers carry the idempotency key and deduplicate at their end.

The outbox pattern guarantees **at-least-once delivery**. Exactly-once semantics require the consumer to also implement idempotency (check idempotency key before processing; process-and-store-key atomically).

---

## Chart of Accounts Design

### Natural Account and Segment Model

The **natural account** is the financial account code classified as asset, liability, equity, revenue, or expense. In isolation it is insufficient for management reporting — analysts need to know *which cost center* incurred an expense, *which product line* generated revenue, *which project* consumed resources.

The segment (dimension) model adds orthogonal classification axes alongside the natural account:

| Segment | Purpose | Example Values |
|---|---|---|
| Company / Entity | Legal entity segregation | 1000 (Germany GmbH), 2000 (US Inc) |
| Natural Account | Financial classification | 400000 (Sales Revenue), 610000 (Salaries) |
| Cost Center | Operational cost accountability | CC-MKTG-US, CC-R&D-EU |
| Profit Center | P&L visibility by business unit | PC-PRODUCT-A, PC-SERVICE |
| Project / WBS | Project-level cost and revenue tracking | P-2026-042 |
| Product / Material Group | Product profitability analysis | MATGRP-PHARMA |
| Intercompany | Identifies intercompany partner entity | ICO-2000 |
| Fund / Grant | Public sector / nonprofit fund tracking | FUND-FED-2026 |

Oracle Fusion General Ledger supports up to 30 chart of accounts segments, with a minimum of 3 required (entity, cost center, natural account). The flexfield structure is configured at implementation and is expensive to restructure post go-live — segment design is one of the highest-stakes architectural decisions in an ERP implementation.

### Account Hierarchies

Account hierarchies form tree structures used for rollup reporting. In SAP, account groups and financial statement versions (FSV) define the tree. In Oracle Fusion, account hierarchies are tree structures in the Financials data model. The hierarchy distinguishes **posting accounts** (leaf nodes; journal entries may post to these) from **summary/group accounts** (internal nodes; used for reporting aggregation only; no direct postings allowed).

Alternate hierarchies allow the same leaf-node accounts to roll up differently for statutory reporting, management reporting, and tax reporting — different trees, same leaf nodes.

### Parallel Ledgers (Multi-GAAP)

The **ledger / book** concept allows a single business event to be posted simultaneously to multiple ledgers, each applying different accounting treatments:

| Platform | Primary Ledger | Parallel Ledger Mechanism | IFRS 16 vs ASC 842 Handling |
|---|---|---|---|
| SAP S/4HANA | Leading Ledger (0L) — local GAAP | Extension Ledger (non-leading): stores only delta entries that differ from leading; inherits common postings | Separate lease accounting entries in non-leading ledger with IFRS 16 ROU asset; leading ledger records ASC 842 treatment |
| Oracle Fusion GL | Primary Ledger | Secondary Ledger (balance, subledger, or journal-level representation type) | Separate secondary ledger with IFRS/US GAAP chart of accounts and SLA rules |
| Dynamics 365 Finance | Default ledger | Financial dimensions + reporting currency on ledger setup; no native secondary ledger concept — uses financial reporting layer | Handled via separate adjustment journals or financial reporting dimensions |
| NetSuite OneWorld | Base accounting book | Multi-Book Accounting: additional accounting books per subsidiary with different GAAP rules | Separate accounting books per GAAP standard |

Multi-GAAP parallel posting means that the same vendor invoice triggers postings to both the IFRS ledger (with IFRS 16 lease liability and right-of-use asset) and the US GAAP ledger (with ASC 842 operating lease straight-line expense). Under IAS 21 [4] and ASC 830 [5], the same transaction may also generate different FX amounts in parallel ledgers if functional currencies differ.

---

## Fiscal Calendar & Period Management

### Calendar Types

| Type | Description | Typical Users |
|---|---|---|
| Calendar year | Jan 1 – Dec 31 | Most entities globally |
| Fiscal year offset | Fixed non-calendar end (e.g., Apr–Mar for UK public sector; Jul–Jun for Australian entities) | Government, education, retail |
| 4-4-5 retail | 52 weeks divided into 13 four-week blocks; months are 4, 4, or 5 weeks | Retail, consumer goods |
| 52/53-week year | Always ends on the same day of week nearest to a date; adds a 53rd week every 5–6 years | US retail (Walmart, Target) |

### Period States and Transitions

Period states enforce posting cutoff discipline:

- **Open**: all authorized users may post
- **Soft close** (limited posting): only designated month-end close team may post; operational users blocked
- **Hard close** (locked): no postings allowed; period is frozen for reporting
- **Reopened**: exceptional state requiring elevated authorization; creates audit event

Opening a period requires: authorization check (T-code OB52 in SAP; Accounting Period Program in Oracle Fusion), update to the period interval table, and optionally a workflow approval.

### Period-End Close Checklist

Executing period-end close is a sequenced dependency chain:

1. Sub-ledger posting cutoff (AP, AR): all vendor invoices and customer payments entered before cutoff date
2. Accruals posting: manual and automated accruals for unprocessed invoices, earned but unbilled revenue
3. Prepayment amortization
4. Fixed asset depreciation run (SAP AFAB, Oracle Fusion Assets depreciation program)
5. Overhead cost center / internal order settlement (SAP CO actual settlement; allocates indirect costs to cost objects)
6. Intercompany reconciliation: matching and eliminating intercompany AR/AP before consolidation
7. Foreign currency revaluation of open items (AR, AP, bank balances) per IAS 21 / ASC 830 at closing rate
8. Inventory valuation and lower-of-cost-or-net realizable value (LCNRV) test per IAS 2 [6] / ASC 330 [7]
9. Cost allocations and activity-based costing distributions
10. Management reporting cutoff
11. General ledger period lock

### Year-End Carry-Forward

At fiscal year end:
- **Balance sheet accounts** (assets, liabilities, equity): balances carried forward to opening balance of next fiscal year (SAP: F.16 Balance Carryforward; Oracle: Run Year End Carry Forward)
- **P&L accounts** (revenue, expense): balances cleared to zero; net income/loss posted to retained earnings account
- **Open items** (unpaid invoices, open purchase orders): migrated to new fiscal year with same document number; fiscal year is part of the primary key
- **Controlling objects** (cost centers, internal orders): budget carry-forward rules configured separately

Parallel close: different legal entities within a group close at different times (e.g., a subsidiary on Dec 31, a joint venture on Mar 31). The consolidation close runs after all entities close and requires intercompany reconciliation to be complete across all close dates.

| Feature | SAP S/4HANA | Oracle Fusion | Dynamics 365 Finance | NetSuite |
|---|---|---|---|---|
| Period open/close granularity | Company code + period + document type | Ledger + period + subledger | Ledger + period | Accounting period per subsidiary |
| Soft close support | Via authorization group on OB52 | Manual journal restriction by role | Via workflow approval for adjustments | Period lock with adjustment period |
| Automated depreciation scheduling | AFAB with batch job | Depreciation submission in Assets | Fixed asset depreciation batch | Automated depreciation schedule |
| Multi-entity parallel close | Yes, per company code | Yes, per legal entity ledger | Yes, per legal entity | Yes, per subsidiary (OneWorld) |

---

## Number Ranges & Sequencing

### Legal Requirements

Many jurisdictions require **gapless, chronological, non-reusable document sequences** for fiscal documents. The EU VAT Directive (Council Directive 2006/112/EC, Article 226) requires that each VAT invoice carry "a sequential number, based on one or more series, which uniquely identifies the invoice" [8]. Italy's e-invoicing mandate via the Sistema di Interscambio (SdI), mandatory for domestic B2B and B2C transactions from January 1, 2019, requires all invoices to pass through the Agenzia delle Entrate's central exchange system; per-period sequential numbering is enforced at validation. Latin American e-invoicing mandates impose analogous requirements: Brazil NF-e (Nota Fiscal Eletrônica), Mexico CFDI (Comprobante Fiscal Digital por Internet), and Chile DTE (Documento Tributario Electrónico) all require authorized sequential folio ranges registered with the respective tax authority before use. Gaps in sequences trigger tax authority inquiries and potential penalties.

### Concurrency-Safe Sequence Generation

The fundamental tradeoff:

| Approach | Gapless? | Performance | Notes |
|---|---|---|---|
| Database SEQUENCE (PostgreSQL/Oracle) | No (gaps on rollback) | High throughput; no contention | Default choice for most document types |
| Gap-tolerant application counter | No | High throughput | Unreliable; avoid for legal documents |
| Gapless sequence with lock | Yes | Low throughput (serialized) | Use only where legally mandated |
| Gapless sequence with reservation + retry | Yes (on commit) | Medium | Reserve a number at start; return on rollback creates complexity |

**SAP number range objects**: each company code + document type + fiscal year has its own number range object. **Buffered** number ranges pre-allocate blocks of numbers to application server memory (fast; gaps appear on server restart or crash). **Unbuffered** number ranges fetch and lock the next number at the DB level for every single document (gapless; serialized; slower). SAP documentation explicitly warns to use unbuffered ranges only where legally mandated.

**Oracle Fusion**: automatic sequencing assigns numbers from a database sequence; manual sequencing allows user-entered numbers; gapless sequencing enforces no gaps per legal entity and VAT registration number. Italian localization requires a separate gapless sequence per VAT period.

---

## Costing & Inventory Valuation Engines

### Standard Costing

A pre-set cost estimate is calculated for each material at the start of (or before) the accounting period via a **cost estimate run** (SAP CO-PC: CK11N for single material, CK40N for mass costing). The standard price is then frozen for the period. All goods movements value inventory at this standard price. Deviations from standard are captured as **variances**:

- **Purchase price variance (PPV)**: actual invoice price differs from standard
- **Quantity/usage variance**: actual material consumption differs from the standard bill of materials quantity
- **Overhead absorption variance**: actual overhead costs differ from applied overhead rates
- **Scrap variance**: unplanned scrap at a production operation

Standard costing simplifies period management and enables straightforward budget-vs-actual variance analysis. It is the dominant method in discrete and process manufacturing.

### Moving Average Price (MAP)

MAP is recalculated on every goods receipt using the formula:

```
New MAP = (Existing stock value + Receipt value) / (Existing qty + Receipt qty)
```

MAP is appropriate for materials with stable, predictable pricing and where the company wants inventory to reflect current market cost. Engineering risks: negative stock corrupts MAP calculation (the divisor can go to zero or negative, producing meaningless results). Goods receipt reversals after further consumption has occurred create mathematically valid but economically misleading price adjustments. SAP enforces a negative stock indicator per plant/material type to prevent the worst corruption scenarios.

### Weighted Average Cost (WAC) / Periodic

WAC is calculated at period end across all receipts in the period:

```
WAC = Sum of all receipt values in period / Sum of all receipt quantities in period
```

All issues in the period are then revalued at WAC. Common in distribution and wholesale, where inventory turns quickly and MAP precision is not required.

### FIFO / LIFO

**FIFO (First In, First Out)**: the cost of the oldest inventory layer is assigned to issues. Maintains **cost layers** (lots) in the inventory sub-ledger. Permitted under IAS 2 [6] (IFRS Foundation) and ASC 330 [7] (FASB).

**LIFO (Last In, First Out)**: the cost of the most recently received inventory is assigned to issues. Permitted under ASC 330 (US GAAP) only. Prohibited under IAS 2 (IFRS) — this is a hard accounting incompatibility for companies reporting under both standards. US GAAP entities using LIFO must disclose the **LIFO reserve** (the difference between LIFO and FIFO/LCNRV cost) in financial statement footnotes per ASC 330-10-50.

### Actual Costing / Material Ledger (SAP CO-PC-ML)

SAP Material Ledger is **mandatory in S/4HANA** (activated by default; cannot be disabled). Actual costing is an **optional activation** on top of Material Ledger. With actual costing enabled:

1. Materials are initially valued at standard cost during the period.
2. At period end, the Material Ledger collects all actual costs (actual purchase prices, actual overhead rates, actual activity prices from Cost Centers).
3. A **multi-level cost rollup** distributes variances upward through the bill of materials: if raw material cost exceeded standard, that variance flows through to the semi-finished and finished goods that consumed it.
4. **Period-end revaluation**: inventory is restated from standard to actual cost; the total variance is split between Cost of Goods Sold and ending inventory based on the consumption ratio during the period. If 70% of the period's inventory was consumed (issued to production or sold) and 30% remains in stock, the variance is split approximately 70% to COGS and 30% to inventory; the exact ratio is computed from actual consumption quantities and is not a fixed split.

**Landed cost**: freight, customs duty, insurance, and other acquisition charges can be absorbed into inventory cost via the Material Ledger's planned delivery cost mechanism, so the material's standard cost includes all costs to bring it to its location.

### Catch Weight / Dual UoM

In food, agriculture, metals, and specialty chemicals, goods are managed simultaneously in two units: a **nominal unit** (e.g., "each" for a box of fish) and an **actual weight unit** (e.g., kg). The actual weight varies per lot. Purchasing and billing may occur in one unit while inventory is tracked in the other. SAP EWM and S/4HANA Catch Weight Management handle this with a dedicated catch weight quantity field on every inventory movement and goods receipt, capturing the actual variable weight at point of physical handling.

---

## Units of Measure & Conversions

Every material has a **base unit of measure (base UoM)** in which stock quantities are managed internally. Alternate UoMs are defined with conversion factors stored in the material master:

- **Purchasing UoM**: the unit in which the vendor invoices (e.g., carton of 12); converted to base UoM on goods receipt
- **Sales UoM**: the unit quoted and billed to customers; may differ from base UoM
- **Production UoM**: the unit used in bill of materials and routings

Conversion factors may be **global** (material-independent; e.g., 1 box = 12 each for all materials using that packaging) or **material-specific** (e.g., this specific material has a variable gross weight per pallet). Rounding rules and tolerance checks prevent accumulation of rounding errors across multiple conversions.

---

## Multi-Currency Mechanics

### Three-Tier Currency Model

| Tier | Definition | Standard Reference |
|---|---|---|
| Transaction currency (document currency) | Currency of the original business document | n/a |
| Functional currency (local currency) | The currency of the primary economic environment in which the entity operates | IAS 21 [4] (IFRS Foundation); ASC 830 [5] (FASB) |
| Reporting / group currency | Currency in which consolidated financial statements are presented | IAS 21 [4]; ASC 830 [5] |

SAP S/4HANA supports up to 10 parallel currency types per ledger (e.g., local currency, group currency, hard currency, index-based currency, global company currency) [9]. The first two currency types are SAP-predefined; the remaining 8 may be SAP-predefined, user-defined, or a combination.

### Exchange Rate Types

ERP systems maintain rate type tables per currency pair:
- **M (spot/daily rate)**: current market rate; used for transaction postings
- **P (budget rate)**: fixed for planning period; used to translate budget amounts
- **Average rate**: arithmetic or weighted average for the period; used for P&L translation under IAS 21
- **Historical rate**: rate at the date of the original transaction; used for equity translation

### Realized vs Unrealized FX

**Realized FX gain/loss**: arises when a foreign-currency receivable or payable is settled. The difference between the rate at invoice booking and the rate at payment is posted to a realized FX account (e.g., GL 820000 Realized FX Gain/Loss). This is a permanent, cash-settled difference.

**Unrealized FX gain/loss**: at period end, open AR, AP, and bank balances denominated in foreign currencies are **revalued** to the closing exchange rate per IAS 21 / ASC 830. The difference between the carrying amount and the revalued amount is posted to an unrealized FX account (e.g., GL 825000 Unrealized FX Gain/Loss). This posting is reversed at the start of the next period (or offset when the item is settled) because it is a valuation adjustment, not a cash event.

### Translation and CTA

When translating a foreign subsidiary's financial statements to the group's presentation currency (functional → reporting currency):

- **Balance sheet monetary items**: translated at the closing rate
- **P&L items**: translated at the average rate for the period (or transaction rate if material)
- **Equity items**: translated at historical rates (the rate at the time of the original equity transaction)

The resulting balancing difference is the **Cumulative Translation Adjustment (CTA)**. Under ASC 830 [5] (US GAAP, formerly SFAS 52) and IAS 21 [4] (IFRS Foundation), CTA is recorded in Other Comprehensive Income (OCI) within equity and is **not recognized in P&L** until the foreign entity is sold or liquidated — at which point it is released to P&L. ERP implementation requires dedicated GL accounts for realized FX, unrealized FX, and CTA, plus automated revaluation batch programs and rate upload interfaces.

---

## Multi-Entity / Multi-Org & Intercompany

### Organizational Hierarchy

```
Client (ERP installation)
└── Company Code (legal entity / statutory reporting unit)
    ├── Business Area / Segment (internal P&L segment)
    ├── Plant (production / storage location)
    │   └── Storage Location / Warehouse
    ├── Sales Organization → Distribution Channel → Division
    └── Purchasing Organization → Purchasing Group
```

This hierarchy drives authorization, document routing, tax determination, and intercompany posting rules.

### Due-To / Due-From and Elimination

Transactions between legal entities within a group create **intercompany receivables (due-from)** on the selling entity's books and **intercompany payables (due-to)** on the buying entity's books. These must net to zero at the consolidated group level. The eliminating journal entries remove:

- Intercompany revenue and COGS (matched pair)
- Intercompany AR and AP balances
- Unrealized profit in intercompany inventory (goods sold by Entity A still in Entity B's inventory)
- Intercompany equity investment vs net assets (parent investment account vs subsidiary equity)

These eliminations are governed by ASC 810 [10] (FASB) — Consolidation, and IFRS 10 [11] (IFRS Foundation) — Consolidated Financial Statements. **SAP Group Reporting** (embedded in S/4HANA) automates intercompany matching and elimination via task-based consolidation workflows. Oracle offers **Financial Consolidation & Close Cloud (FCCS)**; Workday provides consolidation within Workday Financial Management; Dynamics 365 Finance includes a consolidation module; **OneStream** is a widely used standalone consolidation platform.

### Transfer Pricing

Intercompany transactions must be priced at **arm's length** per the OECD Transfer Pricing Guidelines for Multinational Enterprises and Tax Administrations (2022 edition) [12]. ERP systems must record both the intercompany transfer price (what one entity charges another) and the cost base, enabling margin analysis per entity for tax compliance. The OECD/G20 Pillar Two Global Anti-Base Erosion (GloBE) rules — which impose a 15% global minimum effective tax rate on multinational groups with consolidated annual revenue of €750 million or more — took effect January 1, 2024 in jurisdictions including EU member states, UK, Japan, South Korea, and others [13]. Approximately 90% of in-scope multinationals are projected to be subject to the rules by 2025. Pillar Two is increasing scrutiny of transfer pricing arrangements; monitor jurisdiction-level enactment status as adoption continues.

### Shared Services Center Model

One entity (the SSC) provides finance, HR, IT, or procurement services to other entities and charges them via **management fee invoices** or **cost allocation keys** (headcount, revenue, FTE). ERP allocation cycles (SAP CO distribution/assessment cycles; Oracle Fusion allocations) automate this by distributing sender cost center balances to receiver cost centers or legal entities based on configured keys.

---

## Multi-Tenancy & Data Partitioning

Three multi-tenancy models for ERP SaaS platforms:

| Model | Isolation Level | Infrastructure Cost | Scaling Limit | Compliance Fit |
|---|---|---|---|---|
| Shared schema (tenant_id column) | Low: row-level security (RLS) at DB or ORM layer | Lowest | Millions of tenants | Basic; requires RLS to be airtight |
| Schema-per-tenant | Medium: DB enforces schema boundary | Medium | Hundreds of tenants per RDBMS instance | Moderate |
| Database-per-tenant | High: full OS/DB isolation | Highest | Tens to hundreds per host | Required for strict data residency |

NetSuite uses shared-schema multi-tenancy with extensive tenant isolation enforced at the application layer (industry analysis; NetSuite does not publicly document internal schema topology). SAP S/4HANA Cloud Public Edition (multi-tenant cloud) uses isolated tenant cells per SAP's architectural descriptions. Workday uses shared multi-tenant with strict application-layer data partitioning.

**Data residency requirements** impact topology decisions:
- GDPR Articles 44–49 (Regulation EU 2016/679) [14]: restrict transfer of EU personal data to third countries without adequacy decision or appropriate safeguards
- Russia Federal Law No. 242-FZ (effective September 1, 2015): personal data of Russian citizens must be collected, stored, and processed using database infrastructure located within the Russian Federation [15]
- China Cybersecurity Law / Personal Information Protection Law (PIPL): data localization requirements for Chinese user data
- India Digital Personal Data Protection Act, 2023 (DPDP Act, Section 16): adopts a "negative list" approach — cross-border transfers are permitted by default unless the Central Government restricts specific countries by notification [16]

**Tenant onboarding** must support zero-downtime schema migrations. **Flyway** and **Liquibase** are the standard tools for version-controlled schema migration in multi-tenant ERP deployments. Migrations for shared-schema models must be backward compatible (additive columns, deprecate rather than drop).

---

## Concurrency, Locking & Idempotency

### Locking Strategies

**Optimistic locking**: each row carries a version counter or last-modified timestamp. On update, the application includes a `WHERE version = :expectedVersion` predicate. If another session modified the row first, zero rows are updated; the application detects the conflict and either retries or presents an error to the user. Preferred for high-concurrency, low-conflict workloads (e.g., editing master data records).

**Pessimistic locking** (`SELECT FOR UPDATE`): acquires an exclusive row lock immediately. Used for operations that cannot tolerate any concurrent modification: number range allocation, period open/close state transitions, inventory reservation against a specific lot. PostgreSQL `SELECT FOR UPDATE NOWAIT` or `SKIP LOCKED` prevents deadlocks in queue-processing scenarios.

**PostgreSQL advisory locks** and **Oracle DBMS_LOCK**: application-level coordination locks (integer key, not row-based) for cross-session coordination without locking a specific row. Useful for serializing a specific business process (e.g., "only one depreciation run per company code / period").

### Outbox Pattern for Exactly-Once Posting

```
[Application Service]
    │
    ├─ INSERT INTO business_documents (…)     ─┐
    └─ INSERT INTO outbox (id, payload, key)   ─┘  ← single DB transaction
                             │
                [Relay Process / Debezium CDC]
                             │
                [Apache Kafka / Azure Service Bus]
                             │
                [Downstream Consumer]
                     ├─ Check idempotency store for key
                     ├─ Process (if not seen)
                     └─ Store key in idempotency store  ← atomic
```

Debezium is an open-source CDC platform maintained under the Red Hat ecosystem [17]. It reads the database Write-Ahead Log (WAL in PostgreSQL, redo log in Oracle, binary log in MySQL) via Kafka Connect and publishes row-level change events without polling the table. This is a CDC (Change Data Capture) **infrastructure mechanism**, distinct from event sourcing (an **application design pattern**).

---

## Audit Immutability & Event Sourcing

### Core Principle

Financial records are immutable post-posting. No `UPDATE` or `DELETE` is permissible on a posted journal entry or fiscal document. This is both a legal requirement and an architectural guarantee.

**Change documents** capture field-level history for master data and documents: old value, new value, field name, changed-by user, changed-at timestamp. In SAP, change documents are generated automatically for objects marked with change document activation in the ABAP Dictionary.

### Event Sourcing

An event-sourced system stores state as an ordered, immutable sequence of domain events. Current state is derived by replaying the event stream. The natural properties are:
- Complete audit log is a first-class artifact, not an afterthought
- Point-in-time state reconstruction (what did this account balance look like at 14:32 on March 31?)
- Event replay enables rebuilding projections and read models without data loss

Event sourcing is an **application design pattern**; CDC is an **infrastructure mechanism** that taps an existing database's change stream. They can coexist: an event-sourced ERP domain emits domain events; CDC captures those from the database for integration with downstream systems.

### Regulatory Requirements for Audit Trails

| Regulation | Jurisdiction | Audit Trail Requirement |
|---|---|---|
| SOX Sections 302 & 404 (Sarbanes-Oxley Act of 2002) [18] | US public companies | Management and auditor attestation of internal controls over financial reporting; requires tamper-evident audit logs |
| GDPR Article 30 (EU 2016/679) [14] | EU / EEA | Records of processing activities; who accessed what personal data and when |
| 21 CFR Part 11 (US FDA) [19] | US pharmaceutical / life sciences | Audit trail for electronic records and electronic signatures; required for GMP-regulated ERP deployments |
| IAS 8 (IFRS Foundation) [20] | IFRS reporters | Restatement disclosure requirements when accounting policies change or errors are corrected |

See `core/security.md` for Segregation of Duties (SoD) controls and access audit architecture.

---

## Integration & Eventing Architecture

### API Layer

- **REST/JSON**: primary pattern for modern ERP integration; standard HTTP verbs; stateless; versioned via URL path (`/v2/`) or header
- **OData v4 (OASIS Standard)** [21]: SAP's primary API convention for S/4HANA and Fiori APIs; provides query language ($filter, $expand, $select), delta links for change detection, and a machine-readable metadata document
- **GraphQL**: used where consumers need flexible field selection to avoid over/under-fetching; less common in core ERP, more in BFF (Backend for Frontend) patterns
- **SOAP/XML**: legacy; still pervasive in EDI adapter landscapes and older SAP BAPI/RFC interfaces; not appropriate for new integrations

### EDI Standards

- **ANSI ASC X12** [22] (North America): X12 850 (Purchase Order), X12 810 (Invoice), X12 856 (Advance Ship Notice / ASN), X12 820 (Payment Order/Remittance Advice), X12 940 (Warehouse Shipping Order)
- **UN/EDIFACT** [23] (international): ORDERS (purchase order), INVOIC (invoice), DESADV (despatch advice); used in European and cross-border B2B
- Transport: AS2 (HTTPS-based, signed/encrypted, receipts via MDN) or SFTP; increasingly replaced by API-direct connections for new trading partners

### Message Brokers and Event Bus

- **Apache Kafka**: high-throughput, durable, log-structured; retains messages for configurable retention period; CDC-native via Debezium connectors; preferred for high-volume ERP event streaming
- **Azure Service Bus**: Microsoft-native; deep Dynamics 365 / Power Platform integration; AMQP-based; sessions for ordered processing
- **AWS SQS / SNS**: serverless, pay-per-use; used in AWS-hosted ERP satellite services
- **SAP Integration Suite** (formerly SAP Cloud Platform Integration / CPI): SAP's iPaaS; pre-built adapters for SAP-to-SAP and SAP-to-third-party; IDoc, BAPI, OData adapters included
- **MuleSoft Anypoint Platform**: vendor-neutral iPaaS; extensive ERP connector library; API gateway capabilities
- **Dell Boomi**: similar iPaaS; strong in SMB/mid-market ERP integration

### Event-Driven Choreography vs Orchestration

**Choreography**: each service reacts to domain events published by other services with no central coordinator. When an invoice is posted, the AR service publishes `InvoicePosted`; the credit management service, the dunning service, and the revenue recognition service each subscribe and react independently. Looser coupling; harder to trace end-to-end flow.

**Orchestration (Saga pattern)**: a central coordinator (saga orchestrator or process manager) explicitly instructs each step and handles compensation (rollback) on failure. Used for long-running, multi-step business processes (e.g., procure-to-pay spanning 6 systems) where partial failure compensation is complex and must be explicit.

---

## Extensibility Model

### Configuration vs Customization

**Configuration** (upgrade-safe): activating or deactivating delivered functionality through settings tables, workflow rules, field mapping configurations, output condition records. Zero code written; changes survive upgrades.

**Customization** (upgrade-risk): writing or modifying code in the ERP's application layer. Must be regression-tested on every release. Legacy approach (SAP ECC modifications, Oracle E-Business Suite personalizations) created enormous upgrade debt.

**Low-code / metadata-driven extensibility**: user-defined fields (UDFs), custom objects, workflow rules, validation formulas, and calculated fields — managed through configuration UI with no deployment required.

### Vendor Extensibility Platforms

**SAP S/4HANA / SAP BTP**:
- *In-app (Key User tools)*: Custom Fields and Logic app (adds fields, BAdI implementations), Custom CDS Views for reporting extension — no transport required; upgrade-safe
- *Side-by-side (SAP BTP)*: ABAP Cloud on BTP (clean core, only released APIs); CAP (Cloud Application Programming model) for Node.js/Java microservices; BTP Integration Suite for process integration; extensions run in separate runtime and call S/4HANA via stable released OData/REST APIs
- *Clean Core policy*: SAP S/4HANA Cloud enforces the clean core principle — modifications to SAP's delivered objects are blocked; all extensions must use released API surfaces

**Oracle Fusion Cloud ERP**:
- Oracle APEX: low-code web application builder integrated with Fusion; extends UI without full-stack development
- Visual Builder Cloud Service (VBCS): declarative web/mobile UI builder for Fusion extension pages
- Extensible Flexfields: Descriptive Flexfields (DFF) for free-form additional fields; Key Flexfields (KFF) for structured business identifier segments (chart of accounts, asset category)
- Oracle Integration Cloud (OIC): process integration and API management

**Microsoft Dynamics 365 Finance & SCM**:
- **X++**: proprietary object-oriented language compiled to .NET CLR; the core language for Dynamics 365 Finance customization
- **Chain-of-Command (CoC)**: the current standard extension pattern — wraps delivered methods without overlaying source code; `next.method()` call invokes the standard behavior; overlayering (modifying delivered source) is officially deprecated for cloud deployments
- Power Platform: Power Apps (canvas/model-driven apps), Power Automate (workflow), Dataverse (data layer) for low-code extensions and citizen developer scenarios
- AppSource ISV ecosystem

**NetSuite SuiteCloud**:
- SuiteScript 2.x: JavaScript-based scripting API; module pattern; runs server-side and client-side; event-driven (user events, scheduled scripts, RESTlets, portlets)
- SuiteFlow: workflow automation for business process rules; no-code/low-code
- SuiteTalk: SOAP web services and REST Record API for external integration
- SuiteBuilder: point-and-click record and field configuration

**Workday**:
- Workday Studio: Java-based integration development environment for complex integration scenarios
- Workday Extend: low-code/no-code app builder for custom business applications on the Workday platform (verify current product naming in Workday documentation — branding evolves)
- Calculated Fields and Condition Rules: formula-based logic embedded in reports and business processes

**Odoo / ERPNext**:
- Full open-source access; Python (Odoo), Python/Frappe framework (ERPNext)
- Extensions via modules/addons; standard ORM hooks; no vendor API restrictions
- Upgrade migration scripts required per major version; no managed upgrade path

### Upgrade Safety

| Extension model | Upgrade safety | Mechanism |
|---|---|---|
| Side-by-side (SAP BTP, Oracle OIC) | High: extension runs in separate runtime | Stable released API contracts; ERP core upgrades independently |
| In-app configuration (UDF, workflow) | High: vendor owns migration | No compiled artifacts; config data migrated by upgrade |
| In-app code (SAP BAdI, Oracle SOAP customization) | Medium: must be recompiled/retested | Vendor releases compatibility notes per upgrade |
| Overlaying (deprecated for cloud) | Low: source conflict on upgrade | SAP has removed this option in S/4HANA Cloud |

---

## Performance & Scale

### SAP HANA Dual Store Architecture

SAP HANA uses two physical storage engines in the same database instance:
- **Row store**: organizes data as rows; optimal for single-record insert/update/delete operations (OLTP); used for tables with high write frequency and single-row access patterns
- **Column store with delta store**: organizes data in compressed columnar format; optimal for aggregate analytical queries (OLAP); a **delta store** (row-structured buffer) absorbs writes and is periodically merged into the column store, making columnar storage write-efficient

This dual store eliminates the traditional ETL batch pipeline from OLTP to a separate data warehouse for operational reporting — queries that previously required a nightly batch load to a warehouse can run directly on transactional data. The Universal Journal (ACDOCA) table uses column store; header tables and lock objects use row store.

### OLTP vs OLAP Separation

Traditional ERP architecture separated OLTP (ERP database) and OLAP (data warehouse) with nightly ETL batch pipelines. The latency (typically T+1 day) was acceptable for scheduled financial reports but inadequate for operational decision-making. Modern approaches:

- **SAP BW/4HANA**: SAP's data warehouse on HANA; real-time delta loads from S/4HANA via Operational Data Provisioning (ODP)
- **Snowflake / Databricks**: cloud data warehouse / lakehouse targets for ERP data via ELT pipelines
- **Microsoft Fabric / Azure Synapse Analytics**: Microsoft's integrated analytics platform for Dynamics 365 data

### Batch vs Real-Time

Many ERP processes are structurally batch because they require complete period data before they can run (depreciation needs all asset movements for the month; material requirements planning needs all demand signals for the horizon). S/4HANA moves several of these toward real-time computation using in-memory speed: Business Partner credit exposure is checked in real-time using HANA's in-memory aggregate; MRP Live computes material requirements online rather than in a scheduled batch run.

### Archiving / Information Lifecycle Management (ILM)

Legal data retention periods (e.g., 7–10 years for financial records in most jurisdictions; 30 years for certain contract and environmental records) combined with data volume growth require active **archiving**. SAP ILM (Information Lifecycle Management) moves archived data to cold storage (SAP ILM Store, NFS, or cloud object storage) while maintaining read access via Archive Information System (AS). Oracle ILM provides tiered storage policies at the table partition level. Archived data must remain queryable for audit and tax authority requests.

### Database-Level Scale Techniques

- **Partitioning**: PostgreSQL declarative table partitioning (by posting date or tenant_id); Oracle Partitioning (range, list, hash); enables partition pruning on analytical queries and efficient archiving of old partitions
- **Index strategy**: composite indexes matching common query patterns — e.g., `(tenant_id, company_code, fiscal_year, posting_period, gl_account)` for trial balance queries; covering indexes for reporting queries that project specific columns
- **Connection pooling**: **PgBouncer** (transaction-mode pooling for PostgreSQL); Oracle Universal Connection Pool (UCP); critical at ERP scale where hundreds of concurrent user sessions would exhaust DB connection limits without pooling

---

## Reporting Architecture

### Embedded Analytics (Operational Reporting)

Operational reports run directly on transactional data with minimal latency using semantic layers that hide physical table complexity:

- **SAP ABAP CDS (Core Data Services) views**: SQL-based analytical models with annotations for measures, dimensions, hierarchies, and aggregations; consumed by SAP Fiori analytical apps and SAP Analytics Cloud
- **Oracle Fusion OTBI (Oracle Transactional Business Intelligence)**: subject areas built on Fusion schema; end-user ad hoc reporting via Oracle Business Intelligence Publisher (BIP) and OTBI Answers
- **Dynamics 365 + Power BI Embedded**: native Power BI reports embedded directly in Dynamics 365 Finance workspaces; financial period close workspace provides KPI tiles

### Data Warehouse / Lakehouse for Historical and Complex Analytics

For complex cross-domain analytics, multi-year trend analysis, and ML/AI use cases, ERP data is extracted to a dedicated analytical store:

- **SAP BW/4HANA**: SAP's managed data warehouse; semantic layer via InfoObjects, CompositeProviders, Queries; real-time data via ODP connectors
- **Oracle Autonomous Data Warehouse (ADW)**: Oracle-managed cloud DW; native connectivity to Oracle Fusion via the Fusion Analytics Warehouse (FAW) product
- **Microsoft Fabric / Azure Synapse**: Microsoft's analytics platform; Dynamics 365 Finance exports to Dataverse/Synapse link for analytics
- **Snowflake**: vendor-neutral cloud DW; used as ERP analytics target via ELT tools (Fivetran, dbt)
- **Databricks**: data lakehouse platform combining data engineering (Delta Lake) with ML/AI; used for advanced analytics on ERP data

### Financial Close Reporting

- **SAP Group Reporting** (embedded in S/4HANA): consolidation, intercompany elimination, currency translation, and financial close reporting in a single system using ACDOCA as source; reporting currency balances stored in ACDOCA enable instant consolidated trial balance without re-translation batch
- **Oracle Financial Consolidation & Close Cloud (FCCS)**: cloud-based consolidation; intercompany matching, eliminations, currency translation, financial close workflow
- **Workday Adaptive Planning**: financial planning, consolidation, and reporting integrated with Workday Financial Management
- **OneStream**: widely deployed standalone financial close and consolidation platform used alongside ERP systems from multiple vendors

---

## Real-World Implementation Failure Reference

The **Hershey Foods 1999** case remains the canonical ERP big-bang failure. Hershey went live with SAP R/3 (FI, SD, MM), Siebel CRM, and Manugistics SCM simultaneously in July 1999 — in the ramp-up to the Halloween and Christmas candy selling seasons. The compressed 30-month timeline precluded adequate testing; the system failed to process order fulfillment correctly, resulting in approximately $100 million in unfilled orders and a reported $112 million ERP project cost [24]. The primary lesson: never schedule a big-bang go-live during peak operational periods, and never compress testing cycles to meet arbitrary launch dates. See `core/implementation.md` for full methodology discussion.

---

## See also

- `core/features-core.md` — functional feature catalog covering all major ERP module capabilities
- `core/security.md` — segregation of duties, access control architecture, audit trail controls, SoD conflict matrices
- `core/localization-tax.md` — country-specific tax engines, e-invoicing mandates, statutory reporting, localization architecture
- `core/implementation.md` — project delivery methodology, data migration, cutover planning, ERP failure case studies
- `glossary.md` — definitions for all abbreviations and ERP-specific terminology used across the library

---

## Citations & Sources

**SAP Maintenance & Architecture**
1. SAP Community — "Maintenance Timelines for SAP ERP 6.0": EHP 6–8 mainstream maintenance ends December 31, 2027; extended maintenance available through December 31, 2030. https://community.sap.com/t5/enterprise-resource-planning-blog-posts-by-sap/maintenance-timelines-for-sap-erp-6-0/ba-p/13524564
2. Oracle Fusion Cloud Financials — Subledger Journal Entry Rule Set documentation. https://docs.oracle.com/en/cloud/saas/financials/25d/faisl/subledger-journal-entry-rule-set.html
3. SAP Help Portal — ACDOCA (Universal Journal Entry Line Items), introduced with SAP S/4HANA Finance 1503 (March 2015); 500+ fields in current releases. https://help.sap.com/docs/SAP_S4HANA_ON-PREMISE
4. IFRS Foundation — IAS 21 *The Effects of Changes in Foreign Exchange Rates*. https://www.ifrs.org/issued-standards/list-of-standards/ias-21/
5. FASB — ASC 830 *Foreign Currency Matters* (codifies SFAS 52). https://asc.fasb.org/830
6. IFRS Foundation — IAS 2 *Inventories*. https://www.ifrs.org/issued-standards/list-of-standards/ias-2/
7. FASB — ASC 330 *Inventory*. https://asc.fasb.org/330
8. European Commission — Council Directive 2006/112/EC, Article 226 (VAT invoice sequential numbering requirement). https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32006L0112
9. SAP Help Portal — Parallel Currencies in General Ledger Accounting; maximum 10 currency types per ledger in ACDOCA. https://help.sap.com/docs/SAP_S4HANA_ON-PREMISE/67e323b7117e4c91869c258933f47182/4d624952d81ac871e10000000a44176d.html
10. FASB — ASC 810 *Consolidation*. https://asc.fasb.org/810
11. IFRS Foundation — IFRS 10 *Consolidated Financial Statements*. https://www.ifrs.org/issued-standards/list-of-standards/ifrs-10/
12. OECD — *Transfer Pricing Guidelines for Multinational Enterprises and Tax Administrations* (2022 edition). https://www.oecd.org/tax/transfer-pricing/oecd-transfer-pricing-guidelines-for-multinational-enterprises-and-tax-administrations-20769717.htm
13. OECD — *Minimum Tax Implementation Handbook (Pillar Two)*; GloBE Income Inclusion Rule effective January 1, 2024 in EU, UK, Japan, South Korea, and others. https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/global-minimum-tax/minimum-tax-implementation-handbook-pillar-two.pdf
14. European Parliament and Council — Regulation (EU) 2016/679 (GDPR), Articles 30 and 44–49. https://eur-lex.europa.eu/eli/reg/2016/679
15. Russian Federation — Federal Law No. 242-FZ "On Amendments to Certain Legislative Acts of the Russian Federation for Clarification of the Procedure of Personal Data Processing in Information and Telecommunication Networks" (signed July 21, 2014; effective September 1, 2015).
16. India — Digital Personal Data Protection Act, 2023, Section 16 (cross-border data transfers; negative-list approach). https://www.meity.gov.in/
17. Debezium — Open-source CDC platform documentation. https://debezium.io/documentation/
18. US Congress — Sarbanes-Oxley Act of 2002, Sections 302 and 404. https://pcaobus.org/
19. US FDA — 21 CFR Part 11 *Electronic Records; Electronic Signatures*. https://www.ecfr.gov/current/title-21/chapter-I/subchapter-A/part-11
20. IFRS Foundation — IAS 8 *Accounting Policies, Changes in Accounting Estimates and Errors*. https://www.ifrs.org/issued-standards/list-of-standards/ias-8/
21. OASIS — OData Version 4.0 Standard. https://docs.oasis-open.org/odata/odata/v4.0/
22. ASC X12 — ANSI EDI standards (850, 810, 856, 820, 940). https://www.x12.org/
23. UN/CEFACT — UN/EDIFACT standard messages. https://unece.org/trade/uncefact/introducing-unedifact
24. Hershey Foods Corporation — Q3 1999 10-Q filing (primary source for financial impact); secondary analysis: Panorama Consulting, "Hershey's SAP ERP System Implementation Failure Case Study". https://www.panorama-consulting.com/hersheys-erp-failure/

**Additional Standards Referenced**
- FASB — ASC 842 *Leases*. https://asc.fasb.org/842
- IFRS Foundation — IFRS 16 *Leases*. https://www.ifrs.org/issued-standards/list-of-standards/ifrs-16/
- Apache Kafka documentation. https://kafka.apache.org/documentation/
- Flyway database migration tool. https://flywaydb.org/documentation/
- Liquibase schema migration. https://docs.liquibase.com/
- PgBouncer connection pooler. https://www.pgbouncer.org/
- Gartner — *Magic Quadrant for Cloud ERP for Product-Centric Enterprises* (published periodically; successor to the former single ERP Magic Quadrant)
- Gartner — *Magic Quadrant for Cloud ERP for Service-Centric Enterprises*
- Microsoft Dynamics 365 Finance documentation. https://learn.microsoft.com/en-us/dynamics365/finance/
- Dynamics 365 Chain-of-Command extensibility. https://learn.microsoft.com/en-us/dynamics365/fin-ops-core/dev-itpro/extensibility/
- NetSuite SuiteCloud Developer Documentation. https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/
- Oracle Fusion Cloud ERP documentation (Financials, Subledger Accounting, OTBI). https://docs.oracle.com/en/cloud/saas/financials/
- SAP Help Portal — SAP BTP (Business Technology Platform). https://help.sap.com/docs/btp
